"""Direct truth table, streaming classifiers, and explicit lower-bound splices."""
from itertools import combinations, product
from collections import Counter
from random import Random

rng = Random(20261122)
counts = Counter()


def bits(value, width):
    return tuple((value >> i) & 1 for i in reversed(range(width)))


def value(word):
    v = 0
    for b in word:
        v = 2 * v + b
    return v


def query(x, y, w):
    n = len(x)
    m = n.bit_length() - 1
    s = value(x[(y + j) % n] for j in range(m))
    return tuple(x[(s + j) % n] for j in range(w))


def stream(x, y, target, H, D, period=None):
    """Reads bits once. Only the testing harness binds x in memory."""
    n, w = len(x), len(target)
    m, a = n.bit_length() - 1, (n // D).bit_length() - 1
    pages = n // D
    assert H <= a and n % D == 0 and D % H == 0 and w < 2 * D
    assert period is None or (D <= w and all(
        v == period[j % len(period)] for j, v in enumerate(target)))
    high_mask = high_value = address = 0
    live = set(range(pages))
    stored = {}
    for r in range(H):
        for i in range(r, n, H):
            b = x[i]
            j = (i-y) % n
            if j < m:
                if b:
                    address |= 1 << (m - 1 - j)
                if j < a:
                    bit = 1 << (a-1-j)
                    high_mask |= bit
                    if b:
                        high_value |= bit
                    starts = [u for u in range(pages) if u & high_mask == high_value]
                    new = {(u + k) % pages for u in starts for k in range(3)}
                    assert new <= live
                    for u in live - new:
                        stored.pop(u, None)
                    live = new
            u = i // D
            if u in live:
                rec = stored.setdefault(u, {})
                if period is None:
                    rec[i] = b
                else:
                    for e in range(len(period)):
                        if b != period[(i-e) % len(period)]:
                            lo, hi = rec.get(e, (i, i))
                            rec[e] = (min(i, lo), max(i, hi))
            assert high_mask.bit_count() >= r
            assert len(live)*(r+1)*(D//H) <= 3*n//H
    if period is None:
        return all(stored[(v % n)//D][v % n] == target[j]
                   for j, v in enumerate(range(address, address+w)))
    for k in range(address//D, (address+w-1)//D + 1):
        lo, hi = max(k*D, address), min((k+1)*D, address+w)-1
        phase = (address - (lo//n)*n) % len(period)
        lo, hi = lo % n, hi % n
        u = k % pages
        extremes = stored.get(u, {}).get(phase)
        assert lo == u*D or hi == (u+1)*D-1
        if extremes is not None and any(lo <= v <= hi for v in extremes):
            return False
    return True


def test_stream():
    # Small n exhaustive over data, outer address, and all words for widths 1..3.
    n, H = 8, 1
    for xx in product(range(2), repeat=n):
        for y in range(n):
            for w in range(1, 4):
                D = 1 << (w.bit_length()-1)
                expected = query(xx, y, w)
                for word in product(range(2), repeat=w):
                    ok = word == expected
                    assert stream(xx, y, word, H, D) == ok
                    counts['exhaustive raw inputs'] += 1
                    # A full length period exercises the same code for arbitrary words.
                    assert stream(xx, y, word, H, D, word) == ok
                    counts['exhaustive phase inputs'] += 1
    # Stress nontrivial residue schedules, joint pointer/window overlap and ring seams.
    for _ in range(600):
        m = rng.randrange(4, 9)
        n = 1 << m
        H = rng.choice([1, 2, 4])
        options = [1 << k for k in range(m-H+1) if (1 << k) >= H]
        if not options:
            continue
        D = rng.choice(options)
        w = rng.randrange(D, min(n, 2*D-1)+1)
        y = rng.randrange(n)
        x = list(bits(rng.getrandbits(n), n))
        actual = query(x, y, w)
        bad = list(actual)
        bad[rng.randrange(w)] ^= 1
        for W, expected in [(actual, True), (bad, False)]:
            assert stream(x, y, W, H, D) == expected
            counts['random raw checks'] += 1
        p = rng.randrange(1, min(w, 7)+1)
        U = bits(rng.getrandbits(p), p)
        W = tuple(U[i%p] for i in range(w))
        # Construct an accepting instance for this word, even when the read overlaps the pointer.
        base = list(W) + list(bits(rng.getrandbits(n-w), n-w))
        s = value(base[:m])
        rotated = base[-s:] + base[:-s] if s else base.copy()
        assert query(rotated, s, w) == W
        for data, outer in [(x, y), (rotated, s)]:
            assert stream(data, outer, W, H, D, U) == (query(data, outer, w) == W)
            counts['random phase checks'] += 1


def test_word():
    # All triples of the 128 core sites, all 8 assignments, with one fixed literal.
    w = 256
    T = w//2
    W = bits(Random(19).getrandbits(w), w)
    full = (1 << T)-1
    masks = [sum(W[c-j] << j for j in range(T)) for c in range(T,w)]
    for cols in combinations(range(T), 3):
        groups = [full]
        for i in cols:
            v = masks[i]
            groups = [match for g in groups for match in (g & v, g & (full ^ v))]
        assert all(groups), cols
        counts['three-column masks'] += 1
    print('Certified word (MSB first, w=256, strength=3):', hex(value(W)))
    return W


def test_splices(W, universal):
    m, w = 12, len(W)
    n = 1 << m
    for _ in range(20):
        order = list(range(n))
        rng.shuffle(order)
        rank = {v: r for r, v in enumerate(order)}
        first = [min(rank[v] for v in range(b,b+m)) for b in range(0,n-m+1,m)]
        late_index = max(range(len(first)), key=first.__getitem__)
        ptr, cut = late_index*m, first[late_index]
        early = {i for i in range(n) if rank[i] < cut}
        packet_len = (2*((w+m-1)//m)+1)*m
        packets = [b for b in range(0,n-packet_len+1,packet_len)
                   if not b <= ptr < b+packet_len]
        assert len(packets) >= 2
        def build(b):
            if universal:
                T = w//2
                aligned = range(b+((T+m-1)//m)*m, b+w-m+1, m)
                marks = [next(i for i in range(v,v+m) if i in early)
                         for v in list(aligned)[:3]]
                assert len(marks) == 3
                options = {}
                for t in range(T):
                    options[tuple(W[v-b-t] for v in marks)] = b+t
                assert len(options) == 8
            else:
                start = b + ((w+m-1)//m)*m
                q = max(1,w//m)
                marks = [next(i for i in range(v,v+m) if i in early)
                         for v in range(start,start+q*m,m)]
                options = {j+1:v+1-w for j,v in enumerate(marks)}
                options[0] = None
            pre = {}
            for key, s in options.items():
                digits = {v:W[v-s] for v in range(s, s+w) if v in early} if s is not None else {}
                if not universal:
                    digits.update({v:1-W[-1] for v in marks[key:]})
                pre[key] = digits
            return pre, options
        banks = [build(b) for b in packets]
        for _ in range(24):
            left, right = [], []
            for pre, starts in banks:
                choices = list(pre)
                left.append(rng.choice(choices))
                right.append(rng.choice(choices))
            if left == right:
                continue
            d = next(i for i in range(len(left)) if left[i] != right[i])
            if not universal and left[d] < right[d]:
                left, right = right, left
            start = banks[d][1][left[d]]
            tail = {i:b for i,b in zip(range(ptr,ptr+m),bits(start,m))}
            assert not early.intersection(tail)
            tail.update({i:W[i-start] for i in range(start,start+w) if i not in early})
            for msg, want in [(left, True), (right, False)]:
                data = [0]*n
                for (pre, _), key in zip(banks,msg):
                    for i,b in pre[key].items():
                        data[i] = b
                for i,b in tail.items():
                    data[i] = b
                assert (query(data, ptr, w) == W) == want
            counts['hard cross-splices' if universal else 'arbitrary-word cross-splices'] += 1


if __name__ == '__main__':
    test_stream()
    hard = test_word()
    test_splices(hard, True)
    for word in [hard[:42], (0,1)*26, (1,), (0,0,1)*5]:
        test_splices(word, False)
    for name, number in counts.items():
        print(f'{name}: {number:,}')
