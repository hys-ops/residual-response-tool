import PageCapacity

namespace SISA.Pages

private theorem residue_witness {n H r a y j : Nat}
    (div:H ∣ n) (hp:0<H) (inside:H≤a) (rr:r≤H) (jj:j<r) :
    ∃ i, i<a ∧ (y+i)%n%H=j :=by
  have yh:=Nat.mod_lt y hp
  have jh : j<H :=by omega
  by_cases b:y%H≤j
  · refine ⟨j-y%H,by omega,?_⟩
    rw [Nat.mod_mod_of_dvd _ div,←Nat.mod_add_mod y H]
    have e:y%H+(j-y%H)=j:=by omega
    simp [e,Nat.mod_eq_of_lt jh]
  · refine ⟨H+j-y%H,by omega,?_⟩
    rw [Nat.mod_mod_of_dvd _ div,←Nat.mod_add_mod y H]
    have e:y%H+(H+j-y%H)=H+j:=by omega
    simp [e,Nat.mod_eq_of_lt jh]

def physicalPattern (n a y : Nat) (seen : Nat → Bool) (x : Nat → Bool) :=
  (List.range a).map (fun i=>if seen ((y+i)%n) then some (x ((y+i)%n)) else none)

private theorem complement {α : Type} (l : List α) (test:α→Bool) (x:α→Bool) :
    (l.filter test).length + holes (l.map (fun i => if test i then some (x i) else none)) = l.length :=by
  induction l with
  | nil=>rfl
  | cons i tail ih=>cases h:test i <;> simp [h,holes] at * <;> omega

/-- A cut may have advanced arbitrarily within the current residue. Completed
    residues alone already determine enough physical high bits for the bound. -/
theorem high_bits_known {n H r a y : Nat} (div:H ∣ n) (hp:0<H)
    (inside:H≤a) (rr:r≤H) (seen x:Nat→Bool)
    (done:∀ v:Nat,v%H<r → seen v=true) :
    r+holes (physicalPattern n a y seen x)≤a :=by
  let test := fun i:Nat => seen ((y+i)%n)
  let l := (List.range a).filter test
  have subs : List.range r ⊆ l.map (fun i=>(y+i)%n%H) :=by
    intro j hj
    have jj:=List.mem_range.mp hj
    obtain ⟨i,le,eq⟩:=residue_witness (y:=y) div hp inside rr jj
    refine List.mem_map.mpr ⟨i,List.mem_filter.mpr ⟨List.mem_range.mpr le,?_⟩,eq⟩
    exact done _ (eq ▸ jj)
  have count := (List.nodup_range (n:=r)).length_le_of_subset subs
  have comp := complement (List.range a) test (fun i=>x ((y+i)%n))
  simp only [List.length_map,List.length_range] at count comp
  change r + holes ((List.range a).map _) ≤ a
  change r ≤ ((List.range a).filter test).length at count
  unfold test at count comp
  omega

#print axioms high_bits_known
end SISA.Pages

namespace SISA.Pages

theorem physical_capacity {n H J r a y : Nat} (div:H ∣ n) (hp:0<H)
    (inside:H≤a) (rr:r≤H) (seen x:Nat→Bool)
    (done:∀ v:Nat,v%H<r → seen v=true) :
    (retained (2^a) (H*J) H J r (physicalPattern n a y seen x)).length ≤ 3*2^a*J :=
  retained_length_le _ (high_bits_known div hp inside rr seen x done)

private theorem matches_mask {α:Type} (l:List α) (seen x:α→Bool) :
    fits (l.map (fun i=>if seen i then some (x i) else none)) (l.map x) :=by
  induction l with
  | nil=>trivial
  | cons i tail ih=>cases h:seen i <;> simp [h,fits,ih]

def physicalBits (n a y:Nat) (x:Nat→Bool) :=
  (List.range a).map (fun i=>x ((y+i)%n))

theorem physical_fit (n a y:Nat) (seen x:Nat→Bool) :
    fits (physicalPattern n a y seen x) (physicalBits n a y x) :=
  matches_mask (List.range a) (fun i=>seen ((y+i)%n)) (fun i=>x ((y+i)%n))

/-- Read sites queried from this high part and any legal low part lie in the bank. -/
theorem physical_sound {H J r a y low j:Nat} (hp:0<H) (jp:0<J)
    (ls:low<H*J) (oj:j<2*(H*J)) (seen x:Nat→Bool) :
    let D:=H*J
    let n:=2^a*D
    let high:=physicalBits n a y x
    let v:=(SISA.beValue high*D+low+j)%n
    seen v=true → (∀ i:Nat,seen i=true → i%H≤r) →
    v ∈ retained (2^a) D H J r (physicalPattern n a y seen x) :=by
  dsimp only
  intro hv frontier
  exact retained_sound hp jp _ _ (physical_fit _ _ _ _ _) ls oj _ rfl (frontier _ hv)

#print axioms physical_capacity
#print axioms physical_sound
end SISA.Pages
