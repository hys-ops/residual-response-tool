import ResidueDAG

namespace SISA.Pages
open HWB.Circuit HWB.ResidualCompiler

private theorem rank_small {H K i:Nat} (hp:0<H) (kp:0<K) :
    rank H K i<H*K :=by
  have le:=Nat.mul_le_mul_right K (Nat.mod_lt i hp)
  rw [Nat.succ_mul] at le
  have rem:=Nat.mod_lt (i/H) kp
  unfold rank;omega

private theorem unrank_rank {H K i:Nat} (hp:0<H) (kp:0<K) (il:i<H*K) :
    rank H K i%K*H+rank H K i/K=i :=by
  have q:i/H<K:=(Nat.div_lt_iff_lt_mul hp).mpr (by simpa [Nat.mul_comm] using il)
  simp only [rank,Nat.mod_eq_of_lt q,Nat.mul_add_mod_self_right]
  rw [Nat.add_comm (i%H*K),Nat.add_mul_div_right _ _ kp,Nat.div_eq_of_lt q,Nat.zero_add]
  exact Nat.div_add_mod' i H

private theorem rank_unrank {H K i:Nat} (hp:0<H) (kp:0<K) (il:i<H*K) :
    rank H K (i%K*H+i/K)=i :=by
  have q:i/K<H:=(Nat.div_lt_iff_lt_mul kp).mpr il
  simp only [rank,Nat.mul_add_mod_self_right,Nat.mod_eq_of_lt q]
  rw [Nat.add_comm (i%K*H),Nat.add_mul_div_right _ _ hp,Nat.div_eq_of_lt q,Nat.zero_add]
  simp [Nat.div_add_mod']

private def chunk (v:Input) (start len:Nat) := List.ofFn (fun i:Fin len=>v (start+i.val))

private theorem pieces (v:Input) (a b c:Nat) :
    (chunk v 0 a++chunk v a b)++chunk v (a+b) c = chunk v 0 (a+b+c) :=by
  apply List.ext_getElem (by simp [chunk,Nat.add_assoc])
  intro i _ _
  by_cases first:i<a
  · simp [chunk,first]
  · by_cases second:i<a+b
    · simp [chunk,List.getElem_append,first,show i-a<b by omega,Nat.add_sub_of_le (show a≤i by omega)]
    · simp [chunk,List.getElem_append,first,show ¬i-a<b by omega,show a+b+(i-a-b)=i by omega]

/-- The sharper resident-page construction witnesses the very same legal
    size predicate used by SISA.minimum_bounds, in a permutation of the
    original physically named input variables. -/
theorem residue_legal {a b w H J:Nat} (hp:0<H) (jp:0<J) (page:2^b=H*J)
    (upto:H≤a) (width:w≤2*(H*J)) :
    let m:=a+b
    let n:=2^m
    legal m w ((m+w+n)*((2^(3*2^a*J)*2^m)*2^(m+w))) :=by
  let m:=a+b
  let n:=2^m
  let K:=2^a*J
  have kp:0<K:=Nat.mul_pos (Nat.two_pow_pos _) jp
  have size:n=2^a*(H*J):=by simp [n,m,Nat.pow_add,page]
  have layout:n=H*K:=by rw [size];dsimp [K];ac_rfl
  let ord:=fun i=>if i<n then m+w+rank H K i else i-n
  let name:=fun p=>if p<m+w then n+p else (p-(m+w))%K*H+(p-(m+w))/K
  let mask:Mask:=fun p=>if p<m+w+n then none else some false
  have dg:=actual_residue_DAG (w:=w) hp jp page upto width
  dsimp only at dg
  change ∃ g:DAG ((m+w+2^a*(H*J))*((2^(3*2^a*J)*2^m)*2^(m+w))), ∃ root,
    ∀ outer W x:List Bool,outer.length=m → W.length=w → x.length=2^a*(H*J) →
    (g.eval (wordInput ((outer++W)++serialize H K x)) root=true ↔ graph (2^a*(H*J)) outer W x) at dg
  rw [←size] at dg
  obtain ⟨D,root,run⟩:=dg
  refine ⟨ord,name,?_,D.restrict mask,D.bypass mask root,?_,?_,?_⟩
  · intro i bound
    change ord i<n+m+w ∧ name (ord i)=i
    by_cases d:i<n
    · have sm:rank H K i<n:=layout ▸ rank_small hp kp
      have iv:=unrank_rank hp kp (layout ▸ d)
      simp [ord,name,d,iv];omega
    · change i<n+m+w at bound
      have dif:i-n<m+w:=by omega
      simp [ord,name,d,dif];omega
  · intro i hi
    have f:=D.bypass_free mask root i hi
    change D.level i<n+m+w
    apply Classical.byContradiction;intro rev
    simp [mask,show ¬D.level i<m+w+n by omega] at f
  · intro i bit j hi
    have f:=D.restricted_edge_free mask i bit j hi
    change D.level j<n+m+w
    apply Classical.byContradiction;intro rev
    simp [mask,show ¬D.level j<m+w+n by omega] at f
  · intro v
    let o:=chunk v 0 m
    let z:=chunk v m w
    let x:=List.ofFn (fun i:Fin n=>v (m+w+rank H K i.val))
    have ser:serialize H K x=chunk v (m+w) n:=by
      apply List.ext_getElem (by simp [serialize,chunk,layout])
      intro i _ hi
      have il:i<H*K:=by simpa [chunk,layout] using hi
      have d:i/K<H:=(Nat.div_lt_iff_lt_mul kp).mpr il
      have le:=Nat.mul_le_mul_right H (Nat.mod_lt i kp)
      rw [Nat.succ_mul] at le
      have sm:i%K*H+i/K<n:=by rw [layout,Nat.mul_comm H K];omega
      simp [serialize,x,get,sm,rank_unrank hp kp il,chunk]
    have arr : overrideInput mask v = wordInput ((o++z)++serialize H K x) :=by
      rw [ser]
      change _=wordInput ((chunk v 0 m++chunk v m w)++chunk v (m+w) n)
      rw [pieces]
      funext i
      by_cases il:i<m+w+n <;> simp [overrideInput,mask,wordInput,chunk,il]
    change (D.restrict mask).eval v (D.bypass mask root)=true ↔ graphAt m w ord v
    rw [D.eval_restrict mask v root,arr,run _ _ _ (by simp [o,chunk]) (by simp [z,chunk]) (by simp [x])]
    unfold graphAt
    have oy (i:Fin m):ord (n+i.val)=i.val:=by simp [ord,show ¬n+i.val<n by omega]
    have rz (i:Fin w):ord (n+m+i.val)=m+i.val:=by simp [ord,show ¬n+m+i.val<n by omega];omega
    have dx (i:Fin n):ord i=m+w+rank H K i:=by simp [ord,i.isLt]
    change graph n o z x ↔ graph n (List.ofFn (fun i:Fin m=>v (ord (n+i.val))))
      (List.ofFn (fun i:Fin w=>v (ord (n+m+i.val)))) (List.ofFn (fun i:Fin n=>v (ord i.val)))
    simp [o,z,x,chunk,oy,rz,dx]

#print axioms residue_legal
end SISA.Pages

namespace SISA.Pages
private theorem double_le_pow {b:Nat} (h:1≤b) : 2*b≤2^b :=by
  induction b with
  | zero=>omega
  | succ t ih=>
    by_cases z:t=0
    · subst t;decide
    · have it:=ih (by omega)
      rw [Nat.pow_succ];omega

/-- Matching finite upper and lower for the formerly unresolved w=m, at
    the actual minimum over physical orders. No asymptotic assumptions. -/
theorem diagonal_minimum (m:Nat) (hm:4≤m) :
    let n:=2^m
    ∃ B, legal m m B ∧ (∀ s,legal m m s → B≤s) ∧
      2^(n/(4*m))≤B+2 ∧
      B≤(m+m+n)*2^(6*2^(m-m.log2)+3*m) :=by
  let n:=2^m
  let b:=m.log2
  have bl:1≤b:=(Nat.le_log2 (by omega)).mpr (by simp;omega)
  have dm:2^b≤m:=Nat.log2_self_le (by omega)
  have wl:m<2^b*2:=by simpa [b,Nat.pow_succ] using Nat.lt_log2_self (n:=m)
  let H:=2^(b-1)
  have hp:0<H:=Nat.two_pow_pos _
  have page:2^b=H*2:=by
    have e:b=b-1+1:=by omega
    conv => lhs;rw [e,Nat.pow_succ]
  have db:=double_le_pow bl
  let a:=m-b
  have ab:a+b=m:=by dsimp [a];omega
  have hh:H≤a:=by dsimp [a];omega
  have up:=residue_legal (a:=a) (b:=b) (H:=H) (J:=2) (w:=m)
    hp (by decide) page hh (by omega)
  dsimp only at up
  rw [ab] at up
  have room:=double_le_pow (b:=m) (by omega)
  obtain ⟨B,leg,mini,_,_,pack⟩:=minimum_bounds (m:=m) (w:=m) (by omega) (by omega) (by omega) room
  refine ⟨B,leg,mini,?_,?_⟩
  · let k:=n/(4*m)
    have cap:k*(4*m)≤n:=Nat.div_mul_le_self _ _
    apply pack 1 k 1 (by decide) (by simp) (Or.inr rfl)
    calc
      _=k*(4*m):=by simp only [←Nat.mul_add,Nat.mul_assoc]
      _≤n:=cap
  · have e:2^(3*2^a*2)*2^m*2^(m+m)=2^(6*2^a+3*m):=by
      rw [←Nat.pow_add,←Nat.pow_add]
      congr 1;omega
    simpa only [e] using mini _ up

#print axioms diagonal_minimum
end SISA.Pages
