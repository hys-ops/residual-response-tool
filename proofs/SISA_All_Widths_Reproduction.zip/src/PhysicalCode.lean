import PhysicalResidual

namespace SISA.Pages

def masked (seen x : Nat→Bool) (v:Nat) := if seen v then x v else false

def bankCode {a b r H J y : Nat} (hp:0<H) (upto:H≤a) (rr:r≤H)
    (seen : Nat→Bool) (finished:∀ v:Nat,v%H<r → seen v=true) (x:List Bool) :
    Fin (2^(3*2^a*J)*2^(a+b)) :=
  let D:=H*J
  let n:=2^a*D
  let ptr:=physicalBits n (a+b) y (masked seen (get x))
  let bank:=retained (2^a) D H J r (physicalPattern n a y seen (get x))
  let code:=bank.map (fun v=>masked seen (get x) v)
  have div:H∣n := ⟨2^a*J,by dsimp [n,D];ac_rfl⟩
  have le : code.length ≤ 3*2^a*J := by
    simp only [code,List.length_map]
    exact physical_capacity div hp upto rr seen (get x) finished
  pack (valCode (a+b) ptr (by simp [ptr,physicalBits])) (valCode _ code le)

private theorem at_index {l:List Nat} {f g:Nat→Bool} (eq:l.map f=l.map g) {v:Nat}
    (hv:v∈l) : f v=g v :=by
  induction l with
  | nil=>simp at hv
  | cons i t ih=>
    simp only [List.map_cons,List.cons.injEq] at eq
    rcases List.mem_cons.mp hv with h|h
    · simpa [h] using eq.1
    · exact ih eq.2 h

/-- Equal finite codes determine the same output on common unseen data in
    the original graph. The partial pointer and bank are numerically encoded. -/
theorem code_sufficient {a b H J r:Nat} (hp:0<H) (jp:0<J) (page:2^b=H*J)
    (upto:H≤a) (rr:r≤H) (outer W x z:List Bool) (ol:outer.length=a+b)
    (width:W.length≤2*(H*J)) (seen:Nat→Bool)
    (finished:∀ v:Nat,v%H<r → seen v=true) (frontier:∀ v:Nat,seen v=true → v%H≤r)
    (suffix:∀ v,seen v=false → get x v=get z v)
    (eq:bankCode (b:=b) (J:=J) (y:=beValue outer) hp upto rr seen finished x =
        bankCode (b:=b) (J:=J) (y:=beValue outer) hp upto rr seen finished z) :
    graph (2^a*(H*J)) outer W x ↔ graph (2^a*(H*J)) outer W z :=by
  let n:=2^a*(H*J)
  let y:=beValue outer
  have parts:=unpack eq
  have e : physicalBits n (a+b) y (masked seen (get x)) =
           physicalBits n (a+b) y (masked seen (get z)) :=
    value_inj (by simp [physicalBits]) (congrArg Fin.val parts.1)
  have pe (i:Nat) (il:i<a+b) (s:seen ((y+i)%n)=true) :
      get x ((y+i)%n)=get z ((y+i)%n) :=by
    have ee:=congrArg (fun ls:List Bool=>ls[i]?) e
    simpa [physicalBits,il,masked,s] using ee
  have samePat : physicalPattern n a y seen (get x)=physicalPattern n a y seen (get z) :=by
    apply List.map_congr_left
    intro i hi
    have il:=List.mem_range.mp hi
    cases s:seen ((y+i)%n) <;> simp [s,pe i (by omega)]
  let listx:=retained (2^a) (H*J) H J r (physicalPattern n a y seen (get x))
  let listz:=retained (2^a) (H*J) H J r (physicalPattern n a y seen (get z))
  have lists:listx=listz:=congrArg (retained (2^a) (H*J) H J r) samePat
  have dig : listx.map (masked seen (get x))=listz.map (masked seen (get z)) :=
    value_inj (by simp only [List.length_map,lists]) (congrArg Fin.val parts.2)
  rw [←lists] at dig
  apply same_reply hp jp page outer W x z ol width seen frontier suffix pe
  intro v hv
  cases h:seen v with
  | false=>exact suffix _ h
  | true=> simpa [masked,h] using at_index dig hv

#print axioms code_sufficient
end SISA.Pages

namespace SISA.Pages

theorem code_congr {a b r H J y : Nat} (hp:0<H) (upto:H≤a) (rr:r≤H)
    (seen:Nat→Bool) (finished:∀ v:Nat,v%H<r → seen v=true) (x z:List Bool)
    (he:∀ v,seen v=true → get x v=get z v) :
    bankCode (b:=b) (J:=J) (y:=y) hp upto rr seen finished x =
    bankCode (b:=b) (J:=J) (y:=y) hp upto rr seen finished z :=by
  have mm:masked seen (get x)=masked seen (get z):=by
    funext v
    cases hv:seen v <;> simp [masked,hv,he v]
  have pp (n:Nat) : physicalPattern n a y seen (get x)=physicalPattern n a y seen (get z) :=by
    apply List.map_congr_left
    intro i _
    cases hv:seen ((y+i)%n) <;> simp [hv,he _]
  apply Fin.ext
  simp only [bankCode,pack,valCode,mm,pp]

end SISA.Pages
