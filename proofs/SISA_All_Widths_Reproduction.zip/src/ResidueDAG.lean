import PhysicalCode

namespace SISA.Pages
open HWB.Circuit HWB.ResidualCompiler

def rank (H K i:Nat) := i%H*K + (i/H)%K
def observed (H K k:Nat) (v:Nat) := decide (rank H K v<k)
def round (H K k:Nat) := min (k/K) (H-1)

private theorem finished {H K k:Nat} (kp:0<K) (v:Nat) (h:v%H<round H K k) :
    observed H K k v=true :=by
  have e:v%H+1≤k/K :=by exact Nat.le_trans h (Nat.min_le_left ..)
  have le: (v%H+1)*K≤k := Nat.le_trans (Nat.mul_le_mul_right K e) (Nat.div_mul_le_self ..)
  have b:=(Nat.mod_lt (v/H) kp)
  simp only [Nat.add_mul,Nat.one_mul] at le
  apply decide_eq_true
  change v%H*K+(v/H)%K<k
  omega

private theorem frontier {H K k:Nat} (hp:0<H) (kp:0<K) (v:Nat) (h:observed H K k v=true) :
    v%H≤round H K k :=by
  have rem:=Nat.mod_lt v hp
  have le : v%H*K+(v/H)%K<k := of_decide_eq_true h
  exact Nat.le_min.mpr ⟨(Nat.le_div_iff_mul_le kp).mpr (by omega),by omega⟩

def unshuffle (n H K:Nat) (l:List Bool) :=
  List.ofFn (fun i:Fin n => get l (rank H K i))

private theorem read_back (n H K:Nat) (p:List Bool) (v:Nat) :
    get (unshuffle n H K p) v = if v<n then get p (rank H K v) else false :=by
  by_cases hv:v<n <;> simp [get,unshuffle,hv]

def serialize (H K:Nat) (x:List Bool) :=
  List.ofFn (fun j:Fin (H*K) => get x (j.val%K*H + j.val/K))

theorem permutes_data {H K:Nat} (hp:0<H) (kp:0<K) (x:List Bool) (size:x.length=H*K) :
    unshuffle (H*K) H K (serialize H K x)=x :=by
  apply List.ext_getElem (by simp [unshuffle,size])
  intro i hi _
  have il:i<H*K:=by simpa [unshuffle] using hi
  have q:i/H<K:=(Nat.div_lt_iff_lt_mul hp).mpr (by simpa [Nat.mul_comm] using il)
  have r:i%H<H:=Nat.mod_lt i hp
  have lim:rank H K i<H*K:=by
    unfold rank
    have le:=Nat.mul_le_mul_right K r
    rw [Nat.succ_mul] at le
    rw [Nat.mod_eq_of_lt q];omega
  have inv:rank H K i % K*H + rank H K i / K=i:=by
    simp only [rank,Nat.mod_eq_of_lt q,Nat.mul_add_mod_self_right]
    rw [Nat.add_comm (i%H*K), Nat.add_mul_div_right _ _ kp, Nat.div_eq_of_lt q,Nat.zero_add]
    exact Nat.div_add_mod' i H
  simp [unshuffle,serialize,get,lim,inv,show i<x.length by omega]

private def code {a b H J : Nat} (hp:0<H) (jp:0<J) (upto:H≤a) (y:Nat) (p:List Bool) :
    Fin (2^(3*2^a*J)*2^(a+b)) :=
  let K:=2^a*J
  let n:=2^a*(H*J)
  bankCode (b:=b) (J:=J) (y:=y) hp upto (r:=round H K p.length)
    (Nat.le_trans (Nat.min_le_right ..) (Nat.sub_le ..)) (observed H K p.length)
    (finished (Nat.mul_pos (Nat.two_pow_pos _) jp)) (unshuffle n H K p)

/-- One static residue order, a free outer address and free result, and a
    concrete ordinary OBDD in the original circular problem. -/
theorem actual_residue_DAG {a b w H J:Nat} (hp:0<H) (jp:0<J) (page:2^b=H*J)
    (upto:H≤a) (width:w≤2*(H*J)) :
    let m:=a+b
    let n:=2^a*(H*J)
    let K:=2^a*J
    ∃ g:DAG ((m+w+n)*((2^(3*2^a*J)*2^m)*2^(m+w))), ∃ root,
      ∀ outer W x:List Bool,outer.length=m → W.length=w → x.length=n →
        (g.eval (wordInput ((outer++W)++serialize H K x)) root=true ↔ graph n outer W x) :=by
  classical
  let m:=a+b
  let n:=2^a*(H*J)
  let K:=2^a*J
  have kp:0<K:=Nat.mul_pos (Nat.two_pow_pos _) jp
  have layout:n=H*K:=by dsimp [n,K];ac_rfl
  let F:=fun (h p:List Bool)=>decide (graph n (h.take m) (h.drop m) (unshuffle n H K p))
  let C:=fun (h p:List Bool)=>code (b:=b) hp jp upto (beValue (h.take m)) p
  have good : ∀ h:List Bool,h.length=m+w → Refines n (F h) (C h) :=by
    intro h hl p q len eq tail _
    let seen:=observed H K p.length
    have onpre (l:List Bool) (le:l.length=p.length) (v:Nat) (s:seen v=true) :
        get (unshuffle n H K l) v=get (unshuffle n H K (l++tail)) v :=by
      have hv:rank H K v<l.length:=by simpa [seen,observed,le] using s
      rw [read_back,read_back]
      simp only [get,List.getElem?_append_left hv]
    have rbound:round H K p.length≤H := Nat.le_trans (Nat.min_le_right ..) (Nat.sub_le ..)
    let cod:=bankCode (b:=b) (J:=J) (y:=beValue (h.take m)) hp upto rbound seen (finished kp)
    have ec:cod (unshuffle n H K p)=cod (unshuffle n H K q):=by
      simpa only [C,code,←len] using eq
    have both:cod (unshuffle n H K (p++tail))=cod (unshuffle n H K (q++tail)) :=
      (code_congr hp upto rbound seen (finished kp) _ _ (onpre p rfl)).symm.trans
        (ec.trans (code_congr hp upto rbound seen (finished kp) _ _ (onpre q len.symm)))
    apply decide_eq_decide.mpr
    apply code_sufficient hp jp page upto rbound _ _ _ _ (by simp [hl,m]) (by simpa [hl] using width)
      seen (finished kp) (frontier hp kp) _ both
    intro v s
    have hv:p.length≤rank H K v:=by simpa [seen,observed] using s
    rw [read_back,read_back]
    simp only [get,List.getElem?_append_right hv,List.getElem?_append_right (len ▸ hv),len]
  obtain ⟨g,root,ok⟩:=header_DAG F C good
  refine ⟨g,root,?_⟩
  intro outer W x ho hw hx
  change outer.length=m at ho
  change x.length=n at hx
  change (g.eval (wordInput ((outer++W)++serialize H K x)) root=true ↔ graph n outer W x)
  rw [ok _ _ (by simp [ho,hw]) (by simp [serialize,layout])]
  have seq:unshuffle n H K (serialize H K x)=x:=layout ▸ permutes_data hp kp x (hx.trans layout)
  simp [F,←ho,seq]

#print axioms actual_residue_DAG
end SISA.Pages
