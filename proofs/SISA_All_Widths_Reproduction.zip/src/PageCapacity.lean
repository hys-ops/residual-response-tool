import Minimum

namespace SISA.Pages

def holes : List (Option Bool) → Nat
  | [] => 0
  | none::t => holes t+1
  | some _::t => holes t

def fills : List (Option Bool) → List (List Bool)
  | [] => [[]]
  | none::t => (fills t).map (false :: ·) ++ (fills t).map (true :: ·)
  | some b::t => (fills t).map (b :: ·)

@[simp] theorem fills_length (pat:List (Option Bool)) :
    (fills pat).length=2^holes pat :=by
  induction pat with
  | nil=>rfl
  | cons a t ih=>cases a <;> simp [fills,holes,ih,Nat.pow_succ] <;> omega

def fits : List (Option Bool) → List Bool → Prop
  | [], [] => True
  | none::p,_::t => fits p t
  | some a::p,b::t => a=b ∧ fits p t
  | _,_ => False

theorem mem_fills (pat:List (Option Bool)) (x:List Bool) : x∈fills pat ↔ fits pat x :=by
  induction pat generalizing x with
  | nil=>cases x <;> simp [fits,fills]
  | cons a t ih=>
    cases a <;> cases x with
    | nil=>simp [fits,fills]
    | cons b xs=>cases b <;> simp [fits,fills,ih,eq_comm] <;> exact and_comm

/-- Three cyclic pages suffice for all offsets shorter than twice the page
    width. Listing extra pages and duplicate pages only overcounts memory. -/
def candidates (M:Nat) (pat:List (Option Bool)) : List Nat :=
  (fills pat).flatMap (fun p=> ((List.range 3).map (fun k=>(SISA.beValue p+k)%M)))

theorem candidates_length (M:Nat) (pat:List (Option Bool)) :
    (candidates M pat).length = 2^holes pat * 3 :=by
  have count (ls:List (List Bool)) :
      (ls.flatMap (fun p=> ((List.range 3).map (fun k=>(SISA.beValue p+k)%M)))).length=ls.length*3 :=by
    induction ls with | nil=>rfl | cons a l ih=>simp [ih,Nat.succ_mul];omega
  simpa [candidates] using count (fills pat)

theorem candidate_sound {M D low j:Nat} (dp:0<D) (ls:low<D) (offset:j<2*D)
    (p:List (Option Bool)) (hi:List Bool) (ok:fits p hi) :
    (((SISA.beValue hi*D+low+j)%(M*D))/D)∈candidates M p :=by
  let a:=SISA.beValue hi
  have bound:(low+j)/D<3 :=(Nat.div_lt_iff_lt_mul dp).mpr (by omega)
  change ((a*D+low+j)%(M*D))/D∈_
  rw [Nat.mod_mul_left_div_self,Nat.add_assoc,Nat.add_comm (a*D),Nat.add_mul_div_right _ _ dp,Nat.add_comm ((low+j)/D)]
  exact List.mem_flatMap.mpr ⟨hi,(mem_fills p hi).mpr ok,
    List.mem_map.mpr ⟨_,List.mem_range.mpr bound,rfl⟩⟩

/-- Local offsets retained through the possibly partial next round. A page
    of length H*J has J positions of each residue. -/
def offsets (H J r:Nat) : List Nat :=
  (List.range J).flatMap (fun a=>(List.range (r+1)).map (fun b=>a*H+b))

theorem offsets_length (H J r:Nat) : (offsets H J r).length=J*(r+1) :=by
  have aux (xs:List Nat) :
      (xs.flatMap (fun a=>(List.range (r+1)).map (fun b=>a*H+b))).length=xs.length*(r+1) :=by
    induction xs with | nil=>simp | cons a l ih=>simp [ih,Nat.succ_mul];omega
  simpa [offsets] using aux (List.range J)

theorem offset_sound {H J r v:Nat} (hp:0<H) (room:v<J*H) (seen:v%H≤r) :
    v∈offsets H J r :=by
  refine List.mem_flatMap.mpr ⟨v/H,List.mem_range.mpr ((Nat.div_lt_iff_lt_mul hp).mpr room),?_⟩
  refine List.mem_map.mpr ⟨v%H,List.mem_range.mpr (by omega),?_⟩
  exact Nat.div_add_mod' v H

def retained (M D H J r:Nat) (pat:List (Option Bool)) : List Nat :=
  (candidates M pat).flatMap (fun a=>(offsets H J r).map (fun b=>a*D+b))

theorem retained_sound {M H J r low j:Nat} (hp:0<H) (jp:0<J)
    (pat:List (Option Bool)) (high:List Bool) (ok:fits pat high)
    (ls:low<H*J) (oj:j<2*(H*J))
    (v:Nat) (pos:v=(SISA.beValue high*(H*J)+low+j)%(M*(H*J))) (seen:v%H≤r) :
    v∈retained M (H*J) H J r pat :=by
  let D:=H*J
  have dp:0<D:=Nat.mul_pos hp jp
  have page:v/D∈candidates M pat:=pos ▸ candidate_sound dp ls oj pat high ok
  have vm:v%D % H = v%H := Nat.mod_mod_of_dvd v (by exact ⟨J,rfl⟩)
  have loc:v%D∈offsets H J r :=offset_sound hp (by simpa [D,Nat.mul_comm] using Nat.mod_lt v dp) (vm ▸ seen)
  exact List.mem_flatMap.mpr ⟨v/D,page,List.mem_map.mpr ⟨v%D,loc,Nat.div_add_mod' v D⟩⟩

private theorem linear_pow (r:Nat) : r+1≤2^r:=by
  induction r with | zero=>decide | succ r ih=>rw [Nat.pow_succ];omega

/-- Bound on the explicit bank even when the target word and outer header
    are arbitrary. fixed is the number of high bits already supplied. -/
theorem retained_length_le {a r H J:Nat} (pat:List (Option Bool)) (fixed:r+holes pat≤a) :
    (retained (2^a) (H*J) H J r pat).length ≤ 3*2^a*J :=by
  have mult (xs:List Nat) :
     (xs.flatMap (fun i=>(offsets H J r).map (fun b=>i*(H*J)+b))).length
      =xs.length*(J*(r+1)) :=by
    induction xs with | nil=>simp | cons a t ih=>simp [ih,offsets_length,Nat.succ_mul];omega
  rw [retained,mult,candidates_length]
  have ineq:2^holes pat*(r+1)≤2^a:=calc
    _≤2^holes pat*2^r:=Nat.mul_le_mul_left _ (linear_pow r)
    _=2^(holes pat+r):=(Nat.pow_add ..).symm
    _≤2^a:=Nat.pow_le_pow_right (by decide) (by omega)
  calc
    _=(2^holes pat*(r+1))*(3*J):=by ac_rfl
    _≤2^a*(3*J):=Nat.mul_le_mul_right _ ineq
    _=_:=by ac_rfl

#print axioms retained_sound
#print axioms retained_length_le
end SISA.Pages
