import LaneCoverage

namespace SISA.Pages

private theorem le_append (l t : List Bool) :
    leValue (l++t)=leValue l+2^l.length*leValue t :=by
  induction l with
  | nil=>simp [leValue]
  | cons b l ih=>
    cases b <;> simp [leValue,ih,Nat.pow_succ,Nat.mul_add,Nat.mul_assoc,Nat.mul_comm] <;> omega

theorem big_append (l t:List Bool) :
    beValue (l++t)=beValue l*2^t.length+beValue t :=by
  simp [beValue,le_append,Nat.mul_comm,Nat.add_comm]

theorem read_eq_physical (n m y:Nat) (x:List Bool) :
    readPtr n m y x = physicalBits n m y (get x) :=by
  apply List.ext_getElem (by simp [readPtr,physicalBits])
  intro i _ _
  simp [physicalBits,readPtr]

private theorem head_low (n a b y:Nat) (x:Nat→Bool) :
    ∃ low, low<2^b ∧
      beValue (physicalBits n (a+b) y x) =
      beValue (physicalBits n a y x)*2^b+low :=by
  let tail := (List.range b).map (fun i=>x ((y+(a+i))%n))
  refine ⟨beValue tail,?_,?_⟩
  · have lim:=value_lt tail.reverse
    simpa [beValue,tail] using lim
  · have split : physicalBits n (a+b) y x = physicalBits n a y x ++tail :=by
      simp [physicalBits,List.range_add,List.map_map,Function.comp_def,tail]
    simp [split,big_append,tail]

/-- The actual original circular predicate has identical residuals when two
    full assignments share a suffix, the observed pointer bits and the bank.
    No disjointness of the pointer and query is assumed. -/
theorem same_reply {a b H J r:Nat} (hp:0<H) (jp:0<J) (page:2^b=H*J)
    (outer W x z:List Bool) (ol:outer.length=a+b) (width:W.length≤2*(H*J))
    (seen:Nat→Bool) :
    let n := 2^a*(H*J)
    let y := beValue outer
    let bank := retained (2^a) (H*J) H J r (physicalPattern n a y seen (get x))
    (∀ v, seen v=true → v%H≤r) →
    (∀ v, seen v=false → get x v=get z v) →
    (∀ i<a+b,seen ((y+i)%n)=true → get x ((y+i)%n)=get z ((y+i)%n)) →
    (∀ v∈bank, get x v=get z v) →
    (graph n outer W x ↔ graph n outer W z) :=by
  dsimp only
  intro frontier suffix ptreq bankeq
  let n:=2^a*(H*J)
  let y:=beValue outer
  have ptr : readPtr n (a+b) y x = readPtr n (a+b) y z :=by
    apply List.ext_getElem (by simp [readPtr])
    intro i _ hi
    have il:i<a+b:=by simpa [readPtr] using hi
    simp only [readPtr,List.getElem_ofFn]
    cases he:seen ((y+i)%n) with
    | false=>exact suffix _ he
    | true=>exact ptreq _ il he
  obtain ⟨low,ls,addr⟩:=head_low n a b y (get x)
  rw [page] at ls addr
  unfold graph
  rw [ol]
  change (∀ j:Fin W.length, get x ((beValue (readPtr n (a+b) y x)+j.val)%n)=get W j.val) ↔
    ∀ j:Fin W.length, get z ((beValue (readPtr n (a+b) y z)+j.val)%n)=get W j.val
  rw [←ptr,read_eq_physical,addr]
  apply forall_congr';intro j
  let v := (beValue (physicalBits n a y (get x))*(H*J)+low+j.val)%n
  have eq : get x v = get z v :=by
    cases hv:seen v with
    | false=>exact suffix _ hv
    | true=>exact bankeq _ (physical_sound hp jp ls (by have:=j.isLt;omega) seen (get x) hv frontier)
  change get x v=get W j.val ↔ get z v=get W j.val
  rw [eq]

#print axioms same_reply
end SISA.Pages
