import PointerProbe

namespace SISA.Profile

theorem word_probe {m b s : Nat} (W : List Bool) (mp:0<m)
    (ptr:b+m≤2^m) (wp:0<W.length) (valid:s+W.length≤2^m)
    (apart:s+W.length≤b ∨ b+m≤s) (bg : Nat → Bool) :
    graph (2^m) (bigBits m b) W (programmed (2^m) m b s bg) ↔
    ∀ j:Fin W.length, bg (s+j.val)=get W j.val := by
  have bl:b<2^m:=by omega
  have sl:s<2^m:=by omega
  unfold graph
  simp only [big_read bl,big_length,write_read ptr,big_read sl]
  apply forall_congr'; intro j
  have ii:s+j.val<2^m:=by have:=j.isLt;omega
  have outside:¬(b≤s+j.val ∧ s+j.val<b+m):=by have:=j.isLt;rcases apart with h|h <;> omega
  have h: get (programmed (2^m) m b s bg) (s+j.val)=bg (s+j.val):=by
    simp [get, programmed, ii, changed, outside]
  rw [Nat.mod_eq_of_lt ii,h]

#print axioms word_probe
end SISA.Profile
