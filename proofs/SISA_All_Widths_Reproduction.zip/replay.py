"""Build the bundled Lean proof from source with an empty module cache."""
import argparse
import os
from pathlib import Path
import re
import subprocess
import tempfile

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--lean', default=os.environ.get('LEAN', 'lean'))
parser.add_argument('--only', nargs='+', help='optional target module names')
args = parser.parse_args()
version = subprocess.check_output([args.lean,'--version'],text=True).strip()
print(version,flush=True)
if 'version 4.34.1,' not in version:
    raise SystemExit('Use the version pinned in lean-toolchain.')
modules = {}
for folder in ('vendor','src'):
    for path in (root/folder).rglob('*.lean'):
        name = '.'.join(path.relative_to(root/folder).with_suffix('').parts)
        if name in modules:
            raise RuntimeError('Duplicate module '+name)
        modules[name] = path
with tempfile.TemporaryDirectory(prefix='hwb-width-') as scratch:
    done = set()
    def build(name):
        if name in done:
            return
        path = modules[name]
        for dep in re.findall(r'^import\s+([\w.]+)',path.read_text(),re.M):
            if dep in modules:
                build(dep)
            elif dep.split('.')[0] not in ('Init','Lean','Std'):
                raise RuntimeError('Unrecognized import '+dep)
        dest = Path(scratch).joinpath(*name.split('.')).with_suffix('.olean')
        dest.parent.mkdir(parents=True,exist_ok=True)
        print('Checking',name,flush=True)
        subprocess.run([args.lean,'-o',str(dest),str(path.relative_to(root))],cwd=root,
                       env=dict(os.environ,LEAN_PATH=scratch,LEAN_NUM_THREADS='2'),check=True)
        done.add(name)
    for name in args.only or sorted(modules):
        build(name)
    print(f'Completed {len(done)} source modules in a fresh object directory.')
