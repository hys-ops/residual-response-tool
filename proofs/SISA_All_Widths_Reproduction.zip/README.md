# Shifted indirect storage access at every width

Start with **SISA_All_Widths.pdf**. The result is about logarithmic size of optimal deterministic ordinary OBDDs on Sawitzki’s SISA-GRAPH, extended paper, Definition 6 and Theorem 3. Both reads are circular, variables can be ordered arbitrarily, and the output word is free except where explicitly fixed.

For n = 2^m, 1 ≤ w ≤ n write G = min(n/m, (n/w)log₂(w+1)) and Z = (n/w)log₂(1+w/m). The exponent log₂(size+2) is Θ(w+G) with free answer wires. The smallest fixed-word exponent is Θ(m+Z), attained by every bounded-period family. The largest is Θ(m+G); a single word chosen per w works simultaneously for every n and every order. The note does not classify each arbitrary fixed word.

## Verification scope

- **SISA.Pages.residue_legal** constructs a legal actual diagram under the new order in the predecessor's original graph model. Given a+b=m, 2^b=HJ, H,J positive, H≤a and w≤2HJ, its internal size bound is (n+m+w)·2^(3·2^a·J+2m+w). Includes the variable permutation and round count for all cuts. **SISA.Pages.actual_residue_DAG** is the explicit free-header construction used inside.
- **SISA.Pages.diagonal_minimum**, for every m≥4 and w=m, simultaneously returns the least legal size B, the lower 2^floor(n/(4m)) ≤ B+2 and the upper B ≤ (2m+n)·2^(6·2^(m−floor(log₂m))+3m). This gives log₂(B+2)=Θ(n/m) by elementary written estimates. There is no additional assumption about the physical data or a user's variable order.
- **SISA.Profile.word_probe** programs an arbitrarily prescribed result word on a disjoint original physical query through a late pointer. The fixed-word general packing, translated covering-word argument, periodic summary and full all-width asymptotic classification are written proofs. They are not included in the scope of diagonal_minimum.
- **vendor/Minimum.lean** retains the earlier short-cell upper and guarded/answer-crossing lower bounds. All sixteen predecessor modules are copied byte for byte. Paths in vendor/SOURCES.tsv refer to the earlier archive. Axiom lists are printed in logs/lean.txt. None of the listed proof modules introduce new axioms or proof placeholders.
- **tests/check.py** independently exercises circular streaming summaries, exhaustive small truth tables, a fixed three-column covering word, and common-suffix separations in random orders. See logs/checks.txt for counts. A finite word is not the asymptotic existence argument.
- Historical priority and independent human review have not been established. Direct comparison is with the cited extended-source theorem.

## Reproduce offline

Unzip and run the commands from the directory containing this README. Python 3.10+ and Lean 4.34.1 suffice. The Lean build uses the standard Lean distribution and creates an empty temporary object directory.

    sha256sum -c SHA256SUMS
    python3 replay.py --lean lean
    python3 tests/check.py

For the finite two-sided theorem only:

    python3 replay.py --lean lean --only ResidueMinimum

## Links and continuity

[Public source, Definition 6 and Theorem 3](https://citeseerx.ist.psu.edu/document?doi=fecf96da588c7b03df786f3f144a5f888873f077&repid=rep1&type=pdf) · [General covering array antecedent](https://doi.org/10.37236/571).

The previous all-width optimum and ordinary SHWB results stand. The present result resolves the width gap recorded on page 6 of the prior SISA note. A useful next question is to identify an invariant predicting intermediate fixed-word costs. A separate transfer could ask how complexity changes between hidden and explicitly supplied pointer bits; published FSA Proposition 2 supplies the fully disclosed comparison at w=m. No intermediate classification is asserted here.
