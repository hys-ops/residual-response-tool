"""Rebuild the ordinary HWB restricted results in a temporary object directory."""
from pathlib import Path
import argparse
import os
import subprocess
import tempfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--lean", default="lean")
args = parser.parse_args()
here = Path(__file__).resolve().parent
version = subprocess.check_output([args.lean, "--version"], text=True).strip()
print(version, flush=True)
if "version 4.34.1," not in version:
    raise SystemExit("Lean 4.34.1 is required")
with tempfile.TemporaryDirectory() as tmp:
    env = dict(os.environ, LEAN_PATH=tmp)
    for module in (here / "module-order.txt").read_text().splitlines():
        relative = Path(*module.split(".")).with_suffix(".lean")
        obj = (Path(tmp) / relative).with_suffix(".olean")
        obj.parent.mkdir(parents=True, exist_ok=True)
        print("Building", module, flush=True)
        subprocess.run([args.lean, "-j", "1", "-o", str(obj), str(relative)],
                       cwd=here / "source", env=env, check=True)
    subprocess.run([args.lean, "-j", "1", "Audit.lean"], cwd=here, env=env, check=True)
print("Clean build and declaration checks passed.", flush=True)
