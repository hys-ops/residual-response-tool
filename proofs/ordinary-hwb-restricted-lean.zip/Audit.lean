import HWB.Certified
import HWB.ExportBound
import ExactTwoLevels

#check @HWB.Balanced.balanced_width
#check @HWB.BalancedExact.hardware_bits
#check @HWB.CandidateGeometry.uniform_tiny_right
#check @HWB.Exact.all_large_n
#check @HWB.Exact.exact_two_level_lower
#check @HWB.Model.OneRoot.small_right_lower
#check @HWB.Model.root_balanced
#check @HWB.Response.sameResponse_iff_key
#check @HWB.Sentential.ordinary_explicit_SDD_upper
#check @HWB.SmallLeftOnes.hardware_rate
#check @HWB.TwoRoot.Certificate
#check @HWB.ordinary_HWB_certified

#print axioms HWB.ordinary_HWB_certified
#print axioms HWB.Sentential.ordinary_explicit_SDD_upper
#print axioms HWB.Exact.all_large_n
