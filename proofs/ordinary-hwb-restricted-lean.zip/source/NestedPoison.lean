import NestedCylinder

/-! A witness that a constant-zero subresponse occurs inside the constant-one
prime of ordinary hidden weighted bit. Positions and assignments here are
original one-based labels. -/
namespace HWB.NestedPoison
open HWB.NestedCylinder

/-- The actual HWB output on disjoint banks P,Q,B. -/
def raw (p q b : List Nat) : Prop :=
  p.length+q.length+b.length ∈ p++q++b

/-- The top prime for the constant-true B response. -/
def universalB (B p q : List Nat) : Prop :=
  ∀ b : Support B, raw p q b.val

/-- The Q response of this prime is identically false. -/
def deadQ (Q B p : List Nat) : Prop :=
  ∀ q : Support Q, ¬ universalB B p q.val

private theorem selectWeight (B : List Nat) (uniqueB : B.Nodup) {h : Nat}
    (room : h ≤ B.length) :
    ∃ b : Support B, b.val.length=h :=
  ⟨⟨B.take h,uniqueB.take,List.take_subset ..⟩, List.length_take_of_le room⟩

/-- When a reachable address has a zero forced by the left assignment,
one legitimate top-right completion kills the ordinary output. -/
theorem poison_at {P Q B p q : List Nat} (uniqueB : B.Nodup)
    (disPQ : ∀ z∈P, z∉Q) (disPB : ∀ z∈P, z∉B) (qok : q ⊆ Q)
    (addr : p.length+q.length ≤ z ∧ z ≤ p.length+q.length+B.length)
    (forced : z∈P ∧ z∉p) : ¬ universalB B p q := by
  obtain ⟨b,weight⟩ := selectWeight B uniqueB (h:=z-(p.length+q.length)) (by omega)
  have eq : p.length+q.length+b.val.length = z := by omega
  have nQ : z∉q := fun h => disPQ _ forced.1 (qok h)
  have nB : z∉b.val := fun h => disPB _ forced.1 (b.property.2 h)
  intro h
  have yes := h b
  unfold raw at yes
  rw [eq] at yes
  simp [forced.2,nQ,nB] at yes

/-- Let j be the left weight and marker coordinate, and k = |B|.
All positions j+1 through j+k are active left ones. A fixed left zero at
j+k+1 kills every shifted window with offset 1,...,k+1. Larger shifts must
each contain some left zero. These explicit finite placement conditions
make the entire Q response dead exactly when the programmable marker is zero. -/
theorem dead_iff_marker_zero (P Q B : List Nat) (p : Support P) {j : Nat}
    (weight : p.val.length=j) (marker : j∈P)
    (uniqueB : B.Nodup)
    (disPQ : ∀ z ∈ P, z ∉ Q) (disPB : ∀ z ∈ P, z ∉ B)
    (ones : ∀ z, j<z → z≤j+B.length → z∈p.val)
    (firstZero : j+B.length+1 ∈ P ∧ j+B.length+1 ∉ p.val)
    (tailZeros : ∀ h, B.length+1<h → h≤Q.length →
      ∃ z, j+h≤z ∧ z≤j+h+B.length ∧ z∈P ∧ z∉p.val) :
    deadQ Q B p.val ↔ j ∉ p.val := by
  constructor
  · intro dead isOn
    let q0 : Support Q := ⟨[],by simp⟩
    apply dead q0
    intro b
    have bounded := b.property.1.length_le_of_subset b.property.2
    have win : j+b.val.length ∈ p.val := by
      by_cases bz : b.val.length=0
      · simpa [bz] using isOn
      · exact ones _ (by omega) (by omega)
    change p.val.length+0+b.val.length ∈ p.val++[]++b.val
    rw [weight]
    simp [win]
  · intro off q
    have hq := q.property.1.length_le_of_subset q.property.2
    by_cases h0 : q.val.length=0
    · exact poison_at uniqueB disPQ disPB q.property.2 (z:=j) (by omega) ⟨marker,off⟩
    · by_cases early : q.val.length ≤ B.length+1
      · exact poison_at uniqueB disPQ disPB q.property.2
          (z:=j+B.length+1) (by omega) firstZero
      · obtain ⟨z,low,high,left,absent⟩ := tailZeros _ (by omega) hq
        exact poison_at uniqueB disPQ disPB q.property.2 ⟨by omega,by omega⟩ ⟨left,absent⟩

end HWB.NestedPoison
