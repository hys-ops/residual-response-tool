import DyadicBalance

namespace HWB.Exact

/-- A conservative common scale for the final certificate. -/
def factor : Nat := 2^60

theorem scale_square {n t : Nat} (big : 2^128≤n)
    (target : (factor*t)^3 ≤ n*n.log2^2) : (factor*t)^2≤n := by
  have nz : n≠0 := by intro h;subst n;contradiction
  have pos : 0<n.log2 := by have := (Nat.le_log2 nz).mpr big;omega
  have log4 := Nat.le_trans (Nat.pow_le_pow_right pos (by decide : 4≤16))
    (HWB.DensePacking.log_power_sixteen big)
  apply (Nat.pow_le_pow_iff_left (by decide : 3≠0)).mp
  calc
    ((factor*t)^2)^3 = ((factor*t)^3)^2 := by rw [←Nat.pow_mul,←Nat.pow_mul]
    _ ≤ (n*n.log2^2)^2 := Nat.pow_le_pow_left target _
    _ = n^2 * n.log2^4 := by rw [Nat.mul_pow, ←Nat.pow_mul]
    _ ≤ n^2*n := Nat.mul_le_mul_left _ log4
    _ = n^3 := rfl

theorem margins {n k t : Nat} (ht : 0<t) (hk : k<8*t)
    (sq : (factor*t)^2≤n) :
    262144*((t+1)*(t+1))≤n ∧ 100*(k*(k+1))≤n ∧
    t≤n/(512*(k+1)) ∧ 4096*((k+1)*(k+1))≤n := by
  have big : (2^120)*(t*t)≤n := by
    rw [Nat.mul_pow] at sq
    change 1329227995784915872903807060280344576*(t^2)≤n at sq
    simpa only [Nat.pow_two] using sq
  have one : t+1≤2*t := by omega
  have small : k+1≤8*t := by omega
  have t1 := Nat.mul_le_mul one one
  have k1 := Nat.mul_le_mul (Nat.le_trans (Nat.le_succ k) small) small
  have k2 := Nat.mul_le_mul small small
  have kt := Nat.mul_le_mul_right t small
  have e : (2*t)*(2*t)=4*(t*t) := by
    calc _ = (2*2)*(t*t) := by ac_rfl
         _ = _ := rfl
  have e' : (8*t)*(8*t)=64*(t*t) := by
    calc _ = (8*8)*(t*t) := by ac_rfl
         _ = _ := rfl
  have e'' : (8*t)*t=8*(t*t) := Nat.mul_assoc .. 
  rw [e] at t1
  rw [e'] at k1 k2
  rw [e''] at kt
  refine ⟨by omega,by omega,?_,by omega⟩
  apply (Nat.le_div_iff_mul_le (by omega : 0<512*(k+1))).mpr
  calc t*(512*(k+1)) = 512*((k+1)*t) := by ac_rfl
       _ ≤ n := by omega

#print axioms scale_square
#print axioms margins
end HWB.Exact
