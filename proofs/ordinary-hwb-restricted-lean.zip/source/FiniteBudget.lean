import Std

/-! Integer checks of numerical slack in the small-right-bank proof. -/
namespace HWB.DensePacking

/-- The two square-root hypotheses written as integer inequalities imply all the
linear margins used in the slab proof. Here `ell=h+2` and `h=k+q`, `k=w-1`. -/
theorem finite_margins {n w q : Nat} (large : 65536 ≤ n)
    (outer : 4096*(w*w) ≤ n) (inner : 65536*(q*q) ≤ n*w) :
    16384*w ≤ n ∧ 32768*q ≤ n ∧ 1024*((w-1)+q+2) ≤ n := by
  have hw : 16384*w ≤ n := by
    by_cases h : 4 ≤ w
    · have h' := Nat.mul_le_mul_right w h
      have hh := Nat.mul_le_mul_left 4096 h'
      omega
    · omega
  have hq : 32768*q ≤ n := by
    apply Nat.mul_self_le_mul_self_iff.mp
    calc
      _ = 16384*(65536*(q*q)) := by
        rw [← Nat.mul_assoc 16384 65536 (q*q)]
        rw [show 16384*65536 = 32768*32768 by decide]; ac_rfl
      _ ≤ 16384*(n*w) := Nat.mul_le_mul_left 16384 inner
      _ = n*(16384*w) := by ac_rfl
      _ ≤ _ := Nat.mul_le_mul_left n hw
  exact ⟨hw,hq,by omega⟩

/-- The choice `d=floor(64*q*w/n)` has square at most `q`, so the preceding
entropy bound applies even when this floor is zero. -/
theorem exceptional_distance {n w q : Nat} (np : 0<n) (ql : q≤n)
    (outer : 4096*(w*w)≤n) : let d := 64*q*w/n; d*d ≤ q := by
  let d := 64*q*w/n
  have hd : d*n ≤ 64*q*w := Nat.div_mul_le_self _ _
  have h : d*d*(n*n) ≤ q*(n*n) := by
    calc
      _ = (d*n)*(d*n) := by ac_rfl
      _ ≤ (64*q*w)*(64*q*w) := Nat.mul_le_mul hd hd
      _ = (4096*(w*w))*(q*q) := by change _ = ((64*64)*(w*w))*(q*q);ac_rfl
      _ ≤ n*(q*q) := Nat.mul_le_mul_right _ outer
      _ ≤ n*(q*n) := Nat.mul_le_mul_left n (Nat.mul_le_mul_left q ql)
      _ = _ := by ac_rfl
  exact Nat.le_of_mul_le_mul_right h (Nat.mul_pos np np)

/-- The run-exclusion upper estimate has room at finite size, including h=0.
The comparison is written without division to preserve strict inequality. -/
theorem long_run_budget {n w q : Nat} (large : 65536 ≤ n) (wp : 0<w)
    (outer : 4096*(w*w) ≤ n) (inner : 65536*(q*q) ≤ n*w) :
    let h := w-1+q; 128*(h*w + 2*h*(h+1)) < n*w := by
  let h := w-1+q
  obtain ⟨hw,_,hl⟩ := finite_margins large outer inner
  have hs : 4096*(h*h) ≤ n*w := by
    by_cases hq : w ≤ q
    · have hh : h ≤ 2*q := by dsimp [h];omega
      calc
        _ ≤ 4096*((2*q)*(2*q)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul hh hh)
        _ = 16384*(q*q) := by change _ = (4096*(2*2))*(q*q);ac_rfl
        _ ≤ _ := by omega
    · have hh : h ≤ 2*w := by dsimp [h];omega
      calc
        _ ≤ 4096*((2*w)*(2*w)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul hh hh)
        _ = (16384*w)*w := by change _ = ((4096*(2*2))*w)*w;ac_rfl
        _ ≤ _ := Nat.mul_le_mul_right w hw
  have hshift : h*(h+1) ≤ 2*(h*h) := by
    by_cases z : h=0
    · simp [z]
    · have hh := Nat.mul_le_mul_left h (by omega : h+1 ≤ 2*h)
      simpa only [Nat.mul_left_comm, Nat.mul_comm, Nat.mul_assoc] using hh
  have hlin : (1024*h)*w ≤ n*w := Nat.mul_le_mul_right w (by dsimp [h];omega)
  have hn : 0<n*w := Nat.mul_pos (by omega) wp
  change 128*(h*w + 2*h*(h+1)) < n*w
  rw [Nat.mul_assoc 2 h (h+1)]
  rw [Nat.mul_assoc] at hlin
  omega

end HWB.DensePacking
