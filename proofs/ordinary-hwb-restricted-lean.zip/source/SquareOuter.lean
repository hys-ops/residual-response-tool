import TwoRootInner

namespace HWB.TwoRoot
open HWB.Model HWB.Circuit HWB.Slice

private theorem sq_lhs {n t d : Nat} (hn : 262144*((t+1)*(t+1))≤n)
    (hd : d≤80*t) : 3*((d+1)*(d+1))≤n := by
  have eq : (81*(t+1))*(81*(t+1))=6561*((t+1)*(t+1)) := by
    calc _ = (81*81)*((t+1)*(t+1)) := by ac_rfl
         _ = _ := rfl
  have hh : d+1≤81*(t+1) := by omega
  have h := Nat.mul_le_mul hh hh
  rw [eq] at h
  omega

private theorem sq_kw {n t k : Nat} (hn : 262144*((t+1)*(t+1))≤n)
    (hk : k≤8*t) : 4096≤n ∧ 64*(k*k)≤n ∧ 1024*((k+1)*t)≤n ∧
    32*k≤n ∧ 8*(k*(k+1))≤n := by
  let u := t+1
  have nk : k+1 ≤ 9*u := by dsimp [u];omega
  have n0 : k ≤ 9*u := by omega
  have nt : t ≤ u := by dsimp [u];omega
  have uu : u≤u*u := Nat.le_mul_of_pos_right u (by dsimp [u];omega)
  have e : (9*u)*(9*u) = 81*(u*u) := by
    calc _ = (9*9)*(u*u) := by ac_rfl
         _ = _ := rfl
  have e' : (9*u)*u = 9*(u*u) := by ac_rfl
  have kk := Nat.mul_le_mul n0 n0
  have kt := Nat.mul_le_mul nk nt
  have kp := Nat.mul_le_mul n0 nk
  rw [e] at kk kp
  rw [e'] at kt
  change 262144*(u*u)≤n at hn
  have nu : 0<u := by dsimp [u];omega
  omega

theorem square_outer_left (c : Certificate n W) {t : Nat} (ht : 0<t)
    (hn : 262144*((t+1)*(t+1))≤n) (ha : c.A.length<8*t) : 2^t≤W+2 := by
  let zero : Model.Assignment c.A := ⟨[],by simp⟩
  let i := c.dec.selectCase zero
  have rule (y : Model.Assignment c.B) : c.dec.sub i y = decide (y.val.length∈y.val) := by
    simpa [i,zero,Decision.run] using c.correct zero y
  cases c.subs i with
  | ordered order perm g root cost corr =>
    have b := GapBridge.small_left_zero_slice g root order (16*t) (perm.nodup_iff.mpr c.nb)
      (fun j hj => (c.domain j).mp (List.mem_append_right _ (perm.subset hj)))
      (by have := c.total; have := perm.length_eq; omega) (sq_lhs hn (by omega))
      (fun x => (corr x).trans (rule _))
    have eq : 16*t/16=t := by omega
    rw [eq] at b
    omega
  | branch g _ cost corr =>
    have he : ∀ x y, g.dec.run x y = decide (x.val.length+y.val.length∈x.val++y.val) := by
      intro x y
      rw [corr,rule]
      simp [paste]
    let z : ZeroRoot n c.A := ⟨g,he⟩
    have dat := z.sizes_le_wires
    have zw : z.wires≤W := cost
    by_cases la : 64*t≤z.A.length
    · by_cases rb : 8*t≤z.B.length
      · have a := z.balanced t ht (by omega) rb (by omega)
        omega
      · have data := sq_kw hn (show z.B.length≤8*t by omega)
        have da := (sq_kw hn (show c.A.length≤8*t by omega)).2.1
        have a := z.small_right_exponent data.1 data.2.1 da data.2.2.1
        omega
    · have a := z.small_left_DAG (80*t) (by omega) (sq_lhs hn (by omega))
      have le : t≤80*t/16 := by omega
      have p := Nat.pow_le_pow_right (n:=2) (by decide) le
      omega


theorem square_direct (c : Certificate n W) {T : List Nat} (eqT : T.Perm c.A)
    {N : Nat} (g : DAG N) (gate : State N) (cost : N≤W)
    (hc : ∀ x : Assignment T, g.eval (bits T x.val) gate=universal c.B x.val) {t : Nat}
    (ht : 0<t) (hn : 262144*((t+1)*(t+1))≤n) (smallB : c.B.length<8*t) : 2^t≤W+2 := by
  have hnum := sq_kw hn (Nat.le_of_lt smallB)
  have z := qdag (B:=c.B) (H:=c.B) g gate (eqT.nodup_iff.mpr c.na)
    (fun j hj => (c.domain j).mp (List.mem_append_left _ (eqT.subset hj))) (n:=n)
    (fun z lo hi => (List.mem_append.mp ((c.domain z).mpr ⟨lo,hi⟩)).imp
      (fun ha => eqT.symm.subset ha) id)
    hnum.1 hnum.2.1 (by have := c.total; have := eqT.length_eq; omega)
    hnum.2.2.2.2 hnum.2.2.1 ht hc
  omega

#print axioms square_outer_left
#print axioms square_direct
end HWB.TwoRoot
