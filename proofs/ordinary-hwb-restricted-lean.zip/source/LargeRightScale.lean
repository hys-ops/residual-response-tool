import DyadicBalance

namespace HWB.DensePacking

private theorem groups_resolve {r w : Nat} (pos : 0<w) (room : (2^20)*w≤r) :
    let J := (r/w+1)/32768
    let F := (w+1).log2*J/14
    r≤65536*w*J ∧ (w+1).log2*J≤32*F := by
  let J := (r/w+1)/32768
  let F := (w+1).log2*J/14
  have hr : (2^20)≤r/w := (Nat.le_div_iff_mul_le pos).mpr room
  have hj : 32≤J := by dsimp [J]; omega
  have hd : r/w+1≤65536*J := by dsimp [J] at *;omega
  have re : r < (r/w+1)*w := Nat.lt_mul_of_div_lt (by omega) pos
  have size : r ≤ 65536*w*J := by
    calc _ ≤ (r/w+1)*w := Nat.le_of_lt re
         _ ≤ (65536*J)*w := Nat.mul_le_mul_right _ hd
         _ = _ := by ac_rfl
  have logpos : 1≤(w+1).log2 := (Nat.le_log2 (Nat.succ_ne_zero w)).mpr (by omega)
  have jlog : J≤(w+1).log2*J := by simpa using Nat.mul_le_mul_right J logpos
  change r≤65536*w*J ∧ (w+1).log2*J≤32*F
  exact ⟨size,by dsimp [F];omega⟩

/-- The actual large-right branch of `BalancedExact.hardware_bits` can afford a
complete target bit count at threshold `(2^60*t)^3 ≤ n*(floor(log₂ n))^2`. -/
theorem large_q {n p q w t : Nat} (large : 2^1024≤n) (tp : 0<t) (wp : 0<w)
    (width : w≤8*t) (target : (2^60*t)^3≤n*n.log2^2) (square : (2^60*t)^2≤n)
    (dense : n≤128*p) (bigQ : n*w≤65536*(q*q)) :
    ∃ r, 2048≤r ∧ w≤r ∧ r+w≤q ∧ 64*r≤p ∧ 4*(2*w+(w-1)*w)≤p ∧
      t≤(w+1).log2*((r/w+1)/32768)/14 := by
  let A := 2^60*t
  have nlarge : 2^128≤n := Nat.le_trans (Nat.pow_le_pow_right (by decide) (by decide)) large
  have sq : A^2≤n := square
  -- The square budget gives much more headroom than the grouping denominator.
  have ws : (2^50)*w ≤ A := by dsimp [A];omega
  have ww : (2^100)*(w*w) ≤ n := by
    have hh := Nat.pow_le_pow_left ws 2
    rw [Nat.mul_pow, Nat.pow_two w] at hh
    exact Nat.le_trans hh sq
  have wself : w≤w*w := by simpa using Nat.mul_le_mul_left w wp
  have nlin : (2^100)*w ≤ n := by
    exact Nat.le_trans (Nat.mul_le_mul_left _ wself) ww
  have roomq : (2^21)*w≤q := by
    have wide : ((2^29)*w)*((2^29)*w)≤n*w := by
      calc
        _ = ((2^58)*w)*w := by change _ = (((2^29)*(2^29))*w)*w;ac_rfl
        _ ≤ _ := Nat.mul_le_mul_right _ (by omega)
    have s : 65536*(((2^21)*w)*((2^21)*w)) ≤ 65536*(q*q) := by
      apply Nat.le_trans _ (Nat.le_trans wide bigQ)
      change (256*256)*(((2^21)*w)*((2^21)*w)) ≤ (256*(2^21)*w)*(256*(2^21)*w)
      apply Nat.le_of_eq;ac_rfl
    exact Nat.mul_self_le_mul_self_iff.mp (Nat.le_of_mul_le_mul_left s (by decide))
  let r := min (q/2) (p/64)
  have room : (2^20)*w ≤ r := by dsimp [r];omega
  -- In either case the chosen radius is at least sqrt(n*w)/16384.
  have cap : n*w≤(16384*r)^2 := by
    by_cases b : q/2 ≤ p/64
    · have e : r=q/2 := Nat.min_eq_left b
      have rr : q≤64*r := by omega
      calc
        _ ≤ 65536*(q*q) := bigQ
        _ = (256*q)^2 := by rw [Nat.mul_pow,Nat.pow_two q]
        _ ≤ (16384*r)^2 := Nat.pow_le_pow_left (by omega) 2
    · have e : r=p/64 := Nat.min_eq_right (by omega)
      have rr : n≤16384*r := by omega
      simpa [Nat.pow_two] using Nat.mul_le_mul rr (show w≤16384*r by omega)
  have rp := groups_resolve wp room
  let J := (r/w+1)/32768
  let F := (w+1).log2*J/14
  have re : r ≤ 65536*w*J := rp.1
  have lg : (w+1).log2*J ≤ 32*F := rp.2
  have acc : 16384*r*(w+1).log2 ≤ w*((2^35)*F) := by
    calc
      _ ≤ 16384*(65536*w*J)*(w+1).log2 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ re)
      _ = ((2^30)*w)*((w+1).log2*J) := by change _ = ((16384*65536)*w)*_;ac_rfl
      _ ≤ ((2^30)*w)*(32*F) := Nat.mul_le_mul_left _ lg
      _ = _ := by change _ = w*(((2^30)*32)*F);ac_rfl
  -- Turn the two floors paid by hardware into a window cost for dyadic_target.
  have win : n*(w+1).log2^2 ≤ w*((2^35)*F)^2 := by
    apply Nat.le_of_mul_le_mul_right (c:=w) _ wp
    calc
      _ = (n*w)*(w+1).log2^2 := by ac_rfl
      _ ≤ (16384*r)^2*(w+1).log2^2 := Nat.mul_le_mul_right _ cap
      _ = (16384*r*(w+1).log2)^2 := (Nat.mul_pow ..).symm
      _ ≤ (w*((2^35)*F))^2 := Nat.pow_le_pow_left acc 2
      _ = _ := by rw [Nat.mul_pow,Nat.pow_two w];ac_rfl
  have wa : w≤1*A := by dsimp [A];omega
  have terminal := dyadic_target nlarge wp (by decide : 0<1) target wa win
  refine ⟨r,by omega,by omega,?_,?_,?_,?_⟩
  · dsimp [r];omega
  · dsimp [r];omega
  · have m := Nat.mul_le_mul_right w (Nat.sub_le w 1)
    omega
  · change t≤F
    dsimp [A] at terminal
    omega

end HWB.DensePacking
