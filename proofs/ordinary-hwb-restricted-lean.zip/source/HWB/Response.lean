import Std

/-! The semantic compressed root of ordinary hidden weighted bit. Assignments are
lists of *one* labels, without duplicates. The order of the list is immaterial.
The upper construction chooses genuine input labels on each side. -/
namespace HWB.Response

def Valid (B Y : List Nat) : Prop := Y.Nodup ∧ Y ⊆ B
def Separated (B X : List Nat) : Prop := ∀ j ∈ X, j ∉ B
def Covered (B : List Nat) (m : Nat) : Prop :=
  ∀ a ≤ m, ∃ b ∈ B, a < b ∧ b < a + B.length

/-- A set of one labels has as its output its own cardinality's membership bit.
There is no virtual zero label on a positive-indexed input. -/
def ordinary (S : List Nat) : Prop := S.length ∈ S

def answer (X Y : List Nat) : Prop := X.length + Y.length ∈ X ++ Y

theorem answer_eq_ordinary (X Y : List Nat) : answer X Y ↔ ordinary (X ++ Y) := by
  simp [answer, ordinary]

abbrev Key (B : List Nat) := Nat × (Fin (B.length+1) → Bool)
def key (B X : List Nat) : Key B :=
  (X.length, fun s => decide (X.length+s.val ∈ X))

theorem choose_weight {B : List Nat} (hB : B.Nodup) {s : Nat}
    (hs : s ≤ B.length) : ∃ Y, Valid B Y ∧ Y.length = s :=
  ⟨B.take s, ⟨hB.sublist (List.take_sublist ..), (List.take_sublist ..).subset⟩,
    by simp [Nat.min_eq_left hs]⟩

/-- On a nonterminal weight layer we may exclude any designated coordinate. -/
theorem choose_omitting {B : List Nat} (hB : B.Nodup) {s b : Nat}
    (hb : b ∈ B) (hs : s < B.length) :
    ∃ Y, Valid B Y ∧ Y.length = s ∧ b ∉ Y := by
  let T := B.erase b
  have ht : T.Nodup := hB.erase _
  have hn : T.length = B.length - 1 := List.length_erase_of_mem hb
  have hcap : s ≤ T.length := by omega
  obtain ⟨Y, hY, hy⟩ := choose_weight ht hcap
  refine ⟨Y, ⟨hY.1, fun _ h => List.mem_of_mem_erase (hY.2 h)⟩, hy, ?_⟩
  exact fun h => hB.not_mem_erase (hY.2 h)

/-- Put b in the one set and omit c on an interior layer. c may be outside B. -/
theorem choose_distinguishing {B : List Nat} (hB : B.Nodup) {s b c : Nat}
    (hb : b ∈ B) (hbc : b ≠ c) (hs₀ : 0 < s) (hs : s < B.length) :
    ∃ Y, Valid B Y ∧ Y.length = s ∧ b ∈ Y ∧ c ∉ Y := by
  let T := (B.erase b).erase c
  have hU : (B.erase b).Nodup := hB.erase _
  have hT : T.Nodup := hU.erase _
  have hlen : (B.erase b).length = B.length-1 := List.length_erase_of_mem hb
  have hcap : s-1 ≤ T.length := by
    dsimp [T]
    rw [List.length_erase]
    split <;> omega
  obtain ⟨Z, hz, he⟩ := choose_weight hT hcap
  have hnb : b ∉ Z := fun h => hB.not_mem_erase (List.mem_of_mem_erase (hz.2 h))
  have hnc : c ∉ Z := fun h => hU.not_mem_erase (hz.2 h)
  refine ⟨b::Z, ⟨List.nodup_cons.mpr ⟨hnb,hz.1⟩, ?_⟩, ?_, by simp, ?_⟩
  · intro i hi
    rcases List.mem_cons.mp hi with e | h
    · simpa [e] using hb
    · exact List.mem_of_mem_erase (List.mem_of_mem_erase (hz.2 h))
  · simp; omega
  · simp [Ne.symm hbc,hnc]

/-- Actual right-hand assignments, all of the same Hamming weight in each probe,
separate two rows of different left weight if the first has an interior marker. -/
theorem weight_separated {B X X' : List Nat} (hB : B.Nodup)
    (hx : Separated B X) {b : Nat} (hb : b ∈ B)
    (hab : X.length < b) (hbk : b < X.length+B.length) (hne : X.length ≠ X'.length) :
    ∃ Y, Valid B Y ∧ ¬(answer X Y ↔ answer X' Y) := by
  let s := b-X.length
  let c := X'.length+s
  have hs0 : 0<s := by dsimp [s]; omega
  have hsk : s<B.length := by dsimp [s]; omega
  have haddress : X.length+s=b := by dsimp [s]; omega
  have hbc : b ≠ c := by dsimp [c]; omega
  have hbl : b ∉ X := fun h => hx _ h hb
  by_cases hc : c ∈ X'
  · obtain ⟨Y,hY,hy,hout⟩ := choose_omitting hB hb hsk
    refine ⟨Y,hY,?_⟩
    have h₁ : ¬ answer X Y := by simp [answer,hy,haddress,hbl,hout]
    have h₂ : answer X' Y := by
      unfold answer
      rw [hy]
      exact List.mem_append_left _ hc
    exact fun h => h₁ (h.mpr h₂)
  · obtain ⟨Y,hY,hy,hin,hout⟩ := choose_distinguishing hB hb hbc hs0 hsk
    refine ⟨Y,hY,?_⟩
    have h₁ : answer X Y := by simp [answer,hy,haddress,hin]
    have h₂ : ¬ answer X' Y := by
      unfold answer
      rw [hy, List.mem_append]
      exact fun h => h.elim hc hout
    exact fun h => h₂ (h.mp h₁)

theorem key_iff {B X X' : List Nat} :
    key B X = key B X' ↔
    X.length = X'.length ∧
      ∀ s ≤ B.length, (X.length+s ∈ X ↔ X.length+s ∈ X') := by
  constructor
  · intro hk
    have hw : X.length = X'.length := congrArg Prod.fst hk
    refine ⟨hw, fun s hs => ?_⟩
    have he := congrArg (fun (w : Key B) => w.2 ⟨s, by omega⟩) hk
    simpa [key,← hw] using he
  · rintro ⟨hw,h⟩
    apply Prod.ext hw
    funext s
    have he := h s.val (by omega)
    simp [key, ← hw,he]

theorem key_sound {B X X' Y : List Nat} (hY : Valid B Y)
    (h : key B X = key B X') : answer X Y ↔ answer X' Y := by
  obtain ⟨hw,ha⟩ := key_iff.mp h
  have hi := ha Y.length (hY.1.length_le_of_subset hY.2)
  simp only [answer, List.mem_append, ← hw]
  exact or_congr hi Iff.rfl

/-- The exact equivalence classes forced by semantic compression. The hypotheses
are only the chosen ordered label set, its marker coverage, and disjoint left
one sets; in particular no right-layer or separation witness is assumed. -/
theorem sameResponse_iff_key {B X X' : List Nat} {m : Nat} (hB : B.Nodup)
    (hc : Covered B m) (hm : X.length ≤ m) (hx : Separated B X)
    (hx' : Separated B X') :
    (∀ Y, Valid B Y → (answer X Y ↔ answer X' Y)) ↔ key B X = key B X' := by
  refine ⟨fun h => ?_, fun hk _ hy => key_sound hy hk⟩
  obtain ⟨b,hb,hl,hr⟩ := hc X.length hm
  have hw : X.length = X'.length := by
    apply Classical.byContradiction
    intro hn
    obtain ⟨Y,hy,bad⟩ := weight_separated hB hx hb hl hr hn
    exact bad (h Y hy)
  apply key_iff.mpr
  refine ⟨hw,fun s hs => ?_⟩
  by_cases hb' : X.length+s ∈ B
  · exact iff_of_false (fun hi => hx _ hi hb') (fun hi => hx' _ hi hb')
  · obtain ⟨Y, hy, he⟩ := choose_weight hB hs
    have hnot : X.length+s ∉ Y := fun hi => hb' (hy.2 hi)
    have hu := h Y hy
    simpa only [answer, he, ← hw, List.mem_append, hnot, or_false] using hu

/-- Feasible root elements. Different left assignments with identical keys index
one element. Feasibility witnesses are propositions, not external parameters. -/
def RootKey (A B : List Nat) := {w : Key B // ∃ X, Valid A X ∧ key B X = w}

def prime {A B : List Nat} (i : RootKey A B) (X : List Nat) : Prop := key B X = i.val

/-- A key gives an explicit right response without choosing a left representative. -/
def sub {B : List Nat} (w : Key B) (Y : List Nat) : Prop :=
  if h : Y.length ≤ B.length then
    w.2 ⟨Y.length,by omega⟩ = true ∨ w.1 + Y.length ∈ Y
  else False

theorem key_sub {B X Y : List Nat} (hy : Valid B Y) :
    sub (key B X) Y ↔ answer X Y := by
  simp [sub,key,answer,hy.1.length_le_of_subset hy.2]

theorem unique_prime {A B X : List Nat} (hx : Valid A X) :
    ∃ i : RootKey A B, prime i X ∧ ∀ j : RootKey A B, prime j X → i = j := by
  refine ⟨⟨key B X, X, hx, rfl⟩, rfl, fun j hj => Subtype.ext hj⟩

theorem sub_injective {A B : List Nat} (hB : B.Nodup) (dis : Separated B A)
    (hc : Covered B A.length) {i j : RootKey A B}
    (h : ∀ Y, Valid B Y → (sub i.val Y ↔ sub j.val Y)) : i = j := by
  obtain ⟨X,hx,hk⟩ := i.property
  obtain ⟨X',hx',hk'⟩ := j.property
  have hsep : Separated B X := fun u hu => dis u (hx.2 hu)
  have hsep' : Separated B X' := fun u hu => dis u (hx'.2 hu)
  apply Subtype.ext
  rw [← hk, ← hk']
  apply (sameResponse_iff_key hB hc (hx.1.length_le_of_subset hx.2) hsep hsep').mp
  intro Y hy
  simpa only [← hk, ← hk', key_sub hy] using h Y hy

theorem root_computes {A B X Y : List Nat} (hx : Valid A X) (hy : Valid B Y) :
    (∃ i : RootKey A B, prime i X ∧ sub i.val Y) ↔ ordinary (X ++ Y) := by
  rw [← answer_eq_ordinary]
  constructor
  · rintro ⟨i,hi,hr⟩
    rw [← hi] at hr
    exact (key_sub hy).mp hr
  · intro h
    exact ⟨⟨key B X, X, hx, rfl⟩,rfl,(key_sub hy).mpr h⟩

/-- Split a raw ordinary input on original labels. No dummy right variables
are appended. The order of ones in the partitions is irrelevant. -/
def rightOnes (B S : List Nat) := S.filter (fun j => decide (j ∈ B))
def leftOnes (B S : List Nat) := S.filter (fun j => !decide (j ∈ B))

theorem root_on_ordinary_input {A B S : List Nat} (hs : Valid (A ++ B) S) :
    (∃ i : RootKey A B, prime i (leftOnes B S) ∧ sub i.val (rightOnes B S)) ↔
    ordinary S := by
  let X := leftOnes B S
  let Y := rightOnes B S
  have hx : Valid A X := by
    refine ⟨hs.1.sublist List.filter_sublist, fun j hj => ?_⟩
    have g : j ∈ S ∧ j ∉ B := by simpa [X,leftOnes] using hj
    exact (List.mem_append.mp (hs.2 g.1)).resolve_right g.2
  have hy : Valid B Y := by
    refine ⟨hs.1.sublist List.filter_sublist, fun j hj => ?_⟩
    have g : j ∈ S ∧ j ∈ B := by simpa [Y,rightOnes] using hj
    exact g.2
  have p : (X ++ Y).Perm S :=
    (List.perm_append_comm (l₁ := X) (l₂ := Y)).trans
      (List.filter_append_perm (fun j => decide (j ∈ B)) S)
  change (∃ i : RootKey A B, prime i X ∧ sub i.val Y) ↔ ordinary S
  rw [root_computes hx hy]
  simp only [ordinary,p.length_eq]
  exact p.mem_iff

end HWB.Response
