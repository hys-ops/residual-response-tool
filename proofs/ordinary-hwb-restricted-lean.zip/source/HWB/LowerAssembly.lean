import HWB.Model
import HWB.Balanced

namespace HWB.Model

/-- On a balanced root it is the number of distinct root elements itself,
not the cost of evaluating individual elements, that grows exponentially. -/
theorem root_balanced (c : OneRoot n) (t : Nat) (ht : 0<t)
    (ha : 8*t ≤ c.A.length) (hb : 8*t ≤ c.B.length) : 2^t ≤ c.R := by
  classical
  let x0 : Assignment c.A := ⟨[], by simp⟩
  let idx := fun (x : List Nat) => if h : Balanced.Legal c.A x then
    c.dec.selectCase ⟨x,h⟩ else c.dec.selectCase x0
  let out := fun (i : Fin c.R) (y : List Nat) =>
    if h : Balanced.Legal c.B y then c.dec.sub i ⟨y,h⟩ else false
  apply Balanced.balanced_width c.A c.B 0 t c.R c.na c.nb c.dis _ ha hb (by omega) ht idx out
  · intro x y hx hy
    simpa [idx,out,hx,hy,Circuit.Decision.run,Balanced.raw] using c.correct ⟨x,hx⟩ ⟨y,hy⟩
  · intro j hj
    have hu := ((c.domain j).mp (List.mem_append_left _ hj)).2
    have := c.total
    omega

theorem positive_elements (c : OneRoot n) : 0<c.R := by
  exact Nat.lt_of_le_of_lt (Nat.zero_le _) (c.dec.selectCase ⟨[], by simp⟩).isLt

theorem sizes_le_wires (c : OneRoot n) :
    c.R ≤ c.wires ∧ c.NP+2 ≤ c.wires ∧ c.NS+2 ≤ c.wires := by
  have := positive_elements c
  unfold OneRoot.wires
  omega

end HWB.Model
