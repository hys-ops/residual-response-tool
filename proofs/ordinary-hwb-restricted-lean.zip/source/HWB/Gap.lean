import Std

/-! The entries of an input word are ordered by their original labels 1,...,n.
A mask entry `false` marks a hole, including all positions required to stay zero. -/
namespace HWB.Gap

/-- Weight zero reads a sentinel zero, weight one reads the first bit. -/
def ordinary (x : List Bool) : Bool :=
  ((false :: x)[x.count true]?).getD false

theorem count_bits (x : List Bool) :
    x.count false + x.count true = x.length := by
  induction x with
  | nil => rfl
  | cons b x ih => cases b <;> simp at * <;> omega

private theorem run_accounting (x : List Bool) :
    ∃ r L tail u v, x = List.replicate r true ++ tail ∧
      x = u ++ List.replicate L true ++ v ∧ r ≤ L ∧
      x.count true ≤ x.count false * L + r := by
  induction x with
  | nil => exact ⟨0, 0, [], [], [], rfl, rfl, Nat.le_refl _, Nat.le_refl _⟩
  | cons b x ih =>
    obtain ⟨r,L,tail,u,v,hr,hL,hrL,hcount⟩ := ih
    cases b with
    | false =>
      refine ⟨0, L, false::x, false::u, v, rfl, ?_, Nat.zero_le _, ?_⟩
      · simpa only [List.cons_append] using congrArg (false :: ·) hL
      · simp [Nat.succ_mul]
        omega
    | true =>
      by_cases heq : r = L
      · subst L
        refine ⟨r+1, r+1, tail, [], tail, ?_, ?_, Nat.le_refl _, ?_⟩
        · simpa only [List.replicate_succ, List.cons_append] using congrArg (true :: ·) hr
        · simpa only [List.nil_append, List.replicate_succ, List.cons_append] using
            congrArg (true :: ·) hr
        · simp [Nat.mul_succ]
          omega
      · refine ⟨r+1, L, tail, true::u, v, ?_, ?_, by omega, ?_⟩
        · simpa only [List.replicate_succ, List.cons_append] using congrArg (true :: ·) hr
        · simpa only [List.cons_append] using congrArg (true :: ·) hL
        · simp
          omega

/-- Concrete pigeonhole inequality and a contiguous witness for every mask. -/
theorem contiguous_gap (x : List Bool) :
    ∃ L u v, x = u ++ List.replicate L true ++ v ∧
      x.count true ≤ (x.count false + 1) * L := by
  obtain ⟨r,L,_,u,v,_,hL,hle,hcount⟩ := run_accounting x
  exact ⟨L, u, v, hL, by rw [Nat.succ_mul]; omega⟩

/-- The word never sets a masked-out position to one, and both lengths agree. -/
inductive Fits : List Bool → List Bool → Prop where
  | nil : Fits [] []
  | cons {m b ms bs} (ok : b = true → m = true) (tail : Fits ms bs) :
      Fits (m :: ms) (b :: bs)

theorem Fits.length_eq {m b} (h : Fits m b) : m.length = b.length := by
  induction h with
  | nil => rfl
  | cons _ _ ih => simp [ih]

theorem Fits.append {m b m' b'} (a : Fits m b) (c : Fits m' b') :
    Fits (m ++ m') (b ++ b') := by
  induction a with
  | nil => exact c
  | cons ok _ ih => exact .cons ok ih

theorem Fits.lookup {m b} (a : Fits m b) (i : Nat) (hi : b[i]? = some true) :
    m[i]? = some true := by
  induction a generalizing i with
  | nil => simp at hi
  | cons ok _ ih =>
    cases i with
    | zero => simpa using ok (by simpa using hi)
    | succ i => exact ih i hi

private theorem zeros_fit (m : List Bool) : Fits m (List.replicate m.length false) := by
  induction m with
  | nil => exact .nil
  | cons b m ih => exact .cons (by simp) ih

private theorem any_fit (b : List Bool) : Fits (List.replicate b.length true) b := by
  induction b with
  | nil => exact .nil
  | cons bit b ih => exact .cons (by simp) ih

private theorem select_ones (m : List Bool) (p : Nat) (h : p ≤ m.count true) :
    ∃ b, Fits m b ∧ b.count true = p := by
  induction m generalizing p with
  | nil => simp at h; exact ⟨[], .nil, by simp [h]⟩
  | cons v m ih =>
    cases v with
    | false =>
      obtain ⟨b,hb,hc⟩ := ih p (by simpa [List.count_cons] using h)
      exact ⟨false :: b, .cons (by simp) hb, by simpa [List.count_cons] using hc⟩
    | true =>
      cases p with
      | zero =>
        exact ⟨_, zeros_fit _, by simp [List.count_replicate]⟩
      | succ p =>
        obtain ⟨b,hb,hc⟩ := ih p (by simp at h; omega)
        exact ⟨true :: b, .cons (by simp) hb, by simp [hc]⟩

/-- This padding reads the same output even if the internal assignment is all zero.
All preceding bits are zero and the suffix contributes exactly their number of ones. -/
theorem ordinary_padding (p : Nat) (x z : List Bool) (hz : z.count true = p) :
    ordinary (List.replicate p false ++ x ++ z) = ordinary x := by
  unfold ordinary
  have zeroOnes : (List.replicate p false).count true = 0 := by simp [List.count_replicate]
  simp only [List.count_append, zeroOnes, Nat.zero_add, hz]
  have wle := List.count_le_length (a := true) (l := x)
  change (((false :: List.replicate p false) ++ x ++ z)[x.count true + p]?).getD false =
    ((false :: x)[x.count true]?).getD false
  rw [List.getElem?_append_left (by simp; omega)]
  cases hw : x.count true with
  | zero =>
    simp only [Nat.zero_add, List.getElem?_cons_zero]
    rw [List.getElem?_append_left (by simp)]
    change ((List.replicate (p+1) false)[p]?).getD false = false
    simp
  | succ w =>
    rw [List.getElem?_append_right (by simp; omega)]
    simp only [List.length_cons, List.length_replicate, List.getElem?_cons_succ]
    congr 2
    omega

/-- All holes stay zero. The free block consists of consecutive ORIGINAL labels,
and its placement and outside bits are chosen before the free assignment. -/
theorem small_left_restriction (mask : List Bool) (d : Nat)
    (holes : mask.count false ≤ d) (size : 3 * ((d+1)*(d+1)) ≤ mask.length) :
    ∃ (u v z : List Bool),
      mask = u ++ List.replicate d true ++ v ∧
      Fits v z ∧ z.count true = u.length ∧
      ∀ x : List Bool, x.length = d →
        Fits mask (List.replicate u.length false ++ x ++ z) ∧
        ordinary (List.replicate u.length false ++ x ++ z) = ordinary x := by
  let q := (d+1)*(d+1)
  let front := mask.take q
  let back := mask.drop q
  have hsplit : front ++ back = mask := List.take_append_drop q mask
  have hlen : front.length = q := by
    simp only [front, List.length_take]; apply Nat.min_eq_left; dsimp [q]; omega
  have hfrontle : front.count false ≤ d := by
    rw [← hsplit, List.count_append] at holes
    omega
  have htaille : back.count false ≤ d := by
    rw [← hsplit, List.count_append] at holes
    omega
  have hq : d ≤ q := by dsimp [q]; rw [Nat.succ_mul]; omega
  have htail : q ≤ back.count true := by
    have hc := count_bits back
    have hl : back.length = mask.length - q := List.length_drop
    change 3*q ≤ mask.length at size
    omega
  obtain ⟨L,u,v,hu,hL⟩ := contiguous_gap front
  have hd : d ≤ L := by
    apply Classical.byContradiction
    intro h
    have h' : L+1 ≤ d := by omega
    have hm := Nat.mul_le_mul (show front.count false + 1 ≤ d + 1 by omega) h'
    have hc := count_bits front
    have hbound : (front.count false+1)*L + (front.count false+1) ≤ (d+1)*d := by
      simpa only [Nat.mul_succ] using hm
    dsimp [q] at hlen
    rw [Nat.mul_succ] at hlen
    omega
  let extra := List.replicate (L-d) true
  have hrep : List.replicate L true = List.replicate d true ++ extra := by
    rw [List.replicate_append_replicate]
    congr 1
    omega
  have hule : u.length ≤ q := by
    rw [hu, List.length_append, List.length_append, List.length_replicate] at hlen
    omega
  obtain ⟨pad,hpad,hones⟩ := select_ones back u.length (Nat.le_trans hule htail)
  let mid := extra ++ v
  let z := List.replicate mid.length false ++ pad
  have shape : mask = u ++ List.replicate d true ++ (mid ++ back) := by
    rw [← hsplit, hu, hrep]
    simp [mid, List.append_assoc]
  have hc : z.count true = u.length := by simp [z, List.count_replicate, hones]
  have fits : Fits (mid ++ back) z := (zeros_fit mid).append hpad
  refine ⟨u, mid ++ back, z, shape, fits, hc, ?_⟩
  intro x hx
  refine ⟨?_, ordinary_padding _ _ _ hc⟩
  rw [shape, ← hx]
  exact ((zeros_fit u).append (any_fit x)).append fits

end HWB.Gap
