import HWB.Response
import HWB.Markers
import HWB.Model

namespace HWB.UpperAssembly
open HWB.Response HWB.Circuit

/-- Encode a bit vector bijectively into the usual binary-number range.
Only the injection and upper bound are needed. -/
def pack : (k : Nat) → (Fin k → Bool) → Nat
  | 0, _ => 0
  | k+1, w => 2*pack k (fun j => w j.succ) + (w 0).toNat

theorem pack_lt (w : Fin k → Bool) : pack k w < 2^k := by
  induction k with
  | zero => simp [pack]
  | succ k ih =>
    have ht := ih (fun j => w j.succ)
    cases h : w 0 <;> simp [pack,h,Bool.toNat,Nat.pow_succ] <;> omega

theorem pack_inj : ∀ k {x y : Fin k → Bool}, pack k x = pack k y → x = y := by
  intro k
  induction k with
  | zero => intro x y h; funext j; exact Fin.elim0 j
  | succ k ih =>
    intro x y h
    change 2*pack k _ + (x 0).toNat = 2*pack k _ + (y 0).toNat at h
    have hz : x 0 = y 0 := by
      cases hx : x 0 <;> cases hy : y 0 <;> simp_all [Bool.toNat] <;> omega
    have et : pack k (fun j => x j.succ) = pack k (fun j => y j.succ) := by
      rw [hz] at h; omega
    have he := ih et
    funext j
    exact Fin.cases hz (fun i => congrFun he i) j

def capacity (A B : List Nat) := (A.length+1)*2^(B.length+1)

def code {A B : List Nat} (u : RootKey A B) : Nat :=
  u.val.1 * 2^(B.length+1) + pack _ u.val.2

theorem code_lt (u : RootKey A B) : code u < capacity A B := by
  obtain ⟨X,hX,e⟩ := u.property
  have h1 := hX.1.length_le_of_subset hX.2
  have h2 : u.val.1 = X.length := congrArg Prod.fst e.symm
  have hp := pack_lt u.val.2
  have hmul := Nat.mul_le_mul_right (2^(B.length+1)) (show u.val.1+1 ≤ A.length+1 by omega)
  rw [Nat.succ_mul] at hmul
  unfold code capacity; omega

theorem code_injective {A B : List Nat} : Function.Injective (@code A B) := by
  intro u v h
  let d := 2^(B.length+1)
  have hd : 0 < d := Nat.pow_pos (by decide)
  have hu : pack _ u.val.2 < d := pack_lt _
  have hv : pack _ v.val.2 < d := pack_lt _
  have h' : pack _ u.val.2 + u.val.1*d = pack _ v.val.2 + v.val.1*d := by
    simpa only [Nat.add_comm,code,d] using h
  have hm := congrArg (· % d) h'
  rw [Nat.add_mul_mod_self_right,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt hu,Nat.mod_eq_of_lt hv] at hm
  have hq := congrArg (· / d) h'
  rw [Nat.add_mul_div_right _ _ hd,Nat.add_mul_div_right _ _ hd,
    Nat.div_eq_of_lt hu,Nat.div_eq_of_lt hv] at hq
  exact Subtype.ext (Prod.ext (by simpa using hq) (pack_inj _ hm))

/-- A dense index for just the realized keys. The filtering is classical and
is used solely to describe a finite circuit, never as an evaluation oracle. -/
noncomputable def codes (A B : List Nat) : List Nat := by
  classical
  exact (List.range (capacity A B)).filter (fun c => decide (∃ u : RootKey A B, code u=c))

theorem codes_size (A B : List Nat) : (codes A B).length ≤ capacity A B := by
  unfold codes
  simpa using (List.length_filter_le _ (List.range (capacity A B)))

theorem mem_codes {A B : List Nat} {c : Nat} :
    c ∈ codes A B ↔ ∃ u : RootKey A B, code u=c := by
  classical
  simp only [codes,List.mem_filter,List.mem_range,decide_eq_true_eq]
  exact ⟨And.right,fun e => ⟨by obtain ⟨u,rfl⟩ := e; exact code_lt u,e⟩⟩

theorem codes_nodup (A B : List Nat) : (codes A B).Nodup :=
  List.Pairwise.filter _ List.nodup_range

noncomputable def rank {A B} (u : RootKey A B) : Fin (codes A B).length :=
  ⟨(codes A B).idxOf (code u),List.idxOf_lt_length_iff.mpr (mem_codes.mpr ⟨u,rfl⟩)⟩

noncomputable def entry {A B} (i : Fin (codes A B).length) : RootKey A B :=
  Classical.choose (mem_codes.mp (List.getElem_mem i.isLt))

theorem entry_code {A B} (i : Fin (codes A B).length) :
    code (entry i) = (codes A B)[i.val] :=
  Classical.choose_spec (mem_codes.mp (List.getElem_mem i.isLt))

theorem entry_rank {A B} (u : RootKey A B) : entry (rank u) = u := by
  apply code_injective
  rw [entry_code]
  exact List.getElem_idxOf _

theorem rank_entry {A B} (i : Fin (codes A B).length) : rank (entry i) = i := by
  apply Fin.ext
  change List.idxOf _ _ = _
  rw [entry_code,(codes_nodup A B).idxOf_getElem]

/-- Disjoint union of OBDD banks with one common variable order. Only the two
terminal states are shared across banks. Node numbers are contiguous per bank.
Fan-in within any component remains unrestricted. -/
def pairNode (i : Fin r) (j : Fin w) : Fin (r*w) :=
  ⟨j.val+i.val*w,by
    have hm := Nat.mul_le_mul_right w (show i.val+1 ≤ r by omega)
    rw [Nat.succ_mul] at hm; omega⟩

private theorem width_pos (j : Fin (r*w)) : 0<w := by
  by_cases h : w=0
  · have hj := j.isLt; simp [h] at hj
  · omega

def part (j : Fin (r*w)) : Fin r :=
  ⟨j.val/w,(Nat.div_lt_iff_lt_mul (width_pos j)).mpr j.isLt⟩

def localNode (j : Fin (r*w)) : Fin w := ⟨j.val%w,Nat.mod_lt _ (width_pos j)⟩

@[simp] theorem part_pair (i : Fin r) (j : Fin w) : part (pairNode i j) = i := by
  apply Fin.ext
  change (j.val+i.val*w)/w = i.val
  have hp : 0 < w := Nat.zero_lt_of_lt j.isLt
  rw [Nat.add_mul_div_right _ _ hp,Nat.div_eq_of_lt j.isLt,Nat.zero_add]

@[simp] theorem local_pair (i : Fin r) (j : Fin w) : localNode (pairNode i j) = j := by
  apply Fin.ext
  simp [localNode,pairNode,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt j.isLt]

@[simp] theorem pair_inverse (j : Fin (r*w)) : pairNode (part j) (localNode j) = j := by
  apply Fin.ext
  simpa only [pairNode,part,localNode,Nat.mul_comm (j.val/w) w] using Nat.mod_add_div j.val w

def liftState (i : Fin r) : State w → State (r*w)
  | .term b => .term b
  | .node j => .node (pairNode i j)

def bank (G : Fin r → DAG w) : DAG (r*w) where
  level j := (G (part j)).level (localNode j)
  child j b := liftState (part j) ((G (part j)).child (localNode j) b)
  drops j b := by
    have h := (G (part j)).drops (localNode j) b
    have he := congrArg Fin.val (pair_inverse j)
    cases hc : (G (part j)).child (localNode j) b with
    | term v => simp [liftState,State.height]
    | node q =>
      rw [hc] at h
      simp only [liftState,State.height,pairNode] at h he ⊢
      omega
  advances j b k h := by
    cases hc : (G (part j)).child (localNode j) b with
    | term v => simp [hc,liftState] at h
    | node q =>
      rw [hc] at h
      injection h with hk
      subst k
      simp only [part_pair,local_pair]
      exact (G (part j)).advances _ _ _ hc

theorem bank_eval (G : Fin r → DAG w) (i : Fin r) (x : Input) (s : State w) :
    (bank G).eval x (liftState i s) = (G i).eval x s := by
  cases s with
  | term v => simp [liftState,DAG.eval]
  | node j =>
    rw [liftState]
    simp only [DAG.eval]
    simp only [bank,part_pair,local_pair]
    exact bank_eval G i x _
termination_by s.height
decreasing_by apply (G i).drops

open HWB.Model

noncomputable def caseOf {A B : List Nat} (x : Assignment A) : Fin (codes A B).length :=
  rank ⟨key B x.val, x.val, x.property, rfl⟩

theorem entry_caseOf {A B : List Nat} (x : Assignment A) :
    (entry (caseOf (B := B) x)).val = key B x.val :=
  congrArg Subtype.val (entry_rank _)

theorem prime_select {A B : List Nat} (x : Assignment A) (i : Fin (codes A B).length) :
    prime (entry i) x.val ↔ caseOf x = i := by
  change key B x.val = (entry i).val ↔ _
  rw [← entry_caseOf x]
  constructor
  · intro h
    have he := congrArg rank (Subtype.ext h : entry (caseOf x) = entry i)
    simpa only [rank_entry] using he
  · intro h; rw [h]

noncomputable def decision (A B : List Nat) (hB : B.Nodup) (dis : Separated B A)
    (hc : Covered B A.length) : Decision (Assignment A) (Assignment B) (codes A B).length := by
  classical
  exact {
    prime := fun i x => decide (prime (entry i) x.val)
    sub := fun i y => decide (sub (entry i).val y.val)
    selectCase := caseOf
    partition := fun x i => by simp [prime_select]
    compressed := fun i j hs => by
      have he : entry i = entry j := by
        apply sub_injective hB dis hc
        intro Y hy
        have eq := hs ⟨Y,hy⟩
        simpa only [decide_eq_decide] using eq
      simpa only [rank_entry] using congrArg rank he
  }

theorem decision_feasible (A B : List Nat) (hB : B.Nodup) (dis : Separated B A)
    (hc : Covered B A.length) (i : Fin (codes A B).length) :
    ∃ x, (decision A B hB dis hc).selectCase x = i := by
  obtain ⟨X,hX,h⟩ := (entry i).property
  exact ⟨⟨X,hX⟩,(prime_select _ i).mp h⟩

theorem decision_correct (A B : List Nat) (hB : B.Nodup) (dis : Separated B A)
    (hc : Covered B A.length) (x : Assignment A) (y : Assignment B) :
    (decision A B hB dis hc).run x y = decide (x.val.length+y.val.length ∈ x.val++y.val) := by
  classical
  change decide (sub (entry (caseOf x)).val y.val) = _
  rw [entry_caseOf]
  exact decide_eq_decide.mpr (key_sub y.property)

structure Components (A B : List Nat) (p s : Nat) where
  l : RootKey A B → DAG p
  r : RootKey A B → DAG s
  srcP : RootKey A B → State p
  srcS : RootKey A B → State s
  specP : ∀ i (x : Assignment A), (l i).eval (bits A x.val) (srcP i) = true ↔ prime i x.val
  specS : ∀ i (y : Assignment B), (r i).eval (bits B y.val) (srcS i) = true ↔ sub i.val y.val

/-- Convert concrete common-order per-key circuits into one finite shared table
on each side of the root. Neither root-element count nor wire count discounts
the primes or subs. -/
noncomputable def assemble (A B : List Nat) (na : A.Nodup) (nb : B.Nodup)
    (dis : Separated B A) (hc : Covered B A.length)
    (domain : ∀ j, j ∈ A ++ B ↔ 1 ≤ j ∧ j ≤ n) (total : A.length+B.length=n)
    (an : A ≠ []) (bn : B ≠ []) (banks : Components A B p s) : OneRoot n := by
  classical
  exact {
    A, B, na, nb, dis, domain, total
    left_nonempty := an
    right_nonempty := bn
    R := (codes A B).length
    NP := (codes A B).length * p
    NS := (codes A B).length * s
    gP := bank (fun i => banks.l (entry i))
    gS := bank (fun i => banks.r (entry i))
    pRoot := fun i => liftState i (banks.srcP (entry i))
    sRoot := fun i => liftState i (banks.srcS (entry i))
    dec := decision A B nb dis hc
    prime_eq := fun i x => by
      rw [bank_eval]
      change decide (prime (entry i) x.val) = _
      have he := banks.specP (entry i) x
      cases h : (banks.l (entry i)).eval (bits A x.val) (banks.srcP (entry i)) <;> simp_all
    sub_eq := fun i y => by
      rw [bank_eval]
      change decide (sub (entry i).val y.val) = _
      have he := banks.specS (entry i) y
      cases h : (banks.r (entry i)).eval (bits B y.val) (banks.srcS (entry i)) <;> simp_all
    feasible := decision_feasible A B nb dis hc
    correct := decision_correct A B nb dis hc
  }

theorem assemble_wires (A B : List Nat) (na : A.Nodup) (nb : B.Nodup)
    (dis : Separated B A) (hc : Covered B A.length)
    (domain : ∀ j, j ∈ A ++ B ↔ 1 ≤ j ∧ j ≤ n) (total : A.length+B.length=n)
    (an : A ≠ []) (bn : B ≠ []) (banks : Components A B p s) :
    (assemble A B na nb dis hc domain total an bn banks).wires ≤
    capacity A B * (3+2*(p+s)) := by
  change 3*(codes A B).length + 2*((codes A B).length*p+(codes A B).length*s) ≤ _
  calc _ = (codes A B).length * (3+2*(p+s)) := by
            simp only [Nat.mul_add]
            rw [Nat.mul_comm 3 (codes A B).length]
            rw [Nat.mul_left_comm 2 (codes A B).length p, Nat.mul_left_comm 2 (codes A B).length s]
       _ ≤ _ := Nat.mul_le_mul_right _ (codes_size A B)

end HWB.UpperAssembly
