import HWB.Normalize
import HWB.Model

namespace HWB.Model
open HWB.Circuit
open HWB.Normalize

/-- Compression at every Shannon gate is tested on actual legal assignments
of its own bank. Compression at the sentential root is already a field of
OneRoot.dec. -/
def OneRoot.Normalized (c : OneRoot n) : Prop :=
  (∀ i, ∃ x : Assignment c.A, c.gP.eval (bits c.A x.val) (c.gP.child i false) ≠
    c.gP.eval (bits c.A x.val) (c.gP.child i true)) ∧
  (∀ i, ∃ y : Assignment c.B, c.gS.eval (bits c.B y.val) (c.gS.child i false) ≠
    c.gS.eval (bits c.B y.val) (c.gS.child i true))

noncomputable def OneRoot.normalize (c : OneRoot n) : OneRoot n :=
  let xs := fun x : Assignment c.A => bits c.A x.val
  let ys := fun y : Assignment c.B => bits c.B y.val
  { c with
    NP := (survivors c.gP xs).length
    NS := (survivors c.gS ys).length
    gP := reduced c.gP xs
    gS := reduced c.gS ys
    pRoot := fun i => collapse c.gP xs (c.pRoot i)
    sRoot := fun i => collapse c.gS ys (c.sRoot i)
    prime_eq := by intro i x; exact (c.prime_eq i x).trans (reduced_eval c.gP xs x _).symm
    sub_eq := by intro i y; exact (c.sub_eq i y).trans (reduced_eval c.gS ys y _).symm
  }

theorem OneRoot.normalize_isNormalized (c : OneRoot n) : c.normalize.Normalized :=
  ⟨children_distinct c.gP (fun x : Assignment c.A => bits c.A x.val),
   children_distinct c.gS (fun y : Assignment c.B => bits c.B y.val)⟩

theorem OneRoot.normalize_wires (c : OneRoot n) : c.normalize.wires ≤ c.wires := by
  have hp := count_le c.gP (fun x : Assignment c.A => bits c.A x.val)
  have hs := count_le c.gS (fun y : Assignment c.B => bits c.B y.val)
  change 3*c.R+2*((survivors _ _).length+(survivors _ _).length) ≤ 3*c.R+2*(c.NP+c.NS)
  omega

theorem OneRoot.normalize_orders (c : OneRoot n) :
    c.normalize.A = c.A ∧ c.normalize.B = c.B ∧ c.normalize.R = c.R := ⟨rfl,rfl,rfl⟩

theorem exists_normalized (c : OneRoot n) :
    ∃ c' : OneRoot n, c'.Normalized ∧ c'.wires ≤ c.wires :=
  ⟨c.normalize,c.normalize_isNormalized,c.normalize_wires⟩

/-- Every allocated reduced node queries a genuine level of its own bank.
    Position validity follows from a legal witness giving a true bit. -/
theorem OneRoot.normalize_levels (c : OneRoot n) :
    (∀ i, c.normalize.gP.level i < c.A.length) ∧
    (∀ i, c.normalize.gS.level i < c.B.length) := by
  constructor
  · intro i
    obtain ⟨x,hx⟩ := (varies c.gP (fun x : Assignment c.A => bits c.A x.val) i).2
    apply Classical.byContradiction
    intro h
    have e : c.A[c.normalize.gP.level i]? = none := List.getElem?_eq_none (Nat.le_of_not_lt h)
    change (c.A[c.normalize.gP.level i]?).any _ = true at hx
    simp [e] at hx
  · intro i
    obtain ⟨x,hx⟩ := (varies c.gS (fun y : Assignment c.B => bits c.B y.val) i).2
    apply Classical.byContradiction
    intro h
    have e : c.B[c.normalize.gS.level i]? = none := List.getElem?_eq_none (Nat.le_of_not_lt h)
    change (c.B[c.normalize.gS.level i]?).any _ = true at hx
    simp [e] at hx

end HWB.Model
