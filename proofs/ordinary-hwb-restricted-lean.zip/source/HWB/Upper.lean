import HWB.Response

namespace HWB.Upper

/-- A layered ordered binary decision diagram. A label is read at each layer.
The two successors are explicitly specified on a finite state space; the
emission map at the last layer fixes the two terminal edges at that layer. -/
structure OrderedCounter (q : Nat) where
  initial : Fin q
  next : Nat → Fin q → Bool → Fin q
  accept : Fin q → Bool

def go (M : OrderedCounter q) (x : Nat → Bool) : List Nat → Fin q → Fin q
  | [], s => s
  | j :: js, s => go M x js (M.next j s (x j))

def value (M : OrderedCounter q) (A : List Nat) (x : Nat → Bool) : Bool :=
  M.accept (go M x A M.initial)

/-- Take a mismatch or an excess count to the absorbing state a+1. -/
def primeMachine (a : Nat) (allow : Nat → Bool → Bool) : OrderedCounter (a+2) where
  initial := ⟨0, by omega⟩
  next j s b := if allow j b then
    ⟨min (a+1) (s.val + b.toNat), by have := Nat.min_le_left (a+1) (s.val+b.toNat); omega⟩
    else ⟨a+1, by omega⟩
  accept s := s.val == a

theorem prime_state (a : Nat) (allow : Nat → Bool → Bool) (x : Nat → Bool) (A : List Nat)
    (s : Fin (a+2)) :
    (go (primeMachine a allow) x A s).val =
      if A.all (fun j => allow j (x j)) then min (a+1) (s.val+(A.filter x).length) else a+1 := by
  induction A generalizing s with
  | nil => simp [go]; omega
  | cons j A ih =>
    rw [go, ih]
    by_cases h : ∀ z ∈ A, allow z (x z) = true <;>
      cases hb : x j <;> cases hc : allow j (x j) <;>
      simp_all [primeMachine, List.all_cons] <;> (try split) <;> omega

theorem prime_value (a : Nat) (allow : Nat → Bool → Bool) (x : Nat → Bool) (A : List Nat) :
    value (primeMachine a allow) A x = true ↔
      (A.filter x).length = a ∧ ∀ j ∈ A, allow j (x j) = true := by
  change (((go (primeMachine a allow) x A _).val == a) = true) ↔ _
  rw [prime_state]
  by_cases h : A.all (fun j => allow j (x j)) = true
  · have hall : ∀ j ∈ A, allow j (x j) = true := List.all_eq_true.mp h
    simp only [h, ite_true, primeMachine, Nat.zero_add, beq_iff_eq]
    constructor
    · intro v; exact ⟨by omega, hall⟩
    · rintro ⟨v, _⟩; omega
  · have hn : ¬∀ j ∈ A, allow j (x j) = true := fun v => h (List.all_eq_true.mpr v)
    simp [h, hn]

/-- Full Shannon OBDD for an arbitrary right response; the two children always
read the same suffix of the supplied order. -/
inductive Tree
  | terminal : Bool → Tree
  | branch : Nat → Tree → Tree → Tree
  deriving Inhabited

def Tree.eval (T : Tree) (x : Nat → Bool) : Bool := match T with
  | .terminal b => b
  | .branch j lo hi => if x j then hi.eval x else lo.eval x

def Tree.nodes : Tree → Nat
  | .terminal _ => 0
  | .branch _ l h => 1 + l.nodes + h.nodes

def truthTree (F : List Nat → Bool) : List Nat → List Nat → Tree
  | [], acc => .terminal (F acc)
  | j :: js, acc => .branch j (truthTree F js acc) (truthTree F js (acc ++ [j]))

theorem truth_eval (F : List Nat → Bool) (x : Nat → Bool) (B acc : List Nat) :
    (truthTree F B acc).eval x = F (acc ++ B.filter x) := by
  induction B generalizing acc with
  | nil => simp [truthTree, Tree.eval]
  | cons j B ih => cases h : x j <;> simp [truthTree, Tree.eval, h, ih]

theorem truth_size (F : List Nat → Bool) (B acc : List Nat) :
    (truthTree F B acc).nodes + 1 = 2^B.length := by
  induction B generalizing acc with
  | nil => simp [truthTree, Tree.nodes]
  | cons j B ih =>
    simp only [truthTree, Tree.nodes, List.length_cons, Nat.pow_succ]
    have h₀ := ih acc
    have h₁ := ih (acc ++ [j])
    omega

open HWB.Response

noncomputable def witness (i : RootKey A B) : List Nat := Classical.choose i.property

theorem witness_spec (i : RootKey A B) : Valid A (witness i) ∧ key B (witness i) = i.val :=
  Classical.choose_spec i.property

def literal (a k : Nat) (R : List Nat) (j : Nat) (b : Bool) : Bool :=
  if a ≤ j ∧ j ≤ a+k then b == decide (j ∈ R) else true

noncomputable def leftBank (i : RootKey A B) : OrderedCounter ((witness i).length+2) :=
  primeMachine (witness i).length (literal (witness i).length B.length (witness i))

theorem leftBank_yes (i : RootKey A B) (x : Nat → Bool) :
    value (leftBank i) A x = true ↔ prime i (A.filter x) := by
  obtain ⟨hvalid,hkey⟩ := witness_spec i
  let R := witness i
  change value (primeMachine R.length (literal R.length B.length R)) A x = true ↔
    key B (A.filter x) = i.val
  rw [prime_value, ← hkey, key_iff]
  change _ ↔ (A.filter x).length = R.length ∧ _
  constructor
  · rintro ⟨hw,hr⟩
    refine ⟨hw, fun s hs => ?_⟩
    rw [hw]
    let j := R.length+s
    have hj : R.length ≤ j ∧ j ≤ R.length+B.length := by dsimp [j]; omega
    change (j ∈ A.filter x ↔ j ∈ R)
    by_cases ha : j ∈ A
    · have h := hr j ha
      simpa [literal,hj,List.mem_filter,ha] using (show x j = true ↔ j ∈ R from by
        have he : x j = decide (j ∈ R) := by simpa [literal,hj] using h
        simp [he])
    · have hn : j ∉ R := fun h => ha (hvalid.2 h)
      simp [ha,hn]
  · rintro ⟨hw,hr⟩
    refine ⟨hw, fun j ha => ?_⟩
    by_cases h : R.length ≤ j ∧ j ≤ R.length+B.length
    · have hs : j-R.length ≤ B.length := by omega
      have hj : (A.filter x).length+(j-R.length) = j := by omega
      have ht := hr (j-R.length) hs
      rw [hj] at ht
      simp only [List.mem_filter, ha, true_and] at ht
      simp only [literal,h]
      change x j = true ↔ j ∈ R at ht
      by_cases hm : j ∈ R <;> simp_all
    · simp [literal,h]

noncomputable def rightBank (i : RootKey A B) : Tree := by
  classical
  exact truthTree (fun Y => decide (sub i.val Y)) B []

theorem rightBank_yes (i : RootKey A B) (x : Nat → Bool) :
    (rightBank i).eval x = true ↔ sub i.val (B.filter x) := by
  classical
  simp [rightBank,truth_eval]

theorem banks_compute (hA : A.Nodup) (hB : B.Nodup) (x : Nat → Bool) :
    (∃ i : RootKey A B, value (leftBank i) A x = true ∧ (rightBank i).eval x = true) ↔
      ordinary ((A.filter x) ++ (B.filter x)) := by
  simp only [leftBank_yes,rightBank_yes]
  exact root_computes ⟨hA.sublist List.filter_sublist,List.filter_sublist.subset⟩
    ⟨hB.sublist List.filter_sublist,List.filter_sublist.subset⟩

end HWB.Upper
