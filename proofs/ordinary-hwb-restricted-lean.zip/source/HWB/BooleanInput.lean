import HWB.Model

namespace HWB.BooleanInput
open HWB.Model HWB.Circuit HWB.Markers

/-- Standard ordinary HWB on n Boolean inputs (Lean positions are zero based).
At Hamming weight 0 its value is false; for positive weight w it reads x[w−1]. -/
def weight (x : Fin n → Bool) := ((List.finRange n).filter x).length

def oneBased (x : Fin n → Bool) (j : Nat) : Bool :=
  if h : 1≤j ∧ j≤n then x ⟨j-1,by omega⟩ else false

def HWB (x : Fin n → Bool) := oneBased x (weight x)

@[simp] theorem oneBased_index (x : Fin n → Bool) (j : Fin n) :
    oneBased x (j.val+1) = x j := by
  have hj : 1 ≤ j.val+1 ∧ j.val+1 ≤ n := ⟨by omega,j.isLt⟩
  simp [oneBased,hj]

theorem weight_le (x : Fin n → Bool) : weight x ≤ n := by
  simpa [weight] using List.length_filter_le x (List.finRange n)

theorem weight_zero (x : Fin n → Bool) (h : weight x = 0) : HWB x = false := by
  simp [HWB,h,oneBased]

theorem weight_positive (x : Fin n → Bool) (h : 0 < weight x) :
    HWB x = x ⟨weight x-1,by have := weight_le x; omega⟩ := by
  simp [HWB,oneBased,show 1 ≤ weight x ∧ weight x ≤ n from ⟨h,weight_le x⟩]

theorem labels_eq_map (n : Nat) : labels n =
    (List.finRange n).map (fun i => i.val+1) := by
  apply List.ext_getElem (by simp [labels])
  intro i h₁ h₂
  simp [labels,Nat.add_comm]

theorem weight_labels (x : Fin n → Bool) :
    ((labels n).filter (oneBased x)).length = weight x := by
  rw [labels_eq_map,List.filter_map,List.length_map]
  change (List.filter _ (List.finRange n)).length = _
  congr 1
  apply List.filter_congr
  intro i _
  exact oneBased_index x i

def assign (O : List Nat) (hO : O.Nodup) (x : Fin n → Bool) : Assignment O :=
  ⟨O.filter (oneBased x), hO.sublist List.filter_sublist, List.filter_sublist.subset⟩

/-- The actual level query in an OBDD reads the original coordinate in its order. -/
def probe (x : Fin n → Bool) (O : List Nat) (p : Nat) := O[p]?.any (oneBased x)

theorem probe_eq (hO : O.Nodup) (x : Fin n → Bool) :
    bits O (assign O hO x).val = probe x O := by
  funext p
  unfold bits probe assign
  cases h : O[p]? with
  | none => rfl
  | some j =>
    have hj := List.mem_of_getElem? h
    simp [hj]

theorem split_perm (c : OneRoot n) : (c.A++c.B).Perm (labels n) := by
  apply (List.perm_ext_iff_of_nodup ?_ (List.nodup_range' (s:=1) (n:=n))).mpr
  · exact fun j => (c.domain j).trans mem_labels.symm
  · exact List.nodup_append.mpr ⟨c.na,c.nb,fun _ ha _ hb e => c.dis _ ha (e ▸ hb)⟩

theorem assignment_weight (c : OneRoot n) (x : Fin n → Bool) :
    (assign c.A c.na x).val.length + (assign c.B c.nb x).val.length = weight x := by
  have he := ((split_perm c).filter (oneBased x)).length_eq
  simpa [assign,List.filter_append,weight_labels] using he

theorem decision_on_vector (c : OneRoot n) (x : Fin n → Bool) :
    c.dec.run (assign c.A c.na x) (assign c.B c.nb x) = HWB x := by
  rw [c.correct,assignment_weight]
  rw [Bool.eq_iff_iff]
  simp only [assign,List.mem_append,List.mem_filter,decide_eq_true_eq,HWB]
  by_cases e : oneBased x (weight x)=true
  · have hn := weight_le x
    have hp : 1 ≤ weight x := by
      by_cases hz : weight x=0
      · simp [oneBased,hz] at e
      · omega
    have hu := (c.domain _).mpr ⟨hp,hn⟩
    simpa [e] using List.mem_append.mp hu
  · simp [e]

/-- The selected prime actually accepts, all other primes reject, and its
right OBDD computes ordinary Boolean-vector HWB on every original assignment. -/
theorem actual_dags_on_vector (c : OneRoot n) (x : Fin n → Bool) :
    ∃ i : Fin c.R,
      (∀ j : Fin c.R, c.gP.eval (probe x c.A) (c.pRoot j) = true ↔ i = j) ∧
      c.gS.eval (probe x c.B) (c.sRoot i) = HWB x := by
  refine ⟨c.dec.selectCase (assign c.A c.na x), ?_, ?_⟩
  · intro j
    rw [← probe_eq c.na x, ← c.prime_eq, c.dec.partition]
  · rw [← probe_eq c.nb x,← c.sub_eq]
    exact decision_on_vector c x

end HWB.BooleanInput
