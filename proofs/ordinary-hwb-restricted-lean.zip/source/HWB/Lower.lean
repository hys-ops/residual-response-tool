import HWB.LowerAssembly
import HWB.SmallRightCircuit
import HWB.GapBridge

namespace HWB.Model

/-- All partitions, both arbitrary orders, both shared banks, and the same wire
measure. The constants are deliberately loose and the statement is nonasymptotic. -/
theorem OneRoot.lower_at_scale (c : OneRoot n) {u : Nat} (hu : 0 < u)
    (large : (128*u)*(128*u) ≤ n) : 2^u ≤ c.wires := by
  have costs := sizes_le_wires c
  by_cases ha : 8*u ≤ c.A.length
  · by_cases hb : 8*u ≤ c.B.length
    · exact Nat.le_trans (root_balanced c u hu ha hb) costs.1
    · have h8 : c.B.length+1 ≤ 8*u := by omega
      have u2 : 1 ≤ u*u := Nat.mul_pos hu hu
      have scale : (128*u)*(128*u) = 16384*(u*u) := by
        calc _ = (128*128)*(u*u) := by ac_rfl
             _ = _ := rfl
      have hn : 4096 ≤ n := by omega
      have b2 := Nat.mul_le_mul (Nat.le_trans (Nat.le_succ _) h8)
        (Nat.le_trans (Nat.le_succ _) h8)
      have h64 := Nat.mul_le_mul_left 64 b2
      have g64 : 64*((8*u)*(8*u)) = 4096*(u*u) := by
        calc _ = (64*(8*8))*(u*u) := by ac_rfl
             _ = _ := rfl
      have h1024 := Nat.mul_le_mul_left 1024 (Nat.mul_le_mul_right u h8)
      have g1024 : 1024*((8*u)*u) = 8192*(u*u) := by
        calc _ = (1024*8)*(u*u) := by ac_rfl
             _ = _ := rfl
      exact Nat.le_trans (c.small_right_exponent hn (by omega) (by omega)) costs.2.1
  · have h16 : c.A.length ≤ 16*u := by omega
    have le : 16*u+1 ≤ 32*u := by omega
    have h3 := Nat.mul_le_mul_left 3 (Nat.mul_le_mul le le)
    have scale : (128*u)*(128*u) = 16384*(u*u) := by
      calc _ = (128*128)*(u*u) := by ac_rfl
           _ = _ := rfl
    have g3 : 3*((32*u)*(32*u)) = 3072*(u*u) := by
      calc _ = (3*(32*32))*(u*u) := by ac_rfl
           _ = _ := rfl
    have fin := GapBridge.small_left_DAG c (16*u) h16 (by omega)
    have hd : (16*u)/16 = u := by omega
    rw [hd] at fin
    exact Nat.le_trans fin costs.2.2

theorem OneRoot.lower (c : OneRoot n) : 2^(n.sqrt/128) ≤ c.wires := by
  by_cases h : 0 < n.sqrt/128
  · apply c.lower_at_scale h
    have le := Nat.mul_div_le n.sqrt 128
    exact Nat.le_trans (Nat.mul_le_mul le le) (Nat.sqrt_le n)
  · have eq : n.sqrt/128 = 0 := by omega
    have hp := positive_elements c
    have hc := (sizes_le_wires c).1
    simpa [eq] using (show 1 ≤ c.wires by omega)

end HWB.Model
