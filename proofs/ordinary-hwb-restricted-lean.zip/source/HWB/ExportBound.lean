import HWB.Sentential
import HWB.Sparse
import HWB.BooleanInput

namespace HWB.Sentential
open HWB.Model HWB.BooleanInput

/-- The factor 3 in export_cost changes the verified 512 prefactor to 1536.
The same literal AND/OR table handles every ordinary Boolean input. -/
theorem ordinary_explicit_SDD_upper (hn : 3 ≤ n) :
    ∃ c : OneRoot n, (exportRoot c).wires ≤ 1536*n^3*2^(n.sqrt+1) ∧
      (∀ x : Fin n → Bool,
        (exportRoot c).eval (probe x c.A) (probe x c.B) = HWB x) := by
  obtain ⟨c, hc⟩ := HWB.Sparse.paper_upper hn
  refine ⟨c, ?_, ?_⟩
  · calc
      (exportRoot c).wires ≤ 3*c.wires := export_cost c
      _ ≤ 3*(512*n^3*2^(n.sqrt+1)) := Nat.mul_le_mul_left 3 hc
      _ = 1536*n^3*2^(n.sqrt+1) := by
        rw [← Nat.mul_assoc, ← Nat.mul_assoc]
  · intro x
    rw [← probe_eq c.na x, ← probe_eq c.nb x,
      export_correct c (assign c.A c.na x) (assign c.B c.nb x)]
    exact (c.correct _ _).symm.trans (decision_on_vector c x)

end HWB.Sentential
