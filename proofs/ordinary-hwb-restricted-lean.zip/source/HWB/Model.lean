import HWB.Circuit
import HWB.Markers

namespace HWB.Model
open HWB.Circuit

abbrev Assignment (bank : List Nat) := {S : List Nat // S.Nodup ∧ S ⊆ bank}

def bits (order ones : List Nat) (pos : Nat) : Bool :=
  (order[pos]?).any (fun j => decide (j ∈ ones))

/-- Two banks allow full sharing between the root elements. Nonterminal nodes
on opposite sides of a nonempty disjoint split query disjoint variable sets.
Each bank uses its listed order; out-of-range positions, even if allocated,
read a fixed false. Left consistency is required for every root element. -/
structure OneRoot (n : Nat) where
  A : List Nat
  B : List Nat
  na : A.Nodup
  nb : B.Nodup
  dis : ∀ j ∈ A, j ∉ B
  domain : ∀ j, j ∈ A ++ B ↔ 1 ≤ j ∧ j ≤ n
  total : A.length + B.length = n
  left_nonempty : A ≠ []
  right_nonempty : B ≠ []
  R : Nat
  NP : Nat
  NS : Nat
  gP : DAG NP
  gS : DAG NS
  pRoot : Fin R → State NP
  sRoot : Fin R → State NS
  dec : Decision (Assignment A) (Assignment B) R
  prime_eq : ∀ i x, dec.prime i x = gP.eval (bits A x.val) (pRoot i)
  sub_eq : ∀ i y, dec.sub i y = gS.eval (bits B y.val) (sRoot i)
  feasible : ∀ i, ∃ x, dec.selectCase x = i
  correct : ∀ x y, dec.run x y = decide (x.val.length+y.val.length ∈ x.val++y.val)

def OneRoot.wires (c : OneRoot n) : Nat := 3*c.R + 2*(c.NP+c.NS)

end HWB.Model
