import HWB.Lower
import HWB.ReducedModel
import HWB.UpperFinal
import HWB.Prefix

namespace HWB

/-- Any nonempty set of natural-number costs contains its minimum. -/
private theorem attainable_minimum (P : Nat → Prop) (w : Nat) (hw : P w) :
    ∃ z, P z ∧ ∀ v, P v → z ≤ v := by
  induction w using Nat.strongRecOn with
  | ind w ih =>
    by_cases h : ∃ u, u < w ∧ P u
    · obtain ⟨u,hu,hp⟩ := h
      exact ih u hu hp
    · exact ⟨w,hw,fun v hv => by
        by_cases hh : w ≤ v
        · exact hh
        · exact False.elim (h ⟨v,by omega,hv⟩)⟩

open HWB.Model

/-- The optimum is taken over ALL root splits and BOTH arbitrary orders. A
normalized circuit still attains it. This is an actual minimum, with finite
witnesses for the upper bound and a universal competing-circuit lower bound. -/
theorem ordinary_one_root_optimum (hn : 3 ≤ n) :
    ∃ c : OneRoot n, c.Normalized ∧ (∀ d : OneRoot n, c.wires ≤ d.wires) ∧
      2^(n.sqrt/128) ≤ c.wires ∧ c.wires ≤ 2^(7*(n.sqrt+1)+6) := by
  obtain ⟨u,hu⟩ := UpperFinal.subexponential_upper hn
  let P := fun w => ∃ c : OneRoot n, c.wires = w
  obtain ⟨w,⟨best,be⟩,least⟩ := attainable_minimum P u.wires ⟨u,rfl⟩
  have all (c : OneRoot n) : best.normalize.wires ≤ c.wires := by
    exact Nat.le_trans best.normalize_wires (be ▸ least _ ⟨c,rfl⟩)
  exact ⟨best.normalize, best.normalize_isNormalized, all, best.normalize.lower,
    Nat.le_trans (all u) hu⟩

/-- Same growth law with one common ordered prefix, including different
exit-dependent partitions. Front.size is a lower bound on physical resources;
the upper witness embeds the explicit circuit with an empty prefix. -/
theorem ordinary_ordered_prefix_optimum (hn : 3 ≤ n) :
    ∃ f : Slice.Front n, (∀ g : Slice.Front n, f.size ≤ g.size) ∧
      2^(n.sqrt/1024) ≤ f.size ∧ f.size ≤ 2^(7*(n.sqrt+1)+6) := by
  obtain ⟨c,_,_,_,hi⟩ := ordinary_one_root_optimum hn
  let u := Slice.emptyFront c
  let P := fun w => ∃ f : Slice.Front n, f.size = w
  obtain ⟨w,⟨f,be⟩,least⟩ := attainable_minimum P u.size ⟨u,rfl⟩
  have all (g : Slice.Front n) : f.size ≤ g.size := be ▸ least _ ⟨g,rfl⟩
  exact ⟨f,all,f.lower,Nat.le_trans (all u) (by simpa [u,Slice.emptyFront_size] using hi)⟩

end HWB
