import HWB.UpperDAG
import HWB.UpperAssembly

namespace HWB.UpperFinal
open HWB.Response HWB.Upper HWB.UpperAssembly HWB.Circuit HWB.Model HWB.Markers

abbrev L (n : Nat) := Markers.left n
abbrev R (n : Nat) := Markers.right n

/-- The complete right-hand component interface for the concrete marker split. -/
structure RightBank (n s : Nat) where
  r : RootKey (L n) (R n) → DAG s
  srcS : RootKey (L n) (R n) → State s
  specS : ∀ i (y : Assignment (R n)),
    (r i).eval (bits (R n) y.val) (srcS i) = true ↔ sub i.val y.val

def sparseCost (n : Nat) := (R n).length * (16*((R n).length+1))

noncomputable def fullRight (n : Nat) (hn : 3≤n) : RightBank n (subNodes (R n)) :=
  ⟨subDAG,subStart,subDAG_yes (right_nodup hn)⟩

theorem concrete_dis (n : Nat) : Separated (R n) (L n) :=
  fun _ hj => (mem_left.mp hj).2

theorem concrete_domain (n : Nat) (hn : 3 ≤ n) (j : Nat) :
    j ∈ L n ++ R n ↔ 1≤j ∧ j≤n := by
  rw [List.mem_append]
  refine ⟨fun h => ?_, fun h => ?_⟩
  · rcases h with h | h
    · exact mem_labels.mp (mem_left.mp h).1
    · exact right_bounds hn h
  · by_cases hj : j ∈ R n
    · exact Or.inr hj
    · exact Or.inl (mem_left.mpr ⟨mem_labels.mpr h,hj⟩)

theorem concrete_cover (n : Nat) (hn : 3≤n) : Covered (R n) (L n).length := by
  intro a h
  change a ≤ (Markers.left n).length at h
  have t := split_length hn
  exact right_covers hn (by omega)

theorem left_ne (n : Nat) (hn : 3≤n) : L n ≠ [] := by
  have t := split_length hn
  have sq := Nat.sqrt_le n
  have h1 := sqrt_pos_of_three hn
  have le : n.sqrt+1 < n := by
    by_cases h : n.sqrt=1
    · omega
    · have hm := Nat.mul_le_mul_left n.sqrt (show 2 ≤ n.sqrt by omega)
      rw [Nat.mul_two] at hm; omega
  intro h
  change Markers.left n = [] at h
  rw [h,right_length] at t
  simp at t
  omega

theorem right_ne (n : Nat) : R n ≠ [] := by simp [R,Markers.right]

noncomputable def withRight {n s} (hn : 3 ≤ n) (sbank : RightBank n s) : OneRoot n :=
  assemble (L n) (R n) (left_nodup _) (right_nodup hn) (concrete_dis _)
    (concrete_cover _ hn) (concrete_domain _ hn) (split_length hn)
    (left_ne _ hn) (right_ne _) ⟨primeDAG,sbank.r,primeStart,sbank.srcS,
      primeDAG_yes (left_nodup _),sbank.specS⟩

theorem withRight_size {n s} (hn : 3≤n) (sbank : RightBank n s) :
    (withRight hn sbank).wires ≤ ((L n).length+1)*2^((R n).length+1) *
      (3+2*(primeNodes (L n)+s)) :=
  assemble_wires .. 

/-- The straightforward full-right DAGs already yield the square-root exponent
without any sparse-window machine. -/
theorem full_upper (hn : 3≤n) : ∃ c : OneRoot n, c.wires ≤
    ((L n).length+1)*2^((R n).length+1)*
      (3+2*((L n).length*((L n).length+2)+(R n).length*2^(R n).length)) :=
  ⟨withRight hn (fullRight n hn),withRight_size hn _⟩

/-- Concrete polynomial-prefactor accounting for any implementation of the
four-slot right bank. A further theorem instantiates it with an actual DAG. -/
theorem paper_upper_from_sparse {n : Nat} (hn : 3≤n) (sbank : RightBank n (sparseCost n)) :
    ∃ c : OneRoot n, c.wires ≤ 512*n^3*2^(n.sqrt+1) := by
  let m := (L n).length
  let k := (R n).length
  let E := 2^k
  have ht : m+k=n := split_length hn
  have hms : m+1 ≤ 2*n := by omega
  have hmk : m+2 ≤ 2*n := by omega
  have hkk : k+1 ≤ 2*n := by omega
  have hp := Nat.mul_le_mul (show m≤n by omega) hmk
  have hr := Nat.mul_le_mul (show k≤n by omega) (Nat.mul_le_mul_left 16 hkk)
  have hp' : m*(m+2) ≤ 2*(n*n) := by
    calc _ ≤ n*(2*n) := hp
         _ = _ := by ac_rfl
  have hr' : k*(16*(k+1)) ≤ 32*(n*n) := by
    calc _ ≤ n*(16*(2*n)) := hr
         _ = (16*2)*(n*n) := by ac_rfl
         _ = _ := rfl
  have hpos : 1 ≤ n*n := Nat.mul_pos (by omega) (by omega)
  have factor : 3+2*(m*(m+2)+k*(16*(k+1))) ≤ 128*(n*n) := by omega
  refine ⟨withRight hn sbank, Nat.le_trans (withRight_size hn sbank) ?_⟩
  change (m+1)*2^(k+1)*(3+2*(m*(m+2)+k*(16*(k+1)))) ≤ _
  rw [Nat.pow_succ]
  have hc := Nat.mul_le_mul_right (E*2) hms
  have main := Nat.mul_le_mul hc factor
  calc _ ≤ 2*n*(E*2)*(128*(n*n)) := main
       _ = (2*2*128) * (n*(n*n)) * E := by ac_rfl
       _ = 512*n^3*2^(n.sqrt+1) := by simp [E,k,right_length,Nat.pow_succ,Nat.mul_assoc]

/-- An unconditional, clean subexponential bound. No closed-form window
arithmetic beyond existence of the marker set is needed for this version. -/
theorem subexponential_upper {n : Nat} (hn : 3≤n) :
    ∃ c : OneRoot n, c.wires ≤ 2^(7*(n.sqrt+1)+6) := by
  obtain ⟨c,hc⟩ := full_upper hn
  let m := (L n).length
  let k := (R n).length
  change c.wires ≤ (m+1)*2^(k+1)*(3+2*(m*(m+2)+k*2^k)) at hc
  have hw : k = n.sqrt+1 := right_length n
  have ht : m+k=n := split_length hn
  have hk : k≤2^k := Nat.le_of_lt Nat.lt_two_pow_self
  have hh := Nat.lt_succ_sqrt n
  have hnkk : n ≤ k*k := by simpa only [hw] using Nat.le_of_lt hh
  have hnk : n ≤ 2^(2*k) := by
    rw [Nat.two_mul,Nat.pow_add]
    exact Nat.le_trans hnkk (Nat.mul_le_mul hk hk)
  have hmk : m+2 ≤ 2^(2*k+1) := by
    rw [Nat.pow_succ]; omega
  have hp : m*(m+2) ≤ 2^(4*k+1) := by
    have he : 4*k+1 = (2*k)+(2*k+1) := by omega
    rw [he,Nat.pow_add]
    exact Nat.mul_le_mul (by omega) hmk
  have hs : k*2^k ≤ 2^(4*k+1) := by
    calc _ ≤ 2^k*2^k := Nat.mul_le_mul_right _ hk
         _ = 2^(k+k) := (Nat.pow_add ..).symm
         _ ≤ _ := Nat.pow_le_pow_of_le (by decide) (by omega)
  have hp1 : 1 ≤ 2^(4*k+1) := Nat.one_le_two_pow
  have hfac : 3+2*(m*(m+2)+k*2^k) ≤ 2^(4*k+4) := by
    rw [show 4*k+4 = (4*k+1)+3 by omega,Nat.pow_add]
    change _ ≤ 2^(4*k+1)*8
    omega
  have hcap : (m+1)*2^(k+1) ≤ 2^(3*k+2) := by
    calc _ ≤ 2^(2*k+1)*2^(k+1) := Nat.mul_le_mul_right _ (by omega)
         _ = 2^((2*k+1)+(k+1)) := (Nat.pow_add ..).symm
         _ = _ := congrArg (2^·) (by omega)
  refine ⟨c,Nat.le_trans hc ?_⟩
  calc _ ≤ 2^(3*k+2)*2^(4*k+4) := Nat.mul_le_mul hcap hfac
       _ = 2^((3*k+2)+(4*k+4)) := (Nat.pow_add ..).symm
       _ = _ := congrArg (2^·) (by omega)

end HWB.UpperFinal
