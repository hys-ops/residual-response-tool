import HWB.Upper
import HWB.Model

namespace HWB.Upper
open HWB.Circuit HWB.Response

/-- Include a state in a larger node set without changing its address. -/
def promote (h : N ≤ T) : State N → State T
  | .term b => .term b
  | .node i => .node ⟨i.val, Nat.lt_of_lt_of_le i.isLt h⟩

theorem promote_height (h : N ≤ T) (s : State N) : (promote h s).height = s.height := by
  cases s <;> rfl

/-- Add q nodes at a new first level; the old bank is not duplicated. -/
def prepend (g : DAG N) (q : Nat) (entry : Fin q → Bool → State N) : DAG (N+q) where
  level i := if h : i.val < N then g.level ⟨i.val,h⟩+1 else 0
  child i b := if h : i.val < N then promote (Nat.le_add_right ..) (g.child ⟨i.val,h⟩ b)
    else promote (Nat.le_add_right ..) (entry ⟨i.val-N,by have := i.isLt; omega⟩ b)
  drops i b := by
    split
    · rw [promote_height]; exact g.drops _ _
    · rw [promote_height]
      cases hm : entry _ b with
      | term _ => simp [State.height]
      | node j => simp [State.height]; have := j.isLt; omega
  advances i b j hj := by
    split at hj
    · rename_i hi
      cases h : g.child ⟨i.val,hi⟩ b with
      | term v => simp [h,promote] at hj
      | node u =>
        simp [h,promote] at hj
        subst j
        simpa [hi,u.isLt] using g.advances _ _ _ h
    · rename_i hi
      cases h : entry ⟨i.val-N,by have := i.isLt; omega⟩ b with
      | term v => simp [h,promote] at hj
      | node u =>
        simp [h,promote] at hj
        subst j
        simp [hi,u.isLt]

theorem prepend_old (g : DAG N) (q : Nat) (entry : Fin q → Bool → State N)
    (x : Nat → Bool) (s : State N) :
    (prepend g q entry).eval x (promote (Nat.le_add_right ..) s) =
    g.eval (fun i => x (i+1)) s := by
  cases s with
  | term v => simp [promote,DAG.eval]
  | node i =>
    rw [show promote (Nat.le_add_right N q) (.node i) = (.node ⟨i.val,by omega⟩) from rfl]
    conv => lhs; rw [DAG.eval]
    conv => rhs; rw [DAG.eval]
    simp [prepend,i.isLt]
    apply prepend_old
termination_by s.height
decreasing_by apply g.drops

def top (N : Nat) (s : Fin q) : State (N+q) := .node ⟨N+s.val, by omega⟩

theorem prepend_top (g : DAG N) (q : Nat) (entry : Fin q → Bool → State N)
    (x : Nat → Bool) (s : Fin q) :
    (prepend g q entry).eval x (top N s) =
      g.eval (fun i => x (i+1)) (entry s (x 0)) := by
  rw [top,DAG.eval]
  have hn : ¬ (N+s.val < N) := by omega
  simpa [prepend,hn] using prepend_old g q entry x (entry s (x 0))

structure Bank (q : Nat) where
  N : Nat
  g : DAG N
  root : Fin q → State N

def compile (M : OrderedCounter q) : List Nat → Bank q
  | [] => ⟨0, {level := Fin.elim0, child := Fin.elim0, drops := fun i => i.elim0, advances := fun i => i.elim0},
      fun s => .term (M.accept s)⟩
  | j::js =>
    let tail := compile M js
    ⟨tail.N+q, prepend tail.g q (fun s b => tail.root (M.next j s b)), top tail.N⟩

theorem compile_size (M : OrderedCounter q) (order : List Nat) :
    (compile M order).N = order.length*q := by
  induction order with
  | nil => simp [compile]
  | cons j js ih => simp [compile, ih, Nat.succ_mul]

def orderedInput (ord : List Nat) (x : Nat → Bool) (pos : Nat) := (ord[pos]?).any x

theorem compile_eval (M : OrderedCounter q) (order : List Nat) (x : Nat → Bool) (s : Fin q) :
    (compile M order).g.eval (orderedInput order x) ((compile M order).root s)
      = M.accept (go M x order s) := by
  induction order generalizing s with
  | nil => simp [compile,go,DAG.eval]
  | cons j js ih =>
    simp only [compile,go]
    rw [prepend_top]
    exact ih _

def pad (g : DAG N) (h : N ≤ T) : DAG T where
  level i := if hi : i.val < N then g.level ⟨i.val,hi⟩ else 0
  child i b := if hi : i.val < N then promote h (g.child ⟨i.val,hi⟩ b) else .term false
  drops i b := by
    split
    · rw [promote_height]; exact g.drops _ _
    · simp [State.height]
  advances i b j hj := by
    split at hj
    · rename_i hi
      cases hh : g.child ⟨i.val,hi⟩ b with
      | term v => simp [hh,promote] at hj
      | node u =>
        simp [hh,promote] at hj
        subst j
        simpa [hi,u.isLt] using g.advances _ _ _ hh
    · contradiction

theorem pad_eval (g : DAG N) (h : N ≤ T) (x : Nat → Bool) (s : State N) :
    (pad g h).eval x (promote h s) = g.eval x s := by
  cases s with
  | term v => simp [promote,DAG.eval]
  | node i =>
    rw [show promote h (.node i) = (.node ⟨i.val,by omega⟩) from rfl]
    conv => lhs; rw [DAG.eval]
    conv => rhs; rw [DAG.eval]
    simp [pad,i.isLt]
    apply pad_eval
termination_by s.height
decreasing_by apply g.drops

theorem filter_assignment (hn : A.Nodup) (x : Model.Assignment A) :
    (A.filter (fun j => decide (j ∈ x.val))).length = x.val.length ∧
    ∀ j, (j ∈ A.filter (fun j => decide (j ∈ x.val)) ↔ j ∈ x.val) := by
  have hm (j) : (j ∈ A.filter (fun j => decide (j ∈ x.val)) ↔ j ∈ x.val) := by
    simp only [List.mem_filter,decide_eq_true_eq]
    exact ⟨And.right,fun h => ⟨x.property.2 h,h⟩⟩
  have h₁ := (hn.sublist (List.filter_sublist (p:=fun j => decide (j ∈ x.val)))).length_le_of_subset
    (fun {j} h => (hm j).mp h)
  have h₂ := x.property.1.length_le_of_subset (fun {j} h => (hm j).mpr h)
  exact ⟨by omega,hm⟩

def primeNodes (A : List Nat) := A.length*(A.length+2)
def subNodes (B : List Nat) := B.length*2^B.length

theorem left_size_le (i : RootKey A B) : (compile (leftBank i) A).N ≤ primeNodes A := by
  rw [compile_size]
  apply Nat.mul_le_mul_left
  have h := (witness_spec i).1
  have := h.1.length_le_of_subset h.2
  omega

noncomputable def primeDAG (i : RootKey A B) : DAG (primeNodes A) :=
  pad (compile (leftBank i) A).g (left_size_le i)
noncomputable def primeStart (i : RootKey A B) : State (primeNodes A) :=
  promote (left_size_le i) ((compile (leftBank i) A).root (leftBank i).initial)

theorem primeDAG_yes (hA : A.Nodup) (i : RootKey A B) (x : Model.Assignment A) :
    (primeDAG i).eval (Model.bits A x.val) (primeStart i) = true ↔ prime i x.val := by
  let χ := fun j => decide (j ∈ x.val)
  change (pad _ _).eval (orderedInput A χ) (promote _ _) = true ↔ _
  rw [pad_eval,compile_eval]
  change value (leftBank i) A χ = true ↔ _
  rw [leftBank_yes]
  obtain ⟨hl,hm⟩ := filter_assignment hA x
  have hk : key B (A.filter χ) = key B x.val := key_iff.mpr ⟨hl,fun s _ => hm _⟩
  exact congrArg (fun w => w = i.val) hk |> Iff.of_eq

private theorem idx_inj {B : List Nat} {i j : Nat} (hi : i ∈ B) (hj : j ∈ B) :
    B.idxOf i = B.idxOf j ↔ i=j := by
  refine ⟨fun he => ?_, fun h => by rw [h]⟩
  have h₁ := List.getElem_idxOf (List.idxOf_lt_length_of_mem hi)
  have h₂ := List.getElem_idxOf (List.idxOf_lt_length_of_mem hj)
  have hli := List.idxOf_lt_length_of_mem hi
  have hlj := List.idxOf_lt_length_of_mem hj
  have hc : B[B.idxOf i] = B[B.idxOf j] := by simp only [he]
  exact h₁.symm.trans (hc.trans h₂)

def mark (B : List Nat) (j : Nat) (s : Fin (2^B.length)) (b : Bool) : Fin (2^B.length) :=
  if hj : j ∈ B then
    if b then ⟨s.val ||| 2^(B.idxOf j),
      Nat.or_lt_two_pow s.isLt (Nat.pow_lt_pow_right (by decide) (List.idxOf_lt_length_of_mem hj))⟩
    else s
  else s

noncomputable def subMachine (i : RootKey A B) : OrderedCounter (2^B.length) := by
  classical
  exact { initial := ⟨0,Nat.two_pow_pos _⟩, next := mark B,
          accept := fun s => decide (sub i.val (B.filter fun j => s.val.testBit (B.idxOf j))) }

theorem read_mask (i : RootKey A B) (x : Nat → Bool) (s : Fin (2^B.length))
    (hi : j ∈ B) (L : List Nat) (hs : L ⊆ B) :
    (go (subMachine i) x L s).val.testBit (B.idxOf j) =
      (s.val.testBit (B.idxOf j) || decide (j ∈ L.filter x)) := by
  induction L generalizing s with
  | nil => simp [go]
  | cons k L ih =>
    rw [go,ih _ (fun _ h => hs (List.mem_cons_of_mem _ h))]
    have hk := hs List.mem_cons_self
    cases hb : x k <;> by_cases he : k=j <;>
      simp_all [subMachine,mark, idx_inj hk hi, Ne.symm, Bool.or_comm]

theorem sub_machine_yes (i : RootKey A B) (x : Nat → Bool) :
    value (subMachine i) B x = true ↔ sub i.val (B.filter x) := by
  classical
  let M := subMachine i
  let s := go M x B M.initial
  have he : B.filter (fun j => s.val.testBit (B.idxOf j)) = B.filter x := by
    apply List.filter_congr
    intro j hj
    have h := read_mask i x M.initial hj B (fun _ h => h)
    simpa [s,M,subMachine, Nat.zero_testBit,hj] using h
  change decide (sub i.val (B.filter (fun j => s.val.testBit (B.idxOf j)))) = true ↔ _
  rw [he,decide_eq_true_eq]

theorem right_size_le (i : RootKey A B) : (compile (subMachine i) B).N ≤ subNodes B :=
  Nat.le_of_eq (compile_size ..)

noncomputable def subDAG (i : RootKey A B) : DAG (subNodes B) :=
  pad (compile (subMachine i) B).g (right_size_le i)
noncomputable def subStart (i : RootKey A B) : State (subNodes B) :=
  promote (right_size_le i) ((compile (subMachine i) B).root (subMachine i).initial)

theorem subDAG_yes (hB : B.Nodup) (i : RootKey A B) (y : Model.Assignment B) :
    (subDAG i).eval (Model.bits B y.val) (subStart i) = true ↔ sub i.val y.val := by
  let χ := fun j => decide (j ∈ y.val)
  change (pad _ _).eval (orderedInput B χ) (promote _ _) = true ↔ _
  rw [pad_eval,compile_eval]
  change value (subMachine i) B χ = true ↔ _
  rw [sub_machine_yes]
  obtain ⟨hl,hm⟩ := filter_assignment hB y
  simp only [sub,χ,hl,hm]

end HWB.Upper
