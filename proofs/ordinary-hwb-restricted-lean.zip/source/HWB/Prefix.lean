import HWB.SmallRightSlice
import HWB.SliceGap
import HWB.LowerAssembly

namespace HWB.Slice
open HWB.Circuit HWB.Model

/-- A finite-state scan of D, followed by a root decomposition chosen by its
exit state. Allowing transitions to depend on the current level only
strengthens the prefix. post gives the extensional semantics of the actual
exit hardware on its remaining, original labels. -/
structure Front (n : Nat) where
  D : List Nat
  F : List Nat
  unique : (D++F).Nodup
  total : D.length + F.length = n
  bounds : ∀ j ∈ D++F, j ≤ n
  W : Nat
  initial : Fin W
  step : Nat → Fin W → Bool → Fin W
  exit : Fin W → Hardware n D
  rest : ∀ e j, j ∈ (exit e).A ++ (exit e).B ↔ j ∈ F
  post : Fin W → List Nat → Bool
  exitCorrect : ∀ e x y, (exit e).dec.run x y = post e (x.val++y.val)
  correct : ∀ x, Balanced.Legal (D++F) x →
    post (Balanced.scan step D x initial) (x.filter (fun j => decide (j∈F))) =
    decide (x.length ∈ x)

/-- The original labels are precisely 1,...,n. This follows from the
root-domain condition at even one exit, including the positivity direction. -/
theorem Front.label_domain (c : Front n) (j : Nat) :
    j∈c.D++c.F ↔ 1≤j ∧ j≤n := by
  have h := (c.exit c.initial).domain j
  have rest := c.rest c.initial j
  simpa only [List.mem_append, rest, or_comm] using h

def maxCost : List Nat → Nat := List.foldr Nat.max 0

private theorem maxCost_member {l : List Nat} (h : s∈l) : s ≤ maxCost l := by
  induction l with
  | nil => simp at h
  | cons a l ih =>
    change s ≤ max a (maxCost l)
    rcases List.mem_cons.mp h with rfl|hs
    · exact Nat.le_max_left _ _
    · exact Nat.le_trans (ih hs) (Nat.le_max_right _ _)

/-- A lower cost measure that permits arbitrary sharing between exits: at
least the prefix state count and at least the largest single exit wire count.
Charging the union of exit banks cannot reduce this measure. -/
def Front.size (c : Front n) := max c.W (maxCost ((List.finRange c.W).map (fun i => (c.exit i).wires)))

theorem Front.exit_le (c : Front n) (e : Fin c.W) : (c.exit e).wires ≤ c.size := by
  apply Nat.le_trans _ (Nat.le_max_right _ _)
  exact maxCost_member (List.mem_map.mpr ⟨e,List.mem_finRange e,rfl⟩)

def Front.zeroIndex (c : Front n) := Balanced.scan c.step c.D [] c.initial

/-- Fixing the real prefix to zero selects one real exit even when its split
and orders depend on the final state. -/
def Front.zeroRoot (c : Front n) : ZeroRoot n c.D where
  toHardware := c.exit c.zeroIndex
  correct x y := by
    let e := c.zeroIndex
    have rem : x.val++y.val ⊆ c.F := by
      intro j hj
      apply (c.rest e j).mp
      rcases List.mem_append.mp hj with h|h
      · exact List.mem_append_left _ (x.property.2 h)
      · exact List.mem_append_right _ (y.property.2 h)
    have uniq : (x.val++y.val).Nodup := List.nodup_append.mpr
      ⟨x.property.1,y.property.1,fun j hj l hl ej => (c.exit e).dis j (x.property.2 hj) (ej ▸ y.property.2 hl)⟩
    have lg : Balanced.Legal (c.D++c.F) (x.val++y.val) :=
      ⟨uniq,fun _ hj => List.mem_append_right _ (rem hj)⟩
    have fc := (List.nodup_append.mp c.unique).2.2
    have scan0 : Balanced.scan c.step c.D (x.val++y.val) c.initial = e := by
      apply Balanced.scan_congr
      intro j hj; simp only [List.not_mem_nil, iff_false]
      intro hm; exact fc j hj j (rem hm) rfl
    have hf : (x.val++y.val).filter (fun j => decide (j∈c.F)) = x.val++y.val := by
      apply List.filter_eq_self.mpr; intro j hj; simpa using rem hj
    have hh := c.correct _ lg
    rw [scan0,hf] at hh
    rw [c.exitCorrect]
    simpa using hh

private theorem squash {l u a w n : Nat} (hl : l ≤ a*u)
    (hw : w*a*a ≤ 1024*1024) (h : (1024*u)*(1024*u) ≤ n) : w*(l*l) ≤ n := by
  calc w*(l*l) ≤ w*((a*u)*(a*u)) := Nat.mul_le_mul_left w (Nat.mul_le_mul hl hl)
       _ = (w*a*a)*(u*u) := by ac_rfl
       _ ≤ (1024*1024)*(u*u) := Nat.mul_le_mul_right _ hw
       _ = (1024*u)*(1024*u) := by ac_rfl
       _ ≤ n := h

/-- The only exit whose hardware is charged is actually reached by the all-zero
ordered prefix. Unreachable or shared exit circuits cannot inflate the bound. -/
def Front.reachedCost (c : Front n) := max c.W (c.exit c.zeroIndex).wires

theorem Front.lower_at_scale_reached (c : Front n) (t : Nat) (ht : 0<t)
    (large : (1024*t)*(1024*t) ≤ n) : 2^t ≤ c.reachedCost := by
  have h16 : 16*t ≤ n := by
    have hz := Nat.le_mul_of_pos_left (1024*t) (show 0<1024*t by omega)
    omega
  by_cases long : 8*t ≤ c.D.length
  · have boundj : ∀ j∈c.D++c.F,j≤c.D.length+c.F.length := by simpa [c.total] using c.bounds
    have hh := Balanced.long_prefix_width c.D c.F c.W (8*t) t c.unique boundj ht long
      (Nat.le_refl _) (by rw [c.total]; omega : 8*t+8*t≤c.D.length+c.F.length)
      c.step c.initial c.post c.correct
    exact Nat.le_trans hh (Nat.le_max_left _ _)
  · let z := c.zeroRoot
    have hD : c.D.length ≤ 8*t := by omega
    have costs := z.sizes_le_wires
    apply Nat.le_trans _ (Nat.le_max_right _ _)
    change 2^t ≤ z.wires
    by_cases ha : 64*t ≤ z.A.length
    · by_cases hb : 8*t ≤ z.B.length
      · exact Nat.le_trans (z.balanced t ht (by omega) hb (by omega)) costs.1
      · have bk : z.B.length+1 ≤ 8*t := by omega
        have b2 := squash (Nat.le_trans (Nat.le_succ _) bk) (by decide : 64*8*8 ≤ 1024*1024) large
        have d2 := squash hD (by decide : 64*8*8 ≤ 1024*1024) large
        have a1 := Nat.mul_le_mul_left 1024 (Nat.mul_le_mul_right t bk)
        have hf : 1024*((8*t)*t) ≤ (1024*t)*(1024*t) := by
          calc _ = (1024*8)*(t*t) := by ac_rfl
               _ ≤ (1024*1024)*(t*t) := Nat.mul_le_mul_right _ (by decide)
               _ = _ := by ac_rfl
        have lb : 4096 ≤ n := by
          have h1 := Nat.mul_le_mul (show 1024 ≤ 1024*t by omega) (show 1024 ≤ 1024*t by omega)
          omega
        exact Nat.le_trans (z.small_right_exponent lb b2 d2 (Nat.le_trans a1 (Nat.le_trans hf large))) costs.2.1
    · have few : z.A.length+c.D.length ≤ 80*t := by omega
      have sq := squash (show 80*t+1 ≤ 81*t by omega) (by decide : 3*81*81 ≤ 1024*1024) large
      have res := z.small_left_DAG (80*t) few sq
      exact Nat.le_trans (Nat.pow_le_pow_right (by decide : 0<2) (by omega : t≤(80*t)/16))
        (Nat.le_trans res costs.2.2)

theorem Front.lower_reached (c : Front n) : 2^(n.sqrt/1024) ≤ c.reachedCost := by
  by_cases h : 0 < n.sqrt/1024
  · apply c.lower_at_scale_reached _ h
    have le := Nat.mul_div_le n.sqrt 1024
    exact Nat.le_trans (Nat.mul_le_mul le le) (Nat.sqrt_le n)
  · have h0 : n.sqrt/1024 = 0 := by omega
    have w := c.initial.isLt
    have t : c.W ≤ c.reachedCost := Nat.le_max_left _ _
    simp only [h0,Nat.pow_zero]; omega

theorem Front.reached_le (c : Front n) : c.reachedCost ≤ c.size :=
  Nat.max_le.mpr ⟨Nat.le_max_left _ _,c.exit_le _⟩

theorem Front.lower (c : Front n) : 2^(n.sqrt/1024) ≤ c.size :=
  Nat.le_trans c.lower_reached c.reached_le

theorem Front.lower_at_scale (c : Front n) (t : Nat) (ht : 0<t)
    (large : (1024*t)*(1024*t) ≤ n) : 2^t ≤ c.size :=
  Nat.le_trans (c.lower_at_scale_reached t ht large) c.reached_le

/-- The original upper-bound circuits embed with zero preliminary tests and
one scan state. This keeps exactly their original wire measure. -/
def bare (c : OneRoot n) : Hardware n [] where
  A := c.A
  B := c.B
  na := c.na
  nb := c.nb
  dis := c.dis
  disD := by simp
  domain := by simpa using c.domain
  total := by simpa using c.total
  R := c.R
  NP := c.NP
  NS := c.NS
  gP := c.gP
  gS := c.gS
  pRoot := c.pRoot
  sRoot := c.sRoot
  dec := c.dec
  prime_eq := c.prime_eq
  sub_eq := c.sub_eq
  feasible := c.feasible

def emptyFront (c : OneRoot n) : Front n where
  D := []
  F := c.A++c.B
  unique := by
    simp only [List.nil_append]
    exact List.nodup_append.mpr ⟨c.na,c.nb,fun a ha b hb he => c.dis a ha (he ▸ hb)⟩
  total := by simpa using c.total
  bounds := by intro j hj; exact ((c.domain j).mp (by simpa using hj)).2
  W := 1
  initial := 0
  step := fun _ s _ => s
  exit := fun _ => bare c
  rest := by intro e j; rfl
  post := fun _ x => decide (x.length∈x)
  exitCorrect := by intro e x y; simpa [bare] using c.correct x y
  correct := by
    intro x hx
    have f : x.filter (fun j => decide (j∈c.A++c.B)) = x :=
      List.filter_eq_self.mpr (fun j hj => by simpa using (hx.2 hj))
    rw [f]

theorem emptyFront_size (c : OneRoot n) : (emptyFront c).size = c.wires := by
  have h : 1 ≤ c.wires := Nat.le_trans (positive_elements c) ((sizes_le_wires c).1)
  change max 1 (max c.wires 0) = c.wires
  omega

end HWB.Slice
