import HWB.Circuit

namespace HWB.Normalize
open HWB.Circuit

/-- Observably redundant over exactly the incoming bank's legal assignments. -/
def Redundant (g : DAG N) (xs : K → Input) (i : Fin N) : Prop :=
  ∀ a, g.eval (xs a) (g.child i false) = g.eval (xs a) (g.child i true)

/-- A node can also be bypassed when its test is constant on the entire legal input family. -/
def CanTakeLow (g : DAG N) (xs : K → Input) (i : Fin N) : Prop :=
  Redundant g xs i ∨ ∀ a, xs a (g.level i) = false

def Drop (g : DAG N) (xs : K → Input) (i : Fin N) : Prop :=
  CanTakeLow g xs i ∨ ∀ a, xs a (g.level i) = true

noncomputable def choice (g : DAG N) (xs : K → Input) (i : Fin N) : Bool := by
  classical exact decide (¬ CanTakeLow g xs i)

private theorem drop_eval (g : DAG N) (xs : K → Input) (i : Fin N) (h : Drop g xs i) (a : K) :
    g.eval (xs a) (g.child i (choice g xs i)) = g.eval (xs a) (.node i) := by
  classical
  rw [DAG.eval]
  by_cases hL : CanTakeLow g xs i
  · have aux : choice g xs i = false := by simp [choice,hL]
    rw [aux]
    rcases hL with eq|fixed
    · cases hv : xs a (g.level i)
      · rfl
      · exact eq a
    · rw [fixed a]
  · have aux : choice g xs i = true := by simp [choice,hL]
    have fixed := h.resolve_left hL
    rw [aux,fixed a]

noncomputable def survivors (g : DAG N) (xs : K → Input) : List (Fin N) := by
  classical exact (List.finRange N).filter (fun i => decide (¬ Drop g xs i))

@[simp] theorem mem_survivors (g : DAG N) (xs : K → Input) (i : Fin N) :
    i ∈ survivors g xs ↔ ¬Drop g xs i := by
  classical simp [survivors,List.mem_finRange]

theorem count_le (g : DAG N) (xs : K → Input) : (survivors g xs).length ≤ N := by
  classical simpa [survivors] using (List.length_filter_le (fun i => decide (¬Drop g xs i)) (List.finRange N))

noncomputable def original (g : DAG N) (xs : K → Input) (i : Fin (survivors g xs).length) : Fin N :=
  (survivors g xs)[i.val]

theorem original_kept (g : DAG N) (xs : K → Input) (i : Fin (survivors g xs).length) :
    ¬ Drop g xs (original g xs i) := (mem_survivors ..).mp (List.getElem_mem i.isLt)

theorem original_lt (g : DAG N) (xs : K → Input) {i j : Fin (survivors g xs).length} :
    original g xs i < original g xs j ↔ i < j := by
  classical
  have sorted : (survivors g xs).Pairwise (· < ·) :=
    (List.pairwise_lt_finRange N).filter _
  have mono {a b : Fin (survivors g xs).length} (h : a < b) :
      original g xs a < original g xs b :=
    List.pairwise_iff_getElem.mp sorted a b a.isLt b.isLt h
  refine ⟨?_, mono⟩
  intro h
  have hp : i.val ≠ j.val := by intro e; have := Fin.ext e; subst j; exact Nat.lt_irrefl _ h
  by_cases hj : j < i
  · have hn := mono hj; omega
  · change i.val < j.val; change ¬ j.val < i.val at hj; omega

noncomputable def rank (g : DAG N) (xs : K → Input) (i : Fin N) (hn : ¬ Drop g xs i) :
    Fin (survivors g xs).length :=
  ⟨(survivors g xs).idxOf i, List.idxOf_lt_length_of_mem ((mem_survivors ..).mpr hn)⟩

theorem original_rank (g : DAG N) (xs : K → Input) (i : Fin N) (hn : ¬ Drop g xs i) :
    original g xs (rank g xs i hn) = i := List.getElem_idxOf _

noncomputable def restore (g : DAG N) (xs : K → Input) :
    State (survivors g xs).length → State N
  | .term b => .term b
  | .node i => .node (original g xs i)

noncomputable def collapse (g : DAG N) (xs : K → Input) (s : State N) :
    State (survivors g xs).length := by
  classical
  exact match s with
  | .term b => .term b
  | .node i => if h : Drop g xs i then collapse g xs (g.child i (choice g xs i))
    else .node (rank g xs i h)
termination_by s.height
decreasing_by subst_vars; exact g.drops _ _

theorem collapse_height (g : DAG N) (xs : K → Input) (s : State N) :
    (restore g xs (collapse g xs s)).height ≤ s.height := by
  classical
  cases s with
  | term b => rw [collapse]; exact Nat.le_refl _
  | node i =>
    rw [collapse]; split
    · exact Nat.le_trans (collapse_height g xs _) (Nat.le_of_lt (g.drops _ _))
    · simp [restore, original_rank]
termination_by s.height
decreasing_by subst_vars; exact g.drops _ _

private theorem afterChild (g : DAG N) (p : Nat) (i : Fin N) (b : Bool)
    (h : p ≤ g.level i) : g.After p (g.child i b) := by
  cases e : g.child i b with
  | term v => trivial
  | node j => exact Nat.le_trans h (Nat.le_of_lt (g.advances _ _ _ e))

theorem collapse_after (g : DAG N) (xs : K → Input) (p : Nat) (s : State N)
    (hs : g.After p s) : g.After p (restore g xs (collapse g xs s)) := by
  classical
  cases s with
  | term b => rw [collapse]; trivial
  | node i =>
    rw [collapse]; split
    · exact collapse_after g xs p _ (afterChild g p i (choice g xs i) hs)
    · simpa [restore,original_rank] using hs
termination_by s.height
decreasing_by subst_vars; exact g.drops _ _

/-- All semantically redundant nonterminals have actually been removed, and
    the remaining nodes are densely renumbered in their original topological
    order. Both Boolean terminals are shared. -/
noncomputable def reduced (g : DAG N) (xs : K → Input) : DAG (survivors g xs).length where
  level i := g.level (original g xs i)
  child i b := collapse g xs (g.child (original g xs i) b)
  drops i b := by
    have hh := collapse_height g xs (g.child (original g xs i) b)
    have hd := g.drops (original g xs i) b
    cases hm : collapse g xs (g.child (original g xs i) b) with
    | term v => simp [State.height]
    | node j =>
      rw [hm] at hh
      have lt : original g xs j < original g xs i := by
        change (original g xs j).val < (original g xs i).val
        simpa [restore,State.height] using Nat.lt_of_le_of_lt hh hd
      have := (original_lt g xs).mp lt
      simp [State.height]; exact this
  advances i b j eq := by
    have h : g.After (g.level (original g xs i)+1) (g.child (original g xs i) b) := by
      cases h0 : g.child (original g xs i) b with
      | term v => trivial
      | node l => exact g.advances _ _ _ h0
    have z := collapse_after g xs _ _ h
    rw [eq] at z
    exact z

/-- Evaluation agrees on every legal assignment for every possible root;
    normalization is performed once on the shared bank. -/
theorem reduced_eval (g : DAG N) (xs : K → Input) (a : K) (s : State N) :
    (reduced g xs).eval (xs a) (collapse g xs s) = g.eval (xs a) s := by
  classical
  cases s with
  | term b => rw [collapse]; simp [DAG.eval]
  | node i =>
    rw [collapse]; split
    · rename_i h
      rw [reduced_eval g xs a (g.child i (choice g xs i))]
      exact drop_eval g xs i h a
    · rename_i h
      rw [DAG.eval, DAG.eval]
      change (reduced g xs).eval _ (collapse g xs (g.child (original g xs (rank g xs i h))
        (xs a (g.level (original g xs (rank g xs i h)))))) = _
      rw [original_rank]
      exact reduced_eval g xs a _
termination_by s.height
decreasing_by all_goals exact g.drops _ _

/-- Every retained Shannon node has two different right functions, on an
    actual member of the supplied input family. -/
theorem children_distinct (g : DAG N) (xs : K → Input) (i : Fin (survivors g xs).length) :
    ∃ a, (reduced g xs).eval (xs a) ((reduced g xs).child i false) ≠
         (reduced g xs).eval (xs a) ((reduced g xs).child i true) := by
  classical
  have kept := original_kept g xs i
  apply Classical.byContradiction
  intro h
  apply kept
  apply Or.inl
  apply Or.inl
  intro a
  have he : (reduced g xs).eval (xs a) ((reduced g xs).child i false) =
         (reduced g xs).eval (xs a) ((reduced g xs).child i true) := by
    by_cases e : (reduced g xs).eval (xs a) ((reduced g xs).child i false) =
         (reduced g xs).eval (xs a) ((reduced g xs).child i true)
    · exact e
    · exact False.elim (h ⟨a,e⟩)
  change (reduced g xs).eval _ (collapse g xs _) = (reduced g xs).eval _ (collapse g xs _) at he
  simpa only [reduced_eval] using he

/-- In particular every retained node tests a position that can take both
    values on the actual assignment family. This removes out-of-range levels
    (which read a fixed zero) as well as equal-child gates. -/
theorem varies (g : DAG N) (xs : K → Input) (i : Fin (survivors g xs).length) :
    (∃ a, xs a ((reduced g xs).level i) = false) ∧
    (∃ b, xs b ((reduced g xs).level i) = true) := by
  classical
  have kept := original_kept g xs i
  constructor
  · apply Classical.byContradiction
    intro h; apply kept; right
    intro a
    cases e : xs a (g.level (original g xs i)) with
    | false => exact False.elim (h ⟨a,e⟩)
    | true => rfl
  · apply Classical.byContradiction
    intro h; apply kept; left; right
    intro a
    cases e : xs a (g.level (original g xs i)) with
    | false => rfl
    | true => exact False.elim (h ⟨a,e⟩)

end HWB.Normalize
