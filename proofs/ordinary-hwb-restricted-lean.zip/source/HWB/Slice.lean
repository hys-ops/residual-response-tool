import HWB.PrimeBridge
import HWB.Balanced

namespace HWB.Slice
open HWB.Circuit HWB.Model

/-- The actual output bank of one exit, over the surviving original labels.
Different exits can use different splits, orders, and shared gates. -/
structure Hardware (n : Nat) (D : List Nat) where
  A : List Nat
  B : List Nat
  na : A.Nodup
  nb : B.Nodup
  dis : ∀ j ∈ A, j ∉ B
  disD : ∀ j ∈ A++B, j ∉ D
  domain : ∀ j, j ∈ A++B++D ↔ 1≤j ∧ j≤n
  total : A.length+B.length+D.length=n
  R : Nat
  NP : Nat
  NS : Nat
  gP : DAG NP
  gS : DAG NS
  pRoot : Fin R → State NP
  sRoot : Fin R → State NS
  dec : Decision (Assignment A) (Assignment B) R
  prime_eq : ∀ i x, dec.prime i x = gP.eval (bits A x.val) (pRoot i)
  sub_eq : ∀ i y, dec.sub i y = gS.eval (bits B y.val) (sRoot i)
  feasible : ∀ i, ∃ x, dec.selectCase x = i

def Hardware.wires (c : Hardware n D) := 3*c.R + 2*(c.NP+c.NS)

/-- Zero restriction of D preserves the ordinary weight and the original
numeric addresses; D need not be an interval. -/
structure ZeroRoot (n : Nat) (D : List Nat) extends Hardware n D where
  correct : ∀ x y, dec.run x y = decide (x.val.length+y.val.length ∈ x.val++y.val)

theorem ZeroRoot.sizes_le_wires (c : ZeroRoot n D) :
    c.R ≤ c.wires ∧ c.NP+2 ≤ c.wires ∧ c.NS+2 ≤ c.wires := by
  have pos := (c.dec.selectCase ⟨[], by simp⟩).isLt
  unfold Hardware.wires
  omega

theorem ZeroRoot.balanced (c : ZeroRoot n D) (t : Nat) (ht : 0<t)
    (ha : 8*t ≤ c.A.length) (hb : 8*t ≤ c.B.length) (hd : 8*D.length≤c.A.length) :
    2^t ≤ c.R := by
  classical
  let z : Assignment c.A := ⟨[],by simp⟩
  let idx := fun (x : List Nat) => if h : Balanced.Legal c.A x then
    c.dec.selectCase ⟨x,h⟩ else c.dec.selectCase z
  let out := fun (i : Fin c.R) (y : List Nat) =>
    if h : Balanced.Legal c.B y then c.dec.sub i ⟨y,h⟩ else false
  apply Balanced.balanced_width c.A c.B D.length t c.R c.na c.nb c.dis _ ha hb (by omega) ht idx out
  · intro x y hx hy
    simpa [idx,out,hx,hy,Decision.run,Balanced.raw] using c.correct ⟨x,hx⟩ ⟨y,hy⟩
  · intro j hj
    have hu := ((c.domain j).mp (by simp [hj])).2
    have := c.total
    omega
private theorem concat_legal {A P Q : List Nat} (ho : A=P++Q)
    (dis : ∀ j ∈ P, j ∉ Q) (x : Assignment P) (y : Assignment Q) :
    (x.val++y.val).Nodup ∧ x.val++y.val ⊆ A := by
  refine ⟨List.nodup_append.mpr ⟨x.property.1,y.property.1,?_⟩, ?_⟩
  · intro j hj l hl eql; exact dis j (x.property.2 hj) (eql ▸ y.property.2 hl)
  · intro j hj; rw [ho]
    rcases List.mem_append.mp hj with hx|hy
    · exact List.mem_append_left _ (x.property.2 hx)
    · exact List.mem_append_right _ (y.property.2 hy)

/-- There is an actual prime gate for the all-one right response when that
response occurs. If it never occurs the shared false terminal realizes its
empty preimage. No presence or chosen index is assumed. -/
theorem ZeroRoot.one_state (c : ZeroRoot n D) :
    ∃ gate : State c.NP, ∀ x : Assignment c.A,
      c.gP.eval (bits c.A x.val) gate = true ↔
        ∀ y : Assignment c.B, c.dec.run x y = true := by
  classical
  by_cases h : ∃ x : Assignment c.A, ∀ y : Assignment c.B, c.dec.run x y = true
  · obtain ⟨x₀,h₀⟩ := h
    refine ⟨c.pRoot (c.dec.selectCase x₀), fun x => ?_⟩
    rw [←c.prime_eq]
    exact c.dec.forced_const_one x₀ h₀ x
  · refine ⟨.term false, fun x => ?_⟩
    simp only [DAG.eval, Bool.false_eq_true, false_iff]
    exact fun hc => h ⟨x,hc⟩

/-- The packed-label theorem for the actual constant-one prime. No width,
encoding function, or correct decoder is a premise. -/
theorem ZeroRoot.small_right_protected (c : ZeroRoot n D) {P Q J : List Nat} {s : Nat}
    (ho : c.A = P++Q) (w : SmallRight.Protected P Q c.B J s) (hn : J.Nodup) :
    2^J.length ≤ c.NP+2 := by
  obtain ⟨gate, hg⟩ := c.one_state
  let pre := fun x : SmallRight.Assignment P => bits c.A x.val
  let suf := fun y : SmallRight.Assignment Q => bits c.A y.val
  let read := fun x => (c.gP.cut P.length (pre x) gate).encode
  let finish := fun (s : Fin (c.NP+2)) y => c.gP.eval (suf y) (State.decode s) = true
  apply SmallRight.protected_width w hn read finish
  intro x y
  simp only [finish,read,State.decode_encode,pre,suf]
  rw [← c.gP.factor]
  have cb : bits c.A (x.val++y.val) = join P.length (bits c.A x.val) (bits c.A y.val) := by
    simpa only [ho] using bits_cut w.disjointPQ x y
  rw [←cb]
  let z : Assignment c.A := ⟨x.val++y.val,concat_legal ho w.disjointPQ x y⟩
  change c.gP.eval (bits c.A z.val) gate = true ↔ _
  rw [hg]
  change (∀ b, c.dec.run z b = true) ↔ ∀ b : Assignment c.B, SmallRight.ordinary (x.val++y.val++b.val)
  constructor <;> intro h b
  · have h := h b
    rw [c.correct, decide_eq_true_eq] at h
    simpa [SmallRight.ordinary,z,Nat.add_assoc] using h
  · rw [c.correct, decide_eq_true_eq]
    simpa [SmallRight.ordinary,z,Nat.add_assoc] using h b


end HWB.Slice
