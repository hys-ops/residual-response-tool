import Std

/-! The small-right HWB prime. An assignment is represented by the
duplicate-free list of original labels on which it is one. -/
namespace HWB.SmallRight

abbrev Assignment (U : List Nat) := {xs : List Nat // xs.Nodup ∧ xs ⊆ U}

def ordinary (ones : List Nat) : Prop := ones.length ∈ ones

def onePrime (B : List Nat) (p q : List Nat) : Prop :=
  ∀ b : Assignment B, ordinary (p ++ q ++ b.val)

private theorem split_length (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun z => !(f z))).length = U.length := by
  induction U with
  | nil => simp
  | cons a L ih => cases h : f a <;> simp [h] <;> omega

/-- Arbitrarily prescribed Boolean values on the locked positions can be
completed to the target weight whenever there is room for all forced ones
and enough free positions to fill the remaining ones. -/
theorem fill (U : List Nat) (hd : U.Nodup) (locked val : Nat → Bool) (s : Nat)
    (hl : ((U.filter locked).filter val).length ≤ s)
    (hu : s ≤ ((U.filter locked).filter val).length + (U.filter (fun z => !locked z)).length) :
    ∃ p : Assignment U, p.val.length = s ∧
      ∀ z ∈ U, locked z = true → (z ∈ p.val ↔ val z = true) := by
  let forced := (U.filter locked).filter val
  let free := U.filter (fun z => !locked z)
  let extra := free.take (s-forced.length)
  have fe : extra ⊆ free := List.take_subset .. 
  have hf : forced.Nodup := List.Pairwise.filter _ (List.Pairwise.filter _ hd)
  have he : extra.Nodup := (List.Pairwise.filter _ hd).take
  have hdf : (forced ++ extra).Nodup := by
    apply List.nodup_append.mpr
    refine ⟨hf, he, ?_⟩
    intro a ha b hb hab
    subst b
    have ha' := List.mem_filter.mp (List.mem_filter.mp ha).1
    have hb' := (List.mem_filter.mp (fe hb)).2
    simp [ha'.2] at hb'
  refine ⟨⟨forced ++ extra, hdf, ?_⟩, ?_, ?_⟩
  · intro z hz
    rcases List.mem_append.mp hz with h|h
    · exact (List.mem_filter.mp (List.mem_filter.mp h).1).1
    · exact (List.mem_filter.mp (fe h)).1
  · change (forced ++ free.take (s-forced.length)).length = s
    rw [List.length_append, List.length_take]
    change forced.length ≤ s at hl
    change s ≤ forced.length + free.length at hu
    omega
  · intro z hz hlocked
    change z ∈ forced ++ extra ↔ _
    rw [List.mem_append]
    have hne : z ∉ extra := by
      intro h
      have hh := (List.mem_filter.mp (fe h)).2
      simp [hlocked] at hh
    simp [forced, hz, hlocked, hne]

def interval (j k : Nat) := List.range' j (k+1)
@[simp] theorem mem_interval {z j k : Nat} : z ∈ interval j k ↔ j ≤ z ∧ z ≤ j+k := by
  simp only [interval, List.mem_range', Nat.one_mul]
  constructor
  · rintro ⟨i,hi,rfl⟩; omega
  · rintro ⟨h0,h1⟩; exact ⟨z-j, by omega, by omega⟩

def guards (J : List Nat) (k : Nat) := J.flatMap (fun j => interval j k)

theorem guards_length (J : List Nat) (k : Nat) : (guards J k).length = J.length * (k+1) := by
  induction J with
  | nil => simp [guards]
  | cons j J ih => simpa [guards, interval, Nat.succ_mul, Nat.add_comm] using congrArg (· + (k+1)) ih

theorem in_guards {z j k : Nat} {J : List Nat} (hj : j ∈ J) (hz : z ∈ interval j k) :
    z ∈ guards J k := List.mem_flatMap.mpr ⟨j,hj,hz⟩

/-- The assumptions concern only combinatorial placement of labels in the
three parts of the actual variable order, and counts of available positions.
No circuit, assignments for messages, or distinguishing suffixes are assumed. -/
structure Protected (P Q B J : List Nat) (s : Nat) : Prop where
  uniqueP : P.Nodup
  uniqueQ : Q.Nodup
  disjointPQ : ∀ z ∈ P, z ∉ Q
  queries : J ⊆ P
  separated : ∀ j ∈ J, ∀ z ∈ interval j B.length, z ∈ J → z = j
  covered : ∀ z ∈ guards J B.length, z ∈ P ∨ z ∈ Q
  prefixRoomOn : J.length * (B.length+1) ≤ s
  prefixRoomOff : s + J.length * (B.length+1) ≤ P.length
  suffixRoom : ∀ j ∈ J, s ≤ j ∧ B.length ≤ j-s ∧ j-s ≤ Q.length

/-- Every bit of a chosen word is read from the very same constant-one prime.
For each query the completing Q-assignment is independent of the word. -/
theorem protected_decoder {P Q B J : List Nat} {s : Nat} (w : Protected P Q B J s) :
    ∃ enc : (Nat → Bool) → Assignment P, ∃ probe : (j : Nat) → j ∈ J → Assignment Q,
      ∀ (word : Nat → Bool) (j) (hj : j ∈ J),
        onePrime B (enc word).val (probe j hj).val ↔ word j = true := by
  classical
  let g := guards J B.length
  let lock := fun z => decide (z ∈ g)
  let value := fun (word : Nat → Bool) z => if z ∈ J then word z else true
  have hg : (P.filter lock).length ≤ J.length * (B.length+1) := by
    rw [← guards_length]
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter lock w.uniqueP)
    intro z hz
    simpa [lock, g] using (List.mem_filter.mp hz).2
  have en (word : Nat → Bool) := fill P w.uniqueP lock (value word) s
  have encEx (word : Nat → Bool) : ∃ p : Assignment P, p.val.length = s ∧
      ∀ z ∈ P, lock z = true → (z ∈ p.val ↔ value word z = true) := by
    apply en
    · exact Nat.le_trans (List.length_filter_le _ _) (Nat.le_trans hg w.prefixRoomOn)
    · have h := split_length P lock
      have h' := w.prefixRoomOff
      omega
  let enc := fun word => Classical.choose (encEx word)
  have es (word) := Classical.choose_spec (encEx word)
  let qlock := fun j z => decide (z ∈ interval (j+1) (B.length-1) ∧ z ≤ j+B.length)
  have qlock_def j z : qlock j z = true ↔ j < z ∧ z ≤ j+B.length := by
    simp only [qlock, decide_eq_true_eq, mem_interval]; omega
  have ql (j : Nat) : (Q.filter (qlock j)).length ≤ B.length := by
    have hsub : Q.filter (qlock j) ⊆ List.range' (j+1) B.length := by
      intro z hz
      have ⟨h1,h2⟩ := (qlock_def _ _).mp (List.mem_filter.mp hz).2
      apply List.mem_range'.mpr
      exact ⟨z-(j+1),by omega,by omega⟩
    simpa using List.Nodup.length_le_of_subset (List.Pairwise.filter _ w.uniqueQ) hsub
  have probeEx (j) (hj : j ∈ J) : ∃ q : Assignment Q, q.val.length = j-s ∧
      ∀ z ∈ Q, qlock j z = true → z ∈ q.val := by
    have cap := w.suffixRoom j hj
    obtain ⟨q,h,hv⟩ := fill Q w.uniqueQ (qlock j) (fun _ => true) (j-s)
      (by simpa using Nat.le_trans (ql j) cap.2.1)
      (by simpa [split_length] using cap.2.2)
    exact ⟨q,h,fun z hz hlock => (hv _ hz hlock).mpr rfl⟩
  let probe := fun j hj => Classical.choose (probeEx j hj)
  have ps j hj := Classical.choose_spec (probeEx j hj)
  refine ⟨enc, probe, ?_⟩
  intro word j hj
  let p := enc word
  let q := probe j hj
  have hp : p.val.length = s := (es word).1
  have hq : q.val.length = j-s := (ps j hj).1
  have hcap := (w.suffixRoom j hj).1
  have hjp := w.queries hj
  have ifGuard {z : Nat} (hz : z ∈ interval j B.length) : lock z = true := by
    simpa [lock, g] using in_guards hj hz
  have hvar : j ∈ p.val ↔ word j = true := by
    simpa [p, enc, value, hj] using (es word).2 j hjp (ifGuard (by simp))
  change onePrime B p.val q.val ↔ _
  constructor
  · intro h
    have hz := h ⟨[], by simp⟩
    have hnq : j ∉ q.val := fun hmem => w.disjointPQ _ hjp (q.property.2 hmem)
    have sumw : s + (j - s) = j := by omega
    simpa [ordinary, hp, hq, sumw, hnq, hvar] using hz
  · intro hword b
    let z := j + b.val.length
    have hb := b.property.1.length_le_of_subset b.property.2
    have hz : z ∈ interval j B.length := by simp [z]; omega
    have wh : (p.val ++ q.val ++ b.val).length = z := by simp [hp, hq, z]; omega
    change (p.val ++ q.val ++ b.val).length ∈ _
    rw [wh]
    suffices h : z ∈ p.val ∨ z ∈ q.val by simpa [List.mem_append, or_assoc] using (Or.inl h : (z ∈ p.val ∨ z ∈ q.val) ∨ z ∈ b.val)
    rcases w.covered z (in_guards hj hz) with hP|hQ
    · left; apply ((es word).2 _ hP (ifGuard hz)).mpr
      change (if z ∈ J then word z else true) = true
      split
      · rename_i hzj; rwa [w.separated _ hj _ hz hzj]
      · rfl
    · right; apply (ps j hj).2 _ hQ
      apply (qlock_def _ _).mpr
      have hne : z ≠ j := fun h => w.disjointPQ _ hjp (h ▸ hQ)
      have := mem_interval.mp hz
      omega

/-- Every implementation factoring the prime through an intermediate finite
state after P has been read needs at least one state for each bit word. -/
theorem protected_width {P Q B J : List Nat} {s M : Nat}
    (w : Protected P Q B J s) (hJ : J.Nodup)
    (read : Assignment P → Fin M) (finish : Fin M → Assignment Q → Prop)
    (correct : ∀ p q, finish (read p) q ↔ onePrime B p.val q.val) :
    2^J.length ≤ M := by
  obtain ⟨enc, probe, h⟩ := protected_decoder w
  let word := fun (c : Fin (2^J.length)) j => c.val.testBit (J.idxOf j)
  let code := fun c => read (enc (word c))
  have inj : Function.Injective code := by
    intro u v he
    apply Fin.ext; apply Nat.eq_of_testBit_eq
    intro i
    by_cases hi : i < J.length
    · let j := J[i]
      have hj : j ∈ J := List.getElem_mem hi
      have ha := (h _ j hj).symm.trans (correct (enc (word u)) (probe j hj)).symm
      have hb := (h _ j hj).symm.trans (correct (enc (word v)) (probe j hj)).symm
      change read (enc (word u)) = read (enc (word v)) at he
      rw [he] at ha
      have hh := ha.trans hb.symm
      simpa [word, j, hJ.idxOf_getElem i hi] using Bool.eq_iff_iff.mpr hh
    · have le := Nat.pow_le_pow_right (n:=2) (by decide) (Nat.le_of_not_lt hi)
      rw [Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le u.isLt le),
          Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le v.isLt le)]
  have nod : ((List.finRange (2^J.length)).map code).Nodup :=
    List.Pairwise.map code (fun _ _ hne he => hne (inj he)) (List.nodup_finRange _)
  have sub : (List.finRange (2^J.length)).map code ⊆ List.finRange M :=
    fun _ _ => List.mem_finRange _
  simpa using nod.length_le_of_subset sub

private theorem flat_size (L : List Nat) (f : Nat → List Nat) (r : Nat)
    (h : ∀ i ∈ L, (f i).length ≤ r) : (L.flatMap f).length ≤ L.length*r := by
  induction L with
  | nil => simp
  | cons a L ih =>
    have h1 := h a (by simp)
    have h2 := ih (fun i hi => h i (by simp [hi]))
    simpa [List.flatMap_cons, Nat.succ_mul, Nat.add_comm] using Nat.add_le_add h1 h2

private theorem bucket (A : List Nat) (hd : A.Nodup) (f : Nat → Nat) {r t : Nat}
    (hr : 0 < r) (hcap : r*t ≤ A.length) (bound : ∀ j ∈ A, f j < r) :
    ∃ b < r, t ≤ (A.filter (fun j => decide (f j = b))).length := by
  classical
  apply Classical.byContradiction
  intro hh
  let group := fun b => A.filter (fun j => decide (f j = b))
  have short (b) (hb : b < r) : (group b).length < t := by
    exact Nat.lt_of_not_ge (fun h => hh ⟨b,hb,h⟩)
  have ht := short 0 hr
  have incl : A ⊆ (List.range r).flatMap group := by
    intro j hj
    exact List.mem_flatMap.mpr ⟨f j,List.mem_range.mpr (bound j hj), by simp [group,hj]⟩
  have hle := hd.length_le_of_subset incl
  have hsum := flat_size (List.range r) group (t-1) (fun i hi => by
    have := short i (List.mem_range.mp hi); omega)
  simp only [List.length_range] at hsum
  have hlt := Nat.mul_lt_mul_of_pos_left (show t-1<t by omega) hr
  omega

private theorem residue_separates (j z k : Nat) (hj : j ≤ z) (hz : z ≤ j+k)
    (hm : j%(k+1) = z%(k+1)) : z = j := by
  have h1 := Nat.mod_add_div j (k+1)
  have h2 := Nat.mod_add_div z (k+1)
  by_cases h : j/(k+1) = z/(k+1)
  · rw [hm, h] at h1; omega
  have hle := Nat.div_le_div_right (c:=k+1) hj
  have hmul := Nat.mul_le_mul_left (k+1) (show j/(k+1)+1 ≤ z/(k+1) by omega)
  rw [Nat.mul_add_one] at hmul
  omega

/-- A quantitative packing statement; H may include both the right variables
and any original variables fixed to zero before the root. All constants are
absolute. The prefix labels may occur in any order. -/
theorem pack {P Q B H : List Nat} {n d t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z ∈ P, z ∉ Q)
    (pwithin : ∀ z ∈ P, 1 ≤ z ∧ z ≤ n)
    (cover : ∀ z, 1 ≤ z → z ≤ n → z ∈ P ∨ z ∈ Q ∨ z ∈ H)
    (hd : 0 < d) (hn1 : 30*d ≤ n) (hn2 : n < 32*d)
    (plen : 15*d ≤ P.length) (qlen : 15*d ≤ Q.length)
    (holes : H.length*(B.length+1) ≤ 4*d) (hk : B.length ≤ d)
    (count : 32*((B.length+1)*t) ≤ d) (ht : 0<t) :
    ∃ J s, J.Nodup ∧ J.length = t ∧ Protected P Q B J s := by
  classical
  let k := B.length
  let forbidden := H.flatMap (fun z => interval (z-k) k)
  let bad := List.range (4*d) ++ List.range' (28*d) (n+1-28*d) ++ forbidden
  let ok := fun z => decide (z ∉ bad)
  let good := P.filter ok
  have lenf : forbidden.length ≤ H.length*(k+1) :=
    flat_size _ _ _ (by intro i hi; simp [interval])
  have lb : bad.length ≤ 12*d := by
    simp only [bad, List.length_append, List.length_range, List.length_range']
    change H.length * (k+1) ≤ 4*d at holes
    omega
  have lin : (P.filter (fun z => !ok z)).length ≤ bad.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ pd)
    intro a ha
    simpa [ok] using (List.mem_filter.mp ha).2
  have gd : good.Nodup := List.Pairwise.filter ok pd
  have gl : d ≤ good.length := by
    have hh := split_length P ok
    change (P.filter ok).length ≥ d; omega
  have ginfo (z) (zg : z ∈ good) :
      z ∈ P ∧ 4*d ≤ z ∧ z < 28*d ∧ z ∉ forbidden := by
    have ⟨zp,zo⟩ := List.mem_filter.mp zg
    have zn := pwithin _ zp
    have nb : z ∉ bad := by simpa [ok] using zo
    have ln : z ∉ List.range (4*d) := fun h => nb (by simp [bad, h])
    have rn : z ∉ List.range' (28*d) (n+1-28*d) := fun h => nb (by simp [bad, h])
    have hf : z ∉ forbidden := fun h => nb (by simp [bad,h])
    simp only [List.mem_range, Nat.not_lt] at ln
    refine ⟨zp,ln,?_,hf⟩
    apply Classical.byContradiction; intro h
    apply rn; exact List.mem_range'.mpr ⟨z-28*d, by omega, by omega⟩
  have gb (j) (hj : j ∈ good) : j/d < 32 :=
    (Nat.div_lt_iff_lt_mul hd).mpr (by have := (ginfo _ hj).2.2.1; omega)
  obtain ⟨b,hb,hlen⟩ := bucket good gd (fun j => j/d) (by decide : 0<32)
    (Nat.le_trans count gl) gb
  let binGroup := good.filter (fun j => decide (j/d=b))
  have ld : binGroup.Nodup := List.Pairwise.filter _ gd
  obtain ⟨r,hr,rcap⟩ := bucket binGroup ld (fun j => j%(k+1)) (by omega : 0<k+1)
    (show (k+1)*t ≤ binGroup.length from hlen) (fun j _ => Nat.mod_lt j (by omega))
  let full := binGroup.filter (fun j => decide (j%(k+1)=r))
  let J := full.take t
  have jl : J.length = t := by exact (List.length_take ..).trans (Nat.min_eq_left rcap)
  have jd : J.Nodup := (List.Pairwise.filter _ ld).take
  have ji (z) (hz : z ∈ J) : z ∈ good ∧ z/d = b ∧ z%(k+1) = r := by
    have h0 : z ∈ full := List.take_subset t full hz
    have hl := List.mem_filter.mp h0
    have h1 := List.mem_filter.mp hl.1
    exact ⟨h1.1, by simpa using h1.2, by simpa using hl.2⟩
  have j0 : ∃ z, z ∈ J := by
    rw [← List.length_pos_iff_exists_mem, jl]; exact ht
  obtain ⟨z0,hz0⟩ := j0
  have bounds (z) (hz : z ∈ J) : b*d ≤ z ∧ z < b*d+d := by
    have eqv := (ji z hz).2.1
    have f := Nat.div_mul_le_self z d
    have v := Nat.lt_mul_div_succ z hd
    rw [eqv] at f v
    rw [Nat.mul_add_one, Nat.mul_comm d b] at v
    exact ⟨f,v⟩
  have zb := bounds z0 hz0
  have zr := ginfo _ (ji _ hz0).1
  have bd1 : 3*d ≤ b*d := by omega
  have bd2 : b*d < 28*d := by omega
  let s := b*d / 2
  have jt : J.length*(k+1) ≤ d := by rw [jl,Nat.mul_comm]; change 32*((k+1)*t) ≤ d at count; omega
  refine ⟨J,s,jd,jl,⟨pd,qd,pq,?_,?_,?_,?_,?_,?_⟩⟩
  · intro z hz; exact (ginfo _ (ji _ hz).1).1
  · intro j hj z hzw hz
    have hm := (ji j hj).2.2.trans (ji z hz).2.2.symm
    exact residue_separates _ _ _ (mem_interval.mp hzw).1 (mem_interval.mp hzw).2 hm
  · intro z hz
    obtain ⟨j,hj,hz'⟩ := List.mem_flatMap.mp hz
    obtain ⟨lo,hi⟩ := mem_interval.mp hz'
    have gj := ginfo _ (ji j hj).1
    have r := cover z (by omega) (by omega)
    rcases r with hp|hq|hh
    · exact Or.inl hp
    · exact Or.inr hq
    · exfalso; apply gj.2.2.2
      exact List.mem_flatMap.mpr ⟨z, hh, mem_interval.mpr (by change _ ≤ _ ∧ _ ≤ _+k; dsimp [k] at *; omega)⟩
  · dsimp [s]; change J.length * (k+1) ≤ _; omega
  · dsimp [s]; change _ + J.length * (k+1) ≤ P.length; omega
  · intro j hj
    have jb := bounds j hj
    dsimp [s]; omega

/-- Packing for the exact small-right cut in the paper, including the
fixed-zero option as long as the total holes satisfy the displayed budgets.
P and Q are the two consecutive pieces of the left order. -/
theorem pack_at_size {P Q B H : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z ∈ P, z ∉ Q)
    (pwithin : ∀ z ∈ P, 1 ≤ z ∧ z ≤ n)
    (cover : ∀ z, 1 ≤ z → z ≤ n → z ∈ P ∨ z ∈ Q ∨ z ∈ H)
    (hn : 4096 ≤ n) (hk : 64*(B.length*B.length) ≤ n)
    (lefts : 32*(P.length+Q.length) ≥ 31*n)
    (mid : P.length ≤ Q.length ∧ Q.length ≤ P.length+1)
    (holes : 8*(H.length*(B.length+1)) ≤ n)
    (span : 1024*((B.length+1)*t) ≤ n) (ht : 0<t) :
    ∃ J s, J.Nodup ∧ J.length = t ∧ Protected P Q B J s := by
  let d := n/32 + 1
  have ks := Nat.le_mul_self B.length
  apply pack (d:=d) pd qd pq pwithin cover
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · dsimp [d]; omega
  · exact ht

/-- No geometric/counting hypotheses remain in the small-right subproblem:
P and Q are the midpoint split of an arbitrary order of the left labels. -/
theorem pack_small_right {P Q B : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z ∈ P, z ∉ Q)
    (pwithin : ∀ z ∈ P, 1 ≤ z ∧ z ≤ n)
    (cover : ∀ z, 1 ≤ z → z ≤ n → z ∈ P ∨ z ∈ Q ∨ z ∈ B)
    (hn : 4096 ≤ n) (hk : 64*(B.length*B.length) ≤ n)
    (sides : P.length+Q.length+B.length=n)
    (mid : P.length ≤ Q.length ∧ Q.length ≤ P.length+1)
    (span : 1024*((B.length+1)*t) ≤ n) (ht : 0<t) :
    ∃ J s, J.Nodup ∧ J.length = t ∧ Protected P Q B J s := by
  have ks := Nat.le_mul_self B.length
  apply pack_at_size pd qd pq pwithin cover hn hk _ mid _ span ht
  · omega
  · rw [Nat.mul_add_one]; omega

/-- The short-prefix case permits fixed-zero holes D. Their locations are
arbitrary, and B consists of the genuinely free right variables. -/
theorem pack_small_right_zero {P Q B D : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z ∈ P, z ∉ Q)
    (pwithin : ∀ z ∈ P, 1 ≤ z ∧ z ≤ n)
    (cover : ∀ z, 1 ≤ z → z ≤ n → z ∈ P ∨ z ∈ Q ∨ z ∈ B ∨ z ∈ D)
    (hn : 4096 ≤ n) (hk : 64*(B.length*B.length) ≤ n)
    (hd : 64*(D.length*D.length) ≤ n)
    (sides : P.length+Q.length+B.length+D.length=n)
    (mid : P.length ≤ Q.length ∧ Q.length ≤ P.length+1)
    (span : 1024*((B.length+1)*t) ≤ n) (ht : 0<t) :
    ∃ J s, J.Nodup ∧ J.length = t ∧ Protected P Q B J s := by
  have cv z lo hi := cover z lo hi
  apply pack_at_size (H:=B++D) pd qd pq pwithin (by simpa using cv) hn hk _ mid _ span ht
  · have h1 := Nat.le_mul_self B.length; have h2 := Nat.le_mul_self D.length; omega
  · rw [List.length_append, Nat.mul_add_one, Nat.add_mul]
    by_cases h : B.length ≤ D.length
    · have hh := Nat.mul_le_mul_left D.length h
      have h1 := Nat.le_mul_self B.length; have h2 := Nat.le_mul_self D.length; omega
    · have hh := Nat.mul_le_mul_right B.length (Nat.le_of_not_ge h)
      have h1 := Nat.le_mul_self B.length; have h2 := Nat.le_mul_self D.length; omega

end HWB.SmallRight
