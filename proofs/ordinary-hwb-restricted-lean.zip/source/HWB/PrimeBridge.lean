import HWB.Model
import HWB.SmallRight

namespace HWB.Model
open HWB.Circuit

/-- The set of one-indices assembled from a prefix and suffix gives exactly
the concatenation of their positional inputs at the actual OBDD cut. -/
theorem bits_cut {P Q : List Nat} (hd : ∀ j ∈ P, j ∉ Q)
    (x : Assignment P) (y : Assignment Q) :
    bits (P++Q) (x.val++y.val) =
      join P.length (bits (P++Q) x.val) (bits (P++Q) y.val) := by
  funext i
  by_cases hi : i < P.length
  · simp only [bits, join, ite_eq_left hi, List.getElem?_append_left hi]
    cases e : P[i]? with
    | none => rfl
    | some j =>
      have fj := hd j (List.mem_of_getElem? e)
      have : j ∉ y.val := fun h => fj (y.property.2 h)
      simp [this]
  · have hi' := Nat.le_of_not_lt hi
    simp only [bits, join, ite_eq_right hi, List.getElem?_append_right hi']
    cases e : Q[i-P.length]? with
    | none => rfl
    | some j =>
      have fj := List.mem_of_getElem? e
      have : j ∉ x.val := fun h => hd j (x.property.2 h) fj
      simp [this]

private theorem concat_legal {A P Q : List Nat} (ho : A=P++Q)
    (dis : ∀ j ∈ P, j ∉ Q) (x : Assignment P) (y : Assignment Q) :
    (x.val++y.val).Nodup ∧ x.val++y.val ⊆ A := by
  refine ⟨List.nodup_append.mpr ⟨x.property.1,y.property.1,?_⟩, ?_⟩
  · intro j hj l hl eql; exact dis j (x.property.2 hj) (eql ▸ y.property.2 hl)
  · intro j hj; rw [ho]
    rcases List.mem_append.mp hj with hx|hy
    · exact List.mem_append_left _ (x.property.2 hx)
    · exact List.mem_append_right _ (y.property.2 hy)

/-- There is an actual prime gate for the all-one right response when that
response occurs. If it never occurs the shared false terminal realizes its
empty preimage. No presence or chosen index is assumed. -/
theorem OneRoot.one_state (c : OneRoot n) :
    ∃ gate : State c.NP, ∀ x : Assignment c.A,
      c.gP.eval (bits c.A x.val) gate = true ↔
        ∀ y : Assignment c.B, c.dec.run x y = true := by
  classical
  by_cases h : ∃ x : Assignment c.A, ∀ y : Assignment c.B, c.dec.run x y = true
  · obtain ⟨x₀,h₀⟩ := h
    refine ⟨c.pRoot (c.dec.selectCase x₀), fun x => ?_⟩
    rw [←c.prime_eq]
    exact c.dec.forced_const_one x₀ h₀ x
  · refine ⟨.term false, fun x => ?_⟩
    simp only [DAG.eval, Bool.false_eq_true, false_iff]
    exact fun hc => h ⟨x,hc⟩

/-- The packed-label theorem for the actual constant-one prime. No width,
encoding function, or correct decoder is a premise. -/
theorem OneRoot.small_right_protected (c : OneRoot n) {P Q J : List Nat} {s : Nat}
    (ho : c.A = P++Q) (w : SmallRight.Protected P Q c.B J s) (hn : J.Nodup) :
    2^J.length ≤ c.NP+2 := by
  obtain ⟨gate, hg⟩ := c.one_state
  let pre := fun x : SmallRight.Assignment P => bits c.A x.val
  let suf := fun y : SmallRight.Assignment Q => bits c.A y.val
  let read := fun x => (c.gP.cut P.length (pre x) gate).encode
  let finish := fun (s : Fin (c.NP+2)) y => c.gP.eval (suf y) (State.decode s) = true
  apply SmallRight.protected_width w hn read finish
  intro x y
  simp only [finish,read,State.decode_encode,pre,suf]
  rw [← c.gP.factor]
  have cb : bits c.A (x.val++y.val) = join P.length (bits c.A x.val) (bits c.A y.val) := by
    simpa only [ho] using bits_cut w.disjointPQ x y
  rw [←cb]
  let z : Assignment c.A := ⟨x.val++y.val,concat_legal ho w.disjointPQ x y⟩
  change c.gP.eval (bits c.A z.val) gate = true ↔ _
  rw [hg]
  change (∀ b, c.dec.run z b = true) ↔ ∀ b : Assignment c.B, SmallRight.ordinary (x.val++y.val++b.val)
  constructor <;> intro h b
  · have h := h b
    rw [c.correct, decide_eq_true_eq] at h
    simpa [SmallRight.ordinary,z,Nat.add_assoc] using h
  · rw [c.correct, decide_eq_true_eq]
    simpa [SmallRight.ordinary,z,Nat.add_assoc] using h b

end HWB.Model
