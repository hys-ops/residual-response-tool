import HWB.Optimum
import HWB.Sparse
import HWB.BooleanInput

namespace HWB
open Model

/-- End-to-end finite sandwich for the actual minimum of the shared one-root
architecture, including recursive Shannon compression and the original input
semantics at every bit vector. The two upper bounds can be achieved by the
same minimum circuit, independently of the constructions used to prove them. -/
theorem ordinary_HWB_certified (hn : 3 ≤ n) :
    ∃ c : OneRoot n,
      c.Normalized ∧ (∀ d : OneRoot n, c.wires ≤ d.wires) ∧
      2^(n.sqrt/128) ≤ c.wires ∧
      c.wires ≤ 512*n^3*2^(n.sqrt+1) ∧
      c.wires ≤ 2^(7*(n.sqrt+1)+6) ∧
      (∀ x : Fin n → Bool, ∃ i : Fin c.R,
        (∀ j : Fin c.R, c.gP.eval (BooleanInput.probe x c.A) (c.pRoot j) = true ↔ i=j) ∧
        c.gS.eval (BooleanInput.probe x c.B) (c.sRoot i) = BooleanInput.HWB x) := by
  obtain ⟨c,normalized,least,lo,hi⟩ := ordinary_one_root_optimum hn
  obtain ⟨d,sharp⟩ := Sparse.paper_upper hn
  exact ⟨c,normalized,least,lo,Nat.le_trans (least d) sharp,hi,BooleanInput.actual_dags_on_vector c⟩

end HWB
