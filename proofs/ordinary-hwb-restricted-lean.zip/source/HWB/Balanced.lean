import HWB.Circuit

namespace HWB.Balanced

/-- Labels in the left bank whose value is visible at some right weight. -/
def window (A : List Nat) (a k : Nat) :=
  A.filter fun j => decide (a ≤ j ∧ j ≤ a+k)

@[simp] theorem mem_window {A a k j} :
    j ∈ window A a k ↔ j ∈ A ∧ a ≤ j ∧ j ≤ a+k := by
  simp [window]

private theorem flat_bound {α β} (L : List α) (f : α → List β) (t : Nat)
    (H : ∀ i ∈ L, (f i).length ≤ t) : (L.flatMap f).length ≤ L.length * t := by
  induction L with
  | nil => simp
  | cons i L ih =>
    have h := H i (by simp)
    have g := ih (by intro j hj; exact H j (by simp [hj]))
    simp only [List.flatMap_cons, List.length_append, List.length_cons, Nat.add_mul,
      Nat.one_mul]
    omega

/-- For any split (even with h omitted zero coordinates), an interior weight
    sees at least t left labels whenever both banks have at least 8t labels. -/
theorem window_exists (A : List Nat) (k h t : Nat) (nt : 0 < t) (ha : A.Nodup)
    (rangeA : ∀ j ∈ A, j ≤ A.length + k + h)
    (mBig : 8*t ≤ A.length) (kBig : 8*t ≤ k) (holes : 8*h ≤ A.length) :
    ∃ a, t ≤ a ∧ a+t ≤ A.length ∧ t ≤ (window A a k).length := by
  let m := A.length
  let d := 4*t
  have dpos : 0 < d := by dsimp [d]; omega
  have mt : 8*t ≤ m := mBig
  let last := m-t
  have lastgood : t ≤ last ∧ last+t ≤ A.length := by dsimp [last,m]; omega
  apply Classical.byContradiction
  intro no
  have short (a : Nat) (lo : t ≤ a) (hi : a+t ≤ A.length) :
      (window A a k).length ≤ t := by
    by_cases e : t ≤ (window A a k).length
    · exact False.elim (no ⟨a,lo,hi,e⟩)
    · omega
  let block := fun i => window A (min (t+i*d) last) k
  let bins := List.range (m/d+1)
  have fb := flat_bound bins block t (by
    intro i _
    apply short <;> dsimp [last,m] at * <;> omega)
  have lB : bins.length = m/d+1 := by simp [bins]
  have fl := short last lastgood.1 lastgood.2
  let low := List.range t
  let high := List.range' (last+k+1) (t+h)
  have covers : A ⊆ low ++ high ++ window A last k ++ bins.flatMap block := by
    intro j hj
    simp only [List.mem_append, List.mem_flatMap, mem_window]
    by_cases jl : j < t
    · exact Or.inl (Or.inl (Or.inl (by simpa [low] using jl)))
    by_cases jh : last+k < j
    · apply Or.inl; apply Or.inl; apply Or.inr
      apply List.mem_range'.mpr
      have bound := rangeA j hj
      refine ⟨j-(last+k+1), ?_, ?_⟩ <;> dsimp [last,m] at * <;> omega
    by_cases je : last ≤ j
    · exact Or.inl (Or.inr ⟨hj,je,by omega⟩)
    · apply Or.inr
      let i := (j-t)/d
      have iB : i < m/d+1 := by
        have le : j-t ≤ m := by dsimp [last] at je; omega
        have q := Nat.div_le_div_right (c:=d) le
        exact Nat.lt_succ_of_le q
      refine ⟨i, by simpa [bins] using iB, ?_⟩
      have prod : i*d ≤ j-t := Nat.div_mul_le_self _ _
      have rem := Nat.mod_lt (j-t) dpos
      have eqn := Nat.mod_add_div (j-t) d
      rw [Nat.mul_comm d] at eqn
      change (j-t)%d + i*d = j-t at eqn
      apply mem_window.mpr
      refine ⟨hj, ?_, ?_⟩ <;> dsimp [d] at * <;> omega
  have tot := ha.length_le_of_subset covers
  simp only [List.length_append] at tot
  have ll : low.length = t := by simp [low]
  have hh : high.length = t+h := by simp [high]
  rw [ll,hh] at tot
  rw [lB, Nat.add_mul, Nat.one_mul] at fb
  have mult := Nat.div_mul_le_self m d
  have scale : m/d*d = 4*(m/d*t) := by
    dsimp only [d]; simp [Nat.mul_comm, Nat.mul_left_comm, Nat.mul_assoc]
  rw [scale] at mult
  change 8*h ≤ m at holes
  change m ≤ _ at tot
  omega

/-- A support is legal exactly when it names each true input at most once,
    and all its true labels are present in the designated input bank. -/
def Legal (bank bits : List Nat) := bits.Nodup ∧ bits ⊆ bank

/-- On positive, disjoint labels this is ordinary HWB, with value zero on
    the all-zero input. Unlisted labels are fixed to zero. -/
def raw (x y : List Nat) : Bool := decide (x.length+y.length ∈ x++y)

def fill (A T : List Nat) (a : Nat) (p : Nat → Bool) : List Nat :=
  let on := T.filter p
  on ++ (A.filter (fun j => decide (j ∉ T))).take (a-on.length)

/-- Extend any prescribed bits on T to total weight a, with no duplicate,
    when there is space for all choices of the prescribed bits. -/
theorem fill_spec {A T : List Nat} {a : Nat} (p : Nat → Bool)
    (hA : A.Nodup) (hT : T.Nodup) (sub : T ⊆ A)
    (lo : T.length ≤ a) (hi : a + T.length ≤ A.length) :
    Legal A (fill A T a p) ∧ (fill A T a p).length = a ∧
    ∀ j ∈ T, (j ∈ fill A T a p ↔ p j = true) := by
  let on := T.filter p
  let free := A.filter fun j => decide (j ∉ T)
  have nOn : on.Nodup := hT.sublist List.filter_sublist
  have nFree : free.Nodup := hA.sublist List.filter_sublist
  have lOn : on.length ≤ T.length := List.length_filter_le _ _
  have lFree : A.length ≤ T.length+free.length := by
    have pool : A ⊆ T++free := by
      intro j hj
      by_cases e : j∈T
      · simp [e]
      · simp [free,hj,e]
    simpa using hA.length_le_of_subset pool
  have lenPad : a-on.length ≤ free.length := by omega
  let pad := free.take (a-on.length)
  have inOn {j} (hj : j∈on) : j∈T := (List.mem_filter.mp hj).1
  have padSpec {j} (hj : j∈pad) : j∈A ∧ j∉T := by
    have hfree := List.take_subset _ _ hj
    change j ∈ free at hfree
    simpa [free] using hfree
  change Legal A (on++pad) ∧ (on++pad).length = a ∧ _
  refine ⟨⟨List.nodup_append.mpr ⟨nOn,nFree.sublist (List.take_sublist _ _),?_⟩,?_⟩,?_,?_⟩
  · intro j hj l hl eql
    exact (padSpec hl).2 (eql ▸ inOn hj)
  · intro j hj
    rcases List.mem_append.mp hj with h|h
    · exact sub (inOn h)
    · exact (padSpec h).1
  · rw [List.length_append, List.length_take_of_le lenPad]; omega
  · intro j hj
    have np : j∉pad := fun h => (padSpec h).2 hj
    change j ∈ on++pad ↔ _
    simp [on,hj,np]

/-- Converting an actual injective list of signatures into a state-count bound. -/
theorem number_of_codes_le (code : Nat → Nat) {M N : Nat}
    (bd : ∀ i, i < M → code i < N)
    (separates : ∀ i j, i < M → j < M → code i = code j → i=j) :
    M ≤ N := by
  have nod : ((List.range M).map code).Nodup := by
    apply List.pairwise_map.mpr
    apply (List.nodup_range (n:=M)).imp_of_mem
    intro i j hi hj ne eq
    exact ne (separates i j (List.mem_range.mp hi) (List.mem_range.mp hj) eq)
  have sub : (List.range M).map code ⊆ List.range N := by
    intro x hx
    obtain ⟨i,hi,rfl⟩ := List.mem_map.mp hx
    exact List.mem_range.mpr (bd _ (List.mem_range.mp hi))
  simpa using nod.length_le_of_subset sub

/-- A balanced split of the original labels needs 2^t possible states for
    any encoding of the left input from which all right answers can be read.
    Up to h labels can be omitted (fixed to zero). No bound or separation
    fact about HWB or OBDDs is assumed. -/
theorem balanced_width (A B : List Nat) (h t width : Nat)
    (hA : A.Nodup) (hB : B.Nodup)
    (sep : ∀ j ∈ A, j ∉ B)
    (boundA : ∀ j ∈ A, j ≤ A.length + B.length + h)
    (mBig : 8*t ≤ A.length) (kBig : 8*t ≤ B.length)
    (holes : 8*h ≤ A.length) (nt : 0 < t)
    (encode : List Nat → Fin width) (readout : Fin width → List Nat → Bool)
    (correct : ∀ x y, Legal A x → Legal B y → readout (encode x) y = raw x y) :
    2^t ≤ width := by
  obtain ⟨a,alo,ahi,ab⟩ := window_exists A B.length h t nt hA boundA mBig kBig holes
  let T := (window A a B.length).take t
  have lT : T.length = t := List.length_take_of_le ab
  have ndT : T.Nodup := (hA.sublist (@List.filter_sublist _ _ A)).sublist (List.take_sublist _ _)
  have inT {j} (hj : j∈T) : j∈A ∧ a≤j ∧ j≤a+B.length :=
    mem_window.mp (List.take_subset _ _ hj)
  let P := fun (i j : Nat) => i.testBit (T.idxOf j)
  let x := fun i => fill A T a (P i)
  have xspec (i : Nat) := fill_spec (P i) hA ndT (fun _ h => (inT h).1)
    (by omega : T.length ≤ a) (by omega : a+T.length ≤ A.length)
  apply number_of_codes_le (fun i => (encode (x i)).val)
  · intro i _; exact (encode (x i)).isLt
  · intro i j hi hj eq
    have es : encode (x i) = encode (x j) := Fin.ext eq
    apply Nat.eq_of_testBit_eq
    intro z
    by_cases hz : z < t
    · have zlt : z<T.length := by omega
      let label := T[z]
      have hl : label ∈ T := List.getElem_mem zlt
      have key := inT hl
      let y := B.take (label-a)
      have yl : y.length = label-a := List.length_take_of_le (by omega)
      have sy : Legal B y := ⟨hB.sublist (List.take_sublist _ _), List.take_subset _ _⟩
      have yn : label ∉ y := fun e => sep label key.1 (sy.2 e)
      have decodeBit (v : Nat) : readout (encode (x v)) y = v.testBit z := by
        rw [correct _ _ (xspec v).1 sy]
        apply Bool.eq_iff_iff.mpr
        have xv : (x v).length = a := (xspec v).2.1
        have addr : (x v).length + y.length = label := by omega
        have idx : T.idxOf label = z := ndT.idxOf_getElem z zlt
        simpa [raw,addr,yn,P,idx,x] using (xspec v).2.2 label hl
      rw [← decodeBit i, ← decodeBit j, es]
    · have p := Nat.pow_le_pow_right (n:=2) (by decide) (by omega : t ≤ z)
      rw [Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le hi p),
        Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le hj p)]


/-- Read an ordered bank once. The same finite state set is used at every
    point, allowing DAG sharing and skipped tests (stuttering). -/
def scan {σ : Type} (step : Nat → σ → Bool → σ) (order : List Nat)
    (bits : List Nat) (initial : σ) : σ :=
  order.foldl (fun state j => step j state (decide (j ∈ bits))) initial

theorem scan_congr {σ} {step : Nat → σ → Bool → σ} (order x y : List Nat)
    (initial : σ) (same : ∀ j ∈ order, (j ∈ x ↔ j ∈ y)) :
    scan step order x initial = scan step order y initial := by
  induction order generalizing initial with
  | nil => rfl
  | cons v tail ih =>
    have h := same v (by simp)
    simp only [scan, List.foldl_cons]
    rw [show decide (v∈x) = decide (v∈y) by simp [h]]
    exact ih _ (fun j hj => same j (by simp [hj]))

/-- All-order ordinary-HWB lower bound, obtained internally from balanced_width.
    The state update may depend on the position's original label, so this
    also permits the ordinary OBDD rule of staying put on skipped tests. -/
theorem ordered_width (order : List Nat) (width : Nat)
    (nd : order.Nodup) (bounds : ∀ j ∈ order, j ≤ order.length)
    (step : Nat → Fin width → Bool → Fin width) (initial : Fin width)
    (accept : Fin width → Bool)
    (correct : ∀ bits, Legal order bits →
      accept (scan step order bits initial) = decide (bits.length ∈ bits)) :
    2^(order.length/16) ≤ width := by
  let t := order.length/16
  by_cases nt : t=0
  · change 2^t ≤ width
    rw [nt]; have := initial.isLt; omega
  let A := order.take (order.length/2)
  let B := order.drop (order.length/2)
  have split : A++B=order := List.take_append_drop _ _
  have size := congrArg List.length split
  rw [List.length_append] at size
  have hAB : (A++B).Nodup := split ▸ nd
  obtain ⟨an,bn,ds⟩ := List.nodup_append.mp hAB
  have aSize : A.length = order.length/2 := List.length_take_of_le (by omega)
  let encode := fun (x : List Nat) => scan step A x initial
  let readout := fun s y => accept (scan step B y s)
  refine balanced_width A B 0 t width an bn (fun j ha hb => ds j ha j hb rfl) ?_ ?_ ?_ (by omega)
    (by omega) encode readout ?_
  · intro j hj
    have b := bounds j (split ▸ List.mem_append_left B hj)
    omega
  · dsimp [t]; omega
  · dsimp [t]; omega
  · intro x y lx ly
    have ys {j} (hj : j∈A) : j∉y := fun hy => ds j hj j (ly.2 hy) rfl
    have xs {j} (hj : j∈B) : j∉x := fun hx => ds j (lx.2 hx) j hj rfl
    have legalXY : Legal order (x++y) := by
      constructor
      · exact List.nodup_append.mpr ⟨lx.1, ly.1,
          fun j hj l hl => ds j (lx.2 hj) l (ly.2 hl)⟩
      · rw [←split]; intro j hj
        rcases List.mem_append.mp hj with h|h
        · exact List.mem_append_left _ (lx.2 h)
        · exact List.mem_append_right _ (ly.2 h)
    have p := correct (x++y) legalXY
    rw [←split] at p
    change accept ((A++B).foldl _ initial) = _ at p
    rw [List.foldl_append] at p
    change accept (scan step B (x++y) (scan step A (x++y) initial)) = _ at p
    rw [scan_congr A (x++y) x initial (fun j hj => by simp [ys hj]),
      scan_congr B (x++y) y _ (fun j hj => by simp [xs hj])] at p
    simpa [readout,encode,raw] using p


open HWB.Circuit

/-- Free coordinates occur at some (possibly nonconsecutive) DAG levels.
    All other levels read a fixed bit, including any levels beyond the chart. -/
def chartInput (chart : List (Option Nat)) (fixed : Nat → Bool) (bits : List Nat) : Input :=
  fun i => match chart[i]?.join with
    | none => fixed i
    | some j => decide (j∈bits)

private noncomputable def decodeState (v : Fin (N+2)) : State N := by
  classical
  exact if h : ∃ z : State N, z.encode=v then Classical.choose h else .term false

private theorem decode_encode (s : State N) : decodeState s.encode = s := by
  have h : ∃ z : State N, z.encode = s.encode := ⟨s,rfl⟩
  simp only [decodeState, dite_eq_left h]
  exact State.encode_inj (Classical.choose_spec h)

/-- A restriction realizing ordinary HWB on t surviving labels in *any*
    inherited order, with arbitrary fixed Boolean values at all other levels,
    needs at least 2^(t/16) distinct states. N counts original nonterminals
    and both terminals are included in N+2. This derives its own all-order
    exponential OBDD lower bound rather than importing the published bound. -/
theorem dag_restricted_width {N : Nat} (g : DAG N) (root : State N)
    (chart : List (Option Nat)) (fixed : Nat → Bool)
    (nd : (chart.filterMap id).Nodup)
    (bounds : ∀ j ∈ chart.filterMap id, j ≤ (chart.filterMap id).length)
    (correct : ∀ bits, Legal (chart.filterMap id) bits →
      g.eval (chartInput chart fixed bits) root = decide (bits.length ∈ bits)) :
    2^((chart.filterMap id).length/16) ≤ N+2 := by
  let ord := chart.filterMap id
  let t := ord.length/16
  by_cases nt : t=0
  · change 2^t ≤ N+2
    rw [nt]; omega
  let A := ord.take (ord.length/2)
  let B := ord.drop (ord.length/2)
  have split : A++B=ord := List.take_append_drop _ _
  have size := congrArg List.length split
  rw [List.length_append] at size
  have hAB : (A++B).Nodup := split ▸ nd
  obtain ⟨an,bn,ds⟩ := List.nodup_append.mp hAB
  have aSize : A.length = ord.length/2 := List.length_take_of_le (by omega)
  obtain ⟨lc,rc,chartSplit,el,er⟩ := List.filterMap_eq_append_iff.mp
    (show chart.filterMap id = A++B from split.symm)
  let encode := fun x => (g.cut lc.length (chartInput chart fixed x) root).encode
  let readout := fun v y => g.eval (chartInput chart fixed y) (decodeState v)
  refine balanced_width A B 0 t (N+2) an bn (fun j ha hb => ds j ha j hb rfl) ?_ ?_ ?_
    (by omega) (by omega) encode readout ?_
  · intro j hj
    have jo : j ∈ ord := split ▸ List.mem_append_left B hj
    have b := bounds j jo
    change j ≤ ord.length at b; omega
  · dsimp [t]; omega
  · dsimp [t]; omega
  · intro x y lx ly
    have ys {j} (hj : j∈A) : j∉y := fun hy => ds j hj j (ly.2 hy) rfl
    have xs {j} (hj : j∈B) : j∉x := fun hx => ds j (lx.2 hx) j hj rfl
    have legalXY : Legal ord (x++y) := by
      constructor
      · exact List.nodup_append.mpr ⟨lx.1, ly.1, fun j hj l hl => ds j (lx.2 hj) l (ly.2 hl)⟩
      · rw [←split]; intro j hj
        rcases List.mem_append.mp hj with h|h
        · exact List.mem_append_left _ (lx.2 h)
        · exact List.mem_append_right _ (ly.2 h)
    have joinEq : chartInput chart fixed (x++y) =
        join lc.length (chartInput chart fixed x) (chartInput chart fixed y) := by
      funext i
      by_cases early : i<lc.length
      · simp only [join,ite_eq_left early,chartInput,chartSplit,List.getElem?_append_left early]
        cases hi : lc[i]? with
        | none => rfl
        | some o => cases o with
          | none => rfl
          | some j =>
            have jl : j∈A := el ▸ List.mem_filterMap.mpr ⟨some j,List.mem_of_getElem? hi,rfl⟩
            simp [ys jl]
      · simp only [join,ite_eq_right early,chartInput,chartSplit,List.getElem?_append_right (Nat.le_of_not_lt early)]
        cases hi : rc[i-lc.length]? with
        | none => rfl
        | some o => cases o with
          | none => rfl
          | some j =>
            have jr : j∈B := er ▸ List.mem_filterMap.mpr ⟨some j,List.mem_of_getElem? hi,rfl⟩
            simp [xs jr]
    simp only [readout,encode,decode_encode]
    rw [←g.factor,←joinEq,correct _ legalXY]
    simp [raw]


/-- A finite-state ordered prefix followed by an arbitrary procedure on the
    unread bank. The latter can depend on the final prefix state. For any cut
    after p of the prefix variables, the actual number of available states
    is bounded below. Fixed variables/special sentential suffixes are not
    assumed in this long-prefix argument. -/
theorem long_prefix_width (D F : List Nat) (w p t : Nat)
    (nd : (D++F).Nodup) (bounds : ∀ j ∈ D++F, j ≤ D.length+F.length)
    (ht : 0<t) (p_le : p ≤ D.length)
    (preLarge : 8*t ≤ p) (postLarge : 8*t+p ≤ D.length+F.length)
    (step : Nat → Fin w → Bool → Fin w) (initial : Fin w)
    (post : Fin w → List Nat → Bool)
    (correct : ∀ input, Legal (D++F) input →
      post (scan step D input initial) (input.filter (fun j => decide (j ∈ F))) =
        decide (input.length ∈ input)) :
    2^t ≤ w := by
  let A := D.take p
  let tail := D.drop p
  let B := tail++F
  have dsplit : A++tail=D := List.take_append_drop _ _
  have full : A++B = D++F := by rw [←dsplit]; simp [B,List.append_assoc]
  have size := congrArg List.length full
  simp only [List.length_append] at size
  have aSize : A.length = p := List.length_take_of_le p_le
  have hAB : (A++B).Nodup := full ▸ nd
  obtain ⟨an,bn,ds⟩ := List.nodup_append.mp hAB
  let encode := fun x => scan step A x initial
  let readout := fun s y => post (scan step tail y s) (y.filter (fun j => decide (j∈F)))
  refine balanced_width A B 0 t w an bn (fun j ha hb => ds j ha j hb rfl) ?_ ?_ ?_
    (by omega) ht encode readout ?_
  · intro j hj; have hu := bounds j (full ▸ List.mem_append_left B hj); omega
  · omega
  · omega
  · intro x y lx ly
    have ys {j} (hj : j∈A) : j∉y := fun hy => ds j hj j (ly.2 hy) rfl
    have xs {j} (hj : j∈B) : j∉x := fun hx => ds j (lx.2 hx) j hj rfl
    have legalXY : Legal (D++F) (x++y) := by
      constructor
      · exact List.nodup_append.mpr ⟨lx.1, ly.1, fun j hj l hl => ds j (lx.2 hj) l (ly.2 hl)⟩
      · rw [←full]; intro j hj
        rcases List.mem_append.mp hj with h|h
        · exact List.mem_append_left _ (lx.2 h)
        · exact List.mem_append_right _ (ly.2 h)
    have clean : x.filter (fun j => decide (j ∈ F)) = [] := by
      apply List.filter_eq_nil_iff.mpr
      intro j hj
      have hn : j∉F := fun jf => xs (List.mem_append_right tail jf) hj
      simp [hn]
    have q := correct (x++y) legalXY
    rw [←dsplit] at q
    change post ((A++tail).foldl _ initial) _ = _ at q
    rw [List.foldl_append] at q
    change post (scan step tail (x++y) (scan step A (x++y) initial)) _ = _ at q
    rw [scan_congr A (x++y) x initial (fun j hj => by simp [ys hj]),
      scan_congr tail (x++y) y _ (fun j hj => by simp [xs (List.mem_append_left F hj)])] at q
    simpa [readout,encode,raw,List.filter_append,clean] using q

end HWB.Balanced
