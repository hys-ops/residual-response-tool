import Std

/-! Ordered binary decision DAGs. The two terminals are shared, and internal
nodes can have arbitrarily many incoming edges. Edges can skip levels. -/
namespace HWB.Circuit

inductive State (N : Nat) where
  | term : Bool → State N
  | node : Fin N → State N
deriving DecidableEq

def State.height : State N → Nat
  | .term _ => 0
  | .node i => i.val + 1

def State.encode : State N → Fin (N+2)
  | .term false => ⟨0, by omega⟩
  | .term true => ⟨1, by omega⟩
  | .node i => ⟨i.val + 2, by omega⟩

def State.decode (v : Fin (N+2)) : State N :=
  if hz : v.val=0 then .term false else if ho : v.val=1 then .term true else
    .node ⟨v.val-2, by omega⟩

@[simp] theorem State.decode_encode (s : State N) : State.decode s.encode = s := by
  cases s with
  | term b => cases b <;> rfl
  | node i => simp [State.decode, State.encode]

theorem State.encode_inj : Function.Injective (@State.encode N) := by
  intro a b h
  have hv := congrArg Fin.val h
  cases a with
  | term a => cases b with
    | term b => cases a <;> cases b <;> simp_all [State.encode]
    | node j => cases a <;> simp [State.encode] at hv <;> omega
  | node i => cases b with
    | term b => cases b <;> simp [State.encode] at hv <;> omega
    | node j =>
      simp [State.encode] at hv
      have : i = j := Fin.ext (by omega)
      simp [this]

/-- Levels are positions in an arbitrary common order. One may transport
assignments along any chosen list of variable labels. -/
structure DAG (N : Nat) where
  level : Fin N → Nat
  child : Fin N → Bool → State N
  drops : ∀ i b, (child i b).height < (State.node i).height
  advances : ∀ i b j, child i b = State.node j → level i < level j

abbrev Input := Nat → Bool

def DAG.eval (g : DAG N) (x : Input) (s : State N) : Bool :=
  match s with
  | .term v => v
  | .node i => g.eval x (g.child i (x (g.level i)))
termination_by s.height
decreasing_by apply g.drops

def DAG.cut (g : DAG N) (p : Nat) (x : Input) (s : State N) : State N :=
  match s with
  | .term b => .term b
  | .node i => if g.level i < p then g.cut p x (g.child i (x (g.level i))) else .node i
termination_by s.height
decreasing_by apply g.drops

def join (p : Nat) (x y : Input) : Input := fun i => if i < p then x i else y i

def DAG.After (g : DAG N) (p : Nat) : State N → Prop
  | .term _ => True
  | .node i => p ≤ g.level i

private theorem DAG.after_child (g : DAG N) (i : Fin N) (b : Bool) (hp : p ≤ g.level i) :
    g.After p (g.child i b) := by
  cases h : g.child i b with
  | term v => trivial
  | node j =>
    exact Nat.le_trans hp (Nat.le_of_lt (g.advances i b j h))

theorem DAG.eval_after (g : DAG N) (p : Nat) (x y : Input)
    (s : State N) (hs : g.After p s) :
    g.eval (join p x y) s = g.eval y s := by
  cases s with
  | term v => simp only [DAG.eval]
  | node i =>
    change p ≤ g.level i at hs
    simp only [DAG.eval, join, ite_eq_right (Nat.not_lt.mpr hs)]
    exact g.eval_after p x y (g.child i (y (g.level i))) (g.after_child i _ hs)
termination_by s.height
decreasing_by subst_vars; apply g.drops

/-- Reading the prefix factors evaluation through the reached single state. -/
theorem DAG.factor (g : DAG N) (p : Nat) (x y : Input) (s : State N) :
    g.eval (join p x y) s = g.eval y (g.cut p x s) := by
  cases s with
  | term v => simp [DAG.cut, DAG.eval]
  | node i =>
    by_cases h : g.level i < p
    · rw [DAG.cut, ite_eq_left h, DAG.eval]
      simpa only [join, ite_eq_left h] using g.factor p x y (g.child i (x (g.level i)))
    · rw [DAG.cut, ite_eq_right h]
      exact g.eval_after p x y (.node i) (Nat.le_of_not_lt h)
termination_by s.height
decreasing_by apply g.drops

theorem fin_injection_bound (f : Fin t → Fin q) (h : Function.Injective f) : t ≤ q := by
  have hn : ((List.finRange t).map f).Nodup := (List.nodup_finRange t).map f (fun _ _ ne eq => ne (h eq))
  have hsub : (List.finRange t).map f ⊆ List.finRange q := fun z _ => List.mem_finRange z
  simpa using hn.length_le_of_subset hsub

/-- The witness family consists of actual prefix assignments. Every pair has
one *common* separating completion, which may depend on that pair. -/
theorem DAG.width_lower (g : DAG N) (s : State N) (p : Nat)
    (a : Fin t → Input)
    (sep : ∀ i j, i ≠ j → ∃ y, g.eval (join p (a i) y) s ≠ g.eval (join p (a j) y) s) :
    t ≤ N+2 := by
  apply fin_injection_bound (fun i => (g.cut p (a i) s).encode)
  intro i j eqs
  apply Classical.byContradiction
  intro h
  obtain ⟨y, hy⟩ := sep i j h
  rw [g.factor, g.factor, State.encode_inj eqs] at hy
  exact hy rfl

/-- A two-input compressed sentential partition, with true left cases mutually
exclusive and collectively exhaustive and pairwise inequivalent right functions. -/
structure Decision (X Y : Type) (r : Nat) where
  prime : Fin r → X → Bool
  sub : Fin r → Y → Bool
  selectCase : X → Fin r
  partition : ∀ x i, prime i x = true ↔ selectCase x = i
  compressed : ∀ i j, (∀ y, sub i y = sub j y) → i = j

def Decision.run (d : Decision X Y r) (x : X) (y : Y) := d.sub (d.selectCase x) y

theorem Decision.prime_iff_row (d : Decision X Y r) (i : Fin r) (x : X) :
    d.prime i x = true ↔ ∀ y, d.run x y = d.sub i y := by
  rw [d.partition]
  constructor
  · intro h y; simp [Decision.run, h]
  · exact d.compressed _ _

theorem Decision.forced_const_one (d : Decision X Y r) (x₀ : X)
    (h : ∀ y, d.run x₀ y = true) (x : X) :
    d.prime (d.selectCase x₀) x = true ↔ ∀ y, d.run x y = true := by
  rw [d.prime_iff_row]
  simpa only [Decision.run] using (show
    (∀ y, d.run x y = d.run x₀ y) ↔ ∀ y, d.run x y = true by simp [h])

theorem Decision.root_elements_lower (d : Decision X Y r) (a : Fin t → X)
    (h : ∀ i j, i ≠ j → ∃ y, d.run (a i) y ≠ d.run (a j) y) : t ≤ r := by
  apply fin_injection_bound (fun i => d.selectCase (a i))
  intro i j hij
  apply Classical.byContradiction
  intro hn
  obtain ⟨y,hy⟩ := h i j hn
  exact hy (congrArg (fun k => d.sub k y) hij)


/-- Partial restriction by order positions, independently of the test input. -/
abbrev Mask := Nat → Option Bool

def overrideInput (m : Mask) (y : Input) : Input := fun j => (m j).getD (y j)

def DAG.bypass (g : DAG N) (m : Mask) (s : State N) : State N :=
  match s with
  | .term v => .term v
  | .node i =>
    match m (g.level i) with
    | none => .node i
    | some b => g.bypass m (g.child i b)
termination_by s.height
decreasing_by apply g.drops

theorem DAG.bypass_height (g : DAG N) (m : Mask) (s : State N) :
    (g.bypass m s).height ≤ s.height := by
  cases s with
  | term v => simp [DAG.bypass]
  | node i =>
    rw [DAG.bypass]
    cases e : m (g.level i) with
    | none => exact Nat.le_refl _
    | some b => exact Nat.le_trans (g.bypass_height m (g.child i b)) (Nat.le_of_lt (g.drops i b))
termination_by s.height
decreasing_by apply g.drops

private theorem DAG.bypass_after (g : DAG N) (m : Mask) (p : Nat)
    (s : State N) (h : g.After p s) : g.After p (g.bypass m s) := by
  cases s with
  | term v => simp [DAG.bypass, DAG.After]
  | node i =>
    rw [DAG.bypass]
    cases e : m (g.level i) with
    | none => exact h
    | some b => exact g.bypass_after m p (g.child i b) (g.after_child _ _ h)
termination_by s.height
decreasing_by subst_vars; apply g.drops

theorem DAG.bypass_free (g : DAG N) (m : Mask) (s : State N) :
    ∀ j, g.bypass m s = .node j → m (g.level j) = none := by
  cases s with
  | term v => simp [DAG.bypass]
  | node i =>
    rw [DAG.bypass]
    cases e : m (g.level i) with
    | none => intro j h; cases h; exact e
    | some b => exact g.bypass_free m (g.child i b)
termination_by s.height
decreasing_by apply g.drops

/-- Keep the allocated table and rewire every outgoing edge. Fixed internal
nodes may still be allocated but no entry from a bypassed root or from a
rewired edge visits any of them. Thus total allocated count never increases. -/
def DAG.restrict (g : DAG N) (m : Mask) : DAG N where
  level := g.level
  child i b := g.bypass m (g.child i b)
  drops i b := Nat.lt_of_le_of_lt (g.bypass_height m (g.child i b)) (g.drops i b)
  advances i b j eqs := by
    have h : g.After (g.level i + 1) (g.child i b) := by
      cases hc : g.child i b with
      | term v => trivial
      | node t => exact g.advances i b t hc
    have ha := g.bypass_after m _ _ h
    rw [eqs] at ha
    exact ha

theorem DAG.restricted_edge_free (g : DAG N) (m : Mask) (i : Fin N)
    (b : Bool) (j : Fin N) :
    (g.restrict m).child i b = .node j → m (g.level j) = none :=
  g.bypass_free m (g.child i b) j

theorem DAG.eval_restrict (g : DAG N) (m : Mask) (x : Input) (s : State N) :
    (g.restrict m).eval x (g.bypass m s) = g.eval (overrideInput m x) s := by
  cases s with
  | term v => simp only [DAG.bypass, DAG.eval]
  | node i =>
    rw [DAG.bypass, DAG.eval.eq_2]
    cases he : m (g.level i) with
    | some b =>
      simpa only [overrideInput, he, Option.getD_some] using g.eval_restrict m x (g.child i b)
    | none =>
      rw [DAG.eval]
      simpa only [DAG.restrict, overrideInput, he, Option.getD_none] using
        g.eval_restrict m x (g.child i (x (g.level i)))
termination_by s.height
decreasing_by all_goals apply g.drops

/-- The final one-root model has one shared table for all primes, one for
all subs, and r root elements. The left and right orders are independent. -/
structure RootDAG (P S r : Nat) where
  left : DAG P
  right : DAG S
  prime : Fin r → State P
  sub : Fin r → State S
  selectCase : Input → Fin r
  partition : ∀ x i, left.eval x (prime i) = true ↔ selectCase x = i
  live : ∀ i, ∃ x, selectCase x = i
  compressed : ∀ i j, (∀ y, right.eval y (sub i) = right.eval y (sub j)) → i = j

def RootDAG.decision (c : RootDAG P S r) : Decision Input Input r where
  prime i x := c.left.eval x (c.prime i)
  sub i y := c.right.eval y (c.sub i)
  selectCase := c.selectCase
  partition := c.partition
  compressed := c.compressed

abbrev RootDAG.run (c : RootDAG P S r) := c.decision.run
def RootDAG.wireCount (_c : RootDAG P S r) := 2*P + 2*S + 3*r

theorem RootDAG.lower_from_rows (c : RootDAG P S r) (a : Fin t → Input)
    (h : ∀ i j, i ≠ j → ∃ y, c.run (a i) y ≠ c.run (a j) y) :
    3*t ≤ c.wireCount := by
  have hc := c.decision.root_elements_lower a h
  simp [RootDAG.wireCount]; omega

/-- Route from semantic constant-one witnesses directly to a wire lower
bound of the actual circuit, including arbitrary DAG sharing. -/
theorem RootDAG.lower_from_one_prime (c : RootDAG P S r) (p : Nat)
    (x₀ : Input) (one : ∀ y, c.run x₀ y = true) (a : Fin t → Input)
    (sep : ∀ i j, i ≠ j → ∃ z,
      ¬ ((∀ y, c.run (join p (a i) z) y = true) ↔
         (∀ y, c.run (join p (a j) z) y = true))) :
    t ≤ P + 2 ∧ 2*t ≤ c.wireCount + 4 := by
  have u := c.decision.forced_const_one x₀ one
  have w := c.left.width_lower (c.prime (c.selectCase x₀)) p a (by
    intro i j hij
    obtain ⟨z, hz⟩ := sep i j hij
    refine ⟨z, ?_⟩
    intro he
    apply hz
    rw [← u, ← u]
    change (c.left.eval (join p (a i) z) (c.prime (c.selectCase x₀)) = true ↔ c.left.eval (join p (a j) z) (c.prime (c.selectCase x₀)) = true)
    rw [he])
  exact ⟨w, by simp [RootDAG.wireCount]; omega⟩

/-- Fix the left assignment to select a single right gate and then restrict
fixed right variables. Its reachable OBDD still has at most S nonterminals. -/
theorem RootDAG.selected_restriction (c : RootDAG P S r) (x : Input) (m : Mask) :
    ∃ (d : DAG S) (s : State S), ∀ y, d.eval y s = c.run x (overrideInput m y) :=
  ⟨c.right.restrict m, c.right.bypass m (c.sub (c.selectCase x)),
    fun y => c.right.eval_restrict m y _⟩

end HWB.Circuit
