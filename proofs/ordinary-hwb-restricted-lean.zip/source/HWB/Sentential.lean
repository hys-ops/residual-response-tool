import HWB.ReducedModel

/-! Explicit AND/OR syntax for the right-linear banks of a sentential root.
The shared Boolean terminals have no input wires. The leaf for the final
variable is a signed literal, never a decomposition with a missing right child. -/
namespace HWB.Sentential
open HWB.Circuit HWB.Model

structure Literal where
  level : Nat
  sign : Bool

def Literal.eval (l : Literal) (x : Input) : Bool := x l.level == l.sign

structure Element (N : Nat) where
  prime : Literal
  sub : State N

inductive Kind where
  | literal (sign : Bool)
  | decision
deriving DecidableEq

/-- A literal or an OR of two AND elements with opposite literal primes.
Elements retain pointers to shared table entries. -/
structure Table (N : Nat) where
  level : Fin N → Nat
  kind : Fin N → Kind
  sub : Fin N → Bool → State N
  decreases : ∀ i b, (sub i b).height < (State.node i).height

def Table.element (T : Table N) (i : Fin N) (b : Bool) : Element N :=
  ⟨⟨T.level i,b⟩, T.sub i b⟩

def Table.eval (T : Table N) (x : Input) (s : State N) : Bool :=
  match s with
  | .term b => b
  | .node i =>
    match T.kind i with
    | .literal sign => (Literal.mk (T.level i) sign).eval x
    | .decision =>
      ((T.element i false).prime.eval x && T.eval x ((T.element i false).sub)) ||
      ((T.element i true).prime.eval x && T.eval x ((T.element i true).sub))
termination_by s.height
decreasing_by all_goals apply T.decreases

/-- A literal has no incoming wire. A binary decision has four wires into
the two AND elements and two wires from those elements into the OR. -/
def Table.wires (T : Table N) : Nat :=
  6 * ((List.finRange N).filter (fun i => decide (T.kind i = .decision))).length

theorem Table.wires_le (T : Table N) : T.wires ≤ 6*N := by
  have h := List.length_filter_le (fun i => decide (T.kind i = .decision)) (List.finRange N)
  exact Nat.mul_le_mul_left 6 (by simpa using h)

private def terminalBit : State N → Bool
  | .term b => b
  | .node _ => false

def expand (g : DAG N) (w : Nat) : Table N where
  level := g.level
  kind i := if g.level i + 1 < w then .decision else .literal (terminalBit (g.child i true))
  sub := g.child
  decreases := g.drops

/-- A last-level child must be a terminal: edge levels strictly increase and
each queried level is inside this finite bank. -/
private theorem final_child (g : DAG N) (bounds : ∀ j, g.level j < w)
    (i : Fin N) (last : ¬g.level i +1 < w) (b : Bool) : ∃ v, g.child i b = .term v := by
  cases e : g.child i b with
  | term v => exact ⟨v,rfl⟩
  | node j => have := g.advances i b j e; have := bounds j; omega

theorem expand_eval (g : DAG N) (w : Nat) (xs : K → Input)
    (bounds : ∀ j, g.level j < w)
    (vary : ∀ i, ∃ a, g.eval (xs a) (g.child i false) ≠ g.eval (xs a) (g.child i true))
    (s : State N) (x : Input) : (expand g w).eval x s = g.eval x s := by
  cases s with
  | term v => simp only [Table.eval,DAG.eval]
  | node i =>
    rw [Table.eval, DAG.eval]
    by_cases h : g.level i+1<w
    · simp only [expand,ite_eq_left h,Table.element,Literal.eval]
      cases eqb : x (g.level i) with
      | false => simpa [expand] using expand_eval g w xs bounds vary (g.child i false) x
      | true => simpa [expand] using expand_eval g w xs bounds vary (g.child i true) x
    · simp only [expand,ite_eq_right h,Literal.eval]
      obtain ⟨lo,elo⟩ := final_child g bounds i h false
      obtain ⟨hi,ehi⟩ := final_child g bounds i h true
      obtain ⟨a,sep⟩ := vary i
      rw [elo,ehi] at sep
      simp only [DAG.eval] at sep
      cases eqb : x (g.level i) <;> simp [elo,ehi,terminalBit,DAG.eval] <;>
        cases lo <;> cases hi <;> simp_all
termination_by s.height
decreasing_by all_goals apply g.drops

/-- Satisfaction of the two signed primes forms an exhaustive, mutually
exclusive partition. Each sign has a satisfying setting of the one left variable. -/
theorem Table.prime_partition (T : Table N) (i : Fin N) (x : Input) :
    (∀ b, (T.element i b).prime.eval x = true ↔ x (T.level i) = b) ∧
    (∀ b, ∃ y : Input, (T.element i b).prime.eval y = true) := by
  constructor
  · intro b; simp [Table.element, Literal.eval]
  · intro b; exact ⟨fun _ => b, by simp [Table.element, Literal.eval]⟩

inductive VTree where
  | leaf (label : Nat)
  | fork (left right : VTree)
deriving DecidableEq

/-- A spine contains one leaf more than its last argument. The order-to-label
map permits any permutation of the original variable names. -/
def spine (label : Nat → Nat) (a : Nat) : Nat → VTree
  | 0 => .leaf (label a)
  | q+1 => .fork (.leaf (label a)) (spine label (a+1) q)

inductive Subtree : VTree → VTree → Prop where
  | refl (v) : Subtree v v
  | left {u v z} : Subtree u v → Subtree u (.fork v z)
  | right {u v z} : Subtree u z → Subtree u (.fork v z)

theorem spine_suffix (label : Nat → Nat) (a gap rest : Nat) :
    Subtree (spine label (a+gap) rest) (spine label a (gap+rest)) := by
  induction gap generalizing a with
  | zero => simp [Subtree.refl]
  | succ g ih =>
    rw [Nat.succ_add,spine]
    apply Subtree.right
    simpa [Nat.add_assoc,Nat.add_comm,Nat.add_left_comm] using ih (a+1)

/-- The right operand at a decision may skip levels. Its scope is still a
subtree of the right child of the chosen spine node, and the left prime is the
literal at that node. Constants work at any available child subtree. -/
theorem expand_scope (g : DAG N) {w : Nat} (bounds : ∀ j, g.level j < w)
    (label : Nat → Nat) (i : Fin N) (hi : (expand g w).kind i = .decision) :
    g.level i+1<w ∧
    spine label (g.level i) (w-1-g.level i) =
      .fork (.leaf (label (g.level i))) (spine label (g.level i+1) (w-2-g.level i)) ∧
    ∀ b j, (expand g w).sub i b = .node j →
      Subtree (spine label (g.level j) (w-1-g.level j))
        (spine label (g.level i+1) (w-2-g.level i)) := by
  have hr : g.level i+1<w := by
    by_cases h : g.level i+1<w
    · exact h
    · simp [expand,h] at hi
  refine ⟨hr, ?_, ?_⟩
  · rw [show w-1-g.level i = (w-2-g.level i)+1 by omega,spine]
  · intro b j hj
    have adv := g.advances i b j hj
    have bj := bounds j
    have off : g.level i+1+(g.level j-(g.level i+1)) = g.level j := by omega
    have wid : (g.level j-(g.level i+1))+(w-1-g.level j) = w-2-g.level i := by omega
    simpa only [off,wid] using spine_suffix label (g.level i+1) (g.level j-(g.level i+1)) (w-1-g.level j)



/-- For every internal OR the syntax respects its suffix vtree, the two subs
are semantically different on a legal assignment, and the singleton-variable
primes are opposite satisfiable literals (see Table.prime_partition). -/
def Table.BankCertificate (T : Table N) (w : Nat) (xs : K → Input) : Prop :=
  (∀ i, T.level i < w) ∧
  ∀ i, T.kind i = .decision →
    (T.level i +1 < w) ∧
    (∀ b j, T.sub i b = .node j → T.level i < T.level j) ∧
    ∃ x : K, T.eval (xs x) (T.sub i false) ≠ T.eval (xs x) (T.sub i true)

theorem expand_certificate (g : DAG N) (w : Nat) (xs : K → Input)
    (bounds : ∀ j, g.level j < w)
    (vary : ∀ i, ∃ a, g.eval (xs a) (g.child i false) ≠ g.eval (xs a) (g.child i true)) :
    (expand g w).BankCertificate w xs := by
  refine ⟨bounds, ?_⟩
  intro i h
  refine ⟨(expand_scope g bounds id i h).1, g.advances i, ?_⟩
  obtain ⟨x, hx⟩ := vary i
  exact ⟨x, by
    change (expand g w).eval (xs x) (g.child i false) ≠ (expand g w).eval (xs x) (g.child i true)
    rwa [expand_eval g w xs bounds vary, expand_eval g w xs bounds vary]⟩

structure RootTable (P S r : Nat) where
  primes : Table P
  subs : Table S
  element : Fin r → State P × State S

def RootTable.eval (t : RootTable P S r) (x y : Input) : Bool :=
  (List.finRange r).any fun i =>
    t.primes.eval x (t.element i).1 && t.subs.eval y (t.element i).2

def RootTable.wires (t : RootTable P S r) := 3*r + t.primes.wires + t.subs.wires

noncomputable def exportRoot (c : OneRoot n) :
    RootTable c.normalize.NP c.normalize.NS c.R where
  primes := expand c.normalize.gP c.A.length
  subs := expand c.normalize.gS c.B.length
  element i := (c.normalize.pRoot i,c.normalize.sRoot i)

private theorem export_prime (c : OneRoot n) (i : Fin c.R) (x : Assignment c.A) :
    (exportRoot c).primes.eval (bits c.A x.val) ((exportRoot c).element i).1 = c.dec.prime i x := by
  change (expand c.normalize.gP c.A.length).eval _ (c.normalize.pRoot _) = _
  rw [expand_eval _ _ (fun x : Assignment c.A => bits c.A x.val) c.normalize_levels.1
    c.normalize_isNormalized.1]
  exact (c.normalize.prime_eq i x).symm

private theorem export_sub (c : OneRoot n) (i : Fin c.R) (y : Assignment c.B) :
    (exportRoot c).subs.eval (bits c.B y.val) ((exportRoot c).element i).2 = c.dec.sub i y := by
  change (expand c.normalize.gS c.B.length).eval _ (c.normalize.sRoot _) = _
  rw [expand_eval _ _ (fun y : Assignment c.B => bits c.B y.val) c.normalize_levels.2
    c.normalize_isNormalized.2]
  exact (c.normalize.sub_eq i y).symm

theorem export_correct (c : OneRoot n) (x : Assignment c.A) (y : Assignment c.B) :
    (exportRoot c).eval (bits c.A x.val) (bits c.B y.val) =
      decide (x.val.length+y.val.length ∈ x.val++y.val) := by
  rw [←c.correct]
  apply Bool.eq_iff_iff.mpr
  simp only [RootTable.eval,List.any_eq_true,List.mem_finRange,true_and,
    Bool.and_eq_true, export_prime, export_sub, c.dec.partition]
  constructor
  · rintro ⟨i,hp,hs⟩
    simpa [Decision.run,hp] using hs
  · intro h; exact ⟨_,rfl,h⟩

theorem export_cost (c : OneRoot n) : (exportRoot c).wires ≤ 3*c.wires := by
  have hp := (exportRoot c).primes.wires_le
  have hs := (exportRoot c).subs.wires_le
  have h := c.normalize_wires
  unfold RootTable.wires
  change 3*c.R+2*(c.normalize.NP+c.normalize.NS) ≤ c.wires at h
  omega

/-- Explicit root S3--S5, compression at the root, and the compressed,
right-linear internal nodes. Every root element has a satisfying left input.
Equality of right subs is tested over all original right assignments. -/
theorem export_structure (c : OneRoot n) :
    let T := exportRoot c
    T.primes.BankCertificate c.A.length (fun x : Assignment c.A => bits c.A x.val) ∧
    T.subs.BankCertificate c.B.length (fun y : Assignment c.B => bits c.B y.val) ∧
    (∀ i, ∃ x : Assignment c.A, T.primes.eval (bits c.A x.val) (T.element i).1 = true) ∧
    (∀ (x : Assignment c.A) i, T.primes.eval (bits c.A x.val) (T.element i).1 = true ↔
       c.dec.selectCase x = i) ∧
    (∀ i j, (∀ y : Assignment c.B, T.subs.eval (bits c.B y.val) (T.element i).2 =
        T.subs.eval (bits c.B y.val) (T.element j).2) → i=j) := by
  refine ⟨expand_certificate _ _ _ c.normalize_levels.1 c.normalize_isNormalized.1,
    expand_certificate _ _ _ c.normalize_levels.2 c.normalize_isNormalized.2, ?_, ?_, ?_⟩
  · intro i; obtain ⟨x,h⟩ := c.feasible i
    exact ⟨x, by rw [export_prime,c.dec.partition]; exact h⟩
  · intro x i; rw [export_prime,c.dec.partition]
  · intro i j h
    apply c.dec.compressed
    intro y
    simpa only [export_sub] using h y

end HWB.Sentential
