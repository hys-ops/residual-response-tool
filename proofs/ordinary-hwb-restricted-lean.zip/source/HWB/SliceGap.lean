import HWB.GapBridge
import HWB.Slice

namespace HWB.Slice

open HWB.Model HWB.Circuit

/-- At the all-zero prefix exit, fixing the residual left bank to zero
selects a single original sub. Its input inherits the exit's arbitrary B-order. -/
theorem ZeroRoot.small_left_DAG (c : ZeroRoot n D) (d : Nat)
    (few : c.A.length+D.length ≤ d)
    (large : 3*((d+1)*(d+1)) ≤ n) : 2^(d/16) ≤ c.NS+2 := by
  let zero : Assignment c.A := ⟨[], by simp⟩
  let i := c.dec.selectCase zero
  apply GapBridge.small_left_zero_slice c.gS (c.sRoot i) c.B d c.nb
    (fun j hj => (c.domain j).mp (by simp [hj])) (by have := c.total; omega) large
  intro y
  rw [← c.sub_eq i y]
  simpa [zero, Decision.run] using c.correct zero y

end HWB.Slice
