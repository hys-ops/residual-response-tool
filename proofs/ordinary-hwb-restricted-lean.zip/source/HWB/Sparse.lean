import HWB.UpperFinal

/-! The sparse right OBDD remembers the total Hamming weight and a mask of the
candidate labels in the query window. The candidate list may contain repeated
or out-of-domain labels: the first occurrence is sufficient for addressing. -/
namespace HWB.Sparse
open HWB.Upper HWB.Response HWB.Circuit

abbrev width (C : List Nat) := 2^C.length
theorem width_pos (C : List Nat) : 0 < width C := Nat.two_pow_pos _

def pack (C : List Nat) (k : Nat) (count : Fin (k+1)) (mask : Fin (width C)) :
    Fin (width C * (k+1)) :=
  ⟨mask.val + width C * count.val, by
    have hm := Nat.mul_le_mul_left (width C) (show count.val+1 ≤ k+1 by omega)
    rw [Nat.mul_succ] at hm; omega⟩

def countReg (C : List Nat) (k : Nat) (s : Fin (width C * (k+1))) : Fin (k+1) :=
  ⟨s.val / width C, (Nat.div_lt_iff_lt_mul (width_pos C)).mpr (by simpa [Nat.mul_comm] using s.isLt)⟩

def maskReg (C : List Nat) (k : Nat) (s : Fin (width C * (k+1))) : Fin (width C) :=
  ⟨s.val % width C, Nat.mod_lt _ (width_pos C)⟩

@[simp] theorem count_pack (C k c m) : countReg C k (pack C k c m) = c := by
  apply Fin.ext
  simp [countReg,pack,Nat.add_mul_div_left _ _ (width_pos C),Nat.div_eq_of_lt m.isLt]

@[simp] theorem mask_pack (C k c m) : maskReg C k (pack C k c m) = m := by
  apply Fin.ext
  simp [maskReg,pack,Nat.add_mul_mod_self_left,Nat.mod_eq_of_lt m.isLt]

def step (C : List Nat) (k j : Nat) (s : Fin (width C*(k+1))) (b : Bool) :
    Fin (width C*(k+1)) :=
  pack C k ⟨min k ((countReg C k s).val+b.toNat),Nat.lt_succ_of_le (Nat.min_le_left ..)⟩
    (mark C j (maskReg C k s) b)

def start (C : List Nat) (k : Nat) : Fin (width C*(k+1)) :=
  pack C k ⟨0,by omega⟩ ⟨0,width_pos C⟩

def machine (B C : List Nat) (w : Key B) : OrderedCounter (width C*(B.length+1)) where
  initial := start C B.length
  next := step C B.length
  accept s :=
    let count := countReg C B.length s
    let j := w.1 + count.val
    w.2 count || (decide (j ∈ C) && (maskReg C B.length s).val.testBit (C.idxOf j))

theorem count_read (B C : List Nat) (w : Key B) (x : Nat → Bool)
    (L : List Nat) (s : Fin (width C*(B.length+1))) :
    (countReg C B.length (go (machine B C w) x L s)).val =
    min B.length ((countReg C B.length s).val+(L.filter x).length) := by
  induction L generalizing s with
  | nil =>
    simp only [go,List.filter_nil,List.length_nil,Nat.add_zero]
    have := (countReg C B.length s).isLt
    omega
  | cons j L ih =>
    rw [go,ih]
    change min _ ((countReg C B.length (step C B.length j s (x j))).val+_) = _
    rw [step,count_pack]
    cases hb : x j <;> simp [hb] <;> omega

theorem mask_read (B C : List Nat) (w : Key B) (x : Nat → Bool) (L : List Nat)
    (s : Fin (width C*(B.length+1))) (hj : j ∈ C) :
    (maskReg C B.length (go (machine B C w) x L s)).val.testBit (C.idxOf j) =
      ((maskReg C B.length s).val.testBit (C.idxOf j) || decide (j ∈ L.filter x)) := by
  induction L generalizing s with
  | nil => simp [go]
  | cons z L ih =>
    rw [go,ih]
    have hzi (hz : z ∈ C) : (C.idxOf z = C.idxOf j) ↔ z = j := by
      have h₁ := List.idxOf_lt_length_of_mem hz
      have h₂ := List.idxOf_lt_length_of_mem hj
      refine ⟨fun eq => ?_,fun eq => by rw [eq]⟩
      have h₃ : C[C.idxOf z] = C[C.idxOf j] := by simp only [eq]
      exact (List.getElem_idxOf h₁).symm.trans (h₃.trans (List.getElem_idxOf h₂))
    change (((maskReg C B.length (step C B.length z s (x z))).val.testBit (C.idxOf j)) || _) = _
    rw [step,mask_pack]
    by_cases hz : z ∈ C
    · cases hb : x z <;> by_cases h : z = j <;>
        simp_all [machine,mark,Ne.symm,Bool.or_comm]
    · have hn : j ≠ z := fun h => hz (h ▸ hj)
      cases hb : x z <;> simp_all [machine,mark]

/-- The only property required of the remembered coordinates is that they
cover every right label in this key's length-k address window. -/
theorem machine_yes (B C : List Nat) (w : Key B)
    (covers : ∀ j ∈ B, w.1 ≤ j → j ≤ w.1+B.length → j ∈ C) (x : Nat → Bool) :
    value (machine B C w) B x = true ↔ sub w (B.filter x) := by
  let M := machine B C w
  let s := go M x B M.initial
  let Y := B.filter x
  have hw : Y.length ≤ B.length := List.length_filter_le ..
  have hc : (countReg C B.length s).val = Y.length := by
    have h := count_read B C w x B M.initial
    simpa [s,M,machine,start,Y,Nat.min_eq_right hw] using h
  let addr := w.1+Y.length
  have hm : (decide (addr ∈ C) && (maskReg C B.length s).val.testBit (C.idxOf addr)) =
      decide (addr ∈ Y) := by
    by_cases h : addr ∈ C
    · have hr := mask_read B C w x B M.initial h
      simpa [h,s,M,machine,start,Y,Nat.zero_testBit] using hr
    · have hn : addr ∉ Y := fun hy => h (covers _ ((List.mem_filter.mp hy).1) (by dsimp [addr]; omega)
        (by dsimp [addr]; omega))
      simp [h,hn]
  change (w.2 (countReg C B.length s) || _) = true ↔ sub w Y
  have he : countReg C B.length s = ⟨Y.length,by omega⟩ := Fin.ext hc
  change (_ || (decide (_ ∈ C) && (maskReg C B.length s).val.testBit _)) = true ↔ _
  rw [he]
  change (_ || (decide (addr ∈ C) && _)) = true ↔ _
  rw [hm]
  simp [sub,hw,addr]

open HWB.UpperFinal HWB.Markers HWB.Model

private def compiled (n : Nat) (i : RootKey (L n) (R n)) :=
  compile (machine (R n) (candidates n i.val.1) i.val) (R n)

private theorem fits (n : Nat) (i : RootKey (L n) (R n)) :
    (compiled n i).N ≤ sparseCost n := by
  exact Nat.le_of_eq (compile_size (machine (R n) (candidates n i.val.1) i.val) (R n))

/-- A real common-order right OBDD for every feasible root element, with
k layers and 16(k+1) state addresses per layer, including all mask and weight
states. No oracle or truth table from the old construction is used. -/
noncomputable def sparseBank (n : Nat) (hn : 3 ≤ n) : RightBank n (sparseCost n) where
  r i := pad (compiled n i).g (fits n i)
  srcS i := promote (fits n i) ((compiled n i).root
    (machine (R n) (candidates n i.val.1) i.val).initial)
  specS i y := by
    let B := R n
    let C := candidates n i.val.1
    let χ := fun j => decide (j ∈ y.val)
    change (pad _ _).eval (orderedInput B χ) (promote _ _) = true ↔ _
    rw [pad_eval]
    change (compile (machine B C i.val) B).g.eval (orderedInput B χ)
      ((compile (machine B C i.val) B).root _) = true ↔ _
    rw [compile_eval]
    change value (machine B C i.val) B χ = true ↔ _
    rw [machine_yes B C i.val (fun _ h lo hi => mem_candidates hn h lo hi)]
    obtain ⟨hl,hm⟩ := filter_assignment (right_nodup hn) y
    simp only [sub,χ,B,hl,hm]

/-- The full paper upper bound for the ordinary, auxiliary-free function in the
same wire model used by the lower bound. The only premise is n ≥ 3. -/
theorem paper_upper (hn : 3 ≤ n) : ∃ c : OneRoot n, c.wires ≤ 512*n^3*2^(n.sqrt+1) :=
  paper_upper_from_sparse hn (sparseBank n hn)

end HWB.Sparse
