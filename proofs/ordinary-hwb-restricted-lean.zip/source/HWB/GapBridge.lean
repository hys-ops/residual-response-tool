import HWB.Gap
import HWB.Model
import HWB.Balanced

namespace HWB.GapBridge
open HWB.Circuit HWB.Model HWB.Gap HWB.Balanced

/-- Original (one-based) labels whose bits are set in this interval. -/
def support (p : Nat) : List Bool → List Nat
  | [] => []
  | b :: xs => if b then (p+1) :: support (p+1) xs else support (p+1) xs

private theorem support_spec (p : Nat) (w : List Bool) (j : Nat) :
    j ∈ support p w ↔ p < j ∧ w[j-p-1]? = some true := by
  induction w generalizing p with
  | nil => simp [support]
  | cons b w ih =>
    by_cases hj : j = p+1
    · subst j
      have hn := ih (p+1)
      simp only [Nat.lt_irrefl, false_and, iff_false] at hn
      cases b <;> simp [support, hn]
    · by_cases hlt : j ≤ p
      · have hn : j ∉ support (p+1) w := fun h => by have := ((ih _).mp h).1; omega
        cases b <;> simp [support, hn, hj, Nat.not_lt_of_ge hlt]
      · have h₂ : p+1 < j := by omega
        have he : j-p-1 = (j-(p+1)-1)+1 := by omega
        cases b <;> simp [support, ih, h₂, hj, he, show p<j by omega]

theorem support_nodup (p : Nat) (w : List Bool) : (support p w).Nodup := by
  induction w generalizing p with
  | nil => simp [support]
  | cons b w ih =>
    cases b with
    | false => simpa [support] using ih (p+1)
    | true =>
      simp only [support, ↓reduceIte, List.nodup_cons]
      exact ⟨fun h => (Nat.lt_irrefl _) ((support_spec _ _ _).mp h).1, ih _⟩

theorem support_length (p : Nat) (w : List Bool) : (support p w).length = w.count true := by
  induction w generalizing p with
  | nil => rfl
  | cons b w ih => cases b <;> simp [support, ih]

def bankMask (bank : List Nat) (n : Nat) :=
  List.ofFn (fun i : Fin n => decide (i.val+1 ∈ bank))

private theorem mask_at {bank n j} (hj : j < n) :
    (bankMask bank n)[j]? = some (decide (j+1 ∈ bank)) := by
  simp [bankMask, hj]

private theorem of_mask_at {bank n j} (h : (bankMask bank n)[j]? = some true) :
    j+1 ∈ bank := by
  by_cases hj : j<n
  · simpa [mask_at hj] using h
  · simp [bankMask, hj] at h

private theorem support_bank {B n} (br : ∀ j ∈ B, 1 ≤ j ∧ j ≤ n) :
    B ⊆ support 0 (bankMask B n) := by
  intro j hj
  have hr := br j hj
  have he : j-1+1=j := by omega
  apply (support_spec ..).mpr
  refine ⟨by omega, ?_⟩
  simp [mask_at (show j-1<n by omega), he, hj]

/-- A literal restriction of one right bank: the free labels are p+1,...,p+d.
All fixed one labels lie strictly above the entire block. -/
structure Minor (B : List Nat) (d : Nat) where
  p : Nat
  pad : List Nat
  card : pad.length = p
  unique : pad.Nodup
  hasPad : pad ⊆ B
  beyond : ∀ j ∈ pad, p+d < j
  hasBlock : ∀ i, 1 ≤ i → i ≤ d → p+i ∈ B

theorem minor_exists {B : List Nat} {n d : Nat}
    (nb : B.Nodup) (br : ∀ j ∈ B, 1 ≤ j ∧ j ≤ n)
    (holes : n ≤ B.length + d) (large : 3*((d+1)*(d+1)) ≤ n) :
    Nonempty (Minor B d) := by
  let m := bankMask B n
  have mlen : m.length=n := by simp [m, bankMask]
  have hb : B.length ≤ m.count true := by
    rw [← support_length 0 m]
    exact nb.length_le_of_subset (support_bank br)
  have h := count_bits m
  obtain ⟨u,v,z,shape,fits,hz,_⟩ := small_left_restriction m d (by omega) (by omega)
  let p := u.length
  refine ⟨{ p := p, pad := support (p+d) z, card := (support_length ..).trans hz,
            unique := support_nodup .., beyond := ?_, hasPad := ?_, hasBlock := ?_ }⟩
  · intro j hj
    have ⟨hr, atz⟩ := (support_spec ..).mp hj
    have atv := fits.lookup _ atz
    have hidx : (j-1) - (u++List.replicate d true).length = j-(p+d)-1 := by
      simp [p]; omega
    have ha : m[j-1]? = some true := by
      rw [shape, List.getElem?_append_right (by simp [p] at *; omega), hidx]
      exact atv
    have hmem := of_mask_at ha
    simpa [show j-1+1=j by omega] using hmem
  · intro j hj; exact ((support_spec ..).mp hj).1
  · intro i il ih
    have hidx : p+i-1 - u.length = i-1 := by dsimp [p]; omega
    have ha : m[p+i-1]? = some true := by
      rw [shape, List.getElem?_append_left (by simp [p]; omega),
        List.getElem?_append_right (by dsimp [p]; omega), hidx, List.getElem?_replicate]
      simp [show i-1<d by omega]
    have hmem := of_mask_at ha
    simpa [show p+i-1+1=p+i by omega] using hmem



def Minor.decode (M : Minor B d) (j : Nat) : Option Nat :=
  if M.p < j ∧ j ≤ M.p+d then some (j-M.p) else none

private theorem decode_some (M : Minor B d) {i j} :
    M.decode j = some i ↔ (1≤i ∧ i≤d) ∧ j=M.p+i := by
  unfold Minor.decode
  split <;> rename_i h <;> simp <;> omega

def Minor.chart (M : Minor B d) : List (Option Nat) := B.map M.decode

private theorem chart_member (M : Minor B d) {i} :
    i ∈ M.chart.filterMap id ↔ 1≤i ∧ i≤d := by
  change i ∈ (B.map M.decode).filterMap id ↔ _
  rw [List.filterMap_map, List.mem_filterMap]
  constructor
  · rintro ⟨j,_,hj⟩; exact ((decode_some M).mp hj).1
  · intro ir; exact ⟨_, M.hasBlock _ ir.1 ir.2, (decode_some M).mpr ⟨ir,rfl⟩⟩

private theorem chart_unique (M : Minor B d) (nb : B.Nodup) :
    (M.chart.filterMap id).Nodup := by
  have nh (L : List Nat) (h : L.Nodup) : (L.filterMap M.decode).Nodup := by
    induction L with
    | nil => simp
    | cons j js ih =>
      obtain ⟨nmem,hjs⟩ := List.nodup_cons.mp h
      cases eqd : M.decode j with
      | none => simpa [eqd] using ih hjs
      | some i =>
        rw [List.filterMap_cons_some eqd, List.nodup_cons]
        refine ⟨?_,ih hjs⟩
        intro hi
        obtain ⟨j',hj',eqd'⟩ := List.mem_filterMap.mp hi
        exact nmem ((((decode_some M).mp eqd).2.trans ((decode_some M).mp eqd').2.symm) ▸ hj')
  simpa [Minor.chart, List.filterMap_map, Function.comp_def] using nh B nb

private theorem chart_length (M : Minor B d) (nb : B.Nodup) :
    (M.chart.filterMap id).length = d := by
  let dom := (List.range d).map (·+1)
  have nodup : dom.Nodup := List.nodup_range.map _ (fun _ _ ne eqs => ne (by omega))
  have memdom (i : Nat) : i ∈ dom ↔ 1≤i ∧ i≤d := by
    simp [dom]; constructor
    · rintro ⟨j,hj,eqj⟩; omega
    · intro h; exact ⟨i-1,by omega,by omega⟩
  have h₁ := nodup.length_le_of_subset (l₂ := M.chart.filterMap id)
    (fun i hi => (chart_member M).mpr ((memdom i).mp hi))
  have h₂ := (chart_unique M nb).length_le_of_subset (l₂ := dom)
    (fun i hi => (memdom i).mpr ((chart_member M).mp hi))
  have len : dom.length=d := by simp [dom]
  omega

/-- Embed a support set of the smaller HWB into the original right bank. -/
def Minor.lift (M : Minor B d) (x : List Nat) : List Nat :=
  x.map (M.p+·) ++ M.pad

private theorem lift_legal (M : Minor B d) {x : List Nat} (h : Legal (M.chart.filterMap id) x) :
    Legal B (M.lift x) := by
  have edge (i : Nat) (hi : i∈x) : 1≤i ∧ i≤d := (chart_member M).mp (h.2 hi)
  constructor
  · apply List.nodup_append.mpr
    refine ⟨h.1.map _ (fun _ _ ne eqs => ne (by omega)), M.unique, ?_⟩
    intro a ha b hb
    obtain ⟨i, hi, eqi⟩ := List.mem_map.mp ha
    have := edge i hi; have := M.beyond b hb; omega
  · intro j hj
    rcases List.mem_append.mp hj with hv|hz
    · obtain ⟨i,hi,eqi⟩ := List.mem_map.mp hv
      exact eqi ▸ M.hasBlock i (edge i hi).1 (edge i hi).2
    · exact M.hasPad hz

private theorem lifted_raw (M : Minor B d) (nb : B.Nodup) {x : List Nat}
    (h : Legal (M.chart.filterMap id) x) :
    decide ((M.lift x).length ∈ M.lift x) = decide (x.length ∈ x) := by
  have xl := h.1.length_le_of_subset h.2
  rw [chart_length M nb] at xl
  simp only [Minor.lift, List.length_append, List.length_map, M.card,
    List.mem_append, List.mem_map]
  have hpad : x.length+M.p ∉ M.pad := fun hh => by have := M.beyond _ hh; omega
  simp only [hpad, or_false]
  congr 1
  apply propext
  constructor
  · rintro ⟨i,hi,eq⟩; simpa [show i=x.length by omega] using hi
  · intro hmem; exact ⟨x.length,hmem,by omega⟩



private theorem chart_lift (M : Minor B d) {x : List Nat} (h : Legal (M.chart.filterMap id) x) :
    chartInput M.chart (bits B M.pad) x = bits B (M.lift x) := by
  funext pos
  unfold chartInput Minor.chart bits
  rw [List.getElem?_map]
  cases bh : B[pos]? with
  | none => rfl
  | some j =>
    simp only [Option.map_some, Option.join_some, Option.any_some]
    cases decj : M.decode j with
    | none =>
      have nh : j ∉ x.map (M.p+·) := by
        intro mem; obtain ⟨i,hi,eqi⟩ := List.mem_map.mp mem
        have ir := (chart_member M).mp (h.2 hi)
        have := (decode_some M).mpr ⟨ir,eqi.symm⟩
        rw [decj] at this
        contradiction
      simp [Minor.lift, nh]
    | some i =>
      have ⟨ir,he⟩ := (decode_some M).mp decj
      have np : j ∉ M.pad := fun hpad => by have := M.beyond _ hpad; omega
      have hm : j ∈ x.map (M.p+·) ↔ i∈x := by
        constructor
        · intro hmem; obtain ⟨i',hi',eq'⟩ := List.mem_map.mp hmem
          simpa [show i'=i by omega] using hi'
        · intro hi; exact List.mem_map.mpr ⟨i,hi,he.symm⟩
      simp only [Minor.lift, List.mem_append, hm, np, or_false]

/-- The complement of B may contain both left labels and an arbitrary set of
labels previously fixed to zero. Their total size is bounded, and the ordinary
function keeps its original (uncompressed) label numbering. -/
theorem small_left_zero_slice {n N : Nat} (g : DAG N) (root : State N)
    (B : List Nat) (d : Nat) (nb : B.Nodup)
    (br : ∀ j ∈ B, 1 ≤ j ∧ j ≤ n) (few : n ≤ B.length+d)
    (large : 3*((d+1)*(d+1)) ≤ n)
    (row : ∀ y : Assignment B, g.eval (bits B y.val) root = decide (y.val.length ∈ y.val)) :
    2^(d/16) ≤ N+2 := by
  obtain ⟨M⟩ := minor_exists nb br few large
  have res := dag_restricted_width g root M.chart (bits B M.pad) (chart_unique M nb)
    (fun j hj => by rw [chart_length M nb]; exact ((chart_member M).mp hj).2) (by
      intro x hx
      let y : Assignment B := ⟨M.lift x, lift_legal M hx⟩
      rw [chart_lift M hx]
      change g.eval (bits B y.val) root = _
      rw [row y]
      exact lifted_raw M nb hx)
  rwa [chart_length M nb] at res

/-- All orders of both banks and all compressed root decompositions. Fixing the
entire left bank to zero selects an actual sub-OBDD in the given circuit. -/
theorem small_left_DAG (c : OneRoot n) (d : Nat) (few : c.A.length ≤ d)
    (large : 3*((d+1)*(d+1)) ≤ n) : 2^(d/16) ≤ c.NS+2 := by
  let zero : Assignment c.A := ⟨[], by simp⟩
  let i := c.dec.selectCase zero
  apply small_left_zero_slice c.gS (c.sRoot i) c.B d c.nb
    (fun j hj => (c.domain j).mp (by simp [hj])) (by have := c.total; omega) large
  intro y
  rw [← c.sub_eq i y]
  simpa [zero, Decision.run] using c.correct zero y

end HWB.GapBridge
