import Std

/-! A concrete choice of exactly floor(sqrt n)+1 original, one-based input labels. -/
namespace HWB.Markers

def cells (d : Nat) := (List.range d).map (fun i => (i+1)*d)
def extra (n d : Nat) := if (d+1)*d ≤ n then (d+1)*d else 1
def right (n : Nat) := extra n n.sqrt :: cells n.sqrt

theorem mem_cells {b d : Nat} : b ∈ cells d ↔ ∃ i < d, (i+1)*d = b := by
  simp [cells]

theorem sqrt_pos_of_three (hn : 3 ≤ n) : 0 < n.sqrt := by
  have hs := Nat.lt_succ_sqrt n
  by_cases h : n.sqrt = 0
  · simp [h] at hs
    omega
  · omega

theorem sqrt_plus_one_le (hn : 3 ≤ n) : n.sqrt+1 ≤ n := by
  have h := Nat.sqrt_le n
  have hp := sqrt_pos_of_three hn
  by_cases he : n.sqrt = 1
  · omega
  · have hh := Nat.mul_le_mul_left n.sqrt (show 2 ≤ n.sqrt by omega)
    rw [Nat.mul_two] at hh
    omega

theorem cells_nodup {d : Nat} (hd : 0 < d) : (cells d).Nodup := by
  unfold cells List.Nodup
  apply List.pairwise_map.mpr
  apply List.Pairwise.imp _ List.nodup_range
  intro i j hij eq
  exact hij (Nat.add_right_cancel (Nat.mul_right_cancel hd eq))

theorem right_nodup (hn : 3 ≤ n) : (right n).Nodup := by
  let d := n.sqrt
  have hd : 0 < d := sqrt_pos_of_three hn
  change (extra n d :: cells d).Nodup
  refine List.nodup_cons.mpr ⟨?_,cells_nodup hd⟩
  intro hin
  obtain ⟨i,hi,he⟩ := mem_cells.mp hin
  unfold extra at he
  split at he
  · have := Nat.mul_right_cancel hd he
    omega
  · rename_i h
    have : 1 < d := by
      by_cases hz : d = 1
      · simp [hz] at h
        omega
      · omega
    have hl := Nat.mul_le_mul_right d (Nat.le_add_left 1 i)
    simp at hl
    omega

theorem right_length (n : Nat) : (right n).length = n.sqrt+1 := by
  simp [right,cells]

theorem right_bounds (hn : 3 ≤ n) (hb : b ∈ right n) : 1 ≤ b ∧ b ≤ n := by
  let d := n.sqrt
  have hd : 0 < d := sqrt_pos_of_three hn
  change b ∈ extra n d :: cells d at hb
  rcases List.mem_cons.mp hb with he | hi
  · subst b
    unfold extra
    split
    · exact ⟨Nat.mul_pos (by omega) hd, by assumption⟩
    · omega
  · obtain ⟨i,hidx,he⟩ := mem_cells.mp hi
    subst b
    exact ⟨Nat.mul_pos (by omega) hd, Nat.le_trans (Nat.mul_le_mul_right d hidx) (Nat.sqrt_le n)⟩

/-- Each left weight sees a right projection strictly inside its query window. -/
theorem right_covers (hn : 3 ≤ n) (ha : a ≤ n - (right n).length) :
    ∃ b ∈ right n, a < b ∧ b < a + (right n).length := by
  let d := n.sqrt
  have hd : 0 < d := sqrt_pos_of_three hn
  have hdn : d+1 ≤ n := sqrt_plus_one_le hn
  rw [right_length] at ha ⊢
  change a ≤ n - (d+1) at ha
  have hlt : n < (d+1)*d + (d+1) := by
    rw [←Nat.mul_succ]
    exact Nat.lt_succ_sqrt n
  let q := a / d
  have hq : q < d+1 := (Nat.div_lt_iff_lt_mul hd).mpr (by omega)
  have hmod := Nat.mod_lt a hd
  have hdm := Nat.mod_add_div a d
  rw [Nat.mul_comm d] at hdm
  change a % d + q*d = a at hdm
  have hnear : a < (q+1)*d ∧ (q+1)*d < a+(d+1) := by
    rw [Nat.succ_mul]
    omega
  refine ⟨(q+1)*d, ?_, hnear⟩
  change (q+1)*d ∈ extra n d :: cells d
  by_cases h : q < d
  · exact List.mem_cons_of_mem _ (mem_cells.mpr ⟨q,h,rfl⟩)
  · have eq : q = d := by omega
    have hin : (q+1)*d ≤ n := by omega
    subst_vars
    apply List.mem_cons.mpr
    exact Or.inl (by simp [extra,eq,eq ▸ hin])

def labels (n : Nat) := List.range' 1 n

theorem mem_labels : b ∈ labels n ↔ 1 ≤ b ∧ b ≤ n := by
  simp only [labels,List.mem_range',Nat.one_mul]
  constructor
  · rintro ⟨i,hi,he⟩
    omega
  · rintro ⟨hl,hu⟩
    exact ⟨b-1,by omega,by omega⟩

def left (n : Nat) := (labels n).filter (fun i => !(decide (i ∈ right n)))

theorem mem_left : b ∈ left n ↔ b ∈ labels n ∧ b ∉ right n := by
  simp [left]

theorem left_nodup (n : Nat) : (left n).Nodup :=
  List.Pairwise.filter _ (List.nodup_range' (s:=1) (n:=n))

theorem split_length (hn : 3 ≤ n) : (left n).length + (right n).length = n := by
  let inRight := fun i => decide (i ∈ right n)
  let rs := (labels n).filter inRight
  have hN : rs.Nodup := List.Pairwise.filter _ (List.nodup_range' (s:=1) (n:=n))
  have iffMem (i : Nat) : i ∈ rs ↔ i ∈ right n := by
    simp only [rs, List.mem_filter, inRight, decide_eq_true_eq]
    exact ⟨And.right, fun h => ⟨mem_labels.mpr (right_bounds hn h),h⟩⟩
  have h1 := hN.length_le_of_subset (l₂:=right n) (fun {i} hi => (iffMem i).mp hi)
  have h2 := (right_nodup hn).length_le_of_subset (l₂:=rs) (fun {i} hi => (iffMem i).mpr hi)
  have perm := (List.filter_append_perm inRight (labels n)).length_eq
  change (rs ++ left n).length = (List.range' 1 n).length at perm
  rw [List.length_append,List.length_range'] at perm
  omega

/-- Only four explicit right input positions can matter in a given weight
window. A candidate outside the window is harmless and some candidates can coincide. -/
def candidates (n a : Nat) : List Nat :=
  let d := n.sqrt
  let q := a/d
  [extra n d,q*d,(q+1)*d,(q+2)*d]

@[simp] theorem candidates_length (n a : Nat) : (candidates n a).length = 4 := rfl

theorem mem_candidates (hn : 3 ≤ n) (h : j ∈ right n) (lo : a ≤ j)
    (hi : j ≤ a+(right n).length) : j ∈ candidates n a := by
  let d := n.sqrt
  let q := a/d
  have hd : 0 < d := sqrt_pos_of_three hn
  rw [right_length] at hi
  change j ∈ extra n d :: cells d at h
  simp only [candidates, List.mem_cons, List.not_mem_nil, or_false]
  change j = extra n d ∨ j = q*d ∨ j = (q+1)*d ∨ j = (q+2)*d
  rcases List.mem_cons.mp h with he|hc
  · exact Or.inl he
  obtain ⟨i,_,he⟩ := mem_cells.mp hc
  have hm := Nat.mod_lt a hd
  have hdm := Nat.mod_add_div a d
  rw [Nat.mul_comm d] at hdm
  change a%d+q*d=a at hdm
  have hm1 : q*d ≤ (i+1)*d := by omega
  have hm2 : (i+1)*d ≤ (q+2)*d := by
    rw [Nat.add_mul q 2 d, Nat.two_mul]
    change j ≤ a+(d+1) at hi
    omega
  have h1 : q ≤ i+1 := by
    by_cases hc : q ≤ i+1
    · exact hc
    · have := Nat.mul_lt_mul_of_pos_right (Nat.lt_of_not_ge hc) hd
      omega
  have h2 : i+1 ≤ q+2 := by
    by_cases hc : i+1 ≤ q+2
    · exact hc
    · have := Nat.mul_lt_mul_of_pos_right (Nat.lt_of_not_ge hc) hd
      omega
  have hh : i+1=q ∨ i+1=q+1 ∨ i+1=q+2 := by omega
  exact Or.inr (hh.imp (fun h => he.symm.trans (congrArg (·*d) h))
    (fun h => h.imp (fun h => he.symm.trans (congrArg (·*d) h))
      (fun h => he.symm.trans (congrArg (·*d) h))))

end HWB.Markers
