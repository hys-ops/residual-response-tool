import HWB.Slice
namespace HWB.Slice
/-- Every allowed compressed root circuit with a small right side,
regardless of either variable order and all DAG sharing. -/
theorem ZeroRoot.small_right_exponent (c : ZeroRoot n D) {u : Nat}
    (hn : 4096 ≤ n) (hk : 64*(c.B.length*c.B.length) ≤ n)
    (hd : 64*(D.length*D.length) ≤ n)
    (hu : 1024*((c.B.length+1)*u) ≤ n) : 2^u ≤ c.NP+2 := by
  by_cases ze : u=0
  · simp [ze]
  have pos : 0<u := by omega
  let m := c.A.length/2
  let P := c.A.take m
  let Q := c.A.drop m
  have e : c.A = P ++ Q := (List.take_append_drop m c.A).symm
  have good := List.nodup_append.mp (e ▸ c.na)
  have nlen : P.length+Q.length+c.B.length+D.length=n := by
    simpa only [e, List.length_append] using c.total
  have mid : P.length ≤ Q.length ∧ Q.length ≤ P.length+1 := by
    simp [P,Q,m]; omega
  have pwithin (z) (hz : z ∈ P) : 1≤z ∧ z≤n :=
    (c.domain z).mp (List.mem_append_left _ (List.mem_append_left _ (List.take_subset _ _ hz)))
  have cover (z) (lo : 1≤z) (hi : z≤n) : z∈P ∨ z∈Q ∨ z∈c.B ∨ z∈D := by
    have h := (c.domain z).mpr ⟨lo,hi⟩
    simpa only [e, List.mem_append, or_assoc] using h
  obtain ⟨J,s,jd,jl,w⟩ := HWB.SmallRight.pack_small_right_zero good.1 good.2.1
    (fun z hz hq => good.2.2 z hz z hq rfl) pwithin cover hn hk hd nlen mid hu pos
  simpa [jl] using c.small_right_protected e w jd

theorem ZeroRoot.small_right_lower (c : ZeroRoot n D) (hn : 4096 ≤ n)
    (hk : 64*(c.B.length*c.B.length) ≤ n) (hd : 64*(D.length*D.length) ≤ n) :
    2^(n/(1024*(c.B.length+1))) ≤ c.NP+2 := by
  apply c.small_right_exponent hn hk hd
  simpa [Nat.mul_assoc] using Nat.mul_div_le n (1024*(c.B.length+1))

end HWB.Slice
