import HWB.SmallRight
import HWB.Balanced

namespace HWB.NestedLower
open HWB.SmallRight

private theorem flat_size (L : List Nat) (f : Nat → List Nat) (r : Nat)
    (h : ∀ i ∈ L, (f i).length ≤ r) : (L.flatMap f).length ≤ L.length*r := by
  induction L with
  | nil => simp
  | cons a L ih =>
    have h1 := h a (by simp)
    have h2 := ih (fun i hi => h i (by simp [hi]))
    simpa [List.flatMap_cons, Nat.succ_mul, Nat.add_comm] using Nat.add_le_add h1 h2

private theorem bucket (A : List Nat) (hd : A.Nodup) (f : Nat → Nat) {r t : Nat}
    (hr : 0 < r) (hcap : r*t ≤ A.length) (bound : ∀ j ∈ A, f j < r) :
    ∃ b < r, t ≤ (A.filter (fun j => decide (f j = b))).length := by
  classical
  apply Classical.byContradiction
  intro hh
  let group := fun b => A.filter (fun j => decide (f j = b))
  have short (b) (hb : b < r) : (group b).length < t := by
    exact Nat.lt_of_not_ge (fun h => hh ⟨b,hb,h⟩)
  have ht := short 0 hr
  have incl : A ⊆ (List.range r).flatMap group := by
    intro j hj
    exact List.mem_flatMap.mpr ⟨f j,List.mem_range.mpr (bound j hj), by simp [group,hj]⟩
  have hle := hd.length_le_of_subset incl
  have hsum := flat_size (List.range r) group (t-1) (fun i hi => by
    have := short i (List.mem_range.mp hi); omega)
  simp only [List.length_range] at hsum
  have hlt := Nat.mul_lt_mul_of_pos_left (show t-1<t by omega) hr
  omega

private theorem residue_separates (j z k : Nat) (hj : j ≤ z) (hz : z ≤ j+k)
    (hm : j%(k+1) = z%(k+1)) : z = j := by
  have h1 := Nat.mod_add_div j (k+1)
  have h2 := Nat.mod_add_div z (k+1)
  by_cases h : j/(k+1) = z/(k+1)
  · rw [hm, h] at h1; omega
  have hle := Nat.div_le_div_right (c:=k+1) hj
  have hmul := Nat.mul_le_mul_left (k+1) (show j/(k+1)+1 ≤ z/(k+1) by omega)
  rw [Nat.mul_add_one] at hmul
  omega

/-- Number of starts requested from the archived balanced-window theorem before
deleting forbidden starts and thinning to a single residue. -/
def demand (k h t : Nat) := (k+h)*(k+1)+k+(k+1)*t

/-- Arbitrary D|C cut of the forced universal prime. No relation between
the two bank sizes is required; H permits additional bits fixed to zero. -/
theorem balanced_pack {P Q B H : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z∈P, z∉Q)
    (bounds : ∀ j∈P, 1≤j ∧ j≤n)
    (cover : ∀ z, 1≤z → z≤n → z∈P ∨ z∈Q ∨ z∈B ∨ z∈H)
    (sz : P.length+Q.length+B.length+H.length=n) (ht : 0<t)
    (mBig : 8*demand B.length H.length t ≤ P.length)
    (lBig : 8*demand B.length H.length t ≤ Q.length)
    (holeRoom : 8*(B.length+H.length) ≤ P.length) :
    ∃ J a, J.Nodup ∧ J.length=t ∧ Protected P Q B J a := by
  classical
  let k := B.length
  let u := demand k H.length t
  have ku : k+1 ≤ (k+1)*t := Nat.le_mul_of_pos_right _ ht
  have upos : 0 < u := by dsimp [u,demand]; omega
  obtain ⟨a,al,ar,ww⟩ := Balanced.window_exists P Q.length (B.length+H.length) u upos pd
    (fun j hj => by have := (bounds _ hj).2; omega) mBig lBig holeRoom
  let W := Balanced.window P a Q.length
  let bad := List.range' a k ++ (B++H).flatMap (fun z => interval (z-k) k)
  have fsize := flat_size (B++H) (fun z => interval (z-k) k) (k+1)
    (by intro j hj; simp [interval])
  have badsize : bad.length ≤ k+(B.length+H.length)*(k+1) := by
    simpa only [bad,List.length_append,List.length_range'] using Nat.add_le_add_left fsize k
  let ok := fun j => decide (j∉bad)
  let G := W.filter ok
  have wd : W.Nodup := pd.sublist List.filter_sublist
  have gd : G.Nodup := List.Pairwise.filter ok wd
  have del : (W.filter (fun j => !ok j)).length ≤ bad.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ wd)
    intro j hj
    simpa [ok] using (List.mem_filter.mp hj).2
  have wl : u ≤ W.length := ww
  have split := (List.filter_append_perm ok W).length_eq
  rw [List.length_append] at split
  have gsize : (k+1)*t ≤ G.length := by
    change (k+1)*t ≤ (List.filter ok W).length
    dsimp [u,demand,k] at wl ⊢
    dsimp [k] at badsize
    omega
  obtain ⟨r,hr,rl⟩ := bucket G gd (fun z=>z%(k+1)) (by omega) gsize
    (fun z _ => Nat.mod_lt _ (by omega))
  let group := G.filter (fun z=>decide (z%(k+1)=r))
  let J := group.take t
  have jl : J.length=t := by exact (List.length_take ..).trans (Nat.min_eq_left rl)
  have jd : J.Nodup := (List.Pairwise.filter _ gd).take
  have prop (j) (h : j∈J) : j∈P ∧ a+k≤j ∧ j≤a+Q.length ∧ j∉bad ∧ j%(k+1)=r := by
    obtain ⟨hg,he⟩ := List.mem_filter.mp (show j ∈ G.filter (fun z => decide (z%(k+1)=r)) from List.take_subset t group h)
    obtain ⟨hw,ho⟩ := List.mem_filter.mp hg
    have info := Balanced.mem_window.mp hw
    have nb : j∉bad := by simpa [ok] using ho
    have good : a+k≤j := by
      by_cases ge : a+k≤j
      · exact ge
      · exfalso; apply nb
        apply List.mem_append_left _
        apply List.mem_range'.mpr
        refine ⟨j-a,by omega,by omega⟩
    exact ⟨info.1,good,info.2.2,nb,by simpa using he⟩
  have kt : t*(k+1) ≤ u := by dsimp [u,demand]; rw [Nat.mul_comm t (k+1)]; omega
  refine ⟨J,a,jd,jl,⟨pd,qd,pq,?_,?_,?_,?_,?_,?_⟩⟩
  · intro j hj; exact (prop j hj).1
  · intro j hj z hz zz
    have eqv := (prop j hj).2.2.2.2.trans (prop z zz).2.2.2.2.symm
    exact residue_separates j z k (mem_interval.mp hz).1 (mem_interval.mp hz).2 eqv
  · intro z hz
    obtain ⟨j,hj,ww⟩ := List.mem_flatMap.mp hz
    have pp := prop j hj
    have ⟨lo,hi⟩ := mem_interval.mp ww
    have goodj := bounds j pp.1
    have up : z≤n := by dsimp [k] at *; omega
    rcases cover z (by omega) up with p|q|b|h
    · exact Or.inl p
    · exact Or.inr q
    · exfalso; apply pp.2.2.2.1
      apply List.mem_append_right _
      exact List.mem_flatMap.mpr ⟨z,List.mem_append_left _ b,mem_interval.mpr (by dsimp [k]; omega)⟩
    · exfalso; apply pp.2.2.2.1
      apply List.mem_append_right _
      exact List.mem_flatMap.mpr ⟨z,List.mem_append_right _ h,mem_interval.mpr (by dsimp [k]; omega)⟩
  · rw [jl]; exact Nat.le_trans kt al
  · rw [jl]; exact Nat.le_trans (Nat.add_le_add_left kt _) ar
  · intro j hj; have h := prop j hj; change a≤j ∧ k≤j-a ∧ j-a≤Q.length; omega

theorem balanced_prime_width {P Q B H : List Nat} {n t M : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z∈P, z∉Q)
    (bounds : ∀ j∈P, 1≤j ∧ j≤n)
    (cover : ∀ z, 1≤z → z≤n → z∈P ∨ z∈Q ∨ z∈B ∨ z∈H)
    (sz : P.length+Q.length+B.length+H.length=n) (ht : 0<t)
    (mBig : 8*demand B.length H.length t ≤ P.length)
    (lBig : 8*demand B.length H.length t ≤ Q.length)
    (holeRoom : 8*(B.length+H.length) ≤ P.length)
    (read : Assignment P → Fin M) (finish : Fin M → Assignment Q → Prop)
    (correct : ∀ x y, finish (read x) y ↔ onePrime B x.val y.val) : 2^t ≤ M := by
  obtain ⟨J,a,jd,jl,hp⟩ := balanced_pack pd qd pq bounds cover sz ht mBig lBig holeRoom
  simpa only [jl] using protected_width hp jd read finish correct

/-- Numeric threshold in the two-level lower bound. -/
theorem budget {k t : Nat} (ht : 0<t) (hk : k≤8*t) :
    8*demand k 0 t ≤ 4096*(t*t) := by
  have k1 : k+1 ≤ 9*t := by omega
  have k2 : k+t ≤ 9*t := by omega
  have hm := Nat.mul_le_mul k1 k2
  have u : t ≤ t*t := Nat.le_mul_of_pos_right t ht
  have eq : demand k 0 t = (k+1)*(k+t)+k := by
    simp only [demand,Nat.add_zero]
    rw [Nat.mul_add (k+1) k t]
    rw [Nat.mul_comm k (k+1)]
    omega
  have nine : (9*t)*(9*t)=81*(t*t) := by
    calc _ = (9*9)*(t*t) := by ac_rfl
         _ = _ := rfl
  rw [eq]; omega

end HWB.NestedLower

#print axioms HWB.NestedLower.balanced_pack
#print axioms HWB.NestedLower.balanced_prime_width
#print axioms HWB.NestedLower.budget
