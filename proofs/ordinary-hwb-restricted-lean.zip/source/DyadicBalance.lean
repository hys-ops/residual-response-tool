import Std

/-! The dyadic algebra in optimizing a weight-window lower bound. -/
namespace HWB.DensePacking

private theorem linear_le_dyadic {k : Nat} (hk : 7≤k) : 16*(k+1)≤2^k := by
  induction k with
  | zero => omega
  | succ k ih =>
    by_cases h : 7≤k
    · have := ih h
      rw [Nat.pow_succ]; omega
    · have : k=6 := by omega
      subst k; decide

/-- An explicit eventual bound without real asymptotics. -/
theorem log_power_sixteen {n : Nat} (large : 2^128≤n) : n.log2^16 ≤ n := by
  have nn : n≠0 := by intro z; subst n; contradiction
  have hm : 128≤n.log2 := (Nat.le_log2 nn).mpr large
  have hm0 : n.log2≠0 := by omega
  have hk : 7≤n.log2.log2 := (Nat.le_log2 hm0).mpr hm
  have h16 := Nat.le_trans (linear_le_dyadic hk) (Nat.log2_self_le hm0)
  calc
    n.log2^16 ≤ (2^(n.log2.log2+1))^16 := Nat.pow_le_pow_left (Nat.le_of_lt Nat.lt_log2_self) _
    _ = 2^(16*(n.log2.log2+1)) := (Nat.pow_mul' ..).symm
    _ ≤ 2^n.log2 := Nat.pow_le_pow_right (by decide) h16
    _ ≤ n := Nat.log2_self_le nn

/-- The choice of the width either incurs the cube-root cost directly or
retains a fixed fraction of the global logarithm in its window term. -/
theorem dyadic_window_tradeoff {n w t : Nat} (large : 2^128≤n) (wp : 0<w)
    (window : n*(w+1).log2^2 ≤ w*t^2) :
    n*n.log2^2 ≤ 64*(w*t^2) ∨ n*n.log2^2 ≤ t^3 := by
  have np : 0<n := Nat.lt_of_lt_of_le (Nat.pow_pos (by decide)) large
  have bits : 1≤(w+1).log2 := (Nat.le_log2 (Nat.succ_ne_zero w)).mpr (by omega)
  by_cases wide : n ≤ (w+1)^4
  · have lt : n < 2^(((w+1).log2+1)*4) := by
      rw [Nat.pow_mul]
      exact Nat.lt_of_le_of_lt wide (Nat.pow_lt_pow_left Nat.lt_log2_self (by decide))
    have b := (Nat.log2_lt (by omega)).mpr lt
    have bitbound : n.log2≤8*(w+1).log2 := by omega
    left
    calc
      n*n.log2^2 ≤ n*(8*(w+1).log2)^2 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left bitbound 2)
      _ = 64*(n*(w+1).log2^2) := by rw [Nat.mul_pow];change n*(64*_)=_;ac_rfl
      _ ≤ 64*(w*t^2) := Nat.mul_le_mul_left 64 window
  · have w4 : w^4≤n := Nat.le_trans (Nat.pow_le_pow_left (show w≤w+1 by omega) 4) (Nat.le_of_lt (Nat.lt_of_not_ge wide))
    have b1 : 1≤(w+1).log2^2 := Nat.pow_le_pow_left bits 2
    have nbase : n≤w*t^2 := Nat.le_trans (by simpa using Nat.mul_le_mul_left n b1) window
    have n3 : n^3≤t^8 := by
      apply Nat.le_of_mul_le_mul_left (c:=n) _ np
      calc
        n*n^3 = n^4 := by rw [Nat.mul_comm];rfl
        _ ≤ (w*t^2)^4 := Nat.pow_le_pow_left nbase _
        _ = w^4*t^8 := by rw [Nat.mul_pow,← Nat.pow_mul]
        _ ≤ n*t^8 := Nat.mul_le_mul_right _ w4
    have dom := log_power_sixteen large
    have h : (n*n.log2^2)^8 ≤ (t^3)^8 := by
      calc
        _ = n^8*n.log2^16 := by rw [Nat.mul_pow, ← Nat.pow_mul]
        _ ≤ n^8*n := Nat.mul_le_mul_left _ dom
        _ = (n^3)^3 := by rw [← Nat.pow_mul];rfl
        _ ≤ (t^8)^3 := Nat.pow_le_pow_left n3 _
        _ = _ := by rw [← Nat.pow_mul,← Nat.pow_mul]
    exact Or.inr ((Nat.pow_le_pow_iff_left (by decide : 8≠0)).mp h)

/-- A uniform cube bound for the maximum of the two cost terms. -/
theorem dyadic_balance {n w t : Nat} (large : 2^128≤n) (wp : 0<w)
    (wt : w≤t) (window : n*(w+1).log2^2 ≤ w*t^2) : n*n.log2^2 ≤ 64*t^3 := by
  rcases dyadic_window_tradeoff large wp window with h | h
  · calc
      _ ≤ 64*(w*t^2) := h
      _ ≤ 64*(t*t^2) := Nat.mul_le_mul_left 64 (Nat.mul_le_mul_right _ wt)
      _ = _ := by rw [Nat.mul_comm t (t^2)];rfl
  · omega

/-- Explicit threshold version for the small outer bank. `A` may be the floor
cube root of `n*(log2 n)^2`. Any `w≤C*A` gives the target exponent divided
by the constant `8*C`. `t` can absorb an independent constant from a size bound. -/
theorem dyadic_target {n w t A C : Nat} (large : 2^128≤n) (wp : 0<w) (cp : 0<C)
    (target : A^3 ≤ n*n.log2^2) (width : w≤C*A) (window : n*(w+1).log2^2 ≤ w*t^2) :
    A ≤ 8*C*t := by
  by_cases z : A=0
  · simp [z]
  rcases dyadic_window_tradeoff large wp window with h | h
  · have sq : A^2 ≤ 64*C*t^2 := by
      apply Nat.le_of_mul_le_mul_right (c:=A) _ (by omega)
      calc
        _ = A^3 := by rfl
        _ ≤ 64*(w*t^2) := Nat.le_trans target h
        _ ≤ 64*((C*A)*t^2) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ width)
        _ = _ := by ac_rfl
    have cc : C≤C^2 := by simpa [Nat.pow_two] using Nat.mul_le_mul_left C cp
    apply (Nat.pow_le_pow_iff_left (by decide : 2≠0)).mp
    calc
      _ ≤ 64*C*t^2 := sq
      _ ≤ 64*C^2*t^2 := Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ cc)
      _ = (8*C*t)^2 := by rw [Nat.mul_pow,Nat.mul_pow]
  · have at' := (Nat.pow_le_pow_iff_left (by decide : 3≠0)).mp (Nat.le_trans target h)
    have tt : t≤(8*C)*t := by simpa using Nat.mul_le_mul_right t (by omega : 1≤8*C)
    omega

end HWB.DensePacking
