import HWB.SmallRight
import HWB.Circuit

namespace HWB.AlphabetLeft
open SmallRight

private theorem filter_split (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun z => !(f z))).length=U.length := by
  induction U with
  | nil => simp
  | cons z U ih => cases h : f z <;> simp [h] <;> omega

def boxes {g : Nat} (cell : Fin g → List Nat) := (List.finRange g).flatMap cell

/-- A marker ends a B-sized weight window. Geometrical primitives only:
no encoded inputs, decoder, row-count or circuit lower bound is assumed. -/
structure Placement (P Q B : List Nat) (g b a : Nat) where
  cell : Fin g → List Nat
  mark : Fin g → Fin b → Nat
  increasing : ∀ i u v, u.val<v.val → mark i u < mark i v
  cellSep : ∀ i i' z, z∈cell i → z∈cell i' → i=i'
  inP : ∀ i u, mark i u ∈ P
  window : ∀ i u z, z∈interval (mark i u-B.length) B.length →
    z∈cell i ∧ (z∈P ∨ z∈Q)
  prefixRoom : (boxes cell).length ≤ a ∧ a+(boxes cell).length ≤ P.length
  suffixRoom : ∀ i u, a+B.length+(B.length+1) ≤ mark i u ∧ mark i u≤a+B.length+Q.length

/-- A group with b marked endpoints has b+1 possible threshold responses,
realized at one common prefix weight. This quantifies over the original
outer B assignments, including B all ones when reading the endpoint. -/
theorem decoder {P Q B : List Nat} {g b a : Nat} (p : Placement P Q B g b a)
    (ndP : P.Nodup) (ndQ : Q.Nodup) (ndB : B.Nodup)
    (pq : ∀ z∈P, z∉Q) (pb : ∀ z∈P, z∉B) :
    ∃ enc : (Fin g→Fin (b+1)) → Assignment P, ∃ probe : Fin g → Fin b → Assignment Q,
      ∀ w i v, onePrime B (enc w).val (probe i v).val ↔ v.val < (w i).val := by
  classical
  let box := boxes p.cell
  let lock := fun z => decide (z∈box)
  let val := fun (w : Fin g→Fin (b+1)) z =>
    decide (∃ i u, z∈p.cell i ∧ u.val < (w i).val ∧ z≤p.mark i u)
  have cnt : (P.filter lock).length≤box.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ ndP)
    intro z hz; simpa [lock] using (List.mem_filter.mp hz).2
  have locked (i z) (h : z∈p.cell i) : lock z=true := by
    have mem : z∈box := List.mem_flatMap.mpr ⟨i,List.mem_finRange i,h⟩
    simp [lock,mem]
  have encEx (w : Fin g→Fin (b+1)) := fill P ndP lock (val w) a
    (Nat.le_trans (List.length_filter_le ..) (Nat.le_trans cnt p.prefixRoom.1)) (by
      have := filter_split P lock
      have := p.prefixRoom.2
      change a+box.length≤P.length at this
      omega)
  let enc := fun w => Classical.choose (encEx w)
  have es := fun w => Classical.choose_spec (encEx w)
  let start := fun i u => p.mark i u-B.length
  let hit := fun i u z => decide (z∈interval (start i u) B.length)
  have qEx (i : Fin g) (u : Fin b) :
      ∃ q : Assignment Q, q.val.length=start i u-a ∧
        ∀ z∈Q, z∈interval (start i u) B.length → z∈q.val := by
    have card : (Q.filter (hit i u)).length≤(interval (start i u) B.length).length := by
      apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ ndQ)
      intro z hz; simpa [hit] using (List.mem_filter.mp hz).2
    simp only [interval, List.length_range'] at card
    have room := p.suffixRoom i u
    have ft (l : List Nat) : (l.filter (fun _ => true)) = l := by induction l <;> simp [*]
    obtain ⟨q,h,yes⟩ := fill Q ndQ (hit i u) (fun _ => true) (start i u-a)
      (by rw [ft]; dsimp [start]; omega)
      (by rw [ft]; have := filter_split Q (hit i u); dsimp [start]; omega)
    exact ⟨q,h,fun z hz hi => (yes z hz (show decide _ = true from decide_eq_true hi)).mpr rfl⟩
  let probe := fun i u => Classical.choose (qEx i u)
  have qs := fun i u => Classical.choose_spec (qEx i u)
  refine ⟨enc,probe,?_⟩
  intro w i v
  have room := p.suffixRoom i v
  have hP : (enc w).val.length=a := (es w).1
  have hQ : (probe i v).val.length=start i v-a := (qs i v).1
  have ss : a≤start i v ∧ start i v+B.length=p.mark i v := by dsimp [start]; omega
  have endpoint : p.mark i v ∈ interval (start i v) B.length := mem_interval.mpr (by omega)
  have site := p.inP i v
  constructor
  · intro yes
    let allB : Assignment B := ⟨B,ndB,List.Subset.refl _⟩
    have h := yes allB
    change ((enc w).val++(probe i v).val++B).length ∈ (enc w).val++(probe i v).val++B at h
    have weight : ((enc w).val++(probe i v).val++B).length=p.mark i v := by
      simp [hP,hQ]; omega
    rw [weight] at h
    have inEnc := (List.mem_append.mp ((List.mem_append.mp h).resolve_right (pb _ site))).resolve_right
      (fun z => pq _ site ((probe i v).property.2 z))
    have lit := ((es w).2 _ site (locked i _ (p.window i v _ endpoint).1)).mp inEnc
    obtain ⟨i',u,hi',hu,le⟩ := of_decide_eq_true lit
    have eq := p.cellSep i i' _ (p.window i v _ endpoint).1 hi'
    subst i'
    by_cases h : v.val≤u.val
    · omega
    · have lt := p.increasing i u v (by omega)
      omega
  · intro allowed bs
    let z := start i v+bs.val.length
    have cap := bs.property.1.length_le_of_subset bs.property.2
    have hz : z∈interval (start i v) B.length := mem_interval.mpr (by dsimp [z]; omega)
    have hzone := p.window i v _ hz
    have weight : ((enc w).val++(probe i v).val++bs.val).length=z := by
      simp [z,hP,hQ]; omega
    change ((enc w).val++(probe i v).val++bs.val).length ∈ _
    rw [weight]
    rcases hzone.2 with hp|hq
    · have lit : val w z=true := by
        apply decide_eq_true
        exact ⟨i,v,hzone.1,allowed,by dsimp [z]; omega⟩
      exact List.mem_append_left _ (List.mem_append_left _ (((es w).2 _ hp (locked i _ hzone.1)).mpr lit))
    · exact List.mem_append_left _ (List.mem_append_right _ ((qs i v).2 z hq hz))

/-- Least-significant digit first. -/
def digit (base : Nat) (x : Nat) : Nat → Nat
  | 0 => x%base
  | i+1 => digit base (x/base) i

private theorem digit_lt (pos : 0<base) (x i : Nat) : digit base x i<base := by
  induction i generalizing x with
  | zero => exact Nat.mod_lt _ pos
  | succ i ih => exact ih _

private theorem digits_determine (base : Nat) (pos : 0<base) (g : Nat) (u v : Nat)
    (hu : u<base^g) (hv : v<base^g)
    (same : ∀ i, i<g → digit base u i=digit base v i) : u=v := by
  induction g generalizing u v with
  | zero => simp at hu hv; omega
  | succ g ih =>
    have rem := same 0 (Nat.zero_lt_succ g)
    change u%base=v%base at rem
    have divs := ih (u/base) (v/base)
      ((Nat.div_lt_iff_lt_mul pos).mpr (by simpa [Nat.pow_succ] using hu))
      ((Nat.div_lt_iff_lt_mul pos).mpr (by simpa [Nat.pow_succ] using hv))
      (fun i hi => same (i+1) (by omega))
    have e1 := Nat.mod_add_div u base
    rw [rem,divs] at e1
    exact e1.symm.trans (Nat.mod_add_div v base)

/-- Exact response count for b markers per cell. The left reader and right
evaluator may be arbitrary algorithms on the original supports. -/
theorem row_width {P Q B : List Nat} {g b a M : Nat} (p : Placement P Q B g b a)
    (ndP : P.Nodup) (ndQ : Q.Nodup) (ndB : B.Nodup)
    (pq : ∀ z∈P, z∉Q) (pb : ∀ z∈P, z∉B)
    (read : Assignment P→Fin M) (finish : Fin M→Assignment Q→Prop)
    (correct : ∀ x y, finish (read x) y ↔ onePrime B x.val y.val) :
    (b+1)^g ≤ M := by
  obtain ⟨enc,probe,dec⟩ := decoder p ndP ndQ ndB pq pb
  let word (v : Fin ((b+1)^g)) (i : Fin g) : Fin (b+1) :=
    ⟨digit (b+1) v.val i.val,digit_lt (by omega) ..⟩
  apply Circuit.fin_injection_bound (fun v => read (enc (word v)))
  intro u v eq
  change read (enc (word u))=read (enc (word v)) at eq
  apply Fin.ext
  apply digits_determine (b+1) (by omega) g u.val v.val u.isLt v.isLt
  intro i hi
  let idx : Fin g := ⟨i,hi⟩
  change (word u idx).val=(word v idx).val
  have same (m : Fin b) : m.val < (word u idx).val ↔ m.val < (word v idx).val := by
    rw [←dec,←dec,←correct,←correct,eq]
  have lu := (word u idx).isLt
  have lv := (word v idx).isLt
  by_cases lt : (word u idx).val < (word v idx).val
  · have h := same ⟨(word u idx).val,by omega⟩
    change _ < _ ↔ _ < _ at h
    exact False.elim (Nat.lt_irrefl _ (h.mpr lt))
  · by_cases gt : (word v idx).val < (word u idx).val
    · have h := same ⟨(word v idx).val,by omega⟩
      exact False.elim (Nat.lt_irrefl _ (h.mp gt))
    · omega

end HWB.AlphabetLeft

#print axioms HWB.AlphabetLeft.decoder
#print axioms HWB.AlphabetLeft.row_width
