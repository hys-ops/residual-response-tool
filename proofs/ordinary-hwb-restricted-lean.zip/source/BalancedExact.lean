import DensePacking
import Entropy
import AlphabetLeft
import TwoRootModel

set_option maxRecDepth 10000
namespace HWB.BalancedExact
open HWB.SmallRight

private theorem sum_filter (S : List Nat) (f : Nat→Bool) :
    (S.filter f).length + (S.filter (fun z=>!(f z))).length=S.length := by
  induction S with
  | nil => simp
  | cons a s ih => cases h : f a <;> simp [h] <;> omega

private theorem flatLen (S : List Nat) (f : Nat→List Nat) (cap : Nat)
    (h : ∀ i∈S,(f i).length≤cap) : (S.flatMap f).length≤S.length*cap := by
  induction S with
  | nil => simp
  | cons a s ih =>
    simpa [List.flatMap_cons,Nat.succ_mul,Nat.add_comm] using Nat.add_le_add
      (h a (by simp)) (ih (fun i hi=> h i (by simp [hi])))

private theorem pigeon (A : List Nat) (uniq : A.Nodup) (f : Nat→Nat) (m t : Nat)
    (pos : 0<m) (span : ∀ j∈A, f j<m) (count : m*t≤A.length) :
    ∃ i<m, t≤(A.filter (fun j=>decide (f j=i))).length := by
  apply Classical.byContradiction; intro absent
  let row := fun i=> A.filter (fun j=>decide (f j=i))
  have small (i) (hi : i<m) : (row i).length<t := by
    exact Nat.lt_of_not_ge (fun bad=>absent ⟨i,hi,bad⟩)
  have p := small 0 pos
  have sub : A⊆(List.range m).flatMap row := by
    intro j hj
    exact List.mem_flatMap.mpr ⟨f j,List.mem_range.mpr (span j hj),by simp [row,hj]⟩
  have le := uniq.length_le_of_subset sub
  have sum := flatLen (List.range m) row (t-1) (fun i hi=>by have := small i (List.mem_range.mp hi);omega)
  have lt := Nat.mul_lt_mul_of_pos_left (show t-1<t by omega) pos
  simp only [List.length_range] at sum
  omega

/-- Every surviving endpoint is a P-variable and its full backwards
window misses B. Right-weight feasibility is guaranteed on one common slab. -/
theorem slab {P Q B : List Nat} {n r d : Nat}
    (ndP : P.Nodup) (bounded : ∀ j∈P, 1≤j ∧ j≤n)
    (total : P.length+Q.length+B.length=n) (rpos : 0<r) (span : r+(B.length+1)≤Q.length)
    (count : (n/r+1)*d + 2*(P.length/8)+2*B.length+2+B.length*(B.length+1)≤P.length) :
    ∃ (base a : Nat) (xs : List Nat), xs.Nodup ∧ d≤xs.length ∧ P.length/8≤a ∧ a+P.length/8≤P.length ∧
      ∀ m∈xs, m∈P ∧ base≤m ∧ m<base+r ∧ a+B.length+(B.length+1)≤m ∧
        m≤a+B.length+Q.length ∧ ∀ z∈interval (m-B.length) B.length, z∉B := by
  let k := B.length
  let L := P.length/8
  let hi := P.length-L
  let ban := List.range (L+2*k+1) ++ List.range' (hi+k+Q.length+1) (L+1) ++
    B.flatMap (fun b=>interval b k)
  let ok := fun j=>decide (j∉ban)
  let alive := P.filter ok
  have allLen := flatLen B (fun b=>interval b k) (k+1) (by intro b hb; simp [interval])
  have banLen : ban.length≤2*L+2*k+2+B.length*(k+1) := by
    simp only [ban,List.length_append,List.length_range,List.length_range'];omega
  have lost : (P.filter (fun z=>!(ok z))).length≤ban.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ ndP)
    intro z hz
    simpa [ok] using (List.mem_filter.mp hz).2
  have nAlive : (n/r+1)*d≤alive.length := by
    have h := sum_filter P ok
    change (n/r+1)*d+2*L+2*k+2+B.length*(k+1)≤P.length at count
    change (n/r+1)*d≤(P.filter ok).length
    omega
  obtain ⟨i,_,good⟩ := pigeon alive (List.Pairwise.filter _ ndP) (fun j=>j/r) (n/r+1) d
    (Nat.zero_lt_succ _) (fun j hj=>by
      have ub := (bounded j (List.mem_filter.mp hj).1).2
      have ord := Nat.div_le_div_right (c:=r) ub;omega) nAlive
  let base := i*r
  let up := min (hi+k+Q.length) (base+r)
  let a := max L (up-k-Q.length)
  let xs := alive.filter (fun j=>decide (j/r=i))
  have LL : 2*L≤P.length := by dsimp [L];omega
  have ae : L≤a ∧ a+L≤P.length := by dsimp [a,up,hi];omega
  refine ⟨base,a,xs,List.Pairwise.filter _ (List.Pairwise.filter _ ndP),good,ae.1,ae.2,?_⟩
  intro m hm
  have hh := List.mem_filter.mp hm
  have ha := List.mem_filter.mp (show m∈alive from hh.1)
  have im : m/r=i := by simpa using hh.2
  have safe : m∉ban := by simpa [ok] using ha.2
  have inP : m∈P := ha.1
  have lower : L+2*k+1≤m := by
    apply Classical.byContradiction;intro h
    exact safe (List.mem_append_left _ (List.mem_append_left _ (List.mem_range.mpr (by omega))))
  have upper : m≤hi+k+Q.length := by
    apply Classical.byContradiction;intro h
    have within := (bounded m inP).2
    apply safe
    apply List.mem_append_left _; apply List.mem_append_right _
    apply List.mem_range'.mpr
    refine ⟨m-(hi+k+Q.length+1),?_,by omega⟩
    dsimp [hi,k,L] at *;omega
  have b1 : base≤m := by change i*r≤m; rw [←im]; exact Nat.div_mul_le_self m r
  have b2 : m<base+r := by
    have eq := Nat.mod_add_div m r
    have rem := Nat.mod_lt m rpos
    rw [im,Nat.mul_comm r i] at eq
    dsimp [base];omega
  refine ⟨inP,b1,b2,?_,?_,?_⟩
  · change a+k+(k+1)≤m
    dsimp [a,up];change r+(k+1)≤Q.length at span;omega
  · change m≤a+k+Q.length;dsimp [a,up];omega
  · intro z hz bad
    have he := mem_interval.mp hz
    apply safe;apply List.mem_append_right _
    apply List.mem_flatMap.mpr
    refine ⟨z,bad,mem_interval.mpr ?_⟩
    change m-k≤z ∧ z≤m-k+k at he
    omega

/-- Every legal split with the scalar bounds below has a physical alphabet
placement. Grid cell and marker counts include floors at small widths. -/
theorem placement {P Q B : List Nat} {n r : Nat}
    (ndP : P.Nodup) (bounded : ∀ j∈P, 1≤j ∧ j≤n)
    (cover : ∀ z, 1≤z → z≤n → z∈P ∨ z∈Q ∨ z∈B)
    (total : P.length+Q.length+B.length=n)
    (rmin : 2048≤r) (wide : B.length+1≤r) (suffixLen : r+(B.length+1)≤Q.length)
    (preLen : 64*r≤P.length) (dense : n≤128*P.length)
    (holes : 4*(2*B.length+2+B.length*(B.length+1))≤P.length) :
    ∃ a, Nonempty (AlphabetLeft.Placement P Q B
      ((r/(B.length+1)+1)/32768) (1+(B.length+1)/8192) a) := by
  let w := B.length+1
  let K := 4096
  let M := r/w+1
  let d := r/1024
  have pos : 0<w := Nat.zero_lt_succ _
  have rr : r≤n := by omega
  have coarse : (n/r+1)*d*1024 ≤ 2*n := by
    have dv : d*1024≤r := Nat.div_mul_le_self r 1024
    calc _ ≤ (n/r+1)*r := by simpa only [Nat.mul_assoc] using Nat.mul_le_mul_left (n/r+1) dv
         _ = (n/r)*r+r := by rw [Nat.add_one_mul]
         _ ≤ 2*n := by have left := Nat.div_mul_le_self n r;omega
  have dc : (n/r+1)*d+2*(P.length/8)+2*B.length+2+B.length*(B.length+1)≤P.length := by omega
  obtain ⟨base,a,xs,xd,xl,al,ar,good⟩ := slab ndP bounded total (Nat.lt_of_lt_of_le (by decide : 0<2048) rmin) suffixLen dc
  have we : M*w≤r+w := by
    dsimp [M]; rw [Nat.add_one_mul]
    exact Nat.add_le_add_right (Nat.div_mul_le_self r w) _
  have full : r < M*w := (Nat.div_lt_iff_lt_mul pos).mp (Nat.lt_succ_self _)
  have span (j) (hj : j∈xs) : base≤j ∧ j<base+M*w := by
    have h := good j hj;omega
  have load : M*w ≤ K*xs.length := by
    have frac : r≤2048*d := by dsimp [d];omega
    dsimp [K]
    have wd : w≤r := wide
    omega
  obtain ⟨pk⟩ := DensePacking.pack_positive xs base w M 0 K xd pos (by decide) span load
  have tags (i u) := (good _ (pk.mark_in_slab i u).1)
  have rate : M/(8*K)≤M := Nat.div_le_self .. 
  have cap := Nat.mul_le_mul_right w rate
  have zsize := pk.all_zones_size
  have eqMul : M/(8*K)*(3*w)=3*(M/(8*K)*w) := by ac_rfl
  rw [eqMul] at zsize
  have zroom : ((List.finRange (M/(8*K))).flatMap pk.zone).length ≤ P.length/8 := by
    have wd : w≤r := wide
    omega
  have mk : AlphabetLeft.Placement P Q B (M/(8*K)) (1+w/(2*K*(0+1))) a := {
    cell := pk.zone
    mark := pk.mark
    increasing := fun i u v hh=> by simpa using pk.ordered i hh
    cellSep := fun _ _ z h h'=>pk.zone_separate pos z h h'
    inP := fun i u=>(tags i u).1
    window := by
      intro i u z hz
      have zz := mem_interval.mp hz
      have tag := tags i u
      have boundM := bounded _ tag.1
      have kb : B.length≤w := by dsimp [w];omega
      refine ⟨pk.covers_marker_window i u B.length 0 kb (Nat.zero_le _) zz.1 (by omega),?_⟩
      rcases cover z (by omega) (by omega) with pp|qq|bb
      · exact Or.inl pp
      · exact Or.inr qq
      · exact False.elim (tag.2.2.2.2.2 z hz bb)
    prefixRoom := ⟨Nat.le_trans zroom al, by
      change a+((List.finRange _).flatMap pk.zone).length≤P.length
      omega⟩
    suffixRoom := fun i u=>⟨(tags i u).2.2.2.1,(tags i u).2.2.2.2.1⟩ }
  exact ⟨a, ⟨mk⟩⟩

/-- The Boolean run on all original P,Q,B supports is the only functional
hypothesis. The bound applies to the actual physical inner root element count
with no grouping, placement, decoder, or row abundance supplied. -/
theorem hardware {B : List Nat} {n r : Nat} (c : Slice.Hardware n B) (unB : B.Nodup)
    (raw : ∀ x y, c.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (rmin : 2048≤r) (wide : B.length+1≤r) (suffixLen : r+(B.length+1)≤c.B.length)
    (preLen : 64*r≤c.A.length) (dense : n≤128*c.A.length)
    (holes : 4*(2*B.length+2+B.length*(B.length+1))≤c.A.length) :
    (2+(B.length+1)/8192)^((r/(B.length+1)+1)/32768) ≤ c.R := by
  obtain ⟨a,⟨pl⟩⟩ := placement c.na (fun j hj => (c.domain j).mp (by simp [hj]))
    (fun j lo hi => by simpa only [List.mem_append,or_assoc] using (c.domain j).mpr ⟨lo,hi⟩)
    c.total rmin wide suffixLen preLen dense holes
  have v := AlphabetLeft.row_width pl c.na c.nb unB c.dis
    (fun z hz => c.disD z (List.mem_append_left _ hz))
    c.dec.selectCase (fun i y => c.dec.sub i y=true) (fun x y => by
      change c.dec.run x y=true ↔ _
      rw [raw,TwoRoot.universal_iff]
      rfl)
  simpa only [Nat.add_right_comm 1 _ 1] using v

/-- Binary-log form usable by a global scalar case split, including w=1. -/
theorem hardware_bits {B : List Nat} {n r : Nat} (c : Slice.Hardware n B) (unB : B.Nodup)
    (raw : ∀ x y, c.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (rmin : 2048≤r) (wide : B.length+1≤r) (suffixLen : r+(B.length+1)≤c.B.length)
    (preLen : 64*r≤c.A.length) (dense : n≤128*c.A.length)
    (holes : 4*(2*B.length+2+B.length*(B.length+1))≤c.A.length) :
    2^((B.length+2).log2*((r/(B.length+1)+1)/32768)/14) ≤ c.R := by
  let w := B.length+1
  let alphabet := 2+w/8192
  have hz : 2≤alphabet := Nat.le_add_right .. 
  have m : 8192≤alphabet^13 := Nat.pow_le_pow_left hz 13
  have lm := Nat.mul_le_mul_right alphabet m
  have ctl : w+1≤alphabet^14 := by
    have cap : w+1≤8192*alphabet := by dsimp [alphabet];omega
    change w+1≤alphabet^13*alphabet
    exact Nat.le_trans cap lm
  have hb := DensePacking.entropy_bits (ell:=w+1) (b:=alphabet) (p:=14)
    (Nat.zero_lt_succ _) (by decide) ctl ((r/w+1)/32768)
  exact Nat.le_trans hb (hardware c unB raw rmin wide suffixLen preLen dense holes)

end HWB.BalancedExact
#print axioms HWB.BalancedExact.slab
#print axioms HWB.BalancedExact.placement
#print axioms HWB.BalancedExact.hardware
#print axioms HWB.BalancedExact.hardware_bits
