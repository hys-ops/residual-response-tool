import TwoRootModel
import NestedLowerCore
namespace HWB.TwoRoot
open HWB.Model HWB.Circuit HWB.Slice HWB.SmallRight

private theorem sq_le_cube {t : Nat} (ht : 0<t) : t*t≤t*(t*t) := Nat.le_mul_of_pos_left _ ht

theorem scale_bound {n t : Nat} (h : (65536*t)^3≤n) :
    281474976710656*(t*(t*t))≤n := by
  have e : (65536*t)^3 = 281474976710656*(t*(t*t)) :=
    calc _ = (65536*65536*65536)*(t*(t*t)) := by
           simp only [Nat.pow_succ,Nat.pow_zero,Nat.one_mul]; ac_rfl
         _ = _ := rfl
  rwa [e] at h

theorem lhs_numeric {n t d : Nat} (ht : 0<t) (hn : (65536*t)^3≤n) (hd : d≤80*t) :
    3*((d+1)*(d+1))≤n := by
  have hb := scale_bound hn
  have a : d+1≤81*t := by omega
  have m := Nat.mul_le_mul a a
  have eq : (81*t)*(81*t)=6561*(t*t) := by
    calc _ = (81*81)*(t*t) := by ac_rfl
         _ = _ := rfl
  rw [eq] at m
  have z := sq_le_cube ht
  omega

theorem kw_numeric {n t k d : Nat} (ht : 0<t) (hn : (65536*t)^3≤n)
    (hk : k≤8*t) (hd : d≤1024*(t*(k+1))) :
    4096≤n ∧ 64*(k*k)≤n ∧ 1024*((k+1)*t)≤n ∧
    32*(d+k)≤n ∧ 8*((d+k)*(k+1))≤n := by
  have nk := scale_bound hn
  have t2 := Nat.le_mul_of_pos_right t ht
  have t3 := sq_le_cube ht
  have pos : 1≤t := ht
  have w : k+1 ≤ 9*t := by omega
  have mc := Nat.mul_le_mul (Nat.le_refl t) w
  have m2 := Nat.mul_le_mul hk hk
  have ew : t*(9*t)=9*(t*t) := by ac_rfl
  have ek : (8*t)*(8*t)=64*(t*t) := by
    calc _ = (8*8)*(t*t) := by ac_rfl
         _ = _ := rfl
  rw [ew] at mc
  rw [ek] at m2
  have dh : d+k≤9224*(t*t) := by omega
  have mm := Nat.mul_le_mul dh w
  have em : (9224*(t*t))*(9*t)=83016*(t*(t*t)) := by
    calc _ = (9224*9)*(t*(t*t)) := by ac_rfl
         _ = _ := rfl
  rw [em] at mm
  rw [Nat.mul_comm (k+1) t]
  omega

theorem balanced_budget {k t : Nat} (_ht : 0<t) (hk : k<8*t) :
    8*NestedLower.demand k 0 t ≤ 1024*(t*(k+1)) := by
  have h1 : k+t ≤ 9*t := by omega
  have m := Nat.mul_le_mul_right (k+1) h1
  have a : (k+t)*(k+1)=k*(k+1)+t*(k+1) := Nat.add_mul ..
  have b : (9*t)*(k+1)=9*(t*(k+1)) := Nat.mul_assoc ..
  have l : t≤t*(k+1) := Nat.le_mul_of_pos_right _ (by omega)
  rw [a,b] at m
  simp only [NestedLower.demand,Nat.add_zero,Nat.mul_comm (k+1) t]
  omega

theorem Certificate.smallA (c : Certificate n W) {t : Nat} (ht : 0<t)
    (hn : (65536*t)^3≤n) (ha : c.A.length<8*t) : 2^t≤W+2 := by
  let zero : Model.Assignment c.A := ⟨[],by simp⟩
  let i := c.dec.selectCase zero
  have rule (y : Model.Assignment c.B) : c.dec.sub i y = decide (y.val.length∈y.val) := by
    simpa [i,zero,Decision.run] using c.correct zero y
  cases c.subs i with
  | ordered order perm g root cost corr =>
    have b := GapBridge.small_left_zero_slice g root order (16*t) (perm.nodup_iff.mpr c.nb)
      (fun j hj => (c.domain j).mp (List.mem_append_right _ (perm.subset hj)))
      (by have := c.total; have := perm.length_eq; omega) (lhs_numeric ht hn (by omega))
      (fun x => (corr x).trans (rule _))
    have eq : 16*t/16=t := by omega
    rw [eq] at b
    omega
  | branch g _ cost corr =>
    have he : ∀ x y, g.dec.run x y = decide (x.val.length+y.val.length∈x.val++y.val) := by
      intro x y
      rw [corr,rule]
      simp [paste]
    let z : ZeroRoot n c.A := ⟨g,he⟩
    have dat := z.sizes_le_wires
    have zw : z.wires≤W := cost
    by_cases la : 64*t≤z.A.length
    · by_cases rb : 8*t≤z.B.length
      · have a := z.balanced t ht (by omega) rb (by omega)
        omega
      · have data := kw_numeric (d:=0) ht hn (show z.B.length≤8*t by omega) (by omega)
        have da := (kw_numeric (d:=0) ht hn (show c.A.length≤8*t by omega) (by omega)).2.1
        have a := z.small_right_exponent data.1 data.2.1 da data.2.2.1
        omega
    · have a := z.small_left_DAG (80*t) (by omega) (lhs_numeric ht hn (by omega))
      have le : t≤80*t/16 := by omega
      have p := Nat.pow_le_pow_right (n:=2) (by decide) le
      omega

/-- An OBDD on order S computing the universal B-response. The missing
coordinates H may be fixed to zero. The hypothesis on holes is linear in
their count times the original window width. -/
theorem qdag {B H S : List Nat} {n N t : Nat} (g : DAG N) (root : State N)
    (nd : S.Nodup) (br : ∀ j∈S, 1≤j ∧ j≤n)
    (cover : ∀ z, 1≤z → z≤n → z∈S ∨ z∈H)
    (hn : 4096≤n) (hk : 64*(B.length*B.length)≤n) (lefts : 31*n≤32*S.length)
    (holes : 8*(H.length*(B.length+1))≤n) (span : 1024*((B.length+1)*t)≤n) (ht : 0<t)
    (correct : ∀ x : Model.Assignment S, g.eval (bits S x.val) root = universal B x.val) :
    2^t ≤ N+2 := by
  let m := S.length/2
  let P := S.take m
  let Q := S.drop m
  have e : S=P++Q := (List.take_append_drop m S).symm
  have good := List.nodup_append.mp (e ▸ nd)
  have dis := fun z hz hq => good.2.2 z hz z hq rfl
  obtain ⟨J,s,jd,jl,w⟩ := pack_at_size (B:=B) good.1 good.2.1 dis
    (fun z hz => br z (List.take_subset _ _ hz)) (fun z lo hi => by
      have h := cover z lo hi
      simpa only [e,List.mem_append,or_assoc] using h)
    hn hk (by simpa only [e,List.length_append] using lefts)
    (by dsimp [P,Q,m]; simp; omega) holes span ht
  let pre := fun x : Model.Assignment P => bits S x.val
  let suf := fun y : Model.Assignment Q => bits S y.val
  let read := fun x => (g.cut P.length (pre x) root).encode
  let finish := fun (u : Fin (N+2)) y => g.eval (suf y) (State.decode u)=true
  rw [←jl]
  apply protected_width w jd read finish
  intro x y
  simp only [finish,read,State.decode_encode,pre,suf]
  rw [←g.factor]
  have cb : bits S (x.val++y.val) = join P.length (bits S x.val) (bits S y.val) := by
    simpa only [e] using bits_cut dis x y
  rw [←cb]
  let z : Model.Assignment S := paste dis (e ▸ List.Subset.refl _) x y
  change g.eval (bits S z.val) root=true ↔ _
  rw [correct,universal_iff]
  rfl

end HWB.TwoRoot
