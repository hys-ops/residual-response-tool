import TwoRootBounds

namespace HWB.TwoRoot
open HWB.Model HWB.Circuit HWB.Slice

theorem branch_balanced {B : List Nat} (g : Hardware n B) (cost : g.wires≤W)
    (hc : ∀ x y, g.dec.run x y=universal B (x.val++y.val)) {t : Nat}
    (ht : 0<t) (smallB : B.length<8*t)
    (p : 1024*(t*(B.length+1))≤g.A.length)
    (q : 1024*(t*(B.length+1))≤g.B.length) : 2^t≤W+2 := by
  have budget := balanced_budget ht smallB
  have pw : t≤t*(B.length+1) := Nat.le_mul_of_pos_right t (by omega)
  have z := NestedLower.balanced_prime_width (H:=[]) g.na g.nb g.dis
    (fun j hj => (g.domain j).mp (by simp [hj])) (n:=n) (t:=t)
    (fun z lo hi => by simpa [or_assoc] using (g.domain z).mpr ⟨lo,hi⟩)
    (by simpa using g.total) ht (by simpa using Nat.le_trans budget p)
    (by simpa using Nat.le_trans budget q) (by simp; omega)
    g.dec.selectCase (fun i y => g.dec.sub i y=true) (fun x y => by
      change g.dec.run x y=true ↔ _
      rw [hc,universal_iff]
      rfl)
  unfold Hardware.wires at cost
  omega

theorem branch_small_left {B : List Nat} (g : Hardware n B) (cost : g.wires≤W)
    (hc : ∀ x y, g.dec.run x y=universal B (x.val++y.val)) {t : Nat}
    (ht : 0<t) (hn : (65536*t)^3≤n) (smallB : B.length<8*t)
    (smallP : g.A.length<1024*(t*(B.length+1))) : 2^t≤W+2 := by
  let zero : Assignment g.A := ⟨[],by simp⟩
  let gate := g.sRoot (g.dec.selectCase zero)
  have raw (x : Assignment g.B) : g.gS.eval (bits g.B x.val) gate = universal B x.val := by
    rw [← g.sub_eq]
    simpa [zero,Decision.run] using hc zero x
  have hnum := kw_numeric ht hn (Nat.le_of_lt smallB) (Nat.le_of_lt smallP)
  have z := qdag (B:=B) (H:=g.A++B) g.gS gate g.nb
    (fun j hj => (g.domain j).mp (by simp [hj])) (n:=n)
    (fun z lo hi => by
      have hm := (g.domain z).mpr ⟨lo,hi⟩
      simp only [List.mem_append] at hm ⊢
      rcases hm with (hb|hb)|hb <;> simp [hb])
    hnum.1 hnum.2.1 (by have := g.total; omega) (by simpa using hnum.2.2.2.2)
    hnum.2.2.1 ht raw
  unfold Hardware.wires at cost
  omega

theorem leaf_universal (c : Certificate n W) {T : List Nat} (eqT : T.Perm c.A)
    {N : Nat} (g : DAG N) (gate : State N) (cost : N≤W)
    (hc : ∀ x : Assignment T, g.eval (bits T x.val) gate=universal c.B x.val) {t : Nat}
    (ht : 0<t) (hn : (65536*t)^3≤n) (smallB : c.B.length<8*t) : 2^t≤W+2 := by
  have hnum := kw_numeric (d:=0) ht hn (Nat.le_of_lt smallB) (by omega)
  have z := qdag (B:=c.B) (H:=c.B) g gate (eqT.nodup_iff.mpr c.na)
    (fun j hj => (c.domain j).mp (List.mem_append_left _ (eqT.subset hj))) (n:=n)
    (fun z lo hi => (List.mem_append.mp ((c.domain z).mpr ⟨lo,hi⟩)).imp
      (fun ha => eqT.symm.subset ha) id)
    hnum.1 hnum.2.1 (by have := c.total; have := eqT.length_eq; omega)
    (by simpa using hnum.2.2.2.2) hnum.2.2.1 ht hc
  omega

end HWB.TwoRoot
