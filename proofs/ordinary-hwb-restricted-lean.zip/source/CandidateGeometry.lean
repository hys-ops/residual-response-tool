import ThresholdPacked

/-! Raw label geometry for the two-level threshold lower bound. The incidence
argument accounts separately for unavoidable outer and tolerable inner holes.
The disjoint aligned-block argument is adapted from HWB.SharpPacking in the
companion Lean development; here it affects only the long obstruction term. -/
namespace HWB.CandidateGeometry
open HWB.Threshold

private theorem split_length (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun z => !(f z))).length = U.length := by
  induction U with
  | nil => simp
  | cons a L ih => cases h : f a <;> simp [h] <;> omega

private theorem flat_size (L : List Nat) (f : Nat → List Nat) (r : Nat)
    (h : ∀ i ∈ L, (f i).length ≤ r) : (L.flatMap f).length ≤ L.length*r := by
  induction L with
  | nil => simp
  | cons a L ih =>
    have h1 := h a (by simp)
    have h2 := ih (fun i hi => h i (by simp [hi]))
    simpa [List.flatMap_cons, Nat.succ_mul, Nat.add_comm] using Nat.add_le_add h1 h2

private def win (j d : Nat) := List.range' j d

private theorem mem_win {z j d : Nat} : z ∈ win j d ↔ j ≤ z ∧ z < j+d := by
  simp only [win, List.mem_range', Nat.one_mul]
  constructor
  · rintro ⟨i,hi,rfl⟩; omega
  · rintro ⟨h0,h1⟩; exact ⟨z-j, by omega, by omega⟩

private theorem flat_length (L : List Nat) (v : Nat) :
    (L.flatMap (fun i => win (i*v) v)).length = L.length*v := by
  induction L with
  | nil => simp
  | cons a L ih =>
    rw [List.flatMap_cons, List.length_append, ih, List.length_cons, Nat.succ_mul]
    simp only [win, List.length_range']; omega

private noncomputable def blocks (H : List Nat) (n v : Nat) : List Nat := by
  classical
  exact (List.range (n+1)).filter (fun i => decide (win (i*v) v ⊆ H))

private theorem block_count (H : List Nat) (n v : Nat) :
    (blocks H n v).length*v ≤ H.length := by
  classical
  let S := blocks H n v
  have pair : S.Pairwise (· < ·) := List.Pairwise.filter _ (List.pairwise_lt_range)
  have nod : (S.flatMap (fun i => win (i*v) v)).Nodup := by
    apply List.pairwise_flatMap.mpr
    refine ⟨fun i _ => ?_, ?_⟩
    · exact List.nodup_range'
    · apply pair.imp
      intro i j hij x hx y hy hxy
      have xbound := (mem_win.mp hx).2
      have ybound := (mem_win.mp hy).1
      have prod := Nat.mul_le_mul_right v (show i+1≤j by omega)
      rw [Nat.succ_mul] at prod
      omega
  have incl : S.flatMap (fun i => win (i*v) v) ⊆ H := by
    intro z hz
    obtain ⟨i,hi,hz⟩ := List.mem_flatMap.mp hz
    have hs : win (i*v) v ⊆ H := by simpa [S,blocks] using (List.mem_filter.mp hi).2
    exact hs hz
  exact (flat_length S v) ▸ nod.length_le_of_subset incl

private theorem aligned (a v w : Nat) (hv : 0<v) (hw : 2*v ≤ w+1) :
    ∃ i, a ≤ i*v ∧ i*v+v ≤ a+w := by
  have dec := Nat.mod_add_div a v
  rw [Nat.mul_comm v (a/v)] at dec
  have rem := Nat.mod_lt a hv
  by_cases zero : a%v=0
  · exact ⟨a/v,by omega,by omega⟩
  · refine ⟨a/v+1,?_,?_⟩ <;> rw [Nat.succ_mul] <;> omega


/-- Integer-label window beginning at m-k+d, inclusive through m+d when m≥k. -/
def sees (k d m z:Nat) : Bool := decide (z ∈ SmallRight.interval (m-k+d) k)

def occupancy (Q:List Nat) (k d m:Nat) := (Q.filter (sees k d m)).length

private theorem ones (C:List Nat) (f:Nat → Bool) :
    (C.map (fun x => if f x then 1 else 0)).sum = (C.filter f).length := by
  induction C with
  | nil => simp
  | cons a l ih => cases h:f a <;> simp [h,ih] <;> omega

private theorem sum_plus (C:List Nat) (f g:Nat → Nat) :
    (C.map (fun x => f x+g x)).sum = (C.map f).sum+(C.map g).sum := by
  induction C with
  | nil => simp
  | cons a l ih => simp [ih]; omega

private theorem weighted_lower (C:List Nat) (f:Nat → Nat) (d:Nat) :
    (C.filter (fun x => decide (d<f x))).length*(d+1) ≤ (C.map f).sum := by
  induction C with
  | nil => simp
  | cons a l ih =>
    by_cases h:d<f a
    · simp [h,Nat.succ_mul]; omega
    · simp [h]; omega

private theorem fiber (C:List Nat) (nd:C.Nodup) (k d z:Nat)
    (lo:∀ m∈C,k≤m) : (C.filter (fun m => sees k d m z)).length ≤ k+1 := by
  have hs : C.filter (fun m => sees k d m z) ⊆ win (z-d) (k+1) := by
    intro m hm
    obtain ⟨hm,hz⟩ := List.mem_filter.mp hm
    have hr : z ∈ SmallRight.interval (m-k+d) k := by simpa [sees] using hz
    have hb := SmallRight.mem_interval.mp hr
    have low := lo m hm
    exact mem_win.mpr ⟨by omega,by omega⟩
  simpa [win] using List.Nodup.length_le_of_subset (nd.filter _) hs

/-- Total incidence of Q-labels over distinct shifted starts. This remains
valid for an arbitrary subset of potential midpoint markers and any Q order. -/
theorem incidences (C Q:List Nat) (k d:Nat) (nd:C.Nodup) (lo:∀ m∈C,k≤m) :
    (C.map (occupancy Q k d)).sum ≤ Q.length*(k+1) := by
  induction Q with
  | nil =>
    have ha : occupancy [] k d = fun _ => 0 := by funext m; rfl
    have zeroSum (xs : List Nat) : (xs.map (fun _ => (0:Nat))).sum = 0 := by
      induction xs with
      | nil => rfl
      | cons x xs ih => simp [ih]
    simp [ha,zeroSum]
  | cons z Q ih =>
    have incl (m:Nat) : occupancy (z::Q) k d m = (if sees k d m z then 1 else 0) + occupancy Q k d m := by
      cases hh:sees k d m z <;> simp [occupancy,hh] <;> omega
    simp only [show occupancy (z::Q) k d = fun m => (if sees k d m z then 1 else 0) + occupancy Q k d m from funext incl,
      sum_plus,ones,List.length_cons,Nat.succ_mul]
    have h := fiber C nd k d z lo
    omega

/-- Markov counting for the positive Q-weight probe. -/
theorem excessive_window_count (C Q:List Nat) (k d threshold:Nat) (nd:C.Nodup)
    (lo:∀ m∈C,k≤m) :
    (C.filter (fun m => decide (threshold < occupancy Q k d m))).length ≤ Q.length*(k+1)/(threshold+1) := by
  apply (Nat.le_div_iff_mul_le (Nat.succ_pos _)).2
  exact Nat.le_trans (weighted_lower C (occupancy Q k d) threshold) (incidences C Q k d nd lo)

private noncomputable def longCover (H:List Nat) (n v:Nat) :=
  (blocks H n v).flatMap (fun i => win (i*v-(H.length+1)) (H.length+2))

private theorem long_cost (H:List Nat) (n v:Nat) (hv:0<v) :
    (longCover H n v).length ≤ H.length/v*(H.length+2) := by
  have hb := (Nat.le_div_iff_mul_le hv).mpr (block_count H n v)
  apply Nat.le_trans _ (Nat.mul_le_mul_right (H.length+2) hb)
  exact flat_size _ _ _ (by simp [win])

private theorem long_clean (H:List Nat) (n v l m:Nat) (hv:0<v) (hl:2*v≤l+1)
    (edge:m+H.length+1≤n) (good:m∉longCover H n v) :
    ∀ a, m≤a → a+l≤m+H.length+2 → ∃ z, a≤z ∧ z<a+l ∧ z∉H := by
  classical
  intro a ha hb
  obtain ⟨i,il,iu⟩ := aligned a v l hv hl
  apply Classical.byContradiction
  intro bad
  have sub : win (i*v) v ⊆ H := by
    intro z hz
    have bounds := mem_win.mp hz
    apply Classical.byContradiction; intro hn
    exact bad ⟨z,by omega,by omega,hn⟩
  have iv : i≤i*v := by simpa using Nat.mul_le_mul_left i hv
  have ii : i ∈ blocks H n v := by
    simp only [blocks,List.mem_filter,List.mem_range,decide_eq_true_eq]
    exact ⟨by omega,sub⟩
  apply good
  exact List.mem_flatMap.mpr ⟨i,ii,mem_win.mpr (by omega)⟩

/-- A central input slab supplies all the local tests for Candidate. No good
markers, clean windows, or preselected cells are assumed. -/
def PreCandidate (L R Q B : List Nat) (d m : Nat) : Prop :=
  ∀ s, s≤m-B.length → Q.length+B.length+1≤m-B.length-s →
    m-B.length-s+(Q.length+B.length+1)≤R.length → Candidate L R Q B s d m

theorem raw_markers {L R Q B:List Nat} {n base span d v l:Nat}
    (nd:L.Nodup) (complete:∀ z, 1≤z → z≤n → z∈L++R ∨ z∈Q ∨ z∈B)
    (hv:0<v) (align:2*v≤l+1) (middle:d+l≤B.length+1)
    (positive:B.length<base)
    (edge:base+span+(Q.length+B.length)≤n) :
    ∃ xs : List Nat, xs.Nodup ∧
      (∀ m∈xs, base≤m ∧ m<base+span ∧ PreCandidate L R Q B d m) ∧
      ((L.filter (fun m => decide (base≤m ∧ m<base+span))).length ≤
       xs.length + B.length*(B.length+1) + Q.length*(B.length+1)/(d+1) +
         (Q.length+B.length)/v*((Q.length+B.length)+2)) := by
  classical
  let C := L.filter (fun m => decide (base≤m ∧ m<base+span))
  let H := Q++B
  let F := longCover H n v
  have hsize : H.length= Q.length+B.length := by simp [H]
  have hC (m) (hm:m∈C) : m∈L ∧ base≤m ∧ m<base+span := by simpa [C] using hm
  have cn : C.Nodup := nd.filter _
  have lo (m) (hm:m∈C) : B.length≤m := by have := (hC m hm).2.1; omega
  let Bbad := C.filter (fun m => decide (0<occupancy B B.length d m))
  let Qbad := C.filter (fun m => decide (d<occupancy Q B.length d m))
  let bad := Bbad++Qbad++F
  let ok := fun m => decide (m∉bad)
  let xs := C.filter ok
  have bcap : Bbad.length ≤ B.length*(B.length+1) := by simpa [Bbad] using excessive_window_count C B B.length d 0 cn lo
  have qcap : Qbad.length ≤ Q.length*(B.length+1)/(d+1) := excessive_window_count C Q B.length d d cn lo
  have fcap : F.length ≤ (Q.length+B.length)/v*(Q.length+B.length+2) := hsize ▸ long_cost H n v hv
  have split := split_length C ok
  have er : (C.filter (fun m => !ok m)).length ≤ bad.length := by
    apply List.Nodup.length_le_of_subset (cn.filter _)
    intro z hz; simpa [ok] using (List.mem_filter.mp hz).2
  have badn : bad.length=Bbad.length+Qbad.length+F.length := by simp [bad,Nat.add_assoc]
  refine ⟨xs,cn.filter _,?_,?_⟩
  · intro m hm
    obtain ⟨hmC,okm⟩ := List.mem_filter.mp hm
    have gm : m∉bad := by simpa [ok] using okm
    have clean : m∉F := fun hf => gm (by simp [bad,hf])
    have bzero : occupancy B B.length d m=0 := by
      apply Nat.eq_zero_of_not_pos
      intro h; apply gm; simp [bad,Bbad,hmC,h]
    have qsmall : occupancy Q B.length d m≤d := by
      apply Nat.le_of_not_gt; intro h; apply gm; simp [bad,Qbad,hmC,h]
    obtain ⟨hmL,low,high⟩ := hC m hmC
    have guard := long_clean H n v l m hv align (by omega) clean
    have noB (z:Nat) (hz:z∈SmallRight.interval (m-B.length+d) B.length) : z∉B := by
      intro zB
      have em : B.filter (sees B.length d m) = [] := List.length_eq_zero_iff.mp bzero
      have mem : z∈B.filter (sees B.length d m) := List.mem_filter.mpr ⟨zB,by simpa [sees] using hz⟩
      rw [em] at mem; contradiction
    have pLabel (z:Nat) (z0:1≤z) (zn:z≤n) (hz:z∉H) : z∈L++R := by
      rcases complete z z0 zn with h|h|h
      · exact h
      · exact False.elim (hz (List.mem_append_left _ h))
      · exact False.elim (hz (List.mem_append_right _ h))
    refine ⟨low,high,fun s s1 s2 s3 => ⟨by omega,hmL,?_,qsmall,?_,?_,⟨s1,s2,s3⟩⟩⟩
    · intro z zl zh
      have zB := noB z (SmallRight.mem_interval.mpr ⟨zl,by omega⟩)
      rcases complete z (by omega) (by omega) with h|h|h
      · exact Or.inl h
      · exact Or.inr h
      · contradiction
    · intro hd
      obtain ⟨z,zlo,zhi,nz⟩ := guard (m+d+1) (by omega) (by omega)
      exact ⟨z,by omega,by omega,pLabel z (by omega) (by omega) nz⟩
    · intro a alo ahi
      obtain ⟨z,zlo,zhi,nz⟩ := guard a (by omega) (by omega)
      exact ⟨z,zlo,by omega,pLabel z (by omega) (by omega) nz⟩
  · change C.length ≤ xs.length+_+_+_
    change xs.length+_ = C.length at split
    omega


private theorem bucket (A : List Nat) (hd : A.Nodup) (f : Nat → Nat) {r t : Nat}
    (hr : 0 < r) (hcap : r*t ≤ A.length) (bound : ∀ j ∈ A, f j < r) :
    ∃ b < r, t ≤ (A.filter (fun j => decide (f j = b))).length := by
  classical
  apply Classical.byContradiction
  intro hh
  let group := fun b => A.filter (fun j => decide (f j = b))
  have short (b) (hb : b < r) : (group b).length < t := by
    exact Nat.lt_of_not_ge (fun h => hh ⟨b,hb,h⟩)
  have ht := short 0 hr
  have incl : A ⊆ (List.range r).flatMap group := by
    intro j hj
    exact List.mem_flatMap.mpr ⟨f j,List.mem_range.mpr (bound j hj), by simp [group,hj]⟩
  have hle := hd.length_le_of_subset incl
  have hsum := flat_size (List.range r) group (t-1) (fun i hi => by
    have := short i (List.mem_range.mp hi); omega)
  simp only [List.length_range] at hsum
  have hlt := Nat.mul_lt_mul_of_pos_left (show t-1<t by omega) hr
  omega


private theorem central_mass (L:List Nat) (nd:L.Nodup) {n base span:Nat}
    (rng:∀ m∈L, 1≤m ∧ m≤n) :
    L.length ≤ (L.filter (fun m => decide (base≤m ∧ m<base+span))).length +
      base + (n+1-(base+span)) := by
  let pred := fun m => decide (base≤m ∧ m<base+span)
  have h := split_length L pred
  let tails := List.range base ++ win (base+span) (n+1-(base+span))
  have sub : L.filter (fun m => !pred m) ⊆ tails := by
    intro m hm
    have ⟨ml,hp⟩ := List.mem_filter.mp hm
    have hn := (rng m ml).2
    have he : m<base ∨ base+span≤m := by simpa [pred] using hp
    by_cases left : m<base
    · exact List.mem_append_left _ (List.mem_range.mpr left)
    · exact List.mem_append_right _ (mem_win.mpr ⟨by omega,by omega⟩)
  have le := List.Nodup.length_le_of_subset (nd.filter _) sub
  have nlt : tails.length=base+(n+1-(base+span)) := by simp [tails,win]
  change L.length≤(L.filter pred).length+_+_
  omega

/-- Loss for a length-(k+1) live window and any all-hole window of length l.
The allowed block size v satisfies 2v≤l+1. -/
def loss (k q d v:Nat) := k*(k+1)+q*(k+1)/(d+1)+(q+k)/v*(q+k+2)

/-- Number of markers demanded in one packed slab. -/
def need (ell M d G T:Nat) := (4*G)*ell + M*((d+1)*T)

/-- A lower bound for the original compressed decision under purely scalar
finite margins. Neither a good slab nor a clean-window list is an input.
The total deletion budget is applied once, before selecting a slab. -/
theorem raw_hardware {B L R:List Nat} {n lo ell M bins d v l G T:Nat}
    (hw:Slice.Hardware n B) (ndB:B.Nodup)
    (correct:∀ x y,hw.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (cut:hw.A=L++R)
    (dq:d≤hw.B.length) (hv:0<v) (align:2*v≤l+1) (mid:d+l≤B.length+1)
    (epos:0<ell) (mp:0<M) (bp:0<bins) (kcell:B.length≤ell) (qcell:hw.B.length≤ell)
    (lb:B.length<lo) (edge:lo+bins*(M*ell)+(hw.B.length+B.length)≤n)
    (density:bins*need ell M d G T+loss B.length hw.B.length d v+
      lo+(n+1-(lo+bins*(M*ell)))≤L.length)
    (sLo: G*(3*ell) ≤ (lo-B.length)/2)
    (sHi: (lo+bins*(M*ell)-B.length)/2 + G*(3*ell) ≤ L.length)
    (rLo: hw.B.length+B.length+1 ≤ (lo-B.length)/2)
    (rHi: (lo+bins*(M*ell)-B.length)/2 + M*ell + 1 + (hw.B.length+B.length+1) ≤ R.length) :
    (T+1)^G ≤ hw.NP+2 := by
  classical
  let W := M*ell
  have wp : 0<W := Nat.mul_pos mp epos
  have nd := (List.nodup_append.mp (cut ▸ hw.na)).1
  have inside (m:Nat) (hm:m∈L) : 1≤m ∧ m≤n := by
    apply (hw.domain m).1
    simp [cut,hm]
  have cover (z:Nat) (zp:1≤z) (zn:z≤n) : z∈L++R ∨ z∈hw.B ∨ z∈B := by
    have h := (hw.domain z).2 ⟨zp,zn⟩
    simpa [cut,List.mem_append,or_assoc] using h
  obtain ⟨good,ndg,hg,mass⟩ := raw_markers (L:=L) (R:=R) (Q:=hw.B) (B:=B)
    (n:=n) (base:=lo) (span:=bins*W) nd cover hv align mid lb edge
  have cm := central_mass L nd (base:=lo) (span:=bins*W) inside
  change bins*need ell M d G T+loss B.length hw.B.length d v+lo+(n+1-(lo+bins*W))≤L.length at density
  have enough : bins*need ell M d G T ≤ good.length := by unfold loss at density; omega
  let cell := fun m => (m-lo)/W
  have bound (m) (hm:m∈good) : cell m < bins := by
    obtain ⟨a,b,_⟩ := hg m hm
    exact (Nat.div_lt_iff_lt_mul wp).mpr (by omega)
  obtain ⟨b,bb,heavy⟩ := bucket good ndg cell bp enough bound
  let xs := good.filter (fun j => decide (cell j=b))
  let base := lo+b*W
  let s := (base-B.length)/2
  have be : base≤lo+bins*W := by
    have hh := Nat.mul_le_mul_right W (Nat.le_of_lt bb)
    dsimp [base]; omega
  have sblo : (lo-B.length)/2≤s := Nat.div_le_div_right (c:=2) (by dsimp [base]; omega)
  have sbhi : s≤(lo+bins*W-B.length)/2 := Nat.div_le_div_right (c:=2) (by omega)
  have get (m) (hm:m∈xs) : m∈good ∧ base≤m ∧ m<base+W := by
    obtain ⟨gg,ee⟩ := List.mem_filter.mp hm
    have cc : cell m=b := by simpa using ee
    have ge := (hg m gg).1
    have a := Nat.div_mul_le_self (m-lo) W
    have d0 := Nat.mod_add_div (m-lo) W
    have z0 := Nat.mod_lt (m-lo) wp
    change (m-lo)/W=b at cc
    rw [cc] at a d0
    rw [Nat.mul_comm W b] at d0
    dsimp [base]
    exact ⟨gg,by omega,by omega⟩
  change (lo+bins*W-B.length)/2+G*(3*ell)≤L.length at sHi
  change (lo+bins*W-B.length)/2+W+1+(hw.B.length+B.length+1)≤R.length at rHi
  have slo : G*(3*ell) ≤ s := Nat.le_trans sLo sblo
  have shi : s+G*(3*ell)≤L.length := Nat.le_trans (Nat.add_le_add_right sbhi _) sHi
  apply dense_hardware (xs:=xs) (base:=base) (ell:=ell) (M:=M) (s:=s) (d:=d)
    hw ndB correct cut dq _ (ndg.filter _) epos kcell qcell _ heavy slo shi
  · intro m hm
    obtain ⟨gm,gm1,gm2⟩ := get m hm
    apply (hg m gm).2.2 s
    all_goals have eqs : s=(base-B.length)/2 := rfl
    all_goals have gbase : lo≤base := Nat.le_add_right _ _
    all_goals omega
  · exact fun m hm => (get m hm).2

#print axioms excessive_window_count
#print axioms raw_markers
#print axioms raw_hardware
end HWB.CandidateGeometry
