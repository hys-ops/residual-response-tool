import HWB.SliceGap
import HWB.SmallRightSlice
import HWB.LowerAssembly

namespace HWB.TwoRoot
open HWB.Model HWB.Circuit HWB.Slice

def paste {P Q T : List Nat} (dis : ∀ z∈P, z∉Q)
    (scope : P++Q ⊆ T) (x : Assignment P) (y : Assignment Q) : Assignment T :=
  ⟨x.val++y.val, List.nodup_append.mpr ⟨x.property.1, y.property.1, by
    intro a ha b hb eq; subst b; exact dis a (x.property.2 ha) (y.property.2 hb)⟩,
    fun z hz => scope ((List.mem_append.mp hz).elim
      (fun ha => List.mem_append_left Q (x.property.2 ha))
      (fun hb => List.mem_append_right P (y.property.2 hb)))⟩

/-- A gate below the outer decision. A direct ordered leaf can choose its
own permutation. A second decision can choose arbitrary splits, read orders
and shared ordered DAGs. W bounds each physical subcircuit separately,
so sharing among different outer entries never gets billed twice. -/
inductive Child (n W : Nat) (holes T : List Nat) (f : Assignment T → Bool) : Type where
  | ordered {N : Nat} (order : List Nat) (perm : order.Perm T)
      (g : DAG N) (root : State N) (cost : N ≤ W)
      (correct : ∀ x : Assignment order, g.eval (bits order x.val) root =
        f ⟨x.val, x.property.1, fun _ h => perm.subset (x.property.2 h)⟩)
  | branch (g : Hardware n holes) (scope : (g.A++g.B).Perm T) (cost : g.wires ≤ W)
      (correct : ∀ x y, g.dec.run x y = f (paste g.dis scope.subset x y))

structure Certificate (n W : Nat) where
  A : List Nat
  B : List Nat
  na : A.Nodup
  nb : B.Nodup
  dis : ∀ z∈A, z∉B
  domain : ∀ j, j∈A++B ↔ 1≤j ∧ j≤n
  total : A.length+B.length=n
  R : Nat
  cost : R≤W
  dec : Decision (Assignment A) (Assignment B) R
  correct : ∀ x y, dec.run x y = decide (x.val.length+y.val.length ∈ x.val++y.val)
  primes : ∀ i, Child n W B A (dec.prime i)
  subs : ∀ i, Child n W A B (dec.sub i)

theorem Certificate.balanced (c : Certificate n W) {t : Nat} (ht : 0<t)
    (ha : 8*t≤c.A.length) (hb : 8*t≤c.B.length) : 2^t≤W+2 := by
  classical
  let x0 : Assignment c.A := ⟨[], by simp⟩
  let idx := fun (x : List Nat) => if h : Balanced.Legal c.A x then
    c.dec.selectCase ⟨x,h⟩ else c.dec.selectCase x0
  let out := fun (i : Fin c.R) (y : List Nat) =>
    if h : Balanced.Legal c.B y then c.dec.sub i ⟨y,h⟩ else false
  have root : 2^t ≤ c.R := by
    apply Balanced.balanced_width c.A c.B 0 t c.R c.na c.nb c.dis _ ha hb (by omega) ht idx out
    · intro x y hx hy
      simpa [idx,out,hx,hy,Decision.run,Balanced.raw] using c.correct ⟨x,hx⟩ ⟨y,hy⟩
    · intro j hj
      have hu := ((c.domain j).mp (List.mem_append_left _ hj)).2
      have := c.total
      omega
  have := c.cost
  omega

/-- The exact preimage of a constant inner row is computed by an actual
prime, or by the shared false terminal when the row never occurs. -/
theorem const_state (c : Hardware n D) (v : Bool) :
    ∃ s : State c.NP, ∀ x : Assignment c.A,
      c.gP.eval (bits c.A x.val) s = true ↔ ∀ y, c.dec.run x y=v := by
  classical
  by_cases h : ∃ x : Assignment c.A, ∀ y, c.dec.run x y=v
  · obtain ⟨x₀,h₀⟩ := h
    refine ⟨c.pRoot (c.dec.selectCase x₀), fun x => ?_⟩
    rw [←c.prime_eq, c.dec.prime_iff_row]
    change (∀ y, c.dec.run x y = c.dec.run x₀ y) ↔ _
    simp [h₀]
  · refine ⟨.term false, fun x => ?_⟩
    simp only [DAG.eval, Bool.false_eq_true, false_iff]
    exact fun hx => h ⟨x,hx⟩

noncomputable def universal (B x : List Nat) : Bool := by
  classical
  exact decide (∀ y : Assignment B, HWB.SmallRight.ordinary (x++y.val))

theorem universal_iff (B x : List Nat) : universal B x = true ↔
    ∀ y : Assignment B, HWB.SmallRight.ordinary (x++y.val) := by classical simp [universal]

/-- Force the constant-one response at the outer decision; a missing response
has empty preimage and is realized by its false terminal at zero cost. -/
noncomputable def Certificate.universalChild (c : Certificate n W) :
    Child n W c.B c.A (fun x => universal c.B x.val) := by
  classical
  have raw (x : Assignment c.A) :
      (∀ y, c.dec.run x y=true) ↔ universal c.B x.val=true := by
    rw [universal_iff]
    simp [c.correct, SmallRight.ordinary]
  by_cases ex : ∃ x : Assignment c.A, ∀ y, c.dec.run x y=true
  · let x₀ := Classical.choose ex
    have hx := Classical.choose_spec ex
    have same : c.dec.prime (c.dec.selectCase x₀) = (fun x => universal c.B x.val) := by
      funext x
      exact Bool.eq_iff_iff.mpr ((c.dec.forced_const_one _ hx x).trans (raw x))
    rw [←same]; exact c.primes _
  · let g : DAG 0 := ⟨fun i => i.elim0, fun i => i.elim0, fun i => i.elim0, fun i => i.elim0⟩
    apply Child.ordered c.A (List.Perm.refl _) g (.term false) (Nat.zero_le _)
    intro x
    have no : universal c.B x.val ≠ true := fun h => ex ⟨x,(raw x).mpr h⟩
    simpa [DAG.eval] using (Bool.eq_false_iff.mpr no).symm

end HWB.TwoRoot
