import TwoRootModel
import HWB.Balanced
/-! Force all the inner left variables on, paying their cardinality in each
subsequent address. Original B holes alone are deleted, irrespective of the
positions of the fixed ones. -/
namespace HWB.SmallLeftOnes
open HWB.SmallRight

private theorem flat_size (L : List Nat) (f : Nat → List Nat) (r : Nat)
    (h : ∀ i ∈ L, (f i).length ≤ r) : (L.flatMap f).length ≤ L.length*r := by
  induction L with
  | nil => simp
  | cons a L ih =>
    have h1 := h a (by simp)
    have h2 := ih (fun i hi => h i (by simp [hi]))
    simpa [List.flatMap_cons, Nat.succ_mul, Nat.add_comm] using Nat.add_le_add h1 h2

private theorem bucket (A : List Nat) (hd : A.Nodup) (f : Nat → Nat) {r t : Nat}
    (hr : 0 < r) (hcap : r*t ≤ A.length) (bound : ∀ j ∈ A, f j < r) :
    ∃ b < r, t ≤ (A.filter (fun j => decide (f j = b))).length := by
  classical
  apply Classical.byContradiction
  intro hh
  let group := fun b => A.filter (fun j => decide (f j = b))
  have short (b) (hb : b < r) : (group b).length < t := by
    exact Nat.lt_of_not_ge (fun h => hh ⟨b,hb,h⟩)
  have ht := short 0 hr
  have incl : A ⊆ (List.range r).flatMap group := by
    intro j hj
    exact List.mem_flatMap.mpr ⟨f j,List.mem_range.mpr (bound j hj), by simp [group,hj]⟩
  have hle := hd.length_le_of_subset incl
  have hsum := flat_size (List.range r) group (t-1) (fun i hi => by
    have := short i (List.mem_range.mp hi); omega)
  simp only [List.length_range] at hsum
  have hlt := Nat.mul_lt_mul_of_pos_left (show t-1<t by omega) hr
  omega

private theorem residue_separates (j z k : Nat) (hj : j ≤ z) (hz : z ≤ j+k)
    (hm : j%(k+1) = z%(k+1)) : z = j := by
  have h1 := Nat.mod_add_div j (k+1)
  have h2 := Nat.mod_add_div z (k+1)
  by_cases h : j/(k+1) = z/(k+1)
  · rw [hm, h] at h1; omega
  have hle := Nat.div_le_div_right (c:=k+1) hj
  have hmul := Nat.mul_le_mul_left (k+1) (show j/(k+1)+1 ≤ z/(k+1) by omega)
  rw [Nat.mul_add_one] at hmul
  omega

structure Placement (P V B F J : List Nat) (s : Nat) : Prop where
  uniqueP : P.Nodup
  uniqueQ : V.Nodup
  disjointPQ : ∀ z∈P,z∉V
  disjointPF : ∀ z∈P,z∉F
  queries : J ⊆ P
  separated : ∀ j∈J,∀ z∈interval j B.length,z∈J → z=j
  covered : ∀ z∈guards J B.length,z∈P ∨ z∈V ∨ z∈F
  prefixRoomOn : J.length*(B.length+1)≤s
  prefixRoomOff : s+J.length*(B.length+1)≤P.length
  suffixRoom : ∀ j∈J,F.length+s≤j ∧ B.length≤j-F.length-s ∧ j-F.length-s≤V.length

def demand (k f t : Nat) := k*(k+1)+f+k+(k+1)*t

/-- The reachable addresses lie strictly above k. Fixed B labels below
this threshold need not be counted as forbidden starts. -/
def active (B : List Nat) := B.filter fun z => decide (B.length<z)
def actualDemand (B : List Nat) (f t : Nat) :=
  (active B).length*(B.length+1)+f+B.length+(B.length+1)*t

theorem pack_active {P Q B F : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z∈P,z∉Q) (pf : ∀ z∈P,z∉F)
    (bounds : ∀ j∈P,1≤j ∧ j≤n)
    (cover : ∀ z,1≤z → z≤n → z∈P ∨ z∈Q ∨ z∈B ∨ z∈F)
    (sz : P.length+Q.length+B.length+F.length=n) (ht : 0<t)
    (mBig : 8*actualDemand B F.length t≤P.length)
    (lBig : 8*actualDemand B F.length t≤Q.length)
    (holeRoom : 8*(B.length+F.length)≤P.length) :
    ∃ J a, J.Nodup ∧ J.length=t ∧ Placement P Q B F J a := by
  classical
  let k := B.length
  let u := actualDemand B F.length t
  have ku : k+1 ≤ (k+1)*t := Nat.le_mul_of_pos_right _ ht
  have upos : 0 < u := by dsimp [k] at ku; dsimp [u,actualDemand]; omega
  obtain ⟨a,al,ar,ww⟩ := Balanced.window_exists P Q.length (B.length+F.length) u upos pd
    (fun j hj => by have := (bounds _ hj).2; omega) mBig lBig holeRoom
  let W := Balanced.window P a Q.length
  let bad := List.range' a (k+F.length) ++ (active B).flatMap (fun z => interval (z-k) k)
  have fsize := flat_size (active B) (fun z => interval (z-k) k) (k+1)
    (by intro j hj; simp [interval])
  have badsize : bad.length ≤ (k+F.length)+(active B).length*(k+1) := by
    simpa only [bad,List.length_append,List.length_range'] using Nat.add_le_add_left fsize (k+F.length)
  let ok := fun j => decide (j∉bad)
  let G := W.filter ok
  have wd : W.Nodup := pd.sublist List.filter_sublist
  have gd : G.Nodup := List.Pairwise.filter ok wd
  have del : (W.filter (fun j => !ok j)).length ≤ bad.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ wd)
    intro j hj
    simpa [ok] using (List.mem_filter.mp hj).2
  have wl : u ≤ W.length := ww
  have split := (List.filter_append_perm ok W).length_eq
  rw [List.length_append] at split
  have gsize : (k+1)*t ≤ G.length := by
    change (k+1)*t ≤ (List.filter ok W).length
    dsimp [u,actualDemand,k] at wl ⊢
    dsimp [k] at badsize
    omega
  obtain ⟨r,hr,rl⟩ := bucket G gd (fun z=>z%(k+1)) (by omega) gsize
    (fun z _ => Nat.mod_lt _ (by omega))
  let group := G.filter (fun z=>decide (z%(k+1)=r))
  let J := group.take t
  have jl : J.length=t := by exact (List.length_take ..).trans (Nat.min_eq_left rl)
  have jd : J.Nodup := (List.Pairwise.filter _ gd).take
  have prop (j) (h : j∈J) : j∈P ∧ a+k+F.length≤j ∧ j≤a+Q.length ∧ j∉bad ∧ j%(k+1)=r := by
    obtain ⟨hg,he⟩ := List.mem_filter.mp (show j ∈ G.filter (fun z => decide (z%(k+1)=r)) from List.take_subset t group h)
    obtain ⟨hw,ho⟩ := List.mem_filter.mp hg
    have info := Balanced.mem_window.mp hw
    have nb : j∉bad := by simpa [ok] using ho
    have good : a+k+F.length≤j := by
      by_cases ge : a+k+F.length≤j
      · exact ge
      · exfalso; apply nb
        apply List.mem_append_left _
        apply List.mem_range'.mpr
        refine ⟨j-a,by omega,by omega⟩
    exact ⟨info.1,good,info.2.2,nb,by simpa using he⟩
  have kt : t*(k+1) ≤ u := by rw [Nat.mul_comm t (k+1)]; dsimp [u,actualDemand,k]; omega
  refine ⟨J,a,jd,jl,⟨pd,qd,pq,pf,?_,?_,?_,?_,?_,?_⟩⟩
  · intro j hj; exact (prop j hj).1
  · intro j hj z hz zz
    have eqv := (prop j hj).2.2.2.2.trans (prop z zz).2.2.2.2.symm
    exact residue_separates j z k (mem_interval.mp hz).1 (mem_interval.mp hz).2 eqv
  · intro z hz
    obtain ⟨j,hj,ww⟩ := List.mem_flatMap.mp hz
    have pp := prop j hj
    have ⟨lo,hi⟩ := mem_interval.mp ww
    have goodj := bounds j pp.1
    have up : z≤n := by dsimp [k] at *; omega
    rcases cover z (by omega) up with p|q|b|h
    · exact Or.inl p
    · exact Or.inr (Or.inl q)
    · exfalso; apply pp.2.2.2.1
      apply List.mem_append_right _
      exact List.mem_flatMap.mpr ⟨z,List.mem_filter.mpr ⟨b,decide_eq_true_eq.mpr (by change k<z; omega)⟩,mem_interval.mpr (by dsimp [k]; omega)⟩
    · exact Or.inr (Or.inr h)
  · rw [jl]; exact Nat.le_trans kt al
  · rw [jl]; exact Nat.le_trans (Nat.add_le_add_left kt _) ar
  · intro j hj; have h := prop j hj; change F.length+a≤j ∧ k≤j-F.length-a ∧ j-F.length-a≤Q.length; omega

private theorem active_le (B : List Nat) :
    (active B).length*(B.length+1)≤B.length*(B.length+1) :=
  Nat.mul_le_mul_right _ (List.length_filter_le ..)

theorem pack {P Q B F : List Nat} {n t : Nat}
    (pd : P.Nodup) (qd : Q.Nodup) (pq : ∀ z∈P,z∉Q) (pf : ∀ z∈P,z∉F)
    (bounds : ∀ j∈P,1≤j ∧ j≤n)
    (cover : ∀ z,1≤z → z≤n → z∈P ∨ z∈Q ∨ z∈B ∨ z∈F)
    (sz : P.length+Q.length+B.length+F.length=n) (ht : 0<t)
    (mBig : 8*demand B.length F.length t≤P.length)
    (lBig : 8*demand B.length F.length t≤Q.length)
    (holeRoom : 8*(B.length+F.length)≤P.length) :
    ∃ J a, J.Nodup ∧ J.length=t ∧ Placement P Q B F J a := by
  have comp := active_le B
  apply pack_active pd qd pq pf bounds cover sz ht _ _ holeRoom <;>
    dsimp [demand,actualDemand] at * <;> omega

private theorem split_length (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun z => !(f z))).length = U.length := by
  induction U with
  | nil => simp
  | cons a L ih => cases h : f a <;> simp [h] <;> omega

theorem decoder {P Q B F J : List Nat} {s : Nat} (w : Placement P Q B F J s) :
    ∃ enc : (Nat → Bool) → Assignment P, ∃ probe : (j : Nat) → j ∈ J → Assignment Q,
      ∀ (word : Nat → Bool) (j) (hj : j ∈ J),
        onePrime B (F++(enc word).val) (probe j hj).val ↔ word j = true := by
  classical
  let g := guards J B.length
  let lock := fun z => decide (z ∈ g)
  let value := fun (word : Nat → Bool) z => if z ∈ J then word z else true
  have hg : (P.filter lock).length ≤ J.length * (B.length+1) := by
    rw [← guards_length]
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter lock w.uniqueP)
    intro z hz
    simpa [lock, g] using (List.mem_filter.mp hz).2
  have en (word : Nat → Bool) := fill P w.uniqueP lock (value word) s
  have encEx (word : Nat → Bool) : ∃ p : Assignment P, p.val.length = s ∧
      ∀ z ∈ P, lock z = true → (z ∈ p.val ↔ value word z = true) := by
    apply en
    · exact Nat.le_trans (List.length_filter_le _ _) (Nat.le_trans hg w.prefixRoomOn)
    · have h := split_length P lock
      have h' := w.prefixRoomOff
      omega
  let enc := fun word => Classical.choose (encEx word)
  have es (word) := Classical.choose_spec (encEx word)
  let qlock := fun j z => decide (z ∈ interval (j+1) (B.length-1) ∧ z ≤ j+B.length)
  have qlock_def j z : qlock j z = true ↔ j < z ∧ z ≤ j+B.length := by
    simp only [qlock, decide_eq_true_eq, mem_interval]; omega
  have ql (j : Nat) : (Q.filter (qlock j)).length ≤ B.length := by
    have hsub : Q.filter (qlock j) ⊆ List.range' (j+1) B.length := by
      intro z hz
      have ⟨h1,h2⟩ := (qlock_def _ _).mp (List.mem_filter.mp hz).2
      apply List.mem_range'.mpr
      exact ⟨z-(j+1),by omega,by omega⟩
    simpa using List.Nodup.length_le_of_subset (List.Pairwise.filter _ w.uniqueQ) hsub
  have probeEx (j) (hj : j ∈ J) : ∃ q : Assignment Q, q.val.length = j-F.length-s ∧
      ∀ z ∈ Q, qlock j z = true → z ∈ q.val := by
    have cap := w.suffixRoom j hj
    obtain ⟨q,h,hv⟩ := fill Q w.uniqueQ (qlock j) (fun _ => true) (j-F.length-s)
      (by simpa using Nat.le_trans (ql j) cap.2.1)
      (by simpa [split_length] using cap.2.2)
    exact ⟨q,h,fun z hz hlock => (hv _ hz hlock).mpr rfl⟩
  let probe := fun j hj => Classical.choose (probeEx j hj)
  have ps j hj := Classical.choose_spec (probeEx j hj)
  refine ⟨enc, probe, ?_⟩
  intro word j hj
  let p := enc word
  let q := probe j hj
  have hp : p.val.length = s := (es word).1
  have hq : q.val.length = j-F.length-s := (ps j hj).1
  have hcap := (w.suffixRoom j hj).1
  have hjp := w.queries hj
  have ifGuard {z : Nat} (hz : z ∈ interval j B.length) : lock z = true := by
    simpa [lock, g] using in_guards hj hz
  have hvar : j ∈ p.val ↔ word j = true := by
    simpa [p, enc, value, hj] using (es word).2 j hjp (ifGuard (by simp))
  change onePrime B (F++p.val) q.val ↔ _
  constructor
  · intro h
    have hz := h ⟨[], by simp⟩
    have hnq : j ∉ q.val := fun hmem => w.disjointPQ _ hjp (q.property.2 hmem)
    have sumw : F.length + (s + (j - F.length - s)) = j := by omega
    have nF := w.disjointPF j hjp
    simpa [ordinary, hp, hq, sumw, hnq, hvar, nF] using hz
  · intro hword b
    let z := j + b.val.length
    have hb := b.property.1.length_le_of_subset b.property.2
    have hz : z ∈ interval j B.length := by simp [z]; omega
    have wh : (F ++ p.val ++ q.val ++ b.val).length = z := by simp [hp, hq, z]; omega
    change (F ++ p.val ++ q.val ++ b.val).length ∈ _
    rw [wh]
    suffices h : z∈p.val ∨ z∈q.val ∨ z∈F by
      rcases h with h|h|h <;> simp [h]
    rcases w.covered z (in_guards hj hz) with hP|hQ|hF
    · left; apply ((es word).2 _ hP (ifGuard hz)).mpr
      change (if z ∈ J then word z else true) = true
      split
      · rename_i hzj; rwa [w.separated _ hj _ hz hzj]
      · rfl
    · right; left; apply (ps j hj).2 _ hQ
      apply (qlock_def _ _).mpr
      have hne : z ≠ j := fun h => w.disjointPQ _ hjp (h ▸ hQ)
      have := mem_interval.mp hz
      omega

    · exact Or.inr (Or.inr hF)
theorem width {P Q B F J : List Nat} {s M : Nat}
    (w : Placement P Q B F J s) (hJ : J.Nodup)
    (read : Assignment P → Fin M) (finish : Fin M → Assignment Q → Prop)
    (correct : ∀ p q, finish (read p) q ↔ onePrime B (F++p.val) q.val) :
    2^J.length ≤ M := by
  obtain ⟨enc, probe, h⟩ := decoder w
  let word := fun (c : Fin (2^J.length)) j => c.val.testBit (J.idxOf j)
  let code := fun c => read (enc (word c))
  have inj : Function.Injective code := by
    intro u v he
    apply Fin.ext; apply Nat.eq_of_testBit_eq
    intro i
    by_cases hi : i < J.length
    · let j := J[i]
      have hj : j ∈ J := List.getElem_mem hi
      have ha := (h _ j hj).symm.trans (correct (enc (word u)) (probe j hj)).symm
      have hb := (h _ j hj).symm.trans (correct (enc (word v)) (probe j hj)).symm
      change read (enc (word u)) = read (enc (word v)) at he
      rw [he] at ha
      have hh := ha.trans hb.symm
      simpa [word, j, hJ.idxOf_getElem i hi] using Bool.eq_iff_iff.mpr hh
    · have le := Nat.pow_le_pow_right (n:=2) (by decide) (Nat.le_of_not_lt hi)
      rw [Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le u.isLt le),
          Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le v.isLt le)]
  have nod : ((List.finRange (2^J.length)).map code).Nodup :=
    List.Pairwise.map code (fun _ _ hne he => hne (inj he)) (List.nodup_finRange _)
  have sub : (List.finRange (2^J.length)).map code ⊆ List.finRange M :=
    fun _ _ => List.mem_finRange _
  simpa using nod.length_le_of_subset sub

/-- An actual arbitrary-order OBDD for the surviving free bank S. It computes
the universal outer response with exactly the F variables fixed to one. -/
theorem fixed_dag_active {S F B : List Nat} {n t N : Nat}
    (g : Circuit.DAG N) (gate : Circuit.State N)
    (nd : S.Nodup) (disSF : ∀ z∈S,z∉F)
    (dom : ∀ z∈S,1≤z ∧ z≤n)
    (cover : ∀ z,1≤z → z≤n → z∈S ∨ z∈B ∨ z∈F)
    (size : S.length+B.length+F.length=n)
    (pSmall : 100*F.length≤n)
    (badSmall : 100*((active B).length*(B.length+1))≤n)
    (budget : 512*((B.length+1)*t)≤n)
    (correct : ∀ x : Model.Assignment S,
      g.eval (Model.bits S x.val) gate=TwoRoot.universal B (F++x.val)) :
    2^t≤N+2 := by
  by_cases ht : 0<t
  · let m := S.length/2
    let L := S.take m
    let R := S.drop m
    have e : S=L++R := (List.take_append_drop m S).symm
    have good := List.nodup_append.mp (e ▸ nd)
    have dis := fun z hz hq => good.2.2 z hz z hq rfl
    have kpos : B.length≤B.length*(B.length+1) := Nat.le_mul_of_pos_right _ (by omega)
    have mid : L.length≤R.length ∧ R.length≤L.length+1 := by
      dsimp [L,R,m]; simp; omega
    have total : L.length+R.length+B.length+F.length=n := by
      simpa only [e,List.length_append] using size
    have wl : (B.length+1)≤(B.length+1)*t := Nat.le_mul_of_pos_right _ ht
    obtain ⟨J,s,hJ,js,w⟩ := pack_active good.1 good.2.1 dis
      (fun z hz => disSF z (List.take_subset _ _ hz))
      (fun z hz => dom z (List.take_subset _ _ hz))
      (fun z lo hi => by simpa only [e,List.mem_append,or_assoc] using cover z lo hi)
      total ht (by dsimp [actualDemand]; omega) (by dsimp [actualDemand]; omega) (by omega)
    let pre := fun x : Model.Assignment L => Model.bits S x.val
    let suf := fun y : Model.Assignment R => Model.bits S y.val
    let read := fun x => (g.cut L.length (pre x) gate).encode
    let finish := fun (u : Fin (N+2)) y => g.eval (suf y) (Circuit.State.decode u)=true
    rw [←js]
    apply width w hJ read finish
    intro x y
    simp only [read,finish,pre,suf,Circuit.State.decode_encode,←g.factor]
    have cb : Model.bits S (x.val++y.val) =
      Circuit.join L.length (Model.bits S x.val) (Model.bits S y.val) := by
      simpa only [e] using Model.bits_cut dis x y
    rw [←cb]
    let a : Model.Assignment S := TwoRoot.paste dis (e ▸ List.Subset.refl _) x y
    change g.eval (Model.bits S a.val) gate=true ↔ _
    rw [correct,TwoRoot.universal_iff]
    simp only [onePrime,a,TwoRoot.paste,List.append_assoc]
  · have : t=0 := by omega
    simp [this]

theorem fixed_dag {S F B : List Nat} {n t N : Nat}
    (g : Circuit.DAG N) (gate : Circuit.State N)
    (nd : S.Nodup) (disSF : ∀ z∈S,z∉F)
    (dom : ∀ z∈S,1≤z ∧ z≤n)
    (cover : ∀ z,1≤z → z≤n → z∈S ∨ z∈B ∨ z∈F)
    (size : S.length+B.length+F.length=n)
    (pSmall : 100*F.length≤n) (kwSmall : 100*(B.length*(B.length+1))≤n)
    (budget : 512*((B.length+1)*t)≤n)
    (correct : ∀ x : Model.Assignment S,
      g.eval (Model.bits S x.val) gate=TwoRoot.universal B (F++x.val)) :
    2^t≤N+2 := by
  have ac := active_le B
  exact fixed_dag_active g gate nd disSF dom cover size pSmall (by omega) budget correct

/-- After the all-one assignment to the inner-left bank, the selected
right gate belongs to the original shared DAG. Its state count includes the
two terminals. There is no postulated packed set or decoder. -/
theorem hardware_active {B : List Nat} {n t : Nat} (g : Slice.Hardware n B)
    (correct : ∀ x y, g.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (pSmall : 100*g.A.length≤n)
    (badSmall : 100*((active B).length*(B.length+1))≤n)
    (budget : 512*((B.length+1)*t)≤n) : 2^t≤g.NS+2 := by
  let ones : Model.Assignment g.A := ⟨g.A,g.na,List.Subset.refl _⟩
  let gate := g.sRoot (g.dec.selectCase ones)
  have corr (y : Model.Assignment g.B) :
      g.gS.eval (Model.bits g.B y.val) gate=TwoRoot.universal B (g.A++y.val) := by
    rw [←g.sub_eq]
    simpa only [Circuit.Decision.run,ones] using correct ones y
  apply fixed_dag_active (t:=t) g.gS gate g.nb
    (fun z hz ha => g.dis z ha hz) (fun z hz => (g.domain z).mp (by simp [hz]))
    (fun z lo hi => by
      have h := (g.domain z).mpr ⟨lo,hi⟩
      simp only [List.mem_append] at h
      rcases h with (h|h)|h <;> simp [h])
    (by have := g.total; omega) pSmall badSmall budget corr

theorem hardware {B : List Nat} {n t : Nat} (g : Slice.Hardware n B)
    (correct : ∀ x y, g.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (pSmall : 100*g.A.length≤n) (kwSmall : 100*(B.length*(B.length+1))≤n)
    (budget : 512*((B.length+1)*t)≤n) : 2^t≤g.NS+2 := by
  have ac := active_le B
  exact hardware_active g correct pSmall (by omega) budget

/-- Concrete exponent, with no free choice of t. -/
theorem hardware_rate {B : List Nat} {n : Nat} (g : Slice.Hardware n B)
    (correct : ∀ x y, g.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (pSmall : 100*g.A.length≤n) (kwSmall : 100*(B.length*(B.length+1))≤n) :
    2^(n/(512*(B.length+1)))≤g.NS+2 := by
  apply hardware g correct pSmall kwSmall
  rw [←Nat.mul_assoc,Nat.mul_comm]
  exact Nat.div_mul_le_self .. 

/-- If B consists of low physical labels, its width costs only a linear
scalar budget, so this branch also applies to larger trailing words. -/
theorem hardware_initial_rate {B : List Nat} {n : Nat} (g : Slice.Hardware n B)
    (correct : ∀ x y, g.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (pSmall : 100*g.A.length≤n)
    (initial : ∀ z∈B,z≤B.length) : 2^(n/(512*(B.length+1)))≤g.NS+2 := by
  have empty : active B=[] := by
    apply List.eq_nil_iff_forall_not_mem.mpr
    intro z h
    obtain ⟨hz,lt⟩ := List.mem_filter.mp h
    have : B.length<z := by simpa using lt
    have := initial z hz
    omega
  apply hardware_active g correct pSmall (by simp [empty])
  rw [←Nat.mul_assoc,Nat.mul_comm]
  exact Nat.div_mul_le_self ..

#print axioms hardware_initial_rate
#print axioms fixed_dag
#print axioms hardware_rate
end HWB.SmallLeftOnes
