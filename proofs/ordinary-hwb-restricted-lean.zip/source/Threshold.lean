import NestedPoison
import HWB.PrimeBridge

namespace HWB.Threshold
open HWB.SmallRight HWB.NestedPoison

def sizeAt (counts : List Nat) (i : Nat) := counts[i]?.getD 0
def boxes (counts : List Nat) (zone : Nat → List Nat) := (List.range counts.length).flatMap zone

/-- Geometry alone. The groups may have different numbers of queried end markers.
The interval at a marker ends there; later length-(k+1) windows must each contain
an actual P label. Only different groups need disjoint zones. -/
structure Groups (L R Q B counts : List Nat) (s d : Nat) where
  deferRoom : d≤Q.length
  uniqueQ : Q.Nodup
  zone : Nat → List Nat
  mark : Nat → Nat → Nat
  positive : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → B.length<mark i a
  prefixMark : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → mark i a∈L
  ordered : ∀ i, i<counts.length → ∀ a b, a<b → b<sizeAt counts i → mark i a+d < mark i b
  disjoint : ∀ i, i<counts.length → ∀ l, l<counts.length → ∀ z, z∈zone i → z∈zone l → i=l
  contains : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → ∀ z,
    mark i a-B.length≤z → z≤mark i a+Q.length → z∈zone i
  core : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → ∀ z,
    mark i a-B.length+d≤z → z≤mark i a+d → z∈L++R ∨ z∈Q
  overlap : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i →
    (Q.filter (fun z => decide (z∈interval (mark i a-B.length+d) B.length))).length≤d
  guard : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → 0<d →
    ∃ z, mark i a+d<z ∧ z≤mark i a+B.length+1 ∧ z∈L++R
  post : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i → ∀ z,
    mark i a+d<z → z+B.length≤mark i a+Q.length →
    ∃ v, z≤v ∧ v≤z+B.length ∧ v∈L++R
  prefixOn : (boxes counts zone).length≤s
  prefixOff : s+(boxes counts zone).length≤L.length
  suffixRoom : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i →
    s≤mark i a-B.length ∧ Q.length+B.length+1≤mark i a-B.length-s ∧
    mark i a-B.length-s+(Q.length+B.length+1)≤R.length

private theorem splitSize (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun z => !(f z))).length = U.length := by
  induction U with
  | nil => simp
  | cons a U ih => cases e : f a <;> simp [e] <;> omega

private theorem fillBox (U box : List Nat) (s : Nat) (val : Nat → Bool) (hd : U.Nodup)
    (lo : box.length ≤ s) (hi : s+box.length ≤ U.length) :
    ∃ x : Assignment U, x.val.length = s ∧ ∀ z ∈ U, z∈box → (z∈x.val ↔ val z=true) := by
  let lock := fun z => decide (z∈box)
  have bound : (U.filter lock).length ≤ box.length := by
    apply List.Nodup.length_le_of_subset (List.Pairwise.filter _ hd)
    intro z hz
    simpa [lock] using (List.mem_filter.mp hz).2
  have low := Nat.le_trans (List.length_filter_le val (U.filter lock)) (Nat.le_trans bound lo)
  have high := splitSize U lock
  obtain ⟨x,hx,hv⟩ := fill U hd lock val s low (by omega)
  exact ⟨x,hx,fun z hz hm => hv z hz (by simp [lock,hm])⟩

private def appendSupport {L R : List Nat} (dis : ∀ z∈L, z∉R)
    (x : Assignment L) (y : Assignment R) : Assignment (L++R) :=
  ⟨x.val++y.val, List.nodup_append.mpr ⟨x.property.1,y.property.1,by
    intro a ha b hb eq; subst b; exact dis a (x.property.2 ha) (y.property.2 hb)⟩,
    fun z hz => (List.mem_append.mp hz).elim
      (fun ha => List.mem_append_left R (x.property.2 ha))
      (fun hb => List.mem_append_right L (y.property.2 hb))⟩

def Legal (counts : List Nat) (word : Nat → Nat) := ∀ i, i<counts.length → word i≤sizeAt counts i

/-- A single prefix assignment records every threshold. Each marker test has
one fixed suffix, independent of the word, with exact answer in the real zero row. -/
theorem decoder {L R Q B counts : List Nat} {s d : Nat} (g : Groups L R Q B counts s d)
    (ndL : L.Nodup) (ndR : R.Nodup) (dis : ∀ z∈L, z∉R) (ndB : B.Nodup)
    (pq : ∀ z∈L++R, z∉Q) (pb : ∀ z∈L++R, z∉B) :
    ∃ enc : (Nat → Nat) → Assignment L,
      ∃ probe : (i : Nat) → i<counts.length → (a : Nat) → a<sizeAt counts i → Assignment R,
      ∀ word, Legal counts word → ∀ i hi a ha,
          deadQ Q B ((enc word).val++(probe i hi a ha).val) ↔ word i≤a := by
  classical
  let val := fun (word : Nat→Nat) z => decide (∃ l<counts.length, z∈g.zone l ∧
    ∃ b<word l, z≤g.mark l b+d)
  have en (word : Nat→Nat) := fillBox L (boxes counts g.zone) s (val word) ndL g.prefixOn g.prefixOff
  let enc := fun word => Classical.choose (en word)
  let window := fun i a => interval (g.mark i a-B.length) (Q.length+B.length)
  have su (i) (hi : i<counts.length) (a) (ha : a<sizeAt counts i) :=
    fillBox R (window i a) (g.mark i a-B.length-s) (fun z => decide (z≤g.mark i a+d)) ndR
      (by simpa [window,interval] using (g.suffixRoom i hi a ha).2.1)
      (by simpa [window,interval] using (g.suffixRoom i hi a ha).2.2)
  let probe := fun i hi a ha => Classical.choose (su i hi a ha)
  refine ⟨enc,probe,?_⟩
  intro word legal i hi a ha
  let m := g.mark i a
  let j := m-B.length
  have dq := g.deferRoom
  let x := enc word
  let y := probe i hi a ha
  let p := appendSupport dis x y
  have e := Classical.choose_spec (en word)
  have f := Classical.choose_spec (su i hi a ha)
  have pos : B.length<m := g.positive i hi a ha
  have jmk : j+B.length=m := by dsimp [j]; omega
  have ps : p.val.length=j := by
    change (x.val++y.val).length=j
    rw [List.length_append,show x.val.length=s from e.1,show y.val.length=j-s from f.1]
    have : s≤j := (g.suffixRoom i hi a ha).1
    omega
  have xfix (z) (zl : z∈L) (fromJ : j≤z) (toQ : z≤m+Q.length) :
      z∈x.val ↔ ∃ b<word i, z≤g.mark i b+d :=  by
    have zg := g.contains i hi a ha z fromJ toQ
    have allz : z∈boxes counts g.zone := List.mem_flatMap.mpr ⟨i,List.mem_range.mpr hi,zg⟩
    rw [show x.val=(Classical.choose (en word)).val from rfl,e.2 z zl allz]
    simp only [val,decide_eq_true_eq]
    constructor
    · rintro ⟨l,hl,zm,v⟩
      have eq := g.disjoint i hi l hl z zg zm
      simpa [←eq] using v
    · exact fun h => ⟨i,hi,zg,h⟩
  have yfix (z) (zr : z∈R) (fromJ : j≤z) (toQ : z≤m+Q.length) :
      z∈y.val ↔ z≤m+d := by
    have zz : z∈window i a := mem_interval.mpr ⟨fromJ,by change z≤j+(Q.length+B.length); omega⟩
    simpa [y,probe,m] using f.2 z zr zz
  have absent (small : word i≤a) (z) (lo : m≤z) (top : z≤m+Q.length)
      (notV : z≤m+d → z∈L) : z∉p.val := by
    intro present
    rcases List.mem_append.mp present with hx|hy
    · obtain ⟨b,ltb,ge⟩ := (xfix z (x.property.2 hx) (by omega) top).mp hx
      have lt := g.ordered i hi b a (by omega) ha
      change g.mark i b+d<m at lt
      omega
    · have zr := y.property.2 hy
      have le := (yfix z zr (by omega) top).mp hy
      exact dis z (notV le) zr
  constructor
  · intro dead
    apply Classical.byContradiction
    intro notSmall
    have aa : a<word i := by omega
    let lock := fun z => decide (z∈interval (j+d) B.length)
    have lq : (Q.filter lock).length ≤ d := g.overlap i hi a ha
    have enQ := fill Q g.uniqueQ lock (fun _ => true) d (by simpa using lq)
      (by simpa using (show d≤(Q.filter lock).length+
        (Q.filter (fun z => !(lock z))).length by rw [splitSize]; exact dq))
    obtain ⟨q,ww,pins⟩ := enQ
    apply dead q
    intro b
    have bound := b.property.1.length_le_of_subset b.property.2
    let z := j+d+b.val.length
    have low : j+d≤z := by dsimp [z]; omega
    have high : z≤m+d := by dsimp [z]; omega
    have present : z∈p.val++q.val := by
      rcases g.core i hi a ha z low high with lp|qr
      · apply List.mem_append_left
        rcases List.mem_append.mp lp with zl|zr
        · exact List.mem_append_left _ ((xfix z zl (by omega) (by omega)).mpr ⟨a,aa,high⟩)
        · exact List.mem_append_right _ ((yfix z zr (by omega) (by omega)).mpr high)
      · apply List.mem_append_right
        apply (pins z qr ?_).mpr rfl
        apply decide_eq_true
        exact mem_interval.mpr ⟨low,by omega⟩
    change p.val.length+q.val.length+b.val.length∈p.val++q.val++b.val
    rw [ps,ww]
    exact List.mem_append_left _ present
  · intro small q
    have hq := q.property.1.length_le_of_subset q.property.2
    have marker : m∈L := g.prefixMark i hi a ha
    have ml : m∈L++R := List.mem_append_left _ marker
    change ¬ universalB B p.val q.val
    by_cases early : j+q.val.length≤m
    · exact poison_at ndB pq pb q.property.2 (z:=m) (by rw [ps]; omega)
        ⟨ml,absent small m (by omega) (by omega) (fun _ => marker)⟩
    · by_cases medium : j+q.val.length≤m+d
      · obtain ⟨z,low,high,left⟩ := g.guard i hi a ha (by omega)
        exact poison_at ndB pq pb q.property.2 (z:=z) (by rw [ps]; omega)
          ⟨left,absent small z (by omega) (by omega) (by intro hh; omega)⟩
      · obtain ⟨z,lo,high,left⟩ := g.post i hi a ha (j+q.val.length) (by omega) (by omega)
        exact poison_at ndB pq pb q.property.2 (z:=z) (by rw [ps]; omega)
          ⟨left,absent small z (by omega) (by omega) (by intro he; omega)⟩


/-- Number of independent thresholds, including the choice preceding
the first marker in every group. -/
def alphabet (counts : List Nat) : Nat := (counts.map (·+1)).prod

@[simp] theorem alphabet_replicate (G T : Nat) : alphabet (List.replicate G T)=(T+1)^G := by
  induction G with
  | zero => rfl
  | succ g ih =>
    rw [List.replicate_succ, Nat.pow_succ, ←ih]
    simp [alphabet,Nat.mul_comm]

theorem sizeAt_replicate {G i T : Nat} (hi : i<G) :
    sizeAt (List.replicate G T) i=T := by simp [sizeAt,hi]

private def digit : List Nat → Nat → Nat → Nat
  | [], _, _ => 0
  | r::_, x, 0 => x%(r+1)
  | r::rs, x, i+1 => digit rs (x/(r+1)) i

private theorem digits_legal (counts : List Nat) (x : Nat) : Legal counts (digit counts x) := by
  induction counts generalizing x with
  | nil => intro i hi; simp at hi
  | cons r rs ih =>
    intro i hi
    cases i with
    | zero => simpa [digit,sizeAt] using Nat.le_of_lt_succ (Nat.mod_lt x (Nat.zero_lt_succ r))
    | succ i => simpa [digit,sizeAt] using ih (x/(r+1)) i (by simpa using hi)

private theorem digits_unique (counts : List Nat) {x y : Nat} (hx : x<alphabet counts)
    (hy : y<alphabet counts) (eq : ∀ i, i<counts.length → digit counts x i=digit counts y i) :
    x=y := by
  induction counts generalizing x y with
  | nil => simp [alphabet] at hx hy; omega
  | cons r rs ih =>
    have low := eq 0 (by simp)
    change x%(r+1)=y%(r+1) at low
    have bound : alphabet (r::rs)=alphabet rs*(r+1) := by simp [alphabet,Nat.mul_comm]
    rw [bound] at hx hy
    have high := ih ((Nat.div_lt_iff_lt_mul (Nat.zero_lt_succ r)).mpr hx)
      ((Nat.div_lt_iff_lt_mul (Nat.zero_lt_succ r)).mpr hy)
      (fun i hi => eq (i+1) (by simpa using hi))
    calc x = x%(r+1)+(r+1)*(x/(r+1)) := (Nat.mod_add_div ..).symm
         _ = y%(r+1)+(r+1)*(y/(r+1)) := by rw [low,high]
         _ = y := Nat.mod_add_div ..

private theorem code_unique {counts : List Nat} {u v : Fin (alphabet counts)}
    (observed : ∀ i, i<counts.length → ∀ a, a<sizeAt counts i →
      (digit counts u.val i≤a ↔ digit counts v.val i≤a)) : u=v := by
  apply Fin.ext
  apply digits_unique counts u.isLt v.isLt
  intro i hi
  have h1 := digits_legal counts u.val i hi
  have h2 := digits_legal counts v.val i hi
  apply Classical.byContradiction
  intro hn
  rcases Nat.lt_or_gt_of_ne hn with less|greater
  · have eq := observed i hi (digit counts u.val i) (by omega)
    omega
  · have eq := observed i hi (digit counts v.val i) (by omega)
    omega

/-- The number of distinct semantic residuals is at least the product of
the group alphabet sizes. No circuit representation is assumed here. -/
theorem residuals {L R Q B counts : List Nat} {s d : Nat} (g : Groups L R Q B counts s d)
    (ndL : L.Nodup) (ndR : R.Nodup) (dis : ∀ z∈L, z∉R) (ndB : B.Nodup)
    (pq : ∀ z∈L++R, z∉Q) (pb : ∀ z∈L++R, z∉B) :
    ∃ pre : Fin (alphabet counts) → Assignment L, Function.Injective
      (fun c => fun y : Assignment R => deadQ Q B ((pre c).val++y.val)) := by
  obtain ⟨enc,probe,reads⟩ := decoder g ndL ndR dis ndB pq pb
  refine ⟨fun c => enc (digit counts c.val),?_⟩
  intro u v eq
  apply code_unique
  intro i hi a ha
  exact (reads _ (digits_legal _ _) i hi a ha).symm.trans
    ((Iff.of_eq (congrFun eq (probe i hi a ha))).trans (reads _ (digits_legal _ _) i hi a ha))

/-- Every shared OBDD gate for the actual nested zero row has at least this
many reachable cut states (including its two possible terminals). -/
theorem dag_width {L R Q B counts order : List Nat} {s d N : Nat} (order_eq : order=L++R)
    (g : Groups L R Q B counts s d)
    (ndL : L.Nodup) (ndR : R.Nodup) (dis : ∀ z∈L, z∉R) (ndB : B.Nodup)
    (pq : ∀ z∈L++R, z∉Q) (pb : ∀ z∈L++R, z∉B)
    (dag : Circuit.DAG N) (gate : Circuit.State N)
    (computes : ∀ x : Model.Assignment order, dag.eval (Model.bits order x.val) gate=true ↔
      deadQ Q B x.val) : alphabet counts ≤ N+2 := by
  subst order
  obtain ⟨pre,inj⟩ := residuals g ndL ndR dis ndB pq pb
  let read := fun c => (dag.cut L.length (Model.bits (L++R) (pre c).val) gate).encode
  apply Circuit.fin_injection_bound read
  intro u v eq
  apply inj
  funext y
  apply propext
  let test := fun (c : Fin (alphabet counts)) =>
    dag.eval (Model.bits (L++R) y.val) (Circuit.State.decode (read c))=true
  have check (c) : test c ↔ deadQ Q B ((pre c).val++y.val) := by
    simp only [test,read,Circuit.State.decode_encode,←dag.factor,←Model.bits_cut dis]
    exact computes (appendSupport dis _ _)
  exact (check u).symm.trans ((Iff.of_eq (congrArg
    (fun st => dag.eval (Model.bits (L++R) y.val) (Circuit.State.decode st)=true) eq)).trans (check v))

end HWB.Threshold
