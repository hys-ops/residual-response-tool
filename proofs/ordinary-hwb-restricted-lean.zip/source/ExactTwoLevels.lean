import ExactModel
import UniformGeometry
import Dyadic
import LargeRightScale

namespace HWB.Exact
open HWB.Model HWB.Slice HWB.TwoRoot

/-- End-to-end lower bound for ordinary HWB in the two-adjacent-split model.
n and W are the number of original Boolean inputs and a physical resource
budget. Select any integral t at the cube-root-log scale indicated below. -/
theorem exact_two_level_lower {n W t : Nat} (c : Certificate n W)
    (large : 2^1024≤n) (target : ((2^60)*t)^3≤n*n.log2^2) : 2^t≤W+2 := by
  by_cases tp : 0<t
  · have big : 2^128≤n := Nat.le_trans (Nat.pow_le_pow_right (by decide) (by decide)) large
    have sq := scale_square big (t:=t) target
    apply combine c tp big target
    · intro B g nd corr smallB smallQ
      let m:=g.A.length/2
      let L:=g.A.take m
      let R:=g.A.drop m
      have cut : g.A=L++R := (List.take_append_drop m g.A).symm
      have mid : L.length≤R.length ∧ R.length≤L.length+1 := by simp [L,R,m];omega
      have mar := margins tp smallB sq
      have z := HWB.CandidateGeometry.uniform_tiny_right g nd corr cut mid
        (Nat.le_trans (Nat.pow_le_pow_right (by decide) (by decide)) large) mar.2.2.2 smallQ
      have cap : B.length+1≤8*(factor*t) := by unfold factor; omega
      have pow : g.B.length^2≤n*(B.length+1) := by rw [Nat.pow_two];omega
      have z' := HWB.Dyadic.tiny_hardware (q:=g.B.length) (A:=factor*t)
        large target (Nat.succ_pos _) cap pow
      let ell:=max 8192 (g.B.length+B.length+2)
      let d:=64*g.B.length*(B.length+1)/n
      change (max 1 (ell/(64*(d+1)))+1)^(n/(16384*ell))≤g.NP+2 at z
      change 2^(factor*t/2^30)≤(1+max 1 (ell/(64*(d+1))))^(n/(16384*ell)) at z'
      rw [Nat.add_comm 1] at z'
      have ee : t≤factor*t/2^30 := by unfold factor;omega
      exact Nat.le_trans (Nat.pow_le_pow_right (by decide) ee) (Nat.le_trans z' z)
    · intro k p q hk hp hq
      have dense : n≤128*p := by omega
      obtain ⟨r,r0,r1,r2,r3,r4,r5⟩ := HWB.DensePacking.large_q
        (w:=k+1) (q:=q) large tp (Nat.succ_pos _) (by omega) target sq dense (Nat.le_of_lt hq)
      refine ⟨r,r0,r1,r2,r3,dense,?_,r5⟩
      simpa only [Nat.add_sub_cancel,Nat.mul_add,Nat.mul_one,Nat.add_assoc] using r4
  · have h : t=0 := by omega
    simp [h]

/-- An explicit nonzero witness of the claimed order exists for every n
in the asymptotic range, without additional assumptions on its value. -/
theorem all_large_n {n W : Nat} (c : Certificate n W) (large : 2^1024≤n) :
    ∃ t : Nat, 0<t ∧ n*n.log2^2 ≤ 2^191*t^3 ∧ 2^t≤W+2 := by
  obtain ⟨hp,lo,hi⟩ := HWB.Dyadic.witness_bounds large
  exact ⟨HWB.Dyadic.witness n, hp, hi, exact_two_level_lower c large lo⟩

#check all_large_n
#print axioms all_large_n
#check exact_two_level_lower
#print axioms exact_two_level_lower
end HWB.Exact
