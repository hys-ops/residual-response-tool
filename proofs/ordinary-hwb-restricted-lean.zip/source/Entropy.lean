import Std

/-! Integer, floor-safe alphabet and entropy bounds. All arithmetic is over `Nat`. -/
namespace HWB.DensePacking

/-- A square bound on exclusion distance turns a threshold count into polynomial alphabet size. -/
theorem alphabet_square_bound {ell d C b : Nat} (pos : 0 < ell) (distance : d*d ≤ ell)
    (capacity : ell ≤ C*(d+1)*b) : ell ≤ (4*(C*C))*(b*b) := by
  have shift : (d+1)*(d+1) ≤ 4*ell := by
    cases d with
    | zero => simp at *; omega
    | succ e =>
      have h : (e+1)+1 ≤ 2*(e+1) := by omega
      calc
        _ ≤ (2*(e+1))*(2*(e+1)) := Nat.mul_le_mul h h
        _ = 4*((e+1)*(e+1)) := by simp only [Nat.mul_assoc, Nat.mul_comm, Nat.mul_left_comm]
        _ ≤ _ := Nat.mul_le_mul_left 4 distance
  apply Nat.le_of_mul_le_mul_right (c := ell) _ pos
  calc
    ell*ell ≤ (C*(d+1)*b)*(C*(d+1)*b) := Nat.mul_le_mul capacity capacity
    _ = (C*C*(b*b))*((d+1)*(d+1)) := by ac_rfl
    _ ≤ (C*C*(b*b))*(4*ell) := Nat.mul_le_mul_left _ shift
    _ = _ := by ac_rfl

/-- When `C ≤ 2^v`, a nontrivial alphabet of size `b` gives `ell ≤ b^(2v+4)`. -/
theorem alphabet_exponent {ell d C v b : Nat} (pos : 0 < ell) (distance : d*d ≤ ell)
    (cost : C ≤ 2^v) (nontrivial : 2 ≤ b) (capacity : ell ≤ C*(d+1)*b) :
    ell ≤ b^(2*v+4) := by
  have hc : C ≤ b^v := Nat.le_trans cost (Nat.pow_le_pow_left nontrivial v)
  have four : 4 ≤ b^2 := Nat.pow_le_pow_left nontrivial 2
  calc
    ell ≤ (4*(C*C))*(b*b) := alphabet_square_bound pos distance capacity
    _ ≤ (b^2*(b^v*b^v))*(b*b) := Nat.mul_le_mul_right _ (Nat.mul_le_mul four (Nat.mul_le_mul hc hc))
    _ = b^(2*v+4) := by
      rw [← Nat.pow_two b, ← Nat.pow_add, ← Nat.pow_add, ← Nat.pow_add]
      congr 1 <;> omega

/-- The group alphabet includes the all-off symbol and at least one actual marker.
The floor may be zero; `max 1` is essential in that case. -/
theorem floor_alphabet_exponent {ell d C v : Nat} (pos : 0 < ell) (distance : d*d ≤ ell)
    (costpos : 0 < C) (cost : C ≤ 2^v) :
    ell ≤ (1 + max 1 (ell / (C*(d+1))))^(2*v+4) := by
  have pp : 0 < C*(d+1) := Nat.mul_pos costpos (Nat.zero_lt_succ _)
  have bound : ell / (C*(d+1)) < 1 + max 1 (ell / (C*(d+1))) := by omega
  have cap := Nat.lt_mul_of_div_lt bound pp
  exact alphabet_exponent pos distance cost (by omega) (by rw [Nat.mul_comm]; omega)

/-- No real logarithms or estimates of floor rounding are needed for dyadic counting. -/
theorem entropy_bits {ell b p : Nat} (pos : 0 < ell) (precision : 0 < p)
    (control : ell ≤ b^p) (G : Nat) : 2^(ell.log2*G/p) ≤ b^G := by
  have h₀ : 2^ell.log2 ≤ b^p := Nat.le_trans (Nat.log2_self_le (by omega)) control
  have h₁ : 2^(ell.log2*G) ≤ (b^G)^p := by
    calc
      _ = (2^ell.log2)^G := Nat.pow_mul ..
      _ ≤ (b^p)^G := Nat.pow_le_pow_left h₀ G
      _ = _ := by rw [← Nat.pow_mul, ← Nat.pow_mul, Nat.mul_comm p G]
  apply Nat.le_of_not_gt
  intro h
  have h₂ := Nat.pow_lt_pow_left h (by omega : p ≠ 0)
  rw [← Nat.pow_mul (a := 2)] at h₂
  have h₃ := Nat.pow_le_pow_right (by decide : 0 < 2) (Nat.div_mul_le_self (ell.log2*G) p)
  omega

/-- Explicit constant 16 for the per-cell cost 64 of the finite manuscript. -/
theorem paper_entropy (ell d G : Nat) (pos : 0 < ell) (distance : d*d ≤ ell) :
    2^(ell.log2*G/16) ≤ (1 + max 1 (ell / (64*(d+1))))^G := by
  exact entropy_bits pos (by decide) (floor_alphabet_exponent (v := 6) pos distance (by decide) (by decide)) G

end HWB.DensePacking
