import CandidateGeometry
import FiniteBudget
import Entropy

/-! Uniform tiny-right estimates for all list partitions, with a fixed absolute
large-n threshold. Coordinates are never resized or assumed to be in read order. -/
namespace HWB.CandidateGeometry

private theorem floor_multiple (n D r : Nat) (p : 0 < D*r) :
    D * ((n/(D*r))*r) ≤ n ∧ n < D * ((n/(D*r))*r) + D*r := by
  have a := Nat.div_mul_le_self n (D*r)
  have b := Nat.mod_add_div n (D*r)
  have c := Nat.mod_lt n p
  have e : n/(D*r)*(D*r) = D*(n/(D*r)*r) := by ac_rfl
  have e' : D*r*(n/(D*r)) = D*(n/(D*r)*r) := by ac_rfl
  omega

private theorem division_budgets {n k q:Nat} (large:2^26≤n)
    (outer:4096*((k+1)*(k+1))≤n) (inner:65536*(q*q)≤n*(k+1)) :
    let w:=k+1; let d:=64*q*w/n; let h:=q+k; let v:=(w+3)/4; let l:=(w+1)/2
    0<v ∧ 2*v≤l+1 ∧ d+l≤w ∧ d≤q ∧
    32*(h/v*(h+2))≤n ∧ 64*(q*w/(d+1))≤n ∧ 4096*(k*w)≤n := by
  dsimp only
  let w:=k+1
  let d:=64*q*w/n
  let h:=q+k
  let v:=(w+3)/4
  let l:=(w+1)/2
  have np : 0<n := by omega
  have wp : 0<w := by dsimp [w]; omega
  obtain ⟨wb,qb,eb⟩ := DensePacking.finite_margins (by omega) outer inner
  have wo : 64*w≤n := by dsimp [w]; omega
  have qo : 128*q≤n := by omega
  have dn : d*n≤64*q*w := Nat.div_mul_le_self _ _
  have dq : d≤q := by
    apply Nat.le_of_mul_le_mul_right (c:=n) _ np
    calc d*n ≤ 64*q*w := dn
         _ = q*(64*w) := by ac_rfl
         _ ≤ _ := Nat.mul_le_mul_left _ wo
  have dw : 2*d≤w := by
    apply Nat.le_of_mul_le_mul_right (c:=n) _ np
    calc (2*d)*n = 2*(d*n) := by ac_rfl
         _ ≤ 2*(64*q*w) := Nat.mul_le_mul_left _ dn
         _ = (128*q)*w := by change _ = ((2*64)*q)*w; ac_rfl
         _ ≤ n*w := Nat.mul_le_mul_right _ qo
         _ = _ := Nat.mul_comm .. 
  have vp : 0<v := by dsimp [v]; omega
  have v4 : w≤4*v := by dsimp [v]; omega
  have run := DensePacking.long_run_budget (by omega) wp outer inner
  change 128*((w-1+q)*w+2*(w-1+q)*(w-1+q+1))<n*w at run
  have idh : w-1+q=h := by dsimp [w,h]; omega
  rw [idh] at run
  have hh : h*(h+2)≤2*(h*(h+1)) := by
    calc _ ≤ h*(2*(h+1)) := Nat.mul_le_mul_left h (by omega)
         _ = _ := by ac_rfl
  have long : 32*(h/v*(h+2))≤n := by
    apply Nat.le_of_mul_le_mul_right (c:=w) _ wp
    calc (32*(h/v*(h+2)))*w ≤ (32*(h/v*(h+2)))*(4*v) := Nat.mul_le_mul_left _ v4
         _ = 128*((h/v*v)*(h+2)) := by change _ = (32*4)*_; ac_rfl
         _ ≤ 128*(h*(h+2)) := Nat.mul_le_mul_left _ (Nat.mul_le_mul_right _ (Nat.div_mul_le_self _ _))
         _ ≤ 128*(2*(h*(h+1))) := Nat.mul_le_mul_left _ hh
         _ ≤ _ := by rw [Nat.mul_assoc 2 h (h+1)] at run; omega
  have qbudget : 64*(q*w/(d+1))≤n := by
    have hdn := Nat.lt_mul_of_div_lt (show 64*q*w/n<d+1 by change d<d+1;omega) np
    apply Nat.le_of_mul_le_mul_right (c:=d+1) _ (Nat.succ_pos _)
    calc 64*(q*w/(d+1))*(d+1) = 64*((q*w/(d+1))*(d+1)) := by ac_rfl
         _ ≤ 64*(q*w) := Nat.mul_le_mul_left _ (Nat.div_mul_le_self _ _)
         _ = 64*q*w := by ac_rfl
         _ ≤ _ := by rw [Nat.mul_comm n (d+1)]; omega
  have kbudget := Nat.le_trans (Nat.mul_le_mul_left 4096 (Nat.mul_le_mul_right w (Nat.le_succ k))) outer
  change 0<v ∧ 2*v≤l+1 ∧ d+l≤w ∧ d≤q ∧ _
  exact ⟨vp,by dsimp [v,l]; omega,by dsimp [l]; omega,dq,long,qbudget,kbudget⟩

private theorem alphabet_load {ell d : Nat} (eBig : 8192 ≤ ell) (sq : d*d≤ell) :
    (d+1)*max 1 (ell/(64*(d+1))) ≤ ell/32 := by
  have small : 32*(d+1)≤ell := by
    by_cases h:64≤d
    · have a:=Nat.mul_le_mul_right d h; omega
    · omega
  have floor := Nat.div_mul_le_self ell (64*(d+1))
  have eq : (ell/(64*(d+1)))*(64*(d+1))=64*((d+1)*(ell/(64*(d+1)))) := by ac_rfl
  cases Nat.le_total 1 (ell/(64*(d+1))) with
  | inl h => rw [Nat.max_eq_right h]; omega
  | inr h => rw [Nat.max_eq_left h,Nat.mul_one]; omega

private theorem side_margins {n k h L R W A:Nat} (big:2^26≤n) (loK:k≤h+1)
    (hh:1024*(h+2)≤n) (hW:64*W≤n) (hA:16384*A≤n)
    (total:L+R+h=n) (balanced:L≤R ∧ R≤L+1) :
    3*A ≤ (n/8-k)/2 ∧ (n/8+48*W-k)/2+3*A≤L ∧
      h+1≤(n/8-k)/2 ∧ (n/8+48*W-k)/2+W+1+(h+1)≤R := by
  constructor
  · omega
  constructor
  · omega
  constructor <;> omega

/-- Main uniform lower bound for an arbitrary balanced read-order cut of any
compressed decision computing the universal outer response. No piece of
geometric data or secondary numerical allocation budget is assumed. -/
theorem uniform_tiny_right {B L R : List Nat} {n:Nat} (hw:Slice.Hardware n B) (ndB:B.Nodup)
    (correct:∀ x y,hw.dec.run x y=TwoRoot.universal B (x.val++y.val)) (cut:hw.A=L++R)
    (balanced:L.length≤R.length ∧ R.length≤L.length+1)
    (large:2^26≤n) (outer:4096*((B.length+1)*(B.length+1))≤n)
    (inner:65536*(hw.B.length*hw.B.length)≤n*(B.length+1)) :
    let w:=B.length+1; let d:=64*hw.B.length*w/n
    let ell:=max 8192 (hw.B.length+B.length+2)
    (max 1 (ell/(64*(d+1)))+1)^(n/(16384*ell)) ≤ hw.NP+2 := by
  let k:=B.length
  let q:=hw.B.length
  let w:=k+1
  let d:=64*q*w/n
  let h:= q+k
  let v:=(w+3)/4
  let l:=(w+1)/2
  let ell:=max 8192 (h+2)
  let M:= n/(64*ell)
  let G:= n/(16384*ell)
  let T:=max 1 (ell/(64*(d+1)))
  let lo:=n/8
  have np : 0<n := by omega
  have tot:=hw.total
  rw [cut,List.length_append] at tot
  change L.length+R.length+q+k=n at tot
  change 4096*(w*w)≤n at outer
  change 65536*(q*q)≤n*w at inner
  have bounds := division_budgets (k:=k) (q:=q) large outer inner
  change 0<v ∧ 2*v≤l+1 ∧ d+l≤w ∧ d≤q ∧ 32*(h/v*(h+2))≤n ∧ 64*(q*w/(d+1))≤n ∧ 4096*(k*w)≤n at bounds
  obtain ⟨vp,va,dm,dq,run,exc,bcont⟩ :=bounds
  have ⟨wb,qb,hb⟩ := DensePacking.finite_margins (by omega) outer inner
  have hid : w-1+q+2=h+2 := by dsimp [w,h]; omega
  rw [hid] at hb
  have elarge : 8192≤ell := Nat.le_max_left _ _
  have hle : h+2≤ell := Nat.le_max_right _ _
  have eb : 1024*ell≤n := by
    rcases Nat.le_total 8192 (h+2) with he|he
    · rw [show ell=h+2 from Nat.max_eq_right he]; exact hb
    · rw [show ell=8192 from Nat.max_eq_left he]; omega
  have ep : 0<ell := by omega
  obtain ⟨wm,wm'⟩ := floor_multiple n 64 ell (by omega)
  change 64*(M*ell)≤n at wm
  change n<64*(M*ell)+64*ell at wm'
  have mp : 0<M := by dsimp [M]; exact (Nat.div_pos (by omega) (by omega))
  obtain ⟨gg,_⟩ := floor_multiple n 16384 ell (by omega)
  change 16384*(G*ell)≤n at gg
  have dsq : d*d≤q := DensePacking.exceptional_distance np (by omega) outer
  have dsq' : d*d≤ell := by dsimp [h] at hle; omega
  have a := alphabet_load elarge dsq'
  change (d+1)*T≤ell/32 at a
  have af : 32*((d+1)*T)≤ell := by omega
  have mb := Nat.mul_le_mul_left M af
  have eqM : M*(32*((d+1)*T))=32*(M*((d+1)*T)) := by ac_rfl
  rw [eqM] at mb
  have eqG : 4*G*ell = 4*(G*ell) := Nat.mul_assoc ..
  have eqF : G*(3*ell) = 3*(G*ell) := by ac_rfl
  have dual : L.length≤R.length ∧ R.length≤L.length+1 := balanced
  have bmax : k+1 ≤ h+2 ∧ q ≤ h+2 := by dsimp [h]; omega
  have totalH : L.length+R.length+h=n := by dsimp [h]; omega
  obtain ⟨roomA,roomB,roomC,roomD⟩ := side_margins (k:=k) large (by dsimp[h];omega) hb wm gg totalH balanced
  change (T+1)^G≤hw.NP+2
  apply raw_hardware (lo:=lo) (d:=d) (v:=v) (l:=l) (ell:=ell) (M:=M) (bins:=48) (G:=G) (T:=T)
    hw ndB correct cut dq vp va dm ep mp (by decide) (by change k≤ell; omega) (by change q≤ell; omega)
  · change k < n/8; omega
  · change n/8+48*(M*ell)+h≤n; omega
  · change 48*need ell M d G T+loss k q d v+lo+(n+1-(lo+48*(M*ell)))≤L.length
    unfold need loss
    change 48*(4*G*ell+M*((d+1)*T))+(k*w+q*w/(d+1)+h/v*(h+2))+n/8+(n+1-(n/8+48*(M*ell)))≤ L.length
    rw [eqG]
    have hz : q+k=h := rfl
    omega
  · change G*(3*ell)≤(n/8-k)/2; rw [eqF]; exact roomA
  · change (n/8+48*(M*ell)-k)/2+G*(3*ell)≤L.length; rw [eqF]; exact roomB
  · exact roomC
  · exact roomD

/-- Explicit dyadic entropy bound. The adaptive probe budget has been eliminated
from the conclusion. -/
theorem uniform_tiny_right_entropy {B L R : List Nat} {n:Nat} (hw:Slice.Hardware n B) (ndB:B.Nodup)
    (correct:∀ x y,hw.dec.run x y=TwoRoot.universal B (x.val++y.val)) (cut:hw.A=L++R)
    (balanced:L.length≤R.length ∧ R.length≤L.length+1)
    (large:2^26≤n) (outer:4096*((B.length+1)*(B.length+1))≤n)
    (inner:65536*(hw.B.length*hw.B.length)≤n*(B.length+1)) :
    let ell:=max 8192 (hw.B.length+B.length+2)
    2^(ell.log2*(n/(16384*ell))/16) ≤ hw.NP+2 := by
  let ell:=max 8192 (hw.B.length+B.length+2)
  let d:=64*hw.B.length*(B.length+1)/n
  let G:=n/(16384*ell)
  have raw := uniform_tiny_right hw ndB correct cut balanced large outer inner
  have hq : hw.B.length≤n := by have := hw.total; omega
  have hd : d*d≤hw.B.length := DensePacking.exceptional_distance (by omega) hq outer
  have elarge : 8192≤ell := Nat.le_max_left _ _
  have hs := DensePacking.paper_entropy ell d G (by omega)
    (Nat.le_trans hd (Nat.le_trans (by omega) (Nat.le_max_right 8192 (hw.B.length+B.length+2))))
  apply Nat.le_trans hs
  change (1+max 1 (ell/(64*(d+1))))^G ≤ _
  rw [Nat.add_comm 1]
  exact raw

/-- A version depending on q+w with an absolute denominator. -/
theorem uniform_tiny_right_bits {B L R : List Nat} {n:Nat} (hw:Slice.Hardware n B) (ndB:B.Nodup)
    (correct:∀ x y,hw.dec.run x y=TwoRoot.universal B (x.val++y.val)) (cut:hw.A=L++R)
    (balanced:L.length≤R.length ∧ R.length≤L.length+1)
    (large:2^26≤n) (outer:4096*((B.length+1)*(B.length+1))≤n)
    (inner:65536*(hw.B.length*hw.B.length)≤n*(B.length+1)) :
    let x:=hw.B.length+B.length+1
    2^((x+1).log2 * (n/(2^27*x))/16) ≤ hw.NP+2 := by
  let x:=hw.B.length+B.length+1
  let ell:=max 8192 (x+1)
  have xp : 0<x := Nat.succ_pos _
  have ex : ell≤8192*x := by
    apply Nat.max_le.mpr
    exact ⟨by omega,by omega⟩
  have el : x+1≤ell := Nat.le_max_right _ _
  have ep : ell≠0 := by omega
  have logs : (x+1).log2≤ell.log2 := (Nat.le_log2 ep).2 (Nat.le_trans (Nat.log2_self_le (Nat.succ_ne_zero x)) el)
  have den : 16384*ell ≤ (2^27)*x := by
    have a := Nat.mul_le_mul_left 16384 ex
    simpa only [← Nat.mul_assoc] using a
  have G := Nat.div_le_div_left (a:=n) den (Nat.mul_pos (by decide) (by omega))
  have small := Nat.div_le_div_right (c:=16) (Nat.mul_le_mul logs G)
  have big := uniform_tiny_right_entropy hw ndB correct cut balanced large outer inner
  apply Nat.le_trans (Nat.pow_le_pow_right (by decide : 0<2) small)
  exact big

#print axioms uniform_tiny_right
#print axioms uniform_tiny_right_entropy
#print axioms uniform_tiny_right_bits
end HWB.CandidateGeometry
