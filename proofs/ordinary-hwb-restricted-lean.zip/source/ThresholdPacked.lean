import ThresholdHardware
import DensePacking

namespace HWB.Threshold

/-- Local tests on each candidate endpoint before dense cells are chosen.
Only the original label banks and the fixed target prefix weight occur here. -/
structure Candidate (L R Q B : List Nat) (s d m : Nat) : Prop where
  positive : B.length<m
  prefixMark : m∈L
  covered : ∀ z, m-B.length+d≤z → z≤m+d → z∈L++R ∨ z∈Q
  overlap : (Q.filter (fun z => decide (z∈SmallRight.interval (m-B.length+d) B.length))).length≤d
  sentinel : 0<d → ∃ z, m+d<z ∧ z≤m+B.length+1 ∧ z∈L++R
  post : ∀ z, m+d<z → z+B.length≤m+Q.length → ∃ v, z≤v ∧ v≤z+B.length ∧ v∈L++R
  suffixRoom : s≤m-B.length ∧ Q.length+B.length+1≤m-B.length-s ∧
    m-B.length-s+(Q.length+B.length+1)≤R.length

private def extendFin {n : Nat} (f : Fin n → α) (default : α) (i : Nat) :=
  if hi : i<n then f ⟨i,hi⟩ else default

private theorem extendFin_in {n : Nat} (f : Fin n → α) (default : α) (i : Nat) (hi : i<n) :
    extendFin f default i=f ⟨i,hi⟩ := by simp [extendFin,hi]

/-- The cell-packing theorem supplies every group, marker index, separation
and extended zone needed for the threshold theorem. The finite set of good
endpoints is the input; no groups or probe assignments are required. -/
theorem groups_of_candidates {L R Q B xs : List Nat} {s d base ell M G T : Nat}
    (ndQ : Q.Nodup) (dq : d≤Q.length) (good : ∀ m∈xs, Candidate L R Q B s d m)
    (distinct : xs.Nodup) (epos : 0<ell) (kcell : B.length≤ell) (qcell : Q.length≤ell)
    (span : ∀ m∈xs, base≤m ∧ m<base+M*ell)
    (load : (4*G)*ell+M*((d+1)*T)≤xs.length)
    (on : G*(3*ell)≤s) (off : s+G*(3*ell)≤L.length) :
    Nonempty (Groups L R Q B (List.replicate G T) s d) := by
  obtain ⟨c⟩ := DensePacking.pack xs base ell M d G T distinct epos span load
  let counts := List.replicate G T
  have ng : counts.length=G := List.length_replicate
  have ct (i) (hi : i<counts.length) : sizeAt counts i=T := sizeAt_replicate (ng ▸ hi)
  let zn := extendFin c.zone []
  let mk := fun i a => extendFin (fun u => extendFin (c.mark u) 0 a) 0 i
  have zone (i) (hi : i<counts.length) : zn i=c.zone ⟨i,ng ▸ hi⟩ := extendFin_in .. 
  have mark (i) (hi : i<counts.length) (a) (ha : a<sizeAt counts i) :
      mk i a=c.mark ⟨i,ng ▸ hi⟩ ⟨a,(ct i hi) ▸ ha⟩ := by
    dsimp only [mk]
    rw [extendFin_in _ _ _ (ng ▸ hi),extendFin_in _ _ _ ((ct i hi) ▸ ha)]
  have site (i) (hi : i<counts.length) (a) (ha : a<sizeAt counts i) :
      Candidate L R Q B s d (mk i a) := by
    rw [mark i hi a ha]
    exact good _ (c.mark_in_slab _ _).1
  have zbound : (boxes counts zn).length ≤ G*(3*ell) := by
    have aux (idx : List Nat) (held : ∀ i∈idx, i<counts.length) :
        (idx.flatMap zn).length ≤ idx.length*(3*ell) := by
      induction idx with
      | nil => simp
      | cons i idx ih =>
        have zsize : (zn i).length≤3*ell := (zone i (held i (by simp))) ▸ c.zone_size _
        have tail := ih (fun a ha => held a (by simp [ha]))
        simpa [List.flatMap_cons,Nat.succ_mul,Nat.add_comm] using Nat.add_le_add zsize tail
    exact (by simpa [boxes,ng] using aux (List.range counts.length) (fun i hi => List.mem_range.mp hi))
  refine ⟨{
    deferRoom := dq
    uniqueQ := ndQ
    zone := zn
    mark := mk
    positive := fun i hi a ha => (site i hi a ha).positive
    prefixMark := fun i hi a ha => (site i hi a ha).prefixMark
    ordered := ?_
    disjoint := ?_
    contains := ?_
    core := fun i hi a ha => (site i hi a ha).covered
    overlap := fun i hi a ha => (site i hi a ha).overlap
    guard := fun i hi a ha => (site i hi a ha).sentinel
    post := fun i hi a ha => (site i hi a ha).post
    prefixOn := Nat.le_trans zbound on
    prefixOff := Nat.le_trans (Nat.add_le_add_left zbound s) off
    suffixRoom := fun i hi a ha => (site i hi a ha).suffixRoom }⟩
  · intro i hi a b ab hb
    rw [mark i hi a (Nat.lt_trans ab hb),mark i hi b hb]
    exact c.ordered _ ab
  · intro i hi j hj z zi zj
    rw [zone i hi] at zi
    rw [zone j hj] at zj
    exact congrArg Fin.val (c.zone_separate epos _ zi zj)
  · intro i hi a ha z lo top
    rw [zone i hi]
    rw [mark i hi a ha] at lo top
    exact c.covers_marker_window _ _ _ _ kcell qcell lo top

/-- Uniform-alphabet lower bound on the ordered bank of the actual decision
for the universal outer response. In particular the zero-row gate need not be
given. The geometric and numeric conditions apply before grouping. -/
theorem dense_hardware {B L R xs : List Nat} {n s d base ell M G T : Nat}
    (hw : Slice.Hardware n B) (ndB : B.Nodup)
    (correct : ∀ x y, hw.dec.run x y=TwoRoot.universal B (x.val++y.val))
    (cut : hw.A=L++R)
    (dq : d≤hw.B.length) (good : ∀ m∈xs, Candidate L R hw.B B s d m)
    (distinct : xs.Nodup) (epos : 0<ell) (kcell : B.length≤ell) (qcell : hw.B.length≤ell)
    (span : ∀ m∈xs, base≤m ∧ m<base+M*ell)
    (load : (4*G)*ell+M*((d+1)*T)≤xs.length)
    (on : G*(3*ell)≤s) (off : s+G*(3*ell)≤L.length) :
    (T+1)^G≤hw.NP+2 := by
  obtain ⟨groups⟩ := groups_of_candidates hw.nb dq good distinct epos kcell qcell span load on off
  simpa using TwoRoot.threshold_hardware hw ndB correct cut groups

end HWB.Threshold
