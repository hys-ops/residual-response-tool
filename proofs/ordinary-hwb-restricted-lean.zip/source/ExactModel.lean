import SquareOuter
import SmallLeftOnes
import ScaleMargins
import BalancedExact

namespace HWB.Exact
open HWB.Model HWB.Slice HWB.TwoRoot

/-- Separate the only two remaining numeric cases from the physical root
branches, including direct leaf gates and arbitrary leaf orders. -/
theorem combine {n W t : Nat} (c : Certificate n W) (ht : 0<t) (big : 2^128≤n)
    (target : (factor*t)^3≤n*n.log2^2)
    (tiny : ∀ {B : List Nat} (hw : Hardware n B), B.Nodup →
      (∀ x y, hw.dec.run x y=universal B (x.val++y.val)) →
      B.length<8*t → 65536*(hw.B.length*hw.B.length)≤n*(B.length+1) →
      2^t≤hw.NP+2)
    (bignum : ∀ {k p q : Nat}, k<8*t → n<100*p →
      n*(k+1)<65536*(q*q) → ∃ r, 2048≤r ∧ k+1≤r ∧ r+(k+1)≤q ∧
      64*r≤p ∧ n≤128*p ∧ 4*(2*k+2+k*(k+1))≤p ∧
      t≤(k+2).log2*((r/(k+1)+1)/32768)/14) :
    2^t≤W+2 := by
  have sq := scale_square big target
  have os := (margins (k:=0) ht (by omega) sq).1
  by_cases left : c.A.length<8*t
  · exact square_outer_left c ht os left
  by_cases right : c.B.length<8*t
  · have mar := margins ht right sq
    cases c.universalChild with
    | ordered order perm g root cost correct =>
      exact square_direct c perm g root cost correct ht os right
    | branch g scope cost correct =>
      have he (x : Assignment g.A) (y : Assignment g.B) :
          g.dec.run x y=universal c.B (x.val++y.val) := correct x y
      by_cases hp : 100*g.A.length≤n
      · have h1 := HWB.SmallLeftOnes.hardware_rate g he hp mar.2.1
        have h2 := Nat.pow_le_pow_right (by decide : 0<2) mar.2.2.1
        unfold Hardware.wires at cost
        omega
      by_cases hq : 65536*(g.B.length*g.B.length)≤n*(c.B.length+1)
      · have h := tiny g c.nb he right hq
        unfold Hardware.wires at cost
        omega
      · obtain ⟨r,h0,h1,h2,h3,h4,h5,h6⟩ := bignum (p:=g.A.length) (q:=g.B.length) right (by omega) (by omega : n*(c.B.length+1)<65536*(g.B.length*g.B.length))
        have width := HWB.BalancedExact.hardware_bits (r:=r) g c.nb he h0 h1 h2 h3 h4 h5
        have bits := Nat.pow_le_pow_right (by decide : 0<2) h6
        unfold Hardware.wires at cost
        omega
  · exact c.balanced ht (by omega) (by omega)

end HWB.Exact
