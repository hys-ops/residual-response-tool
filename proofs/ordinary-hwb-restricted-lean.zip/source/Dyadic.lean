import Std
import Entropy
import DyadicBalance

set_option maxRecDepth 32768
set_option exponentiation.threshold 4096
namespace HWB.Dyadic

/-- A natural, dyadic representative for (n (log₂(n)+1)²)^(1/3). -/
def level (n : Nat) := (n.log2 + 2 * (n.log2+1).log2) / 3
def target (n : Nat) := 2 ^ level n

private theorem pow_span (a : Nat) (h : 0 < a) :
    2^a.log2 ≤ a ∧ a < 2*2^a.log2 := by
  constructor
  · exact Nat.log2_self_le (by omega)
  · have := (Nat.log2_lt (n:=a) (k:=a.log2+1) (by omega)).mp (by omega)
    simpa [Nat.pow_succ,Nat.mul_comm] using this

private theorem exp_span (n : Nat) :
    (target n)^3 ≤ 2^(n.log2 + 2*(n.log2+1).log2) ∧
    2^(n.log2 + 2*(n.log2+1).log2) ≤ 4*(target n)^3 := by
  let b := n.log2 + 2*(n.log2+1).log2
  have a : 3*(b/3) ≤ b := by omega
  have c : b ≤ 3*(b/3)+2 := by omega
  have two : (0:Nat)<2 := by decide
  have h₁ := Nat.pow_le_pow_right two a
  have h₂ := Nat.pow_le_pow_right two c
  have eq : 2^(3*(b/3)) = (target n)^3 := by
    rw [Nat.mul_comm, Nat.pow_mul]; rfl
  constructor
  · simpa only [eq] using h₁
  · rw [Nat.pow_add 2 (3*(b/3)) 2,eq] at h₂
    change 2^b ≤ 4*(target n)^3
    simpa [Nat.mul_comm] using h₂

/-- Two-sided equivalence at every positive n; cubing avoids all real-analysis imports. -/
theorem scale {n : Nat} (hn : 0<n) :
    target n ^3 ≤ n*(n.log2+1)^2 ∧ n*(n.log2+1)^2 ≤ 32*(target n)^3 := by
  have a := pow_span n hn
  have b := pow_span (n.log2+1) (by omega)
  have c := exp_span n
  have eq : 2^(n.log2 + 2*(n.log2+1).log2) =
      2^n.log2*(2^(n.log2+1).log2)^2 := by
    rw [Nat.pow_add, Nat.mul_comm 2 (n.log2+1).log2, Nat.pow_mul]
  rw [eq] at c
  constructor
  · exact Nat.le_trans c.1 (Nat.mul_le_mul a.1 (Nat.pow_le_pow_left b.1 2))
  · have upper := Nat.mul_le_mul (Nat.le_of_lt a.2) (Nat.pow_le_pow_left (Nat.le_of_lt b.2) 2)
    calc
      n*(n.log2+1)^2 ≤ (2*2^n.log2)*(2*2^(n.log2+1).log2)^2 := upper
      _ = 8*(2^n.log2*(2^(n.log2+1).log2)^2) := by grind
      _ ≤ 8*(4*(target n)^3) := Nat.mul_le_mul_left 8 c.2
      _ = _ := by grind

private theorem gap (d : Nat) : (d+1)^2 ≤ 4*2^d := by
  induction d with
  | zero => decide
  | succ d ih =>
    by_cases small : d<2
    · rcases (show d=0 ∨ d=1 by omega) with h|h <;> subst d <;> decide
    · have dd : 2*2 ≤ d*d := Nat.mul_le_mul (by omega) (by omega)
      have step : (d+2)^2 ≤ 2*(d+1)^2 := by grind
      have two := Nat.mul_le_mul_left 2 ih
      rw [Nat.pow_succ 2 d]
      grind

private theorem log_envelope {w J : Nat} (hw : 0<w) (hJ : w≤2^J) :
    (J+1)^2*w ≤ 8*(2^J)*(w.log2+1)^2 := by
  let z := w.log2
  have hz : z≤J := (Nat.pow_le_pow_iff_right (by decide : (1:Nat)<2)).mp
    (Nat.le_trans (pow_span w hw).1 hJ)
  have add : z+(J-z)=J := by omega
  have plus : J+1 ≤ (z+1)*((J-z)+1) := by grind
  have sq := Nat.pow_le_pow_left plus 2
  have wg : w≤2*2^z := Nat.le_of_lt (pow_span w hw).2
  have dg := gap (J-z)
  have poweq : 2^z*2^(J-z) = 2^J := by rw [←Nat.pow_add,add]
  calc
    (J+1)^2*w ≤ ((z+1)*((J-z)+1))^2*(2*2^z) := Nat.mul_le_mul sq wg
    _ = ((z+1)^2*(2*2^z))*((J-z)+1)^2 := by grind
    _ ≤ ((z+1)^2*(2*2^z))*(4*2^(J-z)) := Nat.mul_le_mul_left _ dg
    _ = 8*(2^z*2^(J-z))*(z+1)^2 := by grind
    _ = _ := by rw [poweq]

/-- The minimax estimate holds simultaneously for every 1 ≤ w ≤ 8 target(n). -/
theorem minimax {n w : Nat} (hn : 0<n) (hw : 0<w) (cap : w ≤ 8*target n) :
    (target n)^2*w ≤ 576*n*(w.log2+1)^2 := by
  let j := level n
  let t := target n
  have hj : n.log2+1 ≤ 3*(j+3+1) := by dsimp [j,level]; omega
  have ht : 2^(j+3) = 8*t := by rw [Nat.pow_add]; simp [t,j,target,Nat.mul_comm]
  have he := log_envelope (J:=j+3) hw (by simpa only [ht] using cap)
  rw [ht] at he
  have sq := Nat.pow_le_pow_left hj 2
  have bound : (n.log2+1)^2 *w ≤ 576*t*(w.log2+1)^2 := by
    calc
      _ ≤ (3*(j+3+1))^2*w := Nat.mul_le_mul_right _ sq
      _ = 9*((j+3+1)^2*w) := by grind
      _ ≤ 9*(8*(8*t)*(w.log2+1)^2) := Nat.mul_le_mul_left _ he
      _ = _ := by grind
  have cub := (scale hn).1
  have pos : 0<t := Nat.pow_pos (by decide : 0<2)
  apply Nat.le_of_mul_le_mul_left (c:=t) _ pos
  calc
    t*((target n)^2*w) = (target n)^3*w := by dsimp [t]; grind
    _ ≤ (n*(n.log2+1)^2)*w := Nat.mul_le_mul_right _ cub
    _ = n*((n.log2+1)^2*w) := by grind
    _ ≤ n*(576*t*(w.log2+1)^2) := Nat.mul_le_mul_left _ bound
    _ = t*(576*n*(w.log2+1)^2) := by grind


/-- Crude but uniform margins for all the square-scale constructors. -/
theorem target_square {n A : Nat} (large : 2^1024 ≤ n)
    (tar : A^3 ≤ n*n.log2^2) : 2^120*(A+1)^2 ≤ n := by
  have lg := HWB.DensePacking.log_power_sixteen (n:=n) (Nat.le_trans (by decide) large)
  have ap : A^24 ≤ n^9 := by
    calc
      _ = (A^3)^8 := by rw [← Nat.pow_mul]
      _ ≤ (n*n.log2^2)^8 := Nat.pow_le_pow_left tar 8
      _ = n^8*n.log2^16 := by rw [Nat.mul_pow,← Nat.pow_mul]
      _ ≤ n^8*n := Nat.mul_le_mul_left _ lg
      _ = n^9 := rfl
  by_cases az : A=0
  · subst A; simpa using (Nat.le_trans (by decide : 2^120 ≤ 2^1024) large)
  have ac : A+1≤2*A := by omega
  have scaled : 2^122*A^2 ≤ n := by
    apply (Nat.pow_le_pow_iff_left (by decide : 12≠0)).mp
    have hp : (2^122)^12 ≤ n^3 :=
      Nat.le_trans (by decide : (2^122)^12 ≤ (2^1024)^3) (Nat.pow_le_pow_left large 3)
    calc
      _ = (2^122)^12 * A^24 := by rw [Nat.mul_pow,←Nat.pow_mul (a:=A)]
      _ ≤ n^3*n^9 := Nat.mul_le_mul hp ap
      _ = n^12 := (Nat.pow_add n 3 9).symm
  calc
    _ ≤ 2^120*(2*A)^2 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left ac 2)
    _ = 2^122*A^2 := by rw [Nat.mul_pow,←Nat.mul_assoc]
    _ ≤ _ := scaled

theorem root_margin {n A t : Nat} (large : 2^1024 ≤ n)
    (tar : A^3 ≤ n*n.log2^2) (small : t ≤ A) : 262144*((t+1)*(t+1))≤n := by
  have h := Nat.mul_le_mul (show 262144≤2^120 by decide)
    (Nat.pow_le_pow_left (show t+1≤A+1 by omega) 2)
  exact Nat.le_trans (by simpa [Nat.pow_two] using h) (target_square large tar)

/-- Width and cell size margins for the small-Q geometric construction. -/
theorem tiny_margins {n A w q : Nat} (large : 2^1024≤n)
    (tar : A^3 ≤ n*n.log2^2) (hw : 0<w) (cap : w≤8*A)
    (small : q^2≤n*w) :
    let ell := max 8192 (q+w+1)
    let d := 64*q*w/n
    2^100*w^2 ≤ n ∧ ell^2 ≤ 16*(n*w) ∧ 2^20*ell≤n ∧ d*d≤ell := by
  dsimp only
  let ell := max 8192 (q+w+1)
  let d := 64*q*w/n
  have np : 0<n := Nat.lt_of_lt_of_le (Nat.pow_pos (by decide)) large
  have width : 2^100*w^2 ≤ n := by
    calc
      _ ≤ 2^100*(8*(A+1))^2 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left (by omega) 2)
      _ = 2^106*(A+1)^2 := by rw [Nat.mul_pow,←Nat.mul_assoc]
      _ ≤ 2^120*(A+1)^2 := Nat.mul_le_mul_right _ (by decide)
      _ ≤ _ := target_square large tar
  have w2 : w≤w^2 := by simpa [Nat.pow_two] using Nat.mul_le_mul_left w hw
  have wn : 2^100*w≤n := Nat.le_trans (Nat.mul_le_mul_left _ w2) width
  have wn' : w≤n := by omega
  have nw : n≤n*w := by simpa using Nat.mul_le_mul_left n hw
  have wnw : w^2≤n*w := by simpa [Nat.pow_two] using Nat.mul_le_mul_right w wn'
  have em : ell^2 ≤ 16*(n*w) := by
    by_cases h₀ : q+w+1 ≤8192
    · have eq : ell=8192 := Nat.max_eq_left h₀
      rw [eq]
      have := Nat.le_trans (by decide : 8192^2≤2^1024) large
      omega
    · have eq : ell=q+w+1 := Nat.max_eq_right (by omega)
      rw [eq]
      by_cases hh : q≤w
      · have pp := Nat.pow_le_pow_left (show q+w+1≤4*w by omega) 2
        calc
          _ ≤ (4*w)^2 := pp
          _ = 16*w^2 := by rw [Nat.mul_pow]
          _ ≤ _ := Nat.mul_le_mul_left _ wnw
      · have pp := Nat.pow_le_pow_left (show q+w+1≤4*q by omega) 2
        calc
          _ ≤ (4*q)^2 := pp
          _ = 16*q^2 := by rw [Nat.mul_pow]
          _ ≤ _ := Nat.mul_le_mul_left _ small
  have cell : 2^20*ell≤n := by
    apply (Nat.pow_le_pow_iff_left (by decide : 2≠0)).mp
    calc
      _ = 2^40*ell^2 := by rw [Nat.mul_pow]
      _ ≤ 2^40*(16*(n*w)) := Nat.mul_le_mul_left _ em
      _ = n*(2^44*w) := by grind
      _ ≤ n*n := Nat.mul_le_mul_left _ (by omega)
      _ = n^2 := by grind
  have qn : q≤n := (Nat.pow_le_pow_iff_left (by decide : 2≠0)).mp
    (Nat.le_trans small (by simpa [Nat.pow_two] using Nat.mul_le_mul_left n wn'))
  have di : n*d ≤ 64*q*w := Nat.mul_div_le ..
  have dist : d*d ≤ q := by
    apply Nat.le_of_mul_le_mul_left (c:=n*n) _ (Nat.mul_pos np np)
    calc
      _ = (n*d)^2 := by grind
      _ ≤ (64*q*w)^2 := Nat.pow_le_pow_left di 2
      _ = q*(q*(4096*w^2)) := by grind
      _ ≤ q*(n*n) := Nat.mul_le_mul_left _ (Nat.mul_le_mul qn (by omega))
      _ = _ := by ac_rfl
  have ql : q≤ell := Nat.le_trans (by omega : q≤q+w+1) (Nat.le_max_right ..)
  exact ⟨width,em,cell,Nat.le_trans dist ql⟩

/-- Actual hardware number of states for the very small Q bank. -/
theorem tiny_hardware {n A w q : Nat} (large : 2^1024≤n)
    (tar : A^3 ≤ n*n.log2^2) (hw : 0<w) (cap : w≤8*A)
    (small : q^2≤n*w) :
    let ell := max 8192 (q+w+1)
    let d := 64*q*w/n
    2^(A/2^30) ≤ (1+max 1 (ell/(64*(d+1))))^(n/(16384*ell)) := by
  let ell := max 8192 (q+w+1)
  let d := 64*q*w/n
  let G := n/(16384*ell)
  have np : 0<n := Nat.lt_of_lt_of_le (Nat.pow_pos (by decide)) large
  have e0 : 0<ell := Nat.lt_of_lt_of_le (by decide : 0<8192) (Nat.le_max_left ..)
  obtain ⟨_, em,cell,dist⟩ := tiny_margins large tar hw cap small
  change ell^2≤16*(n*w) at em
  change 2^20*ell≤n at cell
  change d*d≤ell at dist
  have dp : 0<16384*ell := Nat.mul_pos (by decide) e0
  have gp : 1≤G := (Nat.le_div_iff_mul_le dp).mpr (by omega)
  have floor := Nat.lt_mul_of_div_lt (show n/(16384*ell)<G+1 by omega) dp
  have ng : n ≤ 32768*ell*G := by
    calc
      _ ≤ (G+1)*(16384*ell) := Nat.le_of_lt floor
      _ ≤ (2*G)*(16384*ell) := Nat.mul_le_mul_right _ (by omega)
      _ = _ := by grind
  have wel : w+1≤ell := Nat.le_trans (by omega : w+1≤q+w+1) (Nat.le_max_right ..)
  have logs : (w+1).log2≤ell.log2 := (Nat.le_log2 (by omega)).mpr
    (Nat.le_trans (Nat.log2_self_le (by omega)) wel)
  let score := 131072*G*ell.log2
  have window : n*(w+1).log2^2 ≤ w*score^2 := by
    apply Nat.le_of_mul_le_mul_left (c:=n) _ np
    calc
      _ = n^2*(w+1).log2^2 := by grind
      _ ≤ (32768*ell*G)^2*ell.log2^2 :=
        Nat.mul_le_mul (Nat.pow_le_pow_left ng 2) (Nat.pow_le_pow_left logs 2)
      _ = (32768*G*ell.log2)^2*ell^2 := by grind
      _ ≤ (32768*G*ell.log2)^2*(16*(n*w)) := Nat.mul_le_mul_left _ em
      _ = n*(w*score^2) := by dsimp [score];grind
  have amt := HWB.DensePacking.dyadic_target (n:=n) (A:=A) (C:=8)
    (Nat.le_trans (by decide) large) hw (by decide) tar cap window
  change A≤8*8*(131072*G*ell.log2) at amt
  have bits : A/2^30 ≤ ell.log2*G/16 := by
    rw [Nat.mul_assoc 131072 G ell.log2,Nat.mul_comm G ell.log2] at amt
    omega
  exact Nat.le_trans (Nat.pow_le_pow_right (by decide) bits)
    (HWB.DensePacking.paper_entropy ell d G e0 dist)

/-- An explicit, positive exponent for the physically composed exact-two-level bound. -/
def witness (n : Nat) := target n / 2^61

theorem witness_bounds {n : Nat} (large : 2^1024≤n) :
    0<witness n ∧ ((2^60)*witness n)^3≤n*n.log2^2 ∧
    n*n.log2^2 ≤ 2^191*(witness n)^3 := by
  have np : 0<n := Nat.lt_of_lt_of_le (Nat.pow_pos (by decide)) large
  have logs : 1024 ≤ n.log2 := (Nat.le_log2 (by omega)).mpr large
  have lev : 61≤level n := by unfold level;omega
  have rad : 2^61≤target n := Nat.pow_le_pow_right (by decide) lev
  have denom : 0<(2:Nat)^61 := by decide
  have pos : 1≤witness n := (Nat.le_div_iff_mul_le denom).mpr (by simpa using rad)
  have up : 2*(2^60*witness n) ≤ target n := by
    rw [←Nat.mul_assoc,show 2*2^60=(2:Nat)^61 by decide]
    exact Nat.mul_div_le (target n) (2^61)
  have low : target n ≤ 2^62*witness n := by
    have floor := Nat.lt_mul_of_div_lt (show target n/2^61<witness n+1 by unfold witness;omega) denom
    calc
      _ ≤ (witness n+1)*2^61 := Nat.le_of_lt floor
      _ ≤ (2*witness n)*2^61 := Nat.mul_le_mul_right _ (by omega)
      _ = _ := by grind
  have s := scale np
  have lgr : (n.log2+1)^2≤4*n.log2^2 := by
    simpa [Nat.mul_pow] using Nat.pow_le_pow_left (show n.log2+1≤2*n.log2 by omega) 2
  refine ⟨pos,?_,?_⟩
  · have h : (2*(2^60*witness n))^3 ≤ n*(4*n.log2^2) :=
      Nat.le_trans (Nat.pow_le_pow_left up 3) (Nat.le_trans s.1 (Nat.mul_le_mul_left n lgr))
    rw [Nat.mul_pow 2 _ 3,Nat.mul_left_comm n 4] at h
    omega
  · calc
      _ ≤ n*(n.log2+1)^2 := Nat.mul_le_mul_left n (Nat.pow_le_pow_left (by omega) 2)
      _ ≤ 32*(target n)^3 := s.2
      _ ≤ 32*(2^62*witness n)^3 := Nat.mul_le_mul_left _ (Nat.pow_le_pow_left low 3)
      _ = _ := by rw [Nat.mul_pow,←Nat.mul_assoc]

#print axioms witness_bounds
#print axioms scale
#print axioms minimax
#print axioms target_square
#print axioms root_margin
#print axioms tiny_margins
#print axioms tiny_hardware
end HWB.Dyadic
