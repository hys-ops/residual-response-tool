import Std

/-! Fixed-weight separation and its application to a weighted occurrence
test on intervals of original one-based labels. No other project imports. -/
namespace HWB.NestedCylinder

/-- A support is the duplicate-free list of original labels assigned one. -/
abbrev Support (bank : List Nat) := {x : List Nat // x.Nodup ∧ x ⊆ bank}

def Agrees (S x y : List Nat) : Prop := ∀ j ∈ S, (j ∈ x ↔ j ∈ y)

def Matches (W x : List Nat) (pat : Nat → Bool) : Prop :=
  ∀ j ∈ W, (j ∈ x ↔ pat j = true)

private theorem complement_count (U : List Nat) (f : Nat → Bool) :
    (U.filter f).length + (U.filter (fun j => !(f j))).length = U.length := by
  induction U with
  | nil => simp
  | cons a U ih => cases h : f a <;> simp [h] <;> omega

/-- The two supports have equal weight. They differ only by swapping the
private bit u with v outside both query sets. All other bits agree. -/
theorem cylinder_swap (C W V : List Nat) (pat : Nat → Bool) (s u v : Nat)
    (cn : C.Nodup) (wn : W.Nodup) (inside : W ⊆ C)
    (uw : u ∈ W) (uv' : u ∉ V) (vc : v ∈ C) (vw : v ∉ W) (vv' : v ∉ V)
    (minOnes : W.length + 1 ≤ s) (minZeros : s + W.length + 1 ≤ C.length) :
    ∃ yes no : Support C, yes.val.length = s ∧ no.val.length = s ∧
      Matches W yes.val pat ∧ ¬ Matches W no.val pat ∧ Agrees V yes.val no.val := by
  let lock := fun j => decide (j ∈ v :: W)
  let free := C.filter (fun j => !(lock j))
  let fixed := W.filter (fun j => decide (j ≠ u) && pat j)
  let tail := free.take (s-fixed.length-1)
  let base := fixed ++ tail
  have uv : u ≠ v := fun h => vw (h ▸ uw)
  have clu : (C.filter lock).length ≤ W.length+1 := by
    have nd : (C.filter lock).Nodup := List.Pairwise.filter lock cn
    apply nd.length_le_of_subset (l₂ := v::W)
    intro j hj
    simpa [lock] using (List.mem_filter.mp hj).2
  have clen := complement_count C lock
  change (C.filter lock).length + free.length = C.length at clen
  have fl := List.length_filter_le (fun j => decide (j ≠ u) && pat j) W
  change fixed.length ≤ W.length at fl
  have enough : s-fixed.length-1 ≤ free.length := by omega
  have lenbase : base.length+1 = s := by
    simp only [base,List.length_append,tail,List.length_take_of_le enough]
    omega
  have tail_free : tail ⊆ free := List.take_subset ..
  have fb {j : Nat} (hj : j ∈ tail) : j ∈ C ∧ j ≠ v ∧ j ∉ W := by
    have := List.mem_filter.mp (tail_free hj)
    simpa [lock] using this
  have fx {j} : j ∈ fixed ↔ j ∈ W ∧ j ≠ u ∧ pat j = true := by simp [fixed]
  have bn : base.Nodup := by
    apply List.nodup_append.mpr
    refine ⟨List.Pairwise.filter _ wn, (List.Pairwise.filter _ cn).take,?_⟩
    intro i hi j hj hij; subst j; exact (fb hj).2.2 (fx.mp hi).1
  have bc : base ⊆ C := by
    intro j hj; rcases List.mem_append.mp hj with hf|ht
    · exact inside (fx.mp hf).1
    · exact (fb ht).1
  have bu : u ∉ base := by
    intro h; rcases List.mem_append.mp h with hf|ht
    · exact (fx.mp hf).2.1 rfl
    · exact (fb ht).2.2 uw
  have bv : v ∉ base := by
    intro h; rcases List.mem_append.mp h with hf|ht
    · exact vw (fx.mp hf).1
    · exact (fb ht).2.1 rfl
  let xu : Support C := ⟨u::base, List.nodup_cons.mpr ⟨bu,bn⟩,
    List.cons_subset.mpr ⟨inside uw,bc⟩⟩
  let xv : Support C := ⟨v::base, List.nodup_cons.mpr ⟨bv,bn⟩,
    List.cons_subset.mpr ⟨vc,bc⟩⟩
  have common : Agrees V xu.val xv.val := by
    intro j hj
    have ju : j ≠ u := fun e => uv' (e ▸ hj)
    have jv : j ≠ v := fun e => vv' (e ▸ hj)
    simp [xu,xv,ju,jv]
  have bspec (j) (inW : j ∈ W) (ju : j ≠ u) : j ∈ base ↔ pat j=true := by
    have ht : j ∉ tail := fun h => (fb h).2.2 inW
    simp [base,ht,fx,inW,ju]
  have a1 : u ∈ xu.val := by simp [xu]
  have a0 : u ∉ xv.val := by simp [xv,uv,bu]
  cases hp : pat u with
  | true =>
    refine ⟨xu,xv,lenbase,lenbase,?_,?_,common⟩
    · intro j hj
      by_cases e : j=u
      · subst j; simp [a1,hp]
      · simpa [xu,e] using bspec j hj e
    · intro no; exact a0 ((no u uw).mpr hp)
  | false =>
    refine ⟨xv,xu,lenbase,lenbase,?_,?_,fun j hj => (common j hj).symm⟩
    · intro j hj
      by_cases e : j=u
      · subst j; simp [a0,hp]
      · have jv : j ≠ v := fun he => vw (he ▸ hj)
        simpa [xv,jv] using bspec j hj e
    · intro no; have h := (no u uw).mp a1; simp [hp] at h

def window (a w : Nat) := List.range' a w

theorem in_window : j ∈ window a w ↔ a ≤ j ∧ j < a+w := by
  simp only [window, List.mem_range', Nat.one_mul]
  constructor
  · rintro ⟨t,ht,e⟩; omega
  · rintro ⟨lo,hi⟩; exact ⟨j-a,by omega,by omega⟩

/-- Moving a nonempty window of the same length loses at least one old coordinate. -/
theorem private_bit (wpos : 0 < w) (neq : a ≠ b) :
    ∃ u ∈ window a w, u ∉ window b w := by
  by_cases h : a < b
  · exact ⟨a,in_window.mpr ⟨by omega,by omega⟩,fun hb => by have := in_window.mp hb; omega⟩
  · exact ⟨a+w-1,in_window.mpr ⟨by omega,by omega⟩,fun hb => by have := in_window.mp hb; omega⟩

theorem exterior_bit {C W V : List Nat} (cn : C.Nodup)
    (room : W.length+V.length < C.length) :
    ∃ v ∈ C, v ∉ W ∧ v ∉ V := by
  apply Classical.byContradiction
  intro h
  have subset : C ⊆ W++V := by
    intro j hj
    apply List.mem_append.mpr
    by_cases hw : j ∈ W
    · exact Or.inl hw
    · by_cases hv : j ∈ V
      · exact Or.inr hv
      · exact False.elim (h ⟨j,hj,hw,hv⟩)
  have le := cn.length_le_of_subset subset
  rw [List.length_append] at le
  omega

/-- For root-right labels [1,k], the symmetric root row described by p occurs
precisely at weight a >= k and at offsets j=0,...,k agrees with p.
The borderline zero on the weight-zero root layer is explicit. -/
def Occurs (k : Nat) (p : Nat → Bool) (left right : List Nat) : Prop :=
  let a := left.length + right.length
  k ≤ a ∧ ∀ j, j < k+1 → ((a+j ≠ k ∧ a+j ∈ left++right) ↔ p j = true)

theorem occurrence_on_marker {C X Y : List Nat} {s k a : Nat} (p : Nat → Bool)
    (hlen : a=X.length+s) (hy : Y.length=s) (clear : k<a)
    (inside : window a (k+1) ⊆ C) (sep : ∀ j ∈ X, j ∉ C) :
    Occurs k p X Y ↔ Matches (window a (k+1)) Y (fun z => p (z-a)) := by
  unfold Occurs Matches
  rw [hy,← hlen]
  constructor
  · intro h z hz
    have br := in_window.mp hz
    have h1 := h.2 (z-a) (by omega)
    have e : a+(z-a) = z := by omega
    have nz : z ≠ k := by omega
    have nx : z ∉ X := fun x => sep _ x (inside hz)
    simpa [e,nz,nx] using h1
  · intro m
    refine ⟨by omega, ?_⟩
    intro i hi
    have hz : a+i ∈ window a (k+1) := in_window.mpr ⟨by omega,by omega⟩
    have h1 := m _ hz
    have nz : a+i ≠ k := by omega
    have nx : a+i ∉ X := fun x => sep _ x (inside hz)
    simpa [nz,nx] using h1

theorem occurrence_local {X Y Z : List Nat} {k s : Nat} (p : Nat → Bool)
    (hY : Y.length = s) (hZ : Z.length = s)
    (agree : Agrees (window (X.length+s) (k+1)) Y Z) :
    Occurs k p X Y ↔ Occurs k p X Z := by
  unfold Occurs
  rw [hY,hZ]
  apply and_congr_right
  intro _
  apply forall_congr'
  intro j
  apply forall_congr'
  intro hj
  have hw : X.length+s+j ∈ window (X.length+s) (k+1) :=
    in_window.mpr ⟨by omega,by omega⟩
  simp only [List.mem_append,agree _ hw]

/-- An intact marker window in the second right bank distinguishes the two
left weights in the very same layer, independently of the contents of X'.
The bounds on s alone provide the spare coordinate. -/
theorem nested_weight_distinction {C X X' : List Nat} {k s : Nat} (p : Nat → Bool)
    (cn : C.Nodup) (different : X.length ≠ X'.length)
    (sep : ∀ j ∈ X, j ∉ C) (clear : k < X.length+s)
    (marker : window (X.length+s) (k+1) ⊆ C)
    (low : k+2 ≤ s) (high : s+k+2 ≤ C.length) :
    ∃ y : Support C, y.val.length=s ∧ ¬ (Occurs k p X y.val ↔ Occurs k p X' y.val) := by
  let a := X.length+s
  let a' := X'.length+s
  let W := window a (k+1)
  let V := window a' (k+1)
  have wl : W.length=k+1 := List.length_range'
  have vl : V.length=k+1 := List.length_range'
  have neq : a≠a' := by dsimp [a,a'];omega
  obtain ⟨u,hu,hv⟩ := private_bit (show 0<k+1 by omega) neq
  obtain ⟨v,hvc,hvw,hvv⟩ := exterior_bit (W:=W) (V:=V) cn (by omega)
  obtain ⟨yes,no,hy,hn,good,bad,agree⟩ :=
    cylinder_swap C W V (fun z => p (z-a)) s u v cn
      (List.nodup_range' (s:=a) (n:=k+1)) marker hu hv hvc hvw hvv (by omega) (by omega)
  have y1 := (occurrence_on_marker p rfl hy clear marker sep).mpr good
  have y2 : ¬ Occurs k p X no.val := fun h =>
    bad ((occurrence_on_marker p rfl hn clear marker sep).mp h)
  have h' := occurrence_local (X:=X') p hy hn agree
  by_cases y3 : Occurs k p X' yes.val
  · exact ⟨no,hn,fun eq => y2 (eq.mpr (h'.mp y3))⟩
  · exact ⟨yes,hy,fun eq => y3 (eq.mp y1)⟩

/-- Actual raw HWB on the disjoint supports of the first and second root banks. -/
def answer (L Z : List Nat) : Prop := L.length + Z.length ∈ L++Z

def firstBank (k : Nat) : List Nat := List.range' 1 k

theorem in_first : j ∈ firstBank k ↔ 1 ≤ j ∧ j ≤ k := by
  change j ∈ window 1 k ↔ _
  rw [in_window]; omega

def SymmetricRow (k : Nat) (p : Nat → Bool) (L : List Nat) : Prop :=
  ∀ Z : Support (firstBank k), answer L Z.val ↔ p Z.val.length = true

private theorem raw_above {L Z : List Nat} (separate : ∀ j ∈ L, k < j)
    (inside : Z ⊆ firstBank k) (hk : k ≤ L.length) :
    (answer L Z ↔ L.length + Z.length ≠ k ∧ L.length + Z.length ∈ L) := by
  let t := L.length+Z.length
  by_cases border : t = k
  · have z0 : Z.length = 0 := by dsimp [t] at border; omega
    have zn : Z = [] := List.length_eq_zero_iff.mp z0
    have hl : t ∉ L := fun ht => by have := separate t ht; omega
    change (t ∈ L++Z ↔ t ≠ k ∧ t ∈ L)
    rw [zn,List.append_nil]
    exact ⟨fun ht => (hl ht).elim, And.right⟩
  · have nz : t ∉ Z := by
      intro h; have up := (in_first.mp (inside h)).2; dsimp [t] at up border; omega
    change (t ∈ L++Z ↔ t ≠ k ∧ t ∈ L)
    simp [nz,border]

theorem no_symmetric_below {L : List Nat} (separate : ∀ j ∈ L, k < j)
    (hk : 2 ≤ k) (small : L.length < k) (p : Nat → Bool) :
    ¬ SymmetricRow k p L := by
  let j := L.length+1
  let z := if j=1 then 2 else 1
  have jb : j ∈ firstBank k := in_first.mpr (by dsimp [j]; omega)
  have zb : z ∈ firstBank k := by apply in_first.mpr; dsimp [z]; split <;> omega
  have jz : j ≠ z := by dsimp [z]; split <;> omega
  have jl : j ∉ L := fun h => by have := separate j h; dsimp [j] at *; omega
  let yes : Support (firstBank k) := ⟨[j],by simp,by simpa⟩
  let no : Support (firstBank k) := ⟨[z],by simp,by simpa⟩
  intro h
  have pos : answer L yes.val := by simp [answer,yes,j]
  have neg : ¬ answer L no.val := by
    change ¬ (L.length+[z].length ∈ L++[z])
    change j ∉ L++[z]
    simp [jl,jz]
  exact neg ((h no).mpr ((h yes).mp pos))

/-- Exact classification on ordinary HWB's original [1,k] root bank.
No monotonicity or regularity on the pattern is assumed. -/
theorem symmetricRow_iff_occurs {X Y : List Nat} (p : Nat → Bool)
    (separate : ∀ j ∈ X++Y, k < j) (hk : 2≤k) :
    SymmetricRow k p (X++Y) ↔ Occurs k p X Y := by
  let L := X++Y
  have ll : L.length=X.length+Y.length := List.length_append
  by_cases h : k ≤ L.length
  · constructor
    · intro row
      refine ⟨by omega, ?_⟩
      intro j hj
      let B := firstBank k
      have bl : B.length=k := List.length_range'
      let Z : Support B := ⟨B.take j,(List.nodup_range' (s:=1) (n:=k)).take,List.take_subset ..⟩
      have zl : Z.val.length=j := List.length_take_of_le (by omega)
      have eq := (raw_above (Z:=Z.val) separate Z.property.2 h).symm.trans (row Z)
      change ((L.length+Z.val.length ≠ k ∧ L.length+Z.val.length ∈ L) ↔ p Z.val.length=true) at eq
      simpa only [zl,ll] using eq
    · intro oc Z
      have zl := Z.property.1.length_le_of_subset Z.property.2
      have bl : (firstBank k).length=k := List.length_range'
      have eq := oc.2 Z.val.length (by omega)
      have raw := raw_above (Z:=Z.val) separate Z.property.2 h
      rw [List.length_append] at raw
      exact raw.trans eq
  · have nrow := no_symmetric_below separate hk (Nat.lt_of_not_ge h) p
    exact ⟨fun x => (nrow x).elim, fun x => (h (by simpa [L] using x.1)).elim⟩

/-- Different inner left weights yield different right responses of the actual
top-level HWB prime; choose a single same-weight witness on C to tell them apart. -/
theorem nested_distinct_actual_HWB {C X X' : List Nat} {k s : Nat} (p : Nat → Bool)
    (hk : 2 ≤ k) (cn : C.Nodup) (different : X.length ≠ X'.length)
    (sep : ∀ j ∈ X, j ∉ C) (clear : k < X.length+s)
    (aboveX : ∀ j ∈ X, k<j) (aboveX' : ∀ j ∈ X', k<j) (aboveC : ∀ j ∈ C, k<j)
    (marker : window (X.length+s) (k+1) ⊆ C)
    (low : k+2 ≤ s) (high : s+k+2 ≤ C.length) :
    ∃ y : Support C, y.val.length=s ∧
      ¬ (SymmetricRow k p (X++y.val) ↔ SymmetricRow k p (X'++y.val)) := by
  obtain ⟨y,hy,ne⟩ := nested_weight_distinction p cn different sep clear marker low high
  have inY (j) (hj : j∈y.val) := aboveC j (y.property.2 hj)
  have sep1 : ∀ j ∈ X++y.val, k<j := fun j h => (List.mem_append.mp h).elim (aboveX j) (inY j)
  have sep2 : ∀ j ∈ X'++y.val, k<j := fun j h => (List.mem_append.mp h).elim (aboveX' j) (inY j)
  exact ⟨y,hy, fun h => ne ((symmetricRow_iff_occurs p sep1 hk).symm.trans
    (h.trans (symmetricRow_iff_occurs p sep2 hk)))⟩

end HWB.NestedCylinder
