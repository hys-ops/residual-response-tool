import Threshold
import TwoRootModel

namespace HWB.TwoRoot
open Model Circuit Slice

/-- Apply the grouped threshold decoder to an actual compressed decision
for the universal B response. The inner zero-row gate need not be supplied. -/
theorem threshold_hardware {B L R counts : List Nat} {n s d : Nat} (hw : Hardware n B)
    (ndB : B.Nodup) (correct : ∀ x y, hw.dec.run x y=universal B (x.val++y.val))
    (cut : hw.A=L++R) (groups : Threshold.Groups L R hw.B B counts s d) :
    Threshold.alphabet counts≤hw.NP+2 := by
  have good := List.nodup_append.mp (cut ▸ hw.na)
  have dis := fun z hz hq => good.2.2 z hz z hq rfl
  obtain ⟨gate,hg⟩ := const_state hw false
  have dip : ∀ z∈L++R, z∉hw.B := fun z hz => hw.dis z (cut ▸ hz)
  have dib : ∀ z∈L++R, z∉B := fun z hz => hw.disD z (List.mem_append_left _ (cut ▸ hz))
  apply Threshold.dag_width cut groups good.1 good.2.1 dis ndB dip dib hw.gP gate
  intro x
  rw [hg]
  unfold NestedPoison.deadQ
  apply forall_congr'
  intro y
  rw [correct, Bool.eq_false_iff]
  apply not_congr
  rw [universal_iff]
  apply forall_congr'
  intro b
  simp [SmallRight.ordinary, NestedPoison.raw, Nat.add_assoc]

end HWB.TwoRoot
