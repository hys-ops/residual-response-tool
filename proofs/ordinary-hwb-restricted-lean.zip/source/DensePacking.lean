import Std

/-! A finite packing lemma for distinct integer endpoints in a dense slab.
Cell spacing is measured in cell indices and marker spacing in coordinates.
No circuit, probabilistic, or asymptotic assumptions enter the argument. -/
namespace HWB.DensePacking

def interval (base len : Nat) := List.range' base len

@[simp] theorem in_interval : x ∈ interval a w ↔ a ≤ x ∧ x < a+w := by
  simp only [interval,List.mem_range',Nat.one_mul]
  exact ⟨fun ⟨i,hi,e⟩ => by omega,fun ⟨h₁,h₂⟩ => ⟨x-a,by omega,by omega⟩⟩

def cell (base ell j : Nat) := (j-base)/ell

theorem in_cell {ell base j : Nat} (pos : 0<ell) (lo : base≤j) :
    j ∈ interval (base+cell base ell j*ell) ell := by
  have h1 := Nat.div_mul_le_self (j-base) ell
  have h2 := Nat.mod_add_div (j-base) ell
  have h3 := Nat.mod_lt (j-base) pos
  rw [Nat.mul_comm ell] at h2
  simp only [in_interval,cell];omega

private theorem flat_bound (S : List Nat) (f : Nat → List Nat) (cap : Nat)
    (hf : ∀ j∈S, (f j).length≤cap) : (S.flatMap f).length ≤ S.length*cap := by
  induction S with
  | nil => simp
  | cons a S ih =>
    have h₁ := hf a (by simp)
    have h₂ := ih (fun i h => hf i (by simp [h]))
    simpa [List.flatMap_cons,List.length_append,Nat.succ_mul,Nat.add_comm]
      using Nat.add_le_add h₁ h₂

private theorem residue_class (xs : List Nat) (nd : xs.Nodup) {period t : Nat}
    (hp : 0<period) (enough : t=0 ∨ period*(t-1)<xs.length) :
    ∃ r < period, t ≤ (xs.filter (fun j => decide (j%period=r))).length := by
  apply Classical.byContradiction;intro h
  let group := fun r => xs.filter (fun j => decide (j%period=r))
  have hs (r) (rr : r<period) : (group r).length < t := by
    exact Nat.lt_of_not_ge (fun e => h ⟨_,rr,e⟩)
  have ht := hs 0 hp
  have sub : xs ⊆ (List.range period).flatMap group := fun z hz =>
    List.mem_flatMap.mpr ⟨z%period,List.mem_range.mpr (Nat.mod_lt _ hp),by simp [group,hz]⟩
  have bound := flat_bound (List.range period) group (t-1)
    (fun i hi => by have := hs i (List.mem_range.mp hi);omega)
  have d := nd.length_le_of_subset sub
  rw [List.length_range] at bound
  omega

private theorem gap_of_mod {a b r : Nat} (_hr : 0<r) (ab : a<b)
    (same : a%r=b%r) : a+r≤b := by
  have lo := Nat.div_le_div_right (c:=r) (Nat.le_of_lt ab)
  have ea := Nat.mod_add_div a r
  have eb := Nat.mod_add_div b r
  rw [same] at ea
  by_cases eq : a/r=b/r
  · rw [eq] at ea; omega
  · have mult := Nat.mul_le_mul_left r (show a/r+1 ≤ b/r by omega)
    rw [Nat.mul_succ] at mult
    omega

def fibre (xs : List Nat) (base ell i : Nat) := xs.filter (fun j => decide (cell base ell j = i))

private theorem dense_count (xs : List Nat) (base ell M sparse h : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (range : ∀ j∈xs, base≤j ∧ j<base+M*ell)
    (load : h=0 ∨ (h-1)*ell + M*(sparse-1) < xs.length) :
    h ≤ ((List.range M).filter (fun i => decide (sparse≤(fibre xs base ell i).length))).length := by
  let F := fibre xs base ell
  let good := (List.range M).filter (fun i => decide (sparse ≤ (F i).length))
  let bad := (List.range M).filter (fun i => !decide (sparse ≤ (F i).length))
  have cap (i) : (F i).length ≤ ell := by
    have nn : (F i).Nodup := List.Pairwise.filter _ hd
    have sub : F i ⊆ interval (base+i*ell) ell := by
      intro j hj; have hj' := List.mem_filter.mp hj
      have eq : cell base ell j=i := by simpa using hj'.2
      exact eq ▸ in_cell pos (range j hj'.1).1
    simpa [interval] using nn.length_le_of_subset sub
  have all : xs ⊆ good.flatMap F ++ bad.flatMap F := by
    intro j hj
    let i := cell base ell j
    have ir : i<M := (Nat.div_lt_iff_lt_mul pos).mpr (by have := range _ hj;omega)
    have inp : j∈F i := by simp [F,i,fibre,hj]
    apply List.mem_append.mpr
    by_cases e : sparse ≤ (F i).length
    · exact Or.inl (List.mem_flatMap.mpr ⟨i,by simp [good,ir,e],inp⟩)
    · exact Or.inr (List.mem_flatMap.mpr ⟨i,by simp [bad,ir,e],inp⟩)
  have bound := hd.length_le_of_subset all
  rw [List.length_append] at bound
  have a := flat_bound good F ell (fun i _ => cap i)
  have b := flat_bound bad F (sparse-1) (fun i hi => by
    have he := (List.mem_filter.mp hi).2
    change (!decide (sparse ≤ (F i).length))=true at he
    simp only [Bool.not_eq_true',decide_eq_false_iff_not] at he
    omega)
  have bmax : bad.length ≤ M := by
    simpa [bad] using List.length_filter_le (fun i => !decide (sparse ≤ (F i).length)) (List.range M)
  have bm := Nat.mul_le_mul_right (sparse-1) bmax
  change h ≤ good.length
  by_cases e : h≤good.length
  · exact e
  · have sm : good.length ≤ h-1 := by omega
    have mult := Nat.mul_le_mul_right ell sm
    omega

/-- Ordered groups are indices of cells, and each group has its own ordered
list of endpoints. Each member remains an actual endpoint of xs.
Both exact lengths allow independent mixed-radix choices downstream. -/
structure Packed (xs : List Nat) (base ell M d G T : Nat) where
  groups : List Nat
  members : Nat → List Nat
  group_count : groups.length = G
  group_spacing : groups.Pairwise (fun i j => i+4≤j)
  group_range : ∀ i ∈ groups, i<M
  member_count : ∀ i ∈ groups, (members i).length = T
  member_spacing : ∀ i∈groups, (members i).Pairwise (fun a b => a+d<b)
  original : ∀ i∈groups, ∀ j∈members i, j∈xs ∧ j∈interval (base+i*ell) ell

/-- General packing tradeoff. If one accounts for all sparse cells and for
at most 4G dense cells, there must be G mutually well-spaced cells with
at least T mutually well-spaced endpoints each. -/
theorem pack_strict (xs : List Nat) (base ell M d G T : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (span : ∀ j∈xs, base≤j ∧ j<base+M*ell)
    (load : 4*(G-1)*ell + M*((d+1)*(T-1)) < xs.length) :
    Nonempty (Packed xs base ell M d G T) := by
  classical
  let r := d+1
  let F := fibre xs base ell
  let dense := (List.range M).filter (fun i => decide (r*(T-1)+1≤(F i).length))
  have dl : 4*(G-1)+1 ≤ dense.length := dense_count xs base ell M (r*(T-1)+1) (4*(G-1)+1) hd pos span (Or.inr (by simpa [r] using load))
  have dn : dense.Nodup := List.Pairwise.filter _ List.nodup_range
  obtain ⟨col,_,heavy⟩ := residue_class dense dn (period:=4) (t:=G) (by decide) (by omega)
  let colored := dense.filter (fun i => decide (i%4=col))
  let cells := colored.take G
  have cl : cells.length=G := List.length_take_of_le heavy
  have cid (i) (hi : i ∈ cells) : i<M ∧ r*(T-1)+1 ≤ (F i).length ∧ i%4=col := by
    have a := List.mem_filter.mp (show i∈colored from List.take_subset _ _ hi)
    have b := List.mem_filter.mp (show i∈dense from a.1)
    exact ⟨List.mem_range.mp b.1,by simpa using b.2,by simpa using a.2⟩
  have order : cells.Pairwise (·<·) := ((List.pairwise_lt_range.filter _).filter _).take
  have spaced : cells.Pairwise (fun i j => i+4≤j) := by
    apply List.Pairwise.imp_of_mem _ order
    intro a b ha hb h
    exact gap_of_mod (by decide) h ((cid a ha).2.2.trans (cid b hb).2.2.symm)
  have within (i) (hi : i∈cells) : ∃ ys : List Nat,
      ys.length=T ∧ ys.Pairwise (fun a b => a+d<b) ∧
      ∀ j∈ys, j∈xs ∧ j∈interval (base+i*ell) ell := by
    have fnn : (F i).Nodup := List.Pairwise.filter _ hd
    obtain ⟨c,_,bound⟩ := residue_class (F i) fnn (period:=r) (t:=T) (by omega) (Or.inr (cid i hi).2.1)
    let mask := fun j => decide (j∈F i ∧ j%r=c)
    let arr := (interval (base+i*ell) ell).filter mask
    let picks := arr.take T
    let colorF := (F i).filter (fun j => decide (j%r=c))
    have ncolor : colorF.Nodup := List.Pairwise.filter _ fnn
    have subs : colorF ⊆ arr := by
      intro j hj; have b := List.mem_filter.mp hj
      have a := List.mem_filter.mp (show j∈F i from b.1)
      have eq : cell base ell j=i := by simpa using a.2
      have hjj := eq ▸ (in_cell pos (span j a.1).1)
      simp [arr,mask,b.1,hjj, show j%r=c by simpa using b.2]
    have digits : T ≤ arr.length := Nat.le_trans bound (ncolor.length_le_of_subset subs)
    have pe (j) (hj : j∈picks) : j∈interval (base+i*ell) ell ∧ j∈F i ∧ j%r=c := by
      have inf := List.mem_filter.mp (show j∈arr from List.take_subset _ _ hj)
      exact ⟨inf.1,by simpa [mask] using inf.2⟩
    refine ⟨picks,List.length_take_of_le digits,?_,?_⟩
    · have ord : picks.Pairwise (·<·) := (List.pairwise_lt_range' (s:=base+i*ell) (n:=ell)).filter _ |>.take
      apply List.Pairwise.imp_of_mem _ ord
      intro a b ha hb ab
      have gap := gap_of_mod (show 0<r by omega) ab ((pe a ha).2.2.trans (pe b hb).2.2.symm)
      dsimp [r] at gap;omega
    · intro j hj
      exact ⟨(List.mem_filter.mp (show j∈F i from (pe j hj).2.1)).1,(pe j hj).1⟩
  let mems := fun i => if hi : i∈cells then (within i hi).choose else []
  have spec i (hi : i∈cells) := (within i hi).choose_spec
  refine ⟨⟨cells,mems,cl,spaced,fun i hi => (cid i hi).1,?_,?_,?_⟩⟩
  · intro i hi;simpa [mems,hi] using (spec i hi).1
  · intro i hi;simpa [mems,hi] using (spec i hi).2.1
  · intro i hi;simpa [mems,hi] using (spec i hi).2.2

/-- Non-strict bound, including the vacuous zero-group case. -/
theorem pack_sharp (xs : List Nat) (base ell M d G T : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (span : ∀ j∈xs, base≤j ∧ j<base+M*ell)
    (load : (4*G)*ell + M*((d+1)*(T-1)) ≤ xs.length) :
    Nonempty (Packed xs base ell M d G T) := by
  cases G with
  | zero => exact ⟨⟨[],fun _ => [],rfl,by simp,by simp,by simp,by simp,by simp⟩⟩
  | succ g =>
    apply pack_strict xs base ell M d _ T hd pos span
    simp only [Nat.add_one_sub_one, Nat.mul_succ, Nat.add_mul] at *
    omega

/-- A less sharp version with the simpler cost `(d+1)*T`. -/
theorem pack (xs : List Nat) (base ell M d G T : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (span : ∀ j∈xs, base≤j ∧ j<base+M*ell)
    (load : (4*G)*ell + M*((d+1)*T) ≤ xs.length) :
    Nonempty (Packed xs base ell M d G T) := by
  apply pack_sharp xs base ell M d G T hd pos span
  have h := Nat.mul_le_mul_left M (Nat.mul_le_mul_left (d+1) (Nat.sub_le T 1))
  omega

private theorem density_load (N ell M d K : Nat) (kpos : 0<K) (density : M*ell≤K*N) :
    (4*(M/(8*K)))*ell + M*((d+1)*(ell/(2*K*(d+1)))) ≤ N := by
  let G := M/(8*K)
  let T := ell/(2*K*(d+1))
  have hG : (8*K)*G≤M := Nat.mul_div_le _ _
  have hT : (2*K*(d+1))*T≤ell := Nat.mul_div_le _ _
  have aa := Nat.mul_le_mul_right ell hG
  have bb := Nat.mul_le_mul_left M hT
  let a := (4*G)*ell
  let b := M*((d+1)*T)
  have la : (2*K)*a ≤ M*ell := by
    calc _ = ((8*K)*G)*ell := by
           change (2*K)*((4*G)*ell) = ((2*4*K)*G)*ell
           ac_rfl
         _ ≤ _ := aa
  have lb : (2*K)*b ≤ M*ell := by
    calc _ = M*((2*K*(d+1))*T) := by unfold b;ac_rfl
         _ ≤ _ := bb
  have bound : (2*K)*(a+b) ≤ (2*K)*N := by
    rw [Nat.mul_add]
    have hs := Nat.add_le_add la lb
    have dd := Nat.add_le_add density density
    rw [show (2*K)*N = K*N+K*N by rw [Nat.two_mul,Nat.add_mul]]
    omega
  have load : a+b≤N := Nat.le_of_mul_le_mul_left bound (by omega)
  exact load

/-- An explicit density-only parameterization. Covers arbitrary K and small
cells too; the floors may be zero if there is insufficient density/room. -/
theorem pack_density (xs : List Nat) (base ell M d K : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (kpos : 0<K)
    (span : ∀ j∈xs, base≤j ∧ j<base+M*ell) (density : M*ell ≤ K*xs.length) :
    Nonempty (Packed xs base ell M d (M/(8*K)) (ell/(2*K*(d+1)))) := by
  apply pack xs base ell M d _ _ hd pos span
  exact density_load xs.length ell M d K kpos density

/-- Positive marker count in every group, including cells smaller than the spacing. -/
theorem pack_positive (xs : List Nat) (base ell M d K : Nat)
    (hd : xs.Nodup) (pos : 0<ell) (kpos : 0<K)
    (span : ∀ j∈xs, base≤j ∧ j<base+M*ell) (density : M*ell ≤ K*xs.length) :
    Nonempty (Packed xs base ell M d (M/(8*K)) (1+ell/(2*K*(d+1)))) := by
  apply pack_sharp xs base ell M d _ _ hd pos span
  simpa [Nat.add_comm 1] using density_load xs.length ell M d K kpos density

def Packed.group (c : Packed xs base ell M d G T) (i : Fin G) : Nat :=
  c.groups[i.val]'(by rw [c.group_count]; exact i.isLt)
theorem Packed.group_mem (c : Packed xs base ell M d G T) (i : Fin G) :
    c.group i ∈ c.groups := List.getElem_mem _

def Packed.mark (c : Packed xs base ell M d G T) (i : Fin G) (a : Fin T) : Nat :=
  (c.members (c.group i))[a.val]'(by rw [c.member_count _ (c.group_mem i)]; exact a.isLt)
theorem Packed.mark_in_slab (c : Packed xs base ell M d G T) (i : Fin G) (a : Fin T) :
    c.mark i a ∈ xs ∧ c.mark i a ∈ interval (base+c.group i*ell) ell :=
  c.original _ (c.group_mem i) _ (List.getElem_mem _)
theorem Packed.ordered (c : Packed xs base ell M d G T) (i : Fin G) {a b : Fin T}
    (h : a.val<b.val) : c.mark i a+d<c.mark i b :=
  List.pairwise_iff_getElem.mp (c.member_spacing _ (c.group_mem i)) a.val b.val
    (by rw [c.member_count _ (c.group_mem i)]; exact a.isLt)
    (by rw [c.member_count _ (c.group_mem i)]; exact b.isLt) h
theorem Packed.spaced (c : Packed xs base ell M d G T) {i j : Fin G}
    (h : i.val<j.val) : c.group i+4≤c.group j :=
  List.pairwise_iff_getElem.mp c.group_spacing i.val j.val
    (by rw [c.group_count]; exact i.isLt) (by rw [c.group_count]; exact j.isLt) h

/-- Enlarge each cell by one cell-width to the left and one to the right.
Truncate at label zero. This gives a zone of ≤3ell coordinates. -/
def Packed.zone (c : Packed xs base ell M d G T) (i : Fin G) : List Nat :=
  let first := base+c.group i*ell
  interval (first-ell) (first+2*ell-(first-ell))

theorem Packed.zone_iff (c : Packed xs base ell M d G T) (i : Fin G) (z : Nat) :
    z∈c.zone i ↔ base+c.group i*ell-ell ≤ z ∧ z < base+c.group i*ell+2*ell := by
  unfold Packed.zone
  rw [in_interval]
  omega

theorem Packed.zone_size (c : Packed xs base ell M d G T) (i : Fin G) :
    (c.zone i).length ≤ 3*ell := by
  simp only [Packed.zone,interval,List.length_range']
  omega

theorem Packed.zone_separate (c : Packed xs base ell M d G T) (pos : 0<ell)
    {i j : Fin G} (z : Nat) (hi : z∈c.zone i) (hj : z∈c.zone j) : i=j := by
  have a := (c.zone_iff i z).mp hi
  have b := (c.zone_iff j z).mp hj
  apply Fin.ext
  by_cases e : i.val<j.val
  · have mul := Nat.mul_le_mul_right ell (c.spaced e)
    rw [Nat.add_mul] at mul
    omega
  · by_cases h : j.val<i.val
    · have mul := Nat.mul_le_mul_right ell (c.spaced h)
      rw [Nat.add_mul] at mul
      omega
    · omega

theorem Packed.covers_marker_window (c : Packed xs base ell M d G T)
    (i : Fin G) (a : Fin T) (k q : Nat) (kl : k≤ell) (ql : q≤ell)
    {z : Nat} (lo : c.mark i a-k ≤ z) (hi : z ≤ c.mark i a+q) : z∈c.zone i := by
  apply (c.zone_iff i z).mpr
  have h := in_interval.mp (c.mark_in_slab i a).2
  omega

theorem Packed.all_zones_size (c : Packed xs base ell M d G T) :
    ((List.finRange G).flatMap c.zone).length ≤ G*(3*ell) := by
  have cap (l : List (Fin G)) : (l.flatMap c.zone).length ≤ l.length*(3*ell) := by
    induction l with
    | nil => simp
    | cons i l ih =>
      simpa [List.flatMap_cons,Nat.succ_mul,Nat.add_comm] using Nat.add_le_add (c.zone_size i) ih
  simpa using cap (List.finRange G)

/-- No disjoint-cell or guard-window assumptions are needed by clients. -/
theorem Packed.mark_injective (c : Packed xs base ell M d G T) (ellpos : 0<ell) :
    Function.Injective (fun p : Fin G × Fin T => c.mark p.1 p.2) := by
  rintro ⟨i,a⟩ ⟨j,b⟩ e
  change c.mark i a = c.mark j b at e
  have fi (i : Fin G) (a : Fin T) := c.covers_marker_window i a 0 0
    (Nat.zero_le _) (Nat.zero_le _) (z:=c.mark i a) (by omega) (by omega)
  have ij := c.zone_separate ellpos (c.mark i a) (fi i a) (e ▸ fi j b)
  subst j
  have ab : a = b := by
    apply Fin.ext
    by_cases h : a.val < b.val
    · have := c.ordered i h; omega
    · by_cases h' : b.val < a.val
      · have := c.ordered i h'; omega
      · omega
  subst b; rfl

end HWB.DensePacking
