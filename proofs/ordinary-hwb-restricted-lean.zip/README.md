# Ordinary hidden weighted bit: restricted-model Lean replay
This package replays the one-level upper and lower bounds and the sharp lower bound for two adjacent levels described in Sections 2 and 3 of the accompanying written manuscript. The two-level upper construction is proved in writing and is not an end-to-end Lean result in this package.

Use Python 3 and Lean 4.34.1. After extracting into an empty folder, run:

```sh
sha256sum -c SHA256SUMS
python3 replay.py --lean "$(elan which lean)"
```

Run Audit.lean through the driver. The printed theorems include `HWB.ordinary_HWB_certified` and `HWB.Exact.all_large_n`. The second concerns the exact two-level lower model; see the written proof for transfer to wire size.
