# SHWB all-width OBDD theorem: Lean replay

Use the Lean 4.34.1 toolchain pinned in `lean-toolchain`; no mathlib is required. From the extracted archive run:

```sh
sha256sum -c SHA256SUMS
python3 replay.py --lean lean --only AllGraphOrders
```

The replay rebuilds the 50 source modules in a clean temporary object directory. In `src/AllGraphOrders.lean`, `HWB.AllGraphOrders.optimal_all_widths` proves the exact finite power inequalities for the least legal OBDD size at every width. Its `#print axioms` reports the declaration's dependencies. The paired written proof derives the two-sided asymptotic rate; it need not use the finite constants chosen in Lean.
