import GraphScale

namespace HWB.AllGraphOrders
open HWB.Circuit HWB.ShiftedGraph HWB.ShiftedLower HWB.ShiftedUpper HWB.GraphScale

def canonical (N w:Nat):List Wire :=
  (List.range w).map Wire.output ++ ((List.range' 1 N).reverse.map Wire.data ++ [.penultimate,.last])

theorem canonical_perm (N w:Nat):(canonical N w).Perm (wires N w) :=
  List.perm_append_comm.trans (((List.reverse_perm (List.range' 1 N)).map Wire.data).append_right
    [.penultimate,.last] |>.append_right ((List.range w).map Wire.output))

private theorem inputs {N w:Nat} (x y:List Bool) (xl:x.length=N+2) (yl:y.length=w):
    input N (canonical N w) x y=ResidualCompiler.wordInput (y++x) :=by
  funext i
  unfold input canonical ResidualCompiler.wordInput
  by_cases out:i<w
  · simp [List.getElem?_append,out,yl,wireValue]
  · have no:i≥w:=by omega
    have q:((List.range w).map Wire.output).length=w:=by simp
    rw [List.getElem?_append_right (l₁:=(List.range w).map Wire.output) (by omega),List.getElem?_append_right (l₁:=y) (by omega),q,yl]
    let j:=i-w
    change (((((List.range' 1 N).reverse.map Wire.data)++[Wire.penultimate,Wire.last])[j]?).map _).getD false=(x[j]?).getD false
    by_cases free:j<N
    · have rev:j<(List.range' 1 N).length:=by simpa using free
      have f:N-1-j<N:=by omega
      have cap:j<((List.range' 1 N).reverse.map Wire.data).length:=by simpa using free
      rw [List.getElem?_append_left cap,List.getElem?_map,List.getElem?_reverse rev]
      simp [f,wireValue,atLabel,show N+1-(1+(N-1-j))=j+1 by omega]
    · have bound:((List.range' 1 N).reverse.map Wire.data).length≤j:=by simp;omega
      rw [List.getElem?_append_right bound]
      simp only [List.length_map,List.length_reverse,List.length_range']
      by_cases pen:j=N
      · simp [pen,wireValue,atLabel]
      by_cases last:j=N+1
      · simp [last,wireValue,atLabel]
      · have a:2≤j-N:=by omega
        have b:x.length≤j:=by omega
        rw [List.getElem?_eq_none b,List.getElem?_eq_none (by simpa using a : [Wire.penultimate,Wire.last].length≤j-N)]
        rfl

def legal (n w s:Nat):Prop :=
  match n with
  | 0=>False
  | 1=>∃ o:List Wire, o.Perm ([Wire.last]++(List.range w).map Wire.output) ∧
      ∃ (g:DAG s) (r:State s),∀ x y:List Bool,x.length=1 → y.length=w →
        (g.eval (fun i=>(o[i]?.map (fun v=> match v with
          | .output j=>y[j]?.getD false | _=>x[0]?.getD false)).getD false) r=true ↔ graph x y)
  | N+2=>∃ o:List Wire,o.Perm (wires N w) ∧ ∃(g:DAG s)(r:State s),∀ x y:List Bool,
      x.length=N+2 → y.length=w → (g.eval (input N o x y) r=true ↔ graph x y)

private theorem singleton (a b:Bool): graph [a] [b] ↔ b=false :=by
  constructor
  · intro yes;simpa [atLabel,Nat.mod_one] using yes 0 (by simp)
  · rintro rfl j h
    have eq:j=0:=by simpa using h
    simp [eq,atLabel,Nat.mod_one]

private theorem one_exact:legal 1 1 1 ∧ ¬legal 1 1 0:=by
  let g:DAG 1:={
    level:=fun _=>0
    child:=fun _ b=>.term (!b)
    drops:=by intro i b;simp [State.height]
    advances:=by intro i b j; simp}
  constructor
  · refine ⟨[.output 0,.last],?_,g,.node 0,?_⟩
    · exact List.Perm.swap _ _ _
    intro x y xl yl
    obtain ⟨a,rfl⟩:=List.length_eq_one_iff.mp xl
    obtain ⟨b,rfl⟩:=List.length_eq_one_iff.mp yl
    rw [singleton];cases b <;> simp [g,DAG.eval]
  · rintro ⟨o,_,dag,r,correct⟩
    have yes:=correct [false] [false] rfl rfl
    have no:=correct [false] [true] rfl rfl
    rw [singleton] at yes no
    cases r with
    | node i=>exact Fin.elim0 i
    | term b=>cases b <;> simp [DAG.eval] at yes no

private theorem least {p:Nat→Prop} (big:Nat) (ok:p big):
    ∃ b,p b ∧ ∀ a,p a → b≤a:=by
  induction big using Nat.strongRecOn with
  | ind big ih=>
    by_cases ex:∃ a,a<big ∧ p a
    · obtain ⟨a,lt,h⟩:=ex;exact ih a lt h
    · exact ⟨big,ok,fun a ha=>Nat.le_of_not_lt (fun lt=>ex ⟨a,lt,ha⟩)⟩

private theorem single_lower (k:Nat) (hk:2≤k):target 1 1≤(1+2)^k:=
  Nat.le_trans (by decide : target 1 1≤(1+2)^2) (Nat.pow_le_pow_right (by decide) hk)

/-- The same smallest graph and same vertex convention on both sides, at
every legal original width. The finitary power inequalities express the sharp
two-sided logarithmic rate, without a real-logarithm library. -/
theorem optimal_all_widths {n w:Nat} (wp:0<w) (wn:w≤n) :
    ∃ B, legal n w B ∧ (∀ s,legal n w s → B≤s) ∧
      target n w≤(B+2)^1073742208 ∧ B+2≤(target n w)^16 :=by
  cases n with
  | zero=>omega
  | succ n=>
    cases n with
    | zero=>
      have e:w=1:=by omega
      subst w
      refine ⟨1,one_exact.1,?_,?_,?_⟩
      · intro s hs
        by_cases h:s=0
        · exact False.elim (one_exact.2 (h ▸ hs))
        · omega
      · exact single_lower _ (by decide)
      · decide
    | succ N=>
      have dl (s) (ok:legal (N+2) w s):target (N+2) w≤(s+2)^1073742208:=by
        obtain ⟨o,perm,g,r,c⟩:=ok
        exact GraphScale.lower wp wn o perm g r c
      obtain ⟨g,r,correct⟩:=graph_upper (n:=N+2) wp wn
      have up:legal (N+2) w ((w+(N+2))*(2^w*states (N+2) w)):=by
        refine ⟨canonical N w,canonical_perm N w,g,r,?_⟩
        intro x y hx hy;rw [inputs x y hx hy];exact correct y x hy hx
      obtain ⟨B,leg,mn⟩:=least _ up
      exact ⟨B,leg,mn,dl B leg,Nat.le_trans (Nat.add_le_add_right (mn _ up) 2) (GraphScale.upper wp wn)⟩

#print axioms optimal_all_widths
end HWB.AllGraphOrders
