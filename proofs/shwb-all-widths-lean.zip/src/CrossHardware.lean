import CrossFamily

namespace HWB.CrossHardware
open HWB.Circuit HWB.ShiftedLower HWB.ShiftedGraph HWB.CrossLayout

/-- Splicing two complete positive assignments of a fixed-weight matching
produces the data word of one and the result word of the other. -/
private theorem splice {N w h:Nat} {o:List Wire} (perm:o.Perm (wires N w)) {lookup:Nat→Nat→Nat} (k:Layout N w h o lookup)
    (X Y:Fin (2^h)→List Bool)
    (xout:∀ i j a,a∉k.J.map (fun t=>lookup k.z t) → atLabel (X i) a=atLabel (X j) a)
    (yout:∀ i j t,t∉k.J → (Y i)[t]?=(Y j)[t]?) (i j:Fin (2^h)):
    join k.L.length (input N o (X i) (Y i)) (input N o (X j) (Y j)) =
      input N o (X (if k.dir then i else j)) (Y (if k.dir then j else i)) :=by
  let pick (b:Bool):=if b then i else j
  let isL:=fun t=>decide (t∈k.L)
  have localEq (t:Wire) (inO:t∈o) :
      wireValue N (X (pick (isL t))) (Y (pick (isL t))) t =
      wireValue N (X (pick k.dir)) (Y (pick (!k.dir))) t:=by
    have xbit (a:Nat) (key:physical N a=t):
        atLabel (X (pick (isL t))) a=atLabel (X (pick k.dir)) a :=by
      by_cases sel:a∈k.J.map (fun t=>lookup k.z t)
      · obtain ⟨r,hr,eq⟩:=List.mem_map.mp sel
        have col:= (k.pair r hr).2.2.2.1
        rw [eq,key] at col
        change atLabel (X (pick (decide (t∈k.L)))) _=_
        rw [col]
      · exact xout _ _ _ sel
    cases t with
    | data l=>
      have inside:=perm.mem_iff.mp inO
      simp [wires,List.mem_range'_1] at inside
      apply xbit (N+1-l)
      simp [physical,show N+1-l≠N+2 by omega,show N+1-l≠N+1 by omega,show N+1-(N+1-l)=l by omega]
    | penultimate=>exact xbit _ (by simp [physical])
    | last=>exact xbit _ (by simp [physical])
    | output a=>
      by_cases sel:a∈k.J
      · have eq: isL (Wire.output a)= !k.dir:=(k.pair a sel).2.2.2.2
        simp only [eq,wireValue]
      · exact congrArg (fun x:Option Bool=>x.getD false) (yout _ _ a sel)
  have negpick:pick (!k.dir)=(if k.dir then j else i):=by cases k.dir <;> rfl
  funext p
  cases atP:o[p]? with
  | none=>simp [join,input,atP]
  | some t=>
    have ino:=List.mem_of_getElem? atP
    have eq:=localEq t ino
    have ds:=List.nodup_append.mp (k.cut ▸ CrossLayout.nodup perm)
    by_cases early:p<k.L.length
    · have hleft:k.L[p]?=some t:=by simpa [k.cut,List.getElem?_append_left early] using atP
      have yes:isL t=true:=by simp [isL,List.mem_of_getElem? hleft]
      rw [yes,negpick] at eq
      simpa [join,input,atP,early,pick] using eq
    · have outside:p≥k.L.length:=by omega
      have hright:k.R[p-k.L.length]?=some t:=by simpa [k.cut,List.getElem?_append_right outside] using atP
      have nt:t∉k.L:=fun m=>ds.2.2 _ m _ (List.mem_of_getElem? hright) rfl
      have no:isL t=false:=by simp [isL,nt]
      rw [no,negpick] at eq
      simpa [join,input,atP,early,pick] using eq

theorem table_output_lower (lookup:Nat→Nat→Nat) {N w s:Nat} (width:w≤N+2) (o:List Wire) (perm:o.Perm (wires N w))
    (g:DAG s) (root:State s)
    (covers:∀j,j<w → ∀a,0<a → a<N+2 → ∃ z,z<N+2 ∧ lookup z j=a)
    (distinct:∀z,z<N+2 → ∀i j,i<w → j<w → lookup z i=lookup z j → i=j)
    (correct:∀ x y:List Bool,x.length=N+2 → y.length=w →
      (g.eval (input N o x y) root=true ↔ CrossFamily.tableGraph lookup x y)) : 2^(w/64)≤s+2 :=by
  let h:=w/64
  by_cases zero:h=0
  · change 2^h≤s+2;simp [zero]
  obtain ⟨k⟩:=placement lookup (h:=h) o perm covers width (by omega) (by
    dsimp [h];rw [Nat.mul_comm];exact Nat.div_mul_le_self ..)
  obtain ⟨X,Y,sz,diag,xout,yout⟩:=CrossFamily.family lookup (distinct k.z (by have :=k.far;omega)) k.J k.nod k.len k.near k.far
    (fun j hj=>⟨(k.pair j hj).1,(k.pair j hj).2.1,(k.pair j hj).2.2.1⟩)
  let a:=fun i=>input N o (X i) (Y i)
  apply g.width_lower root k.L.length a
  intro i j ne
  have spec (u v:Fin (2^h)):
      g.eval (join k.L.length (a u) (a v)) root=true ↔ u=v:=by
    dsimp [a]
    rw [splice perm k X Y xout yout]
    cases k.dir <;> simp only [Bool.false_eq_true,ite_false,ite_true]
    · exact (correct _ _ (sz v).1 (sz u).2).trans ((diag v u).trans eq_comm)
    · exact (correct _ _ (sz u).1 (sz v).2).trans (diag u v)
  refine ⟨a i,?_⟩
  intro eq
  have yes:=(spec i i).mpr rfl
  rw [eq] at yes
  exact ne ((spec j i).mp yes).symm
theorem graph_output_lower {N w s:Nat} (width:w≤N+2) (o:List Wire) (perm:o.Perm (wires N w))
    (g:DAG s) (root:State s)
    (correct:∀ x y:List Bool,x.length=N+2 → y.length=w →
      (g.eval (input N o x y) root=true ↔ graph x y)) : 2^(w/64)≤s+2 :=by
  apply table_output_lower (fun z j=>(z+j)%(N+2)) width o perm g root
  · exact fun j hj a _ ha=>CrossCount.rotate_cover ha (Nat.lt_of_lt_of_le hj width)
  · exact fun _ _ _ _ hi hj=>CrossFamily.rotate_inj (Nat.lt_of_lt_of_le hi width) (Nat.lt_of_lt_of_le hj width)
  · intro x y hx hy
    simpa only [graph,CrossFamily.tableGraph,hx] using correct x y hx hy

#print axioms table_output_lower
#print axioms graph_output_lower
end HWB.CrossHardware
