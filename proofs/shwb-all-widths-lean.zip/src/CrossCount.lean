import Std

namespace HWB.CrossCount

private def mass (rows cols:List Nat) (p:Nat→Nat→Bool):Nat :=
  (rows.map (fun i=>(cols.filter (p i)).length)).sum

private theorem add_column (rows cols:List Nat) (p:Nat→Nat→Bool) (j:Nat) :
    mass rows (j::cols) p=(rows.filter (fun i=>p i j)).length+mass rows cols p := by
  induction rows with
  | nil=>simp [mass]
  | cons a r ih=>
    cases h:p a j <;> simp [mass,List.filter_cons,h] at ih ⊢ <;> omega

private theorem transpose (rows cols:List Nat) (p:Nat→Nat→Bool) :
    mass rows cols p=mass cols rows (fun j i=>p i j) :=by
  induction cols with
  | nil=>induction rows with
    | nil=>rfl
    | cons a rows ih=>simp [mass] at ih ⊢; exact ih
  | cons j c ih=>rw [add_column,ih];rfl

private theorem mass_lo (rows cols:List Nat) (p:Nat→Nat→Bool) (k:Nat)
    (h:∀ i∈rows,k≤(cols.filter (p i)).length) : rows.length*k≤mass rows cols p :=by
  induction rows with
  | nil=>simp [mass]
  | cons a r ih=>
    have ha:=h a (by simp)
    have hr:=ih (fun i hi=>h i (by simp [hi]))
    simp [mass,Nat.succ_mul] at hr ⊢;omega

private theorem mass_hi (rows cols:List Nat) (p:Nat→Nat→Bool) (k:Nat)
    (h:∀ i∈rows,(cols.filter (p i)).length≤k) : mass rows cols p≤rows.length*k :=by
  induction rows with
  | nil=>simp [mass]
  | cons a r ih=>
    have ha:=h a (by simp)
    have hr:=ih (fun i hi=>h i (by simp [hi]))
    simp [mass,Nat.succ_mul] at hr ⊢;omega

def good (lookup:Nat→Nat→Nat) (n h:Nat) (A:List Nat) (z j:Nat):Bool :=
  decide (h≤z ∧ z+h≤n ∧ lookup z j∈A)

private theorem per_offset (lookup:Nat→Nat→Nat) {n h j:Nat} {A:List Nat} (covers:∀a∈A,∃z,z<n ∧ lookup z j=a) (hw:64*h≤n)
    (nd:A.Nodup) (many:n≤2*A.length+2) (_wide:0<h) :
    n/4 ≤ ((List.range n).filter (fun z=>good lookup n h A z j)).length :=by
  let Z:=(List.range n).filter (fun z=>good lookup n h A z j)
  let bad:=List.range h ++ List.range' (n-h) h
  have incl:A⊆(Z++bad).map (fun z=>lookup z j) :=by
    intro a ha
    obtain ⟨z,zl,eq⟩:=covers a ha
    refine List.mem_map.mpr ⟨z,?_,eq⟩
    by_cases valid:h≤z ∧ z+h≤n
    · exact List.mem_append_left _ (List.mem_filter.mpr ⟨List.mem_range.mpr zl,by simp [good,valid,eq,ha]⟩)
    · apply List.mem_append_right
      by_cases early:z<h
      · exact List.mem_append_left _ (List.mem_range.mpr early)
      · apply List.mem_append_right
        rw [List.mem_range'_1];omega
  have est:=nd.length_le_of_subset incl
  simp only [List.length_map,List.length_append,bad,List.length_range,List.length_range'] at est
  change n/4≤Z.length
  omega

/-- A side containing at least half of the real lookup sites, and the opposite
half of the outputs, have 2h disjoint matches at ONE attainable central weight. -/
theorem find_table (lookup:Nat→Nat→Nat) {n w h:Nat} (A Y:List Nat) (wn:w≤n) (hn:0<h) (small:64*h≤w)
    (nd:A.Nodup) (covers:∀j∈Y,∀a∈A,∃z,z<n ∧ lookup z j=a) (many:n≤2*A.length+2)
    (yd:Y.Nodup) (ym:w/2≤Y.length) :
    ∃ (z:Nat) (J:List Nat), h≤z ∧ z+h≤n ∧ J.Nodup ∧ J.length=2*h ∧
      ∀ j∈J,j∈Y ∧ lookup z j∈A :=by
  let R:=List.range n
  let p:=good lookup n h A
  have lower:=mass_lo Y R (fun j z=>p z j) (n/4) (fun j hj=>
    per_offset lookup (covers j hj) (by omega) nd many hn)
  rw [transpose] at lower
  have scale: n*(2*h)≤Y.length*(n/4) :=by
    have step:=Nat.mul_le_mul (show n≤8*(n/4) by omega) (show 2*h≤2*h by omega)
    have eq:(8*(n/4))*(2*h)=(16*h)*(n/4):=by
      calc _=(8*2)*h*(n/4):=by ac_rfl
           _=_:=rfl
    rw [eq] at step
    exact Nat.le_trans step (Nat.mul_le_mul_right _ (by omega))
  have ex:∃ z∈R,2*h≤(Y.filter (p z)).length:=by
    apply Classical.byContradiction
    intro no
    have upper:=mass_hi R Y p (2*h-1) (fun i hi=>by
      have bad:¬2*h≤(Y.filter (p i)).length:=fun e=>no ⟨i,hi,e⟩;omega)
    have ne:n*(2*h-1)<n*(2*h):=Nat.mul_lt_mul_of_pos_left (by omega) (by omega)
    change Y.length*(n/4)≤mass R Y p at lower
    simp only [R,List.length_range] at upper
    dsimp [R] at lower
    omega
  obtain ⟨z,hz,cap⟩:=ex
  let J:=(Y.filter (p z)).take (2*h)
  have len:J.length=2*h:=List.length_take_of_le cap
  have spec (j) (hj:j∈J) : j∈Y ∧ h≤z ∧ z+h≤n ∧ lookup z j∈A :=by
    have mem:=List.mem_filter.mp (List.take_subset _ _ hj : j∈Y.filter (p z))
    exact ⟨mem.1,of_decide_eq_true mem.2⟩
  have pos:0<J.length:=by omega
  have first:=spec J[0] (List.getElem_mem ..)
  exact ⟨z,J,first.2.1,first.2.2.1,(yd.filter _).sublist (List.take_sublist ..),len,
    fun j hj=>⟨(spec j hj).1,(spec j hj).2.2.2⟩⟩
/-- Translation hits every address during one full cycle. -/
theorem rotate_cover {n a j:Nat} (an:a<n) (jh:j<n) :∃ z,z<n ∧ (z+j)%n=a:=by
  let z:=if j≤a then a-j else n+a-j
  refine ⟨z,by dsimp [z];split <;> omega,?_⟩
  dsimp [z];split
  · rw [show a-j+j=a by omega,Nat.mod_eq_of_lt an]
  · rw [show n+a-j+j=n+a by omega,Nat.add_mod_left,Nat.mod_eq_of_lt an]

#print axioms find_table
end HWB.CrossCount
