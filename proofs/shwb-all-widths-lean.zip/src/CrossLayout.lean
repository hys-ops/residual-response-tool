import CrossCount
import ShiftedLower

namespace HWB.CrossLayout
open HWB.ShiftedLower

def physical (N a:Nat):Wire :=
  if a=N+2 then .last else if a=N+1 then .penultimate else .data (N+1-a)

def outId : Wire→Option Nat
  | .output j=>some j | _=>none

private theorem extract {N w:Nat} {o:List Wire} (perm:o.Perm (wires N w)):
    (o.filterMap outId).Perm (List.range w) :=by
  have empty (s:List Nat): s.filterMap (fun _=>(none:Option Nat))=[]:=by
    induction s with
    | nil=>rfl
    | cons a s ih=>exact ih
  simpa [wires,List.filterMap_append,List.filterMap_map,List.filterMap_cons,Function.comp_def,outId,empty] using perm.filterMap outId

theorem nodup {N w:Nat} {o:List Wire} (perm:o.Perm (wires N w)):o.Nodup:=by
  apply perm.nodup_iff.mpr
  have data:((List.range' 1 N).map Wire.data).Nodup:=((List.nodup_range' : (List.range' 1 N).Nodup)).map (f:=Wire.data) (fun _ _ ne eq=>ne (Wire.data.inj eq))
  have out:((List.range w).map Wire.output).Nodup:=(List.nodup_range).map (f:=Wire.output) (fun _ _ ne eq=>ne (Wire.output.inj eq))
  simp [wires,List.nodup_append,data,out]
  rintro a x _ _ rfl; simp

private theorem split_at (o:List Wire) (k:Nat) (room:k≤(o.filterMap outId).length):
    ∃ L R, o=L++R ∧ (L.filterMap outId).length=k:=by
  induction o generalizing k with
  | nil=>simp at room;exact ⟨[],[],rfl,by simp [room]⟩
  | cons a o ih=>
    by_cases zero:k=0
    · exact ⟨[],a::o,rfl,by simp [zero]⟩
    cases e:outId a with
    | none=>
      obtain ⟨L,R,eq,sz⟩:=ih k (by simpa [List.filterMap_cons,e] using room)
      exact ⟨a::L,R,by simp [eq],by simpa [List.filterMap_cons,e] using sz⟩
    | some j=>
      have rk:=room
      simp [e] at rk
      obtain ⟨L,R,eq,sz⟩:=ih (k-1) (by omega)
      exact ⟨a::L,R,by simp [eq],by simp [e,sz];omega⟩

private theorem mem_output {j:Nat} {L:List Wire} : j∈L.filterMap outId ↔ Wire.output j∈L :=by
  constructor
  · intro h
    obtain ⟨a,ha,eq⟩:=List.mem_filterMap.mp h
    cases a <;> simp [outId] at eq
    simpa [eq] using ha
  · intro h;exact List.mem_filterMap.mpr ⟨_,h,rfl⟩

private theorem colour_total (S:List Nat) (f:Nat→Bool) :
    (S.filter f).length+(S.filter (fun j=>!(f j))).length=S.length:=by
  induction S with
  | nil=>rfl
  | cons a S ih=>cases h:f a <;> simp [h] <;> omega

structure Layout (N w h:Nat) (o:List Wire) (lookup:Nat→Nat→Nat) where
  L : List Wire
  R : List Wire
  cut : o=L++R
  dir : Bool
  z : Nat
  near : h≤z
  far : z+h≤N+2
  J : List Nat
  nod : J.Nodup
  len : J.length=2*h
  pair : ∀ j∈J, j<w ∧ 0<lookup z j ∧ lookup z j<N+2 ∧
    decide (physical N (lookup z j)∈L)=dir ∧ decide (Wire.output j∈L)=!dir

theorem placement (lookup:Nat→Nat→Nat) {N w h:Nat} (o:List Wire) (perm:o.Perm (wires N w))
    (covers:∀j,j<w → ∀a,0<a → a<N+2 → ∃ z,z<N+2 ∧ lookup z j=a)
    (width:w≤N+2) (hp:0<h) (room:64*h≤w) : Nonempty (Layout N w h o lookup) :=by
  have po:=extract perm
  have sz: (o.filterMap outId).length=w:=po.length_eq.trans (by simp)
  obtain ⟨L,R,cut,half⟩:=split_at o (w/2) (by omega)
  have sp:(L.filterMap outId++R.filterMap outId).Perm (List.range w):=by simpa [cut] using po
  have nd:=List.nodup_append.mp (sp.nodup_iff.mpr List.nodup_range)
  have card:=sp.length_eq
  simp at card
  let X:=List.range' 1 (N+1)
  let left:=fun v=>decide (physical N v∈L)
  have parts:=colour_total X left
  have xl:X.length=N+1:=by simp [X]
  let b:=decide ((X.filter (fun j=>!(left j))).length≤(X.filter left).length)
  let A:=X.filter (fun v=>left v==b)
  let Y:=if b then R.filterMap outId else L.filterMap outId
  have many:N+2≤2*A.length+2:=by
    by_cases yes:(X.filter (fun j=>!(left j))).length≤(X.filter left).length
    · have eq:A=X.filter left:=by simp [A,b,yes]
      rw [eq];omega
    · have eq:A=X.filter (fun j=>!(left j)):=by simp [A,b,yes]
      rw [eq];omega
  have sy:w/2≤Y.length:=by dsimp [Y];split <;> omega
  have prop (j) (hj:j∈Y): j<w ∧ decide (Wire.output j∈L)=!b:=by
    have sep:=List.nodup_append.mp (cut ▸ nodup perm)
    cases eb:b with
    | false=>
      have mem:j∈L.filterMap outId:=by simpa [Y,eb] using hj
      have jm:=sp.mem_iff.mp (List.mem_append_left _ mem)
      exact ⟨List.mem_range.mp jm,by simp [mem_output.mp mem]⟩
    | true=>
      have mem:j∈R.filterMap outId:=by simpa [Y,eb] using hj
      have jm:=sp.mem_iff.mp (List.mem_append_right _ mem)
      have outside:Wire.output j∉L:=fun m=>sep.2.2 _ m _ (mem_output.mp mem) rfl
      exact ⟨List.mem_range.mp jm,by simp [outside]⟩
  have ax (v) (hv:v∈A):1≤v ∧ v<N+2 ∧ left v=b:=by
    have hv':=List.mem_filter.mp hv
    have xi:=List.mem_range'_1.mp hv'.1
    exact ⟨xi.1,by omega,beq_iff_eq.mp hv'.2⟩
  have yn:Y.Nodup:=by dsimp [Y];split <;> first | exact nd.1 | exact nd.2.1
  obtain ⟨z,J,lo,hi,jn,jl,js⟩:=CrossCount.find_table lookup A Y width hp room ((List.nodup_range' : X.Nodup).filter _)
    (fun j hj a ha=>covers j (prop j hj).1 a (ax a ha).1 (ax a ha).2.1) many yn sy
  refine ⟨⟨L,R,cut,b,z,lo,hi,J,jn,jl,?_⟩⟩
  intro j hj
  have jp:=prop j (js j hj).1
  have ap:=ax _ (js j hj).2
  exact ⟨jp.1,ap.1,ap.2.1,ap.2.2,jp.2⟩

#print axioms placement
end HWB.CrossLayout
