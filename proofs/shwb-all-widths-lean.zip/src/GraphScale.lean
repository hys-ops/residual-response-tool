import CrossHardware
import ShiftedWindowRate

namespace HWB.GraphScale
open HWB.Circuit HWB.ShiftedLower HWB.ShiftedGraph HWB.ShiftedUpper

def target (n w:Nat) := 2^w*(w+1)^(n/w)

private theorem pow2 (w:Nat) : w+1≤2^w:=by
  induction w with
  | zero=>decide
  | succ w ih=>rw [Nat.pow_succ];omega

theorem lower {N w s:Nat} (wp:0<w) (wn:w≤N+2) (o:List Wire) (perm:o.Perm (wires N w))
    (g:DAG s) (root:State s) (correct:∀ x y:List Bool,x.length=N+2 → y.length=w →
      (g.eval (input N o x y) root=true ↔ graph x y)):
    target (N+2) w≤(s+2)^1073742208 :=by
  have free:=CrossHardware.graph_output_lower wn o perm g root correct
  have ww:w≤(w/64+1)*64:=by omega
  have fe:2^(w/64+1)≤(s+2)^2:=by
    rw [Nat.pow_succ,Nat.pow_two]
    exact Nat.mul_le_mul free (by omega)
  have high:2^w≤(s+2)^128:=by
    apply Nat.le_trans (Nat.pow_le_pow_right (by decide : 0<2) ww)
    rw [Nat.pow_mul,show 128=2*64 by decide,Nat.pow_mul (s+2)]
    exact Nat.pow_le_pow_left fe _
  have low:(w+1)^(N/w)≤(s+2)^1073741824:=by
    by_cases h:w≤N
    · exact graph_data_lower (s:=s) wp h o perm g root correct
    · rw [Nat.div_eq_of_lt (by omega),Nat.pow_zero]
      exact Nat.pow_pos (by omega)
  have dl:(N+2)/w≤N/w+2:=by
    have e:=Nat.div_le_div_right (c:=w) (show N+2≤N+2*w by omega)
    simpa [Nat.add_mul_div_right _ _ wp] using e
  have extra:=Nat.pow_le_pow_left (Nat.le_trans (pow2 w) high) 2
  calc target (N+2) w ≤ 2^w*(w+1)^(N/w+2) :=
           Nat.mul_le_mul_left _ (Nat.pow_le_pow_right (by omega) dl)
       _ = 2^w*((w+1)^(N/w)*(w+1)^2) := by rw [Nat.pow_add]
       _ ≤ (s+2)^128*((s+2)^1073741824*((s+2)^128)^2) :=
           Nat.mul_le_mul high (Nat.mul_le_mul low extra)
       _ = (s+2)^(128+(1073741824+128*2)) := by
           rw [Nat.pow_add,Nat.pow_add (s+2) 1073741824,Nat.pow_mul]
       _ = _ := rfl

theorem upper {n w:Nat} (wp:0<w) (wn:w≤n):
    (w+n)*(2^w*states n w)+2≤(target n w)^16 :=by
  let m:=w+n
  let A:=1+w*(w+1)/2
  let R:=n/w
  have rp:1≤R:=(Nat.le_div_iff_mul_le wp).mpr (by simpa using wn)
  have md:m/w≤2*R:=by
    have e:m/w=R+1:=by dsimp [m,R];rw [Nat.add_comm,Nat.add_div_right _ wp]
    omega
  have cell:cells n w≤m/w:=Nat.div_le_div_right (c:=w) (show n+w-1≤m by dsimp [m];omega)
  have cap:n+1≤(m+1)*(w+1):=by
    have h:=Nat.mul_le_mul_left (m+1) (show 1≤w+1 by omega)
    simp only [Nat.mul_one] at h; dsimp [m] at *;omega
  have inside:states n w≤(m+1)*(w+1)*A^(m/w):=
    Nat.mul_le_mul cap (Nat.pow_le_pow_right (by change 0<1+w*(w+1)/2;omega) cell)
  have co:=Nat.mul_le_mul_left (2^w) (Nat.mul_le_mul_left m inside)
  have ab:=PatternRate.upper_scale wp (show w≤m by dsimp [m];omega)
  have cost:m*(2^w*states n w)+2≤2^w*(w+1)^(8*(m/w)):=by
    apply Nat.le_trans _ (Nat.mul_le_mul_left (2^w) ab)
    rw [Nat.mul_add,show m*(2^w*states n w)=2^w*(m*states n w) by ac_rfl]
    exact Nat.add_le_add co (Nat.mul_le_mul_right 2 (Nat.pow_pos (by decide)))
  apply Nat.le_trans cost
  rw [target,Nat.mul_pow]
  apply Nat.mul_le_mul
  · simpa using (Nat.pow_le_pow_right (n:=2^w) (Nat.pow_pos (by decide)) (by decide:1≤16))
  · rw [←Nat.pow_mul];apply Nat.pow_le_pow_right (by omega);change 8*(m/w)≤R*16;omega
#print axioms lower
#print axioms upper
end HWB.GraphScale
