import ShiftedLower
import CrossLayout

namespace HWB.CrossFamily
open HWB.ShiftedGraph HWB.WordSupport

/-- Different offsets in a single rotation read different physical addresses. -/
theorem rotate_inj {n z i j:Nat} (hi:i<n) (hj:j<n)
    (eq:(z+i)%n=(z+j)%n) : i=j :=by
  have zp:=Nat.mod_lt z (by omega:0<n)
  rw [Nat.add_mod_eq_sub,Nat.add_mod_eq_sub,Nat.mod_eq_of_lt hi,Nat.mod_eq_of_lt hj] at eq
  split at eq <;> split at eq <;> omega

private theorem count_support (n:Nat) (s:List Nat) (nd:s.Nodup) (sub:s⊆List.range' 1 n):
    (dense n s).count true=s.length:=by
  let bank:=List.range' 1 n
  let ones:=bank.filter (fun j=>decide (j∈s))
  have a:ones⊆s:=fun _ h=>of_decide_eq_true (List.mem_filter.mp h).2
  have b:s⊆ones:=fun j hj=>List.mem_filter.mpr ⟨sub hj,decide_eq_true hj⟩
  have d:ones.Nodup:=List.Pairwise.filter _ List.nodup_range'
  have eq:=Nat.le_antisymm (d.length_le_of_subset a) (nd.length_le_of_subset b)
  rw [dense,List.count_eq_countP,List.countP_map,List.countP_eq_length_filter]
  simpa [ones,bank,Function.comp_def] using eq

theorem read_dense {n a:Nat} {s:List Nat} (sub:s⊆List.range' 1 n):
    atLabel (dense n s) a=decide (a∈s) :=by
  by_cases ha:1≤a ∧ a≤n
  · have ix:a-1<n:=by omega
    simp [atLabel,dense,show a≠0 by omega,ix,show 1+(a-1)=a by omega]
  · have no:a∉s:=fun h=>by have :=List.mem_range'_1.mp (sub h);omega
    by_cases z:a=0
    · simp [atLabel,z] at *
      exact no
    · have past:n≤a-1:=by omega
      simp [atLabel,dense,no,z,List.getElem?_eq_none (by simpa using past : (List.range' 1 n).length≤a-1)]

/-- An h-bit message occupies a support of weight z. Only labels in A vary
and the first h designated labels in A recover the message, in their given order. -/
theorem encode {n h z:Nat} (A:List Nat) (nd:A.Nodup) (len:A.length=2*h)
    (domain:A⊆List.range' 1 n) (lo:h≤z) (hi:z+h≤n) :
    ∃ X: Fin (2^h)→List Bool,
      (∀ i,(X i).length=n ∧ (X i).count true=z) ∧
      (∀ i j a,a∉A → atLabel (X i) a=atLabel (X j) a) ∧
      (∀ i j,(∀ a∈A,atLabel (X i) a=atLabel (X j) a) → i=j) :=by
  let T:=A.take h
  have tlen:T.length=h:=List.length_take_of_le (by omega)
  have td:T.Nodup:=nd.sublist (List.take_sublist ..)
  let E:=(List.range' 1 n).filter (fun a=>decide (a∉A))
  have full:List.range' 1 n⊆A++E:=by
    intro a ha
    by_cases h:a∈A <;> simp [E,h,ha]
  have size: n≤A.length+E.length:=by
    simpa using (List.nodup_range' : (List.range' 1 n).Nodup).length_le_of_subset full
  let pad:=E.take (z-h)
  have plen:pad.length=z-h:=List.length_take_of_le (by omega)
  have pd:pad.Nodup:=((List.nodup_range' : (List.range' 1 n).Nodup).filter _).sublist (List.take_sublist ..)
  have ps (a) (ha:a∈pad):a∈List.range' 1 n ∧ a∉A:=by
    have hv:=List.mem_filter.mp (List.take_subset _ _ ha : a∈E)
    exact ⟨hv.1,of_decide_eq_true hv.2⟩
  let value (v:Fin (2^h)) (a:Nat):=v.val.testBit (T.idxOf a)
  let inner (v:Fin (2^h)):=Balanced.fill A T h (value v)
  have inside (v:Fin (2^h)):=Balanced.fill_spec (a:=h) (value v) nd td (List.take_subset _ _)
    (by omega) (by omega)
  let supp (v:Fin (2^h)):=inner v++pad
  have snd (v:Fin (2^h)):(supp v).Nodup:=List.nodup_append.mpr
    ⟨(inside v).1.1,pd,fun a ha b hb e=>(ps b hb).2 (e ▸ (inside v).1.2 ha)⟩
  have sb (v:Fin (2^h)):supp v⊆List.range' 1 n:=fun a ha=>
    (List.mem_append.mp ha).elim (fun h=>domain ((inside v).1.2 h)) (fun h=>(ps a h).1)
  let X:=fun v=>dense n (supp v)
  refine ⟨X,?_,?_,?_⟩
  · intro v
    refine ⟨by simp [X,dense],?_⟩
    rw [show (X v).count true=(supp v).length from count_support n _ (snd v) (sb v)]
    have wgt:(inner v).length=h:=(inside v).2.1
    simp only [supp,List.length_append,wgt,plen];omega
  · intro i j a ha
    have out (v):a∉inner v:=fun e=>ha ((inside v).1.2 e)
    simp [X,read_dense (sb _),supp,out]
  · intro i j agree
    apply Fin.ext
    apply Nat.eq_of_testBit_eq
    intro k
    by_cases hk:k<h
    · have kt:k<T.length:=by omega
      let a:=T[k]
      have atT:a∈T:=List.getElem_mem kt
      have atA:a∈A:=List.take_subset _ _ atT
      have np:a∉pad:=fun e=>(ps _ e).2 atA
      have decode (v):atLabel (X v) a=v.val.testBit k:=by
        rw [show atLabel (X v) a=decide (a∈supp v) from read_dense (sb v)]
        apply Bool.eq_iff_iff.mpr
        simp only [supp,List.mem_append,np,or_false,decide_eq_true_eq]
        have eq:T.idxOf a=k:=td.idxOf_getElem k kt
        simpa [value,inner,eq] using (inside v).2.2 a atT
      rw [←decode i,←decode j];exact agree a atA
    · have lim:=Nat.pow_le_pow_right (n:=2) (by decide) (Nat.le_of_not_lt hk)
      rw [Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le i.isLt lim),Nat.testBit_lt_two_pow (Nat.lt_of_lt_of_le j.isLt lim)]

/-- The graph restricted to these assignments is equality; changing messages
can only alter the selected original data wires and their matched output wires. -/
def tableGraph (lookup:Nat→Nat→Nat) (x y:List Bool):Prop :=
  ∀ j,(hj:j<y.length) → y[j]=atLabel x (lookup (x.count true) j)

theorem family (lookup:Nat→Nat→Nat) {n w h z:Nat}
    (inj:∀ i j,i<w → j<w → lookup z i=lookup z j → i=j) (J:List Nat) (nd:J.Nodup) (len:J.length=2*h)
    (lo:h≤z) (hi:z+h≤n) (valid:∀ j∈J,j<w ∧ 0<lookup z j ∧ lookup z j<n) :
    ∃ X Y:Fin (2^h)→List Bool,
     (∀ i,(X i).length=n ∧ (Y i).length=w) ∧
     (∀ i j,tableGraph lookup (X i) (Y j) ↔ i=j) ∧
     (∀ i j a,a∉J.map (fun t=>lookup z t) → atLabel (X i) a=atLabel (X j) a) ∧
     (∀ i j t,t∉J → (Y i)[t]?=(Y j)[t]?) :=by
  let f:=lookup z
  let A:=J.map f
  have ad:A.Nodup:=by
    exact List.pairwise_map.mpr (nd.imp_of_mem (fun {a b} ha hb ne eq=>
      ne (inj a b (valid a ha).1 (valid b hb).1 eq)))
  have sub:A⊆List.range' 1 n:=by
    intro a ha
    obtain ⟨j,jm,rfl⟩:=List.mem_map.mp ha
    have vl:=valid j jm
    rw [List.mem_range'_1];exact ⟨vl.2.1,by dsimp [f];omega⟩
  obtain ⟨X,sz,out,read⟩:=encode A ad (by simp [A,len]) sub lo hi
  let Y:=fun (v:Fin (2^h))=>(List.range w).map (fun j=>atLabel (X v) (f j))
  have yl (v):(Y v).length=w:=by simp [Y]
  have bit (v) (j) (hj:j<w):(Y v)[j]?=some (atLabel (X v) (f j)):=by simp [Y,hj]
  have diag (i j) : tableGraph lookup (X i) (Y j) ↔ i=j:=by
    constructor
    · intro ok
      apply read i j
      intro a ha
      obtain ⟨t,ht,rfl⟩:=List.mem_map.mp ha
      have tw:=(valid t ht).1
      have htl:t<(Y j).length:=by rw [yl];exact tw
      have eq:=ok t htl
      have bybit:=bit j t tw
      rw [List.getElem?_eq_getElem htl] at bybit
      simpa [f,(sz i).2,Option.some.inj bybit] using eq.symm
    · rintro rfl t ht
      have tw:t<w:=by simpa [yl] using ht
      have e:=bit i t tw
      rw [List.getElem?_eq_getElem ht] at e
      simpa [f,(sz i).2] using Option.some.inj e
  refine ⟨X,Y,fun i=>⟨(sz i).1,yl i⟩,diag,out,?_⟩
  intro i j t nt
  by_cases tw:t<w
  · rw [bit i t tw,bit j t tw]
    apply congrArg some
    apply out
    intro hm
    obtain ⟨b,hb,eq⟩:=List.mem_map.mp hm
    have e:b=t:=inj b t (valid b hb).1 tw eq
    exact nt (e ▸ hb)
  · simp [Y,show w≤t by omega]
#print axioms family
end HWB.CrossFamily
