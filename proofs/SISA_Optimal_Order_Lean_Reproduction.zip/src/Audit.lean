import OptimalOrder
#check @SISA.Rate.optimal_rate
#check @SISA.Rate.optimal_sandwich
#check @SISA.Rate.sharp_upper
#check @SISA.Rate.superpolynomial
#check @SISA.Rate.superpolynomial_total
#print SISA.Rate.realizes
#print SISA.Rate.correct
#print axioms SISA.Rate.optimal_rate
#print axioms SISA.Rate.optimal_sandwich
#print axioms SISA.Rate.sharp_upper
#print axioms SISA.Rate.sharp_lower
#print axioms SISA.Rate.superpolynomial
#print axioms SISA.Rate.superpolynomial_total
