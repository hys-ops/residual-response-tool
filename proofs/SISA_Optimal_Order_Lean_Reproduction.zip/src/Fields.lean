import LateLayer
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

def options : Option Bool→List Bool
  | none=>[false,true]
  | some v=>[v]

def free (xs:List (Option Bool)):Nat:=(xs.filter Option.isNone).length

theorem option_count (l:List (Option Bool)):(rows options l).length=2^(free l):=by
  rw [rows_length]
  induction l with
  | nil=>simp [free]
  | cons a l ih=>cases a <;> simp [options,free,Nat.pow_succ,Nat.mul_comm,free] at ih ⊢ <;> omega

theorem constraints_mem (l:List (Option Bool)) (v:List Bool) (len:v.length=l.length)
    (ok:∀ i (hi:i<l.length),v[i]'(by omega)∈options l[i]):
    v∈rows options l:=by
  induction l generalizing v with
  | nil=>simp at len;simp [len,rows]
  | cons a l ih=>
    cases v with
    | nil=>simp at len
    | cons x xs=>
      have hx:=ok 0 (by simp)
      apply List.mem_flatMap.mpr;refine ⟨x,hx,List.mem_map.mpr ⟨xs,ih _ (by simpa using len) ?_,rfl⟩⟩
      intro i hi;apply ok (i+1) (by simpa using hi)

def mask (rank:Nat→Nat) (n Y j start len:Nat) (z:List Bool):List (Option Bool):=
  List.ofFn fun i:Fin len=>if rank ((Y+(start+i.val))%n)<j then some (get z (start+i.val)) else none

def knownCount (rank:Nat→Nat) (n Y j start len:Nat):Nat:=
  ((List.finRange len).filter (fun i=>decide (rank ((Y+(start+i.val))%n)<j))).length

theorem count_free (rank:Nat→Nat) (n Y j start len:Nat) (z:List Bool):
    free (mask rank n Y j start len z)+knownCount rank n Y j start len=len:=by
  let pred:=fun i:Fin len=>decide (rank ((Y+(start+i.val))%n)<j)
  have count (l:List (Fin len)):
      free (l.map (fun i=>if pred i then some (get z (start+i.val)) else none))+(l.filter pred).length=l.length:=by
    induction l with
    | nil=>simp [free]
    | cons i l ih=>cases h:pred i <;> simp [free,h] at ih ⊢ <;> omega
  simpa [mask,knownCount,List.finRange,List.map_ofFn,Function.comp_def,pred] using count (List.finRange len)

theorem page_digit {m b d:Nat} (p:Fin (2^b)) (a:Fin (2^d)) {i:Nat} (ii:i<b):
    get (head m b d (p,a)) (m-2*b+i)=get (bigBits b p.val) i:=by
  change get (((List.replicate (m-2*b) false ++ bigBits b p.val) ++ List.replicate (b-d) false) ++ bigBits d a.val) _=_
  rw [List.append_assoc,List.append_assoc]
  simp [get,List.getElem?_append_right (by simp : (List.replicate (m-2*b) false).length≤m-2*b+i),
    List.getElem?_append_left (show i<(bigBits b p.val).length by simpa using ii)]

theorem off_digit {m b d:Nat} (fit:2*b≤m) (db:d≤b) (p:Fin (2^b)) (a:Fin (2^d)) {i:Nat} (_ii:i<d):
    get (head m b d (p,a)) (m-d+i)=get (bigBits d a.val) i:=by
  let pre:=List.replicate (m-2*b) false ++ bigBits b p.val ++ List.replicate (b-d) false
  have len:pre.length=m-d:=by simp [pre];omega
  change get (pre++bigBits d a.val) _=_
  simp [get,List.getElem?_append_right (by rw [len];omega : pre.length≤m-d+i),len]

def pagePool {b:Nat} (xs:List (Option Bool)):List (Fin (2^b)):=
  (rows options xs).map (fun v=>⟨beValue v%2^b,Nat.mod_lt _ (Nat.two_pow_pos _)⟩)

theorem physical_page {n m b d M s k j:Nat} (fit:2*b≤m) (y z:List Bool) (rank:Nat→Nat)
    (p:Fin (2^b)) (a:Fin (2^d)) (allowedHere:allowed (highModel n m b d M s k y rank) j z p a):
    p∈pagePool (mask rank n (beValue y) j (m-2*b) b z):=by
  let ms:=mask rank n (beValue y) j (m-2*b) b z
  apply List.mem_map.mpr;refine ⟨bigBits b p.val,constraints_mem ms _ (by simp [ms,mask]) ?_,?_⟩
  · intro i hi
    have il:i<b:=by simpa [ms,mask] using hi
    let atH:Fin m:=⟨m-2*b+i,by omega⟩
    simp only [ms,mask,List.getElem_ofFn]
    split
    · rename_i read
      have bit:=allowedHere atH read
      change get z (m-2*b+i)=get (head m b d (p,a)) (m-2*b+i) at bit
      simp only [page_digit p a il] at bit
      simp [options,get,List.getElem?_eq_getElem (show i<(bigBits b p.val).length by simpa using il)] at bit ⊢
      exact bit.symm
    · cases (bigBits b p.val)[i]'(by simpa using il) <;> simp [options]
  · apply Fin.ext;simp [big_read p.isLt,Nat.mod_eq_of_lt p.isLt]

theorem page_pool_budget {n m b j:Nat} (y z:List Bool) (rank:Nat→Nat):
    (pagePool (b:=b) (mask rank n (beValue y) j (m-2*b) b z)).length
      *2^(knownCount rank n (beValue y) j (m-2*b) b)=2^b:=by
  simp [pagePool,option_count,←Nat.pow_add,count_free]

private theorem prefix_bits {d s a:Nat} (sd:s≤d):
    (bigBits d a).take (d-s)=bigBits (d-s) (a/2^s):=by
  have aux (x y c:Nat):lowBits (x+y) c=lowBits x c++lowBits y (c/2^x):=by
    induction x generalizing c with
    | zero=>simp [lowBits]
    | succ x ih=>
      rw [Nat.succ_add];simp [lowBits,ih,Nat.div_div_eq_div_mul,Nat.pow_succ,Nat.mul_comm]
  have de:bigBits d a=bigBits (d-s) (a/2^s)++bigBits s a:=by
    unfold bigBits
    calc (lowBits d a).reverse = (lowBits (s+(d-s)) a).reverse := by rw [Nat.add_sub_of_le sd]
         _ = _ := by rw [aux,List.reverse_append]
  rw [de,List.take_append_of_le_length (by simp),List.take_of_length_le (by simp)]

noncomputable def tilePool (n m d s j:Nat) (y z:List Bool) (rank:Nat→Nat):List Nat:=
  (rows options (mask rank n (beValue y) j (m-d) (d-s) z)).map beValue

theorem physical_tile {n m b d M s k j:Nat} (fit:2*b≤m) (db:d≤b) (sd:s≤d) (y z:List Bool) (rank:Nat→Nat)
    (p:Fin (2^b)) (a:Fin (2^d)) (ok:allowed (highModel n m b d M s k y rank) j z p a):
    a.val/2^s∈tilePool n m d s j y z rank:=by
  let ms:=mask rank n (beValue y) j (m-d) (d-s) z
  let v:=(bigBits d a.val).take (d-s)
  have len:v.length=d-s:=by simp [v]
  apply List.mem_map.mpr;refine ⟨v,constraints_mem ms v (by simp [ms,mask,len]) ?_,?_⟩
  · intro i hi
    have il:i<d-s:=by simpa [ms,mask] using hi
    let pos:Fin m:=⟨m-d+i,by omega⟩
    simp only [ms,mask,List.getElem_ofFn];split
    · rename_i read
      have bit:=ok pos read
      change get z (m-d+i)=get (head m b d (p,a)) (m-d+i) at bit
      rw [off_digit fit db p a (by omega)] at bit
      simp [v,options,get,List.getElem?_eq_getElem (show i<(bigBits d a.val).length by simp;omega)] at bit ⊢
      exact bit.symm
    · cases v[i] <;> simp [options]
  · unfold v;rw [prefix_bits sd,big_read]
    apply (Nat.div_lt_iff_lt_mul (Nat.two_pow_pos _)).mpr
    rw [←Nat.pow_add,Nat.sub_add_cancel sd];exact a.isLt

theorem tile_pool_budget {n m d s j:Nat} (y z:List Bool) (rank:Nat→Nat):
    (tilePool n m d s j y z rank).length*2^(knownCount rank n (beValue y) j (m-d) (d-s))=2^(d-s):=by
  simp [tilePool,option_count,←Nat.pow_add,count_free]

#print axioms physical_page
#print axioms physical_tile
#print axioms page_pool_budget
#print axioms tile_pool_budget
end SISA.Rate
