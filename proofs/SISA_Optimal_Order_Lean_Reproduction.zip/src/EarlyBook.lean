import RecordCount
import ActualOrder

namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

def vicinity (k z:Nat):List Nat:=(List.range (2*k+1)).map (fun i=>z+i-k)

theorem in_vicinity {k z a:Nat} (lo:z≤a+k) (hi:a≤z+k):a∈vicinity k z:=by
  apply List.mem_map.mpr;exact ⟨a+k-z,List.mem_range.mpr (by omega),by omega⟩

def anchorBase (d s:Nat):Nat:=(d*d-1)/(d-2*s)

def centers (b d s:Nat):List Nat:=
  [0,b-1,b-(d-s)]++(List.range 3).map (fun j=>(d-2*s)*(anchorBase d s+j))

def labels (b d s k:Nat):List Nat:=(centers b d s).flatMap (vicinity k)

theorem labels_length (b d s k:Nat):(labels b d s k).length=6*(2*k+1):=by
  unfold labels
  rw [flatMap_count _ _ (2*k+1)]
  · simp [centers]
  · intro z;simp [vicinity]

theorem anchor_center {b d s j:Nat} (room:4*s+2≤d) (jj:j<d):
    (clippedAnchors d s (highGap d j)).1∈centers b d s:=by
  let w:=d-2*s
  let v:=d*d-1
  let u:=highGap d j-1
  have pos:0<w:=by dsimp [w];omega
  have q:d≤2*w:=by dsimp [w];omega
  have pp:0<d*d:=Nat.mul_pos (by omega) (by omega)
  have lu:v≤u ∧ u≤v+d:=by simp only [v,u,highGap];split <;> omega
  have low:=Nat.div_le_div_right (c:=w) lu.1
  have upper:u/w≤v/w+2:=by
    have a:=Nat.div_le_div_right (c:=w) (show u≤v+2*w by omega)
    rwa [Nat.add_mul_div_right _ _ pos] at a
  unfold centers;apply List.mem_append_right;apply List.mem_map.mpr
  refine ⟨u/w-v/w,List.mem_range.mpr (by omega),?_⟩
  change w*(v/w+(u/w-v/w))=w*(u/w)
  rw [Nat.add_sub_of_le low]

private theorem double_label {b d s k j a x:Nat} (room:4*s+2≤d) (jj:j<d)
    (small:2*highGap d j<b) (av:a<b)
    (read:interior b (highGap d j) (clippedAnchors d s (highGap d j)).1 (d-s) k x=true)
    (edit:x=a ∨ x=a+highGap d j ∨ x=a+b ∨ x=a+b+highGap d j):
    a∈labels b d s k:=by
  let g:=highGap d j
  let A:=(clippedAnchors d s g).1
  have dg:d≤g:=by dsimp [g,highGap];have:=Nat.le_mul_self d;split <;> omega
  have fit:=anchors_fit (by omega : 2*s<d) dg
  change A<g ∧ 0<d-s ∧ d-s≤g ∧ _ at fit
  change interior b g A (d-s) k x=true at read
  simp [interior,nearby] at read
  change x=a ∨ x=a+g ∨ x=a+b ∨ x=a+b+g at edit
  have bd:d-s≤b:=by dsimp [g] at *;omega
  have h:=@thick_labels (b:Int) (g:Int) (A:Int) ((d-s:Nat):Int) (k:Int) (x:Int) (a:Int)
    (by omega) (by change 2*g<b at small;omega) (by omega) (by omega) (by omega) (by omega)
    (by unfold close;omega) (by omega)
  have mem (z:Nat) (hz:z∈centers b d s) (left:z≤a+k) (right:a≤z+k):a∈labels b d s k:=
    List.mem_flatMap.mpr ⟨z,hz,in_vicinity left right⟩
  unfold close at h
  rcases h with h|h|h|h
  · exact mem A (anchor_center room jj) (by omega) (by omega)
  · exact mem (b-(d-s)) (by simp [centers]) (by omega) (by omega)
  · exact mem 0 (by simp [centers]) (by omega) (by omega)
  · exact mem (b-1) (by simp [centers]) (by omega) (by omega)

/-- At an actual early core site of the literal high-cluster word, a deviation
    from the common half-word determines an offset in a six-centre list. -/
theorem early_edit_label {m b d M s k p i a:Nat} (half:M+M=m) (room:4*s+2≤d)
    (small:∀ j<d,2*highGap d j<b) (av:a<b) (site:coreSite m b M p i)
    (read:clipped m b d M d k s (highGap d) i=true)
    (edit:get (word .double m b M d (highGap d)) (i-(p*m+a))≠decide (p*m+M≤i)):
    a∈labels b d s k:=by
  let u:=i-p*m
  have core:(b≤u ∧ u<M) ∨ (M+b≤u ∧ u<m):=by dsimp [u];unfold coreSite at site;omega
  have um:u<m:=by omega
  have rep:i%m=u:=by
    have eq:i=u+p*m:=by dsimp [u];unfold coreSite at site;omega
    rw [eq,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt um]
  have baseline:(p*m+M≤i) ↔ M≤u:=by dsimp [u];unfold coreSite at site;omega
  have me:i-(p*m+a)=u-a:=by dsimp [u];omega
  rw [me] at edit
  simp only [baseline] at edit
  rcases core with front|back
  · have lo:u-a<M:=by omega
    have e:(u-a)%(4*b)=0 ∧ (u-a)/(4*b)<8*d:=by
      simpa [word,get,show u-a<m by omega,lo,show ¬M≤u by omega] using edit
    have de:=Nat.mod_add_div (u-a) (4*b)
    have eq:u=a+((u-a)/(4*b))*(4*b):=by rw [Nat.mul_comm ((u-a)/(4*b))];omega
    have rem:u%(4*b)=a:=(congrArg (·%(4*b)) eq).trans ((Nat.add_mul_mod_self_right ..).trans (Nat.mod_eq_of_lt (by omega)))
    have quo:u/(4*b)<8*d:=by
      calc u/(4*b) = (a+((u-a)/(4*b))*(4*b))/(4*b) := congrArg (·/(4*b)) eq
           _ = (u-a)/(4*b) := by rw [Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt (by omega : a<4*b),Nat.zero_add]
           _ < _ := e.2
    simp [clipped,early,rep,show ¬M≤u by omega,show ¬u<b by omega,front.2,quo,rem,av] at read
  · let l:=u-a-M
    let j:=l/(32*b)
    let r:=l%(32*b)
    let g:=highGap d j
    have e:j<d ∧ holes .double b g r=true:=by
      simpa [word,get,show u-a<m by omega,show ¬u-a<M by omega,show M≤u by omega,l,j,g,r] using edit
    have sm:=small j e.1
    change 2*g<b at sm
    have edits:=e.2
    simp only [holes,starts,List.any_cons,List.any_nil,Bool.or_false,Bool.or_eq_true,decide_eq_true_eq] at edits
    have rl:r+a<32*b:=by omega
    have split:u-M=(r+a)+j*(32*b):=by
      have x:=Nat.mod_add_div l (32*b);rw [Nat.mul_comm j] ;dsimp only [l,r,j] at *;omega
    have quo:(u-M)/(32*b)=j:=by rw [split,Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt rl,Nat.zero_add]
    have rem:(u-M)%(32*b)=r+a:=by rw [split,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt rl]
    by_cases dbl:r<6*b
    · have range:4*b≤r+a ∧ r+a<6*b+g:=by omega
      have cut:interior b g (clippedAnchors d s g).1 (d-s) k (r+a-4*b)=true:=by
        simpa [clipped,rep,show M≤u by omega,quo,rem,e.1,range.1,range.2,g,clippedAnchors] using read
      exact double_label room e.1 sm av cut (by omega)
    · have outside:¬(4*b≤r+a ∧ r+a<6*b+g):=by omega
      have dropped:(12*b≤r+a ∧ r+a<13*b+g) ∨ (16*b≤r+a ∧ r+a<17*b+g):=by omega
      simp [clipped,early,rep,show M≤u by omega,show ¬u<b by omega,show ¬u<M+b by omega,
        show ¬u<M by omega,quo,rem,e.1,show ¬d≤j by omega,outside,show highGap d j=g from rfl,dropped] at read

#print axioms early_edit_label
end SISA.Rate
