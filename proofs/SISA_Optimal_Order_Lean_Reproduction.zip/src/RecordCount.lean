import ClippedOrder
import Counting
namespace SISA.Rate
open SISA.Balanced SISA.Shadow HWB.Circuit

/-- All vectors with one entry from each position's finite dictionary. -/
def rows (D:ι→List α):List ι→List (List α)
  | []=>[[]]
  | i::is=>(D i).flatMap (fun x=>(rows D is).map (x::·))

theorem rows_length (D:ι→List α) (is:List ι):
    (rows D is).length=(is.map (fun i=>(D i).length)).prod:=by
  induction is with
  | nil=>rfl
  | cons i is ih=>
    have aux (xs:List α):(xs.flatMap (fun x=>(rows D is).map (x::·))).length=xs.length*(rows D is).length:=by
      induction xs with | nil=>simp | cons x xs h=>simp [h,Nat.succ_mul,Nat.add_comm]
    simp [rows,aux,ih]

theorem row_mem (D:ι→List α) (xs:List ι) (f:ι→α) (valid:∀ i∈xs,f i∈D i):xs.map f∈rows D xs:=by
  induction xs with
  | nil=>simp [rows]
  | cons i xs ih=>
    exact List.mem_flatMap.mpr ⟨_,valid i (by simp),List.mem_map.mpr ⟨_,ih (fun i m=>valid _ (by simp [m])),rfl⟩⟩

theorem words_len (k:Nat):(words k).length=2^k:=by
  have flat (l:List (List Bool)):(l.flatMap (fun x=>[false::x,true::x])).length=l.length*2:=by
    induction l with | nil=>rfl | cons x xs ih=>simp [ih,Nat.succ_mul,Nat.add_comm];omega
  induction k with | zero=>rfl | succ k ih=>simp [words,flat,ih,Nat.pow_succ]

theorem dedupND [BEq α] [LawfulBEq α] (xs:List α):xs.eraseDups.Nodup:=by
  cases xs with
  | nil=>simp
  | cons a xs=>
    rw [List.eraseDups_cons,List.nodup_cons]
    refine ⟨?_,dedupND _⟩
    intro mem;have z:=List.mem_filter.mp (List.mem_eraseDups.mp mem);simp at z
termination_by xs.length
decreasing_by have:=List.length_filter_le (fun b=>!(b==a)) xs;simp;omega

theorem word_len_of_mem (j:Nat) (v:List Bool) (mem:v∈words j):v.length=j:=by
  induction j generalizing v with
  | zero=>simp [words] at mem;subst v;rfl
  | succ j ih=>
    obtain ⟨xs,hs,hv⟩:=List.mem_flatMap.mp mem
    rcases List.mem_cons.mp hv with rfl|more
    · simp [ih xs hs]
    · have eq:=List.mem_singleton.mp more;subst v;simp [ih xs hs]

variable {P A h:Nat} (S:Model P A h)
/-- A header fixes the subset of candidate offsets at the given layer. -/
def allowed (layer:Nat) (header:List Bool) (p:Fin P) (a:Fin A):Prop:=
  ∀ j:Fin h,S.addr j<layer → get header j.val=S.head p a j

noncomputable def offsetsFor (layer:Nat) (z:List Bool) (p:Fin P):List (Fin A):=by
  classical exact (List.finRange A).filter (fun a=>decide (allowed S layer z p a))

theorem allowed_iff (x:List Bool) (p:Fin P) (a:Fin A):
    compatible S x p a ↔ allowed S x.length (record S x).1 p a:=by
  simp only [record,compatible,allowed,get,List.getElem?_ofFn,Fin.isLt,↓reduceDIte,Option.getD_some]

def signature (j:Nat) (p:Fin P) (k:Bool) (a:Fin A):List Bool:=
  projected S p a (seen S j (S.core p k))

noncomputable def dictionary (j:Nat) (z:List Bool) (p:Fin P) (k:Bool):List (List Bool):=
  ((offsetsFor S j z p).map (signature S j p k)).eraseDups

/-- Decode an observed signature using the same first matching offset as the original compiler. -/
noncomputable def representative (j:Nat) (z:List Bool) (p:Fin P) (k:Bool) (v:List Bool):Option (Fin A):=by
  classical exact (List.finRange A).find? (fun a=>decide (allowed S j z p a ∧ v=signature S j p k a))

noncomputable def reps (j:Nat) (z:List Bool) (p:Fin P) (k:Bool):List (Option (Fin A)):=
  none::(dictionary S j z p k).map (representative S j z p k)

theorem witness_mem (x:List Bool) (p:Fin P) (k:Bool):
    witness S x p k∈reps S x.length (record S x).1 p k:=by
  classical
  let v:=observed S x (seen S x.length (S.core p k))
  have eq:witness S x p k=representative S x.length (record S x).1 p k v:=by
    unfold witness representative
    dsimp only;apply congrArg (fun pred : Fin A→Bool=>(List.finRange A).find? pred)
    funext a;apply Bool.eq_iff_iff.mpr; simp only [decide_eq_true_eq,v,signature,allowed_iff]
    exact ⟨fun hz=>decide_eq_true hz,fun hz=>of_decide_eq_true hz⟩
  cases e:witness S x p k with
  | none=>simp [reps]
  | some a=>
    have cond:=List.find?_some (show (List.finRange A).find? _=some a from e)
    have info:compatible S x p a ∧ v=signature S x.length p k a:=of_decide_eq_true cond
    have mem:a∈offsetsFor S x.length (record S x).1 p:=by simp [offsetsFor,(allowed_iff S x p a).mp info.1]
    have vin:v∈dictionary S x.length (record S x).1 p k:=List.mem_eraseDups.mpr (List.mem_map.mpr ⟨a,mem,info.2.symm⟩)
    exact List.mem_cons.mpr (Or.inr (List.mem_map.mpr ⟨v,vin,eq.symm.trans e⟩))

noncomputable def pageBook (j:Nat) (z:List Bool) (p:Fin P):List (Option (PageRow A)):=by
  classical
  exact if ∃ a,allowed S j z p a then
    (reps S j z p false).flatMap fun a=>(reps S j z p true).flatMap fun b=>
      (words (seen S j (S.edge p)).length).map fun e=>some (a,b,e)
    else [none]

theorem page_mem (x:List Bool) (p:Fin P):page S x p∈pageBook S x.length (record S x).1 p:=by
  classical
  unfold page pageBook
  simp only [allowed_iff]
  split
  · exact List.mem_flatMap.mpr ⟨_,witness_mem S x p false,List.mem_flatMap.mpr ⟨_,witness_mem S x p true,
      List.mem_map.mpr ⟨_,(by simpa [observed] using word_member (observed S x (seen S x.length (S.edge p)))),rfl⟩⟩⟩
  · simp

theorem flatMap_count (xs:List α) (f:α→List β) (k:Nat) (eq:∀ x,(f x).length=k):
    (xs.flatMap f).length=xs.length*k:=by
  induction xs with | nil=>simp | cons x xs ih=>simp [ih,eq,Nat.succ_mul,Nat.add_comm]

noncomputable def pageCost (j:Nat) (z:List Bool) (p:Fin P):Nat:=by
  classical
  exact if ∃ a,allowed S j z p a then
    ((dictionary S j z p false).length+1)*(((dictionary S j z p true).length+1)*2^(seen S j (S.edge p)).length)
    else 1

theorem pageBook_count (j:Nat) (z:List Bool) (p:Fin P):
    (pageBook S j z p).length=pageCost S j z p:=by
  classical
  unfold pageBook pageCost
  split
  · rw [flatMap_count _ _ ((reps S j z p true).length*2^(seen S j (S.edge p)).length)]
    · simp [reps]
    · intro a;rw [flatMap_count _ _ (2^(seen S j (S.edge p)).length)];intro t;simp [words_len]
  · rfl

noncomputable def headerBook (j:Nat) (z:List Bool):List (Record A):=
  (rows (pageBook S j z) (List.finRange P)).map (fun v=>(z,v))

theorem headerBook_count (j:Nat) (z:List Bool):
    (headerBook S j z).length=((List.finRange P).map (pageCost S j z)).prod:=by
  simp [headerBook,rows_length,pageBook_count]

/-- A bound on real layer records by sums and products of physical local signatures. -/
theorem attained_product (j:Nat):
    (attained S j).length≤((words h).map (fun z=>((List.finRange P).map (pageCost S j z)).prod)).sum:=by
  let B:=(words h).flatMap (headerBook S j)
  have cover:attained S j⊆B:=by
    intro u hu
    obtain ⟨x,hx,rfl⟩:=List.mem_map.mp (List.mem_eraseDups.mp hu)
    have l:=word_len_of_mem j x hx
    let z:=(record S x).1
    have hl:z.length=h:=by simp [z,record]
    have hz:z∈words h:=hl ▸ word_member z
    apply List.mem_flatMap.mpr;refine ⟨z,hz,List.mem_map.mpr ⟨_,?_,rfl⟩⟩
    rw [←l]
    simpa [List.finRange,List.map_ofFn,Function.comp_def] using row_mem (pageBook S x.length z) (List.finRange P) (page S x) (fun p _=>page_mem S x p)
  have nd:(attained S j).Nodup:=dedupND _
  have count (l:List (List Bool)):(l.flatMap (headerBook S j)).length=(l.map (fun z=>((List.finRange P).map (pageCost S j z)).prod)).sum:=by
    induction l with | nil=>rfl | cons z l ih=>simp [ih,headerBook_count]
  exact Nat.le_trans (nd.length_le_of_subset cover) (Nat.le_of_eq (count _))

#print axioms attained_product
end SISA.Rate
