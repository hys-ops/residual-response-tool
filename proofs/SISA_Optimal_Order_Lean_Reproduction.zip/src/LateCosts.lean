import Fields
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

def bases (d:Nat):List Nat:=[0,d*d+1]

theorem literal_bands {d H e:Nat} (dp:0<d) (cover:d≤H) (he:e∈edits d):
    ∃ g∈bases d,g≤e ∧ e<g+H:=by
  rcases List.mem_cons.mp he with z|z
  · exact ⟨0,by simp [bases],by omega,by omega⟩
  · obtain ⟨j,hj,rfl⟩:=List.mem_map.mp z
    have:=List.mem_range.mp hj
    exact ⟨d*d+1,by simp [bases],by unfold highGap;split <;> omega,by unfold highGap;split <;> omega⟩

noncomputable def suspect (n m b d M s k j:Nat) (y z:List Bool) (rank:Nat→Nat):List Nat:=
  candidates b (2^s) (residuesRead n m b j (clipped m b d M d k s (highGap d)) rank) (bases d)
    (tilePool n m d s j y z rank)

theorem late_outside {n m b d M s k j:Nat} (half:M+M=m) (align:b∣M) (bb:2^d=b) (dp:0<d)
    (fit:2*b≤m) (db:d≤b) (sd:s≤d) (cover:d≤2^s) (small:∀ z<d,2*highGap d z<b)
    (y z:List Bool) (rank:Nat→Nat) (p:Fin (2^b))
    (out:p.val%b∉suspect n m b d M s k j y z rank):
    (dictionary (highModel n m b d M s k y rank) j z p false).length≤1:=by
  classical
  let S:=highModel n m b d M s k y rank
  let base:=lateBase m M p.val (seen S j (S.core p false))
  apply dict_cover _ _ _ _ _ [base]
  intro a ha;apply List.mem_singleton.mpr
  apply Classical.byContradiction;intro bad
  obtain ⟨r,hr,e,he,el,rl,_,rot⟩:=late_witness half align bb small y rank p a bad
  have tile:=physical_tile fit db sd y z rank p a (of_decide_eq_true (List.mem_filter.mp ha).2)
  apply out
  let A:Fin b:=⟨a.val,bb ▸ a.isLt⟩
  let E:Fin b:=⟨e,el⟩
  let R:Fin b:=⟨r,rl⟩
  let T:Fin b:=⟨p.val%b,Nat.mod_lt _ (by omega)⟩
  apply in_budget _ _ _ (r:=R) (c:=E) (a:=A) (t:=T) hr tile (literal_bands dp cover he) (Nat.two_pow_pos s)
  exact Fin.ext rot

/-- Total cover multiplicity across all shifts, before intersecting with surviving pages. -/
theorem suspect_budget {n m b d M s k j:Nat} (sd:s≤d) (bb:2^d=b) (y z:List Bool) (rank:Nat→Nat):
    (suspect n m b d M s k j y z rank).length*2^(knownCount rank n (beValue y) j (m-d) (d-s))
    ≤4*b*(residuesRead n m b j (clipped m b d M d k s (highGap d)) rank).length:=by
  let R:=residuesRead n m b j (clipped m b d M d k s (highGap d)) rank
  let T:=tilePool n m d s j y z rank
  let v:=knownCount rank n (beValue y) j (m-d) (d-s)
  have eq:T.length*2^v=2^(d-s):=tile_pool_budget y z rank
  unfold suspect;rw [budget];change R.length*(2*(T.length*(2*2^s-1)))*2^v≤4*b*R.length
  calc
    _ ≤ R.length*(2*(T.length*(2*2^s)))*2^v := by
      exact Nat.mul_le_mul_right _ (Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ (Nat.mul_le_mul_left _ (by omega))))
    _ = 4*R.length*((T.length*2^v)*2^s) := by rw [show 4=2*2 by decide];ac_rfl
    _ = _ := by rw [eq,←Nat.pow_add,Nat.sub_add_cancel sd,bb];ac_rfl

def boundaryBook (m b M p:Nat) (R:List Nat):List Nat:=
  [(p*m,p),(p*m+M,p),(p*m+m,p+1)].flatMap (fun (x,t)=>R.map (fun r=>x+(t%b+r)%b))

theorem edge_budget {n m b d M s k j:Nat} (half:M+M=m) (bm:b≤M) (align:b∣M) (bp:0<b)
    (y:List Bool) (rank:Nat→Nat) (p:Fin (2^b)):
    let R:=residuesRead n m b j (clipped m b d M d k s (highGap d)) rank
    let S:=highModel n m b d M s k y rank
    (seen S j (S.edge p)).length≤3*R.length:=by
  dsimp only
  classical
  let S:=highModel n m b d M s k y rank
  let first:=clipped m b d M d k s (highGap d)
  let R:=residuesRead n m b j first rank
  have nd:(seen S j (S.edge p)).Nodup:=
    List.Pairwise.filter _ (List.Pairwise.filter _ List.nodup_range)
  have length:(boundaryBook m b M p.val R).length=3*R.length:=by
    unfold boundaryBook;rw [flatMap_count _ _ R.length];rfl
    intro x;simp
  rw [←length];apply nd.length_le_of_subset;intro i hi
  obtain ⟨he,read⟩:=List.mem_filter.mp hi
  have e:=List.mem_filter.mp he
  have ib:=List.mem_range.mp e.1
  have zz:p.val*m≤i ∧ i<p.val*m+m+b ∧ ¬coreSite m b M p.val i:=of_decide_eq_true e.2
  have falseSite:first i=false:=clipped_boundary half bm zz.1 zz.2.1 zz.2.2
  let r:=residue m b i
  have rm:r∈R:=by
    apply List.mem_eraseDups.mpr;apply List.mem_map.mpr;refine ⟨i,List.mem_filter.mpr ⟨e.1,?_⟩,rfl⟩
    simpa [first,falseSite,S,highModel,physical] using read
  have ad:b∣m:=half ▸ Nat.dvd_add align align
  have strip:(p.val*m≤i ∧ i<p.val*m+b) ∨ (p.val*m+M≤i ∧ i<p.val*m+M+b) ∨ (p.val*m+m≤i ∧ i<p.val*m+m+b):=by
    unfold coreSite at zz;omega
  have lay (x t:Nat) (mem:(x,t)∈[(p.val*m,p.val),(p.val*m+M,p.val),(p.val*m+m,p.val+1)])
      (start:t*m≤x) (endSite:i<t*m+m) (div:b∣x-t*m) (instrip:x≤i ∧ i<x+b):
      i∈boundaryBook m b M p.val R:=by
    have val:=rotate_residue (Nat.le_trans start instrip.1) endSite bp ad
    have loc:i-t*m=(i-x)+(x-t*m):=by omega
    obtain ⟨q,hq⟩:=div
    rw [loc,hq,Nat.mul_comm b q,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt (by omega : i-x<b)] at val
    apply List.mem_flatMap.mpr;refine ⟨(x,t),mem,List.mem_map.mpr ⟨r,rm,?_⟩⟩
    change x+(t%b+residue m b i)%b=i;rw [val];omega
  rcases strip with L|Mstrip|E
  · apply lay _ p.val (by simp) (by omega) (by omega) (by simp) L
  · apply lay _ p.val (by simp) (by omega) (by omega) (by simpa using align) Mstrip
  · have eq:(p.val+1)*m=p.val*m+m:=Nat.succ_mul .. 
    apply lay _ (p.val+1) (by simp) (by omega) (by omega) (by rw [eq];simp) E
#print axioms late_outside
#print axioms suspect_budget
#print axioms edge_budget
end SISA.Rate
