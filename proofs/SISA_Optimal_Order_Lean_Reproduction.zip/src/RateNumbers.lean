import Std
namespace SISA.Rate

def depth (d:Nat):Nat:=d.log2.log2.log2

theorem exp_grows {x:Nat} (hx:8≤x):8*x+16≤2^x:=by
  obtain ⟨k,rfl⟩:=Nat.exists_eq_add_of_le hx
  induction k with
  | zero=>decide
  | succ k ih=>rw [show 8+(k+1)=(8+k)+1 by omega,Nat.pow_succ];omega

theorem pow2mono {i j:Nat} (le:i≤j):2^i≤2^j:=Nat.pow_le_pow_right (by decide) le

theorem pow2mul (i j:Nat):2^i*2^j=2^(i+j):=(Nat.pow_add ..).symm

theorem log_envelope {d:Nat} (h:10≤depth d):
    10≤d.log2.log2 ∧ 10≤d.log2 ∧ 10≤d ∧ 2^d.log2≤d ∧
    2^d.log2.log2≤d.log2 ∧ 2^(depth d)≤d.log2.log2:=by
  have h1:=Nat.log2_le_self d.log2.log2
  have h2:=Nat.log2_le_self d.log2
  have h3:=Nat.log2_le_self d
  unfold depth at *; exact ⟨by omega,by omega,by omega,Nat.log2_self_le (by omega),Nat.log2_self_le (by omega),Nat.log2_self_le (by omega)⟩

structure Numbers (m b d:Nat) where
  M : Nat
  P : Nat
  K : Nat
  L : Nat
  s : Nat
  J : Nat
  q₁ : Nat
  q₂ : Nat
  t₁ : Nat
  t₂ : Nat
  half : M+M=m
  fits : 32*b*d≤M
  room : m*m≤2^m
  pages : 4*P≤m
  sd : s≤d
  tile : d*d+d≤2^s
  small : 2*(d*d+d)<b
  budget : L*L+(K+1)*(K*s)<d
  lb : L≤b
  pg : 2*J+1≤P
  sz₁ : 2*q₁≤J
  sz₂ : 2^K*q₂≤J
  m₁ : 4*t₁≤K
  m₂ : 2^K*(2*t₂)≤L
  qpos : 0<q₁ ∧ 0<q₂
  tpos : 0<t₁ ∧ 0<t₂
  gain₁ : (2^m)^(depth d)≤(t₁^q₁)^64
  gain₂ : (2^m)^(depth d)≤(t₂^q₂)^64

theorem chooseNumbers {d b m:Nat} (hr:10≤depth d) (bb:2^d=b) (mm:2^b=m):Nonempty (Numbers m b d):=by
  let u:=d.log2
  let v:=u.log2
  let h:=depth d
  let K:=v/4
  let s:=2*u+3
  let l:=u/4
  let w:=2^K*h
  obtain ⟨v10,u10,d10,ud,vu,hv⟩:=log_envelope hr
  change 10≤v at v10;change 10≤u at u10;change 2^u≤d at ud;change 2^v≤u at vu;change 2^h≤v at hv
  change 10≤h at hr
  have vh:=Nat.lt_two_pow_self (n:=h)
  have uv:=exp_grows (show 8≤v by omega)
  have ug:=exp_grows (show 8≤u by omega)
  have dg:=exp_grows (show 8≤d by omega)
  have vb:8*v+16≤u:=Nat.le_trans uv vu
  have ub:8*u+16≤d:=Nat.le_trans ug ud
  have db:8*d+16≤b:=Nat.le_trans dg (Nat.le_of_eq bb)
  have bg:=exp_grows (show 8≤b by omega)
  have mb:8*b+16≤m:=Nat.le_trans bg (Nat.le_of_eq mm)
  have dtop:d≤2^(u+1):=Nat.le_of_lt (Nat.lt_log2_self (n:=d))
  have dsq:d*d≤2^(u+1+(u+1)):=by rw [←pow2mul];exact Nat.mul_le_mul dtop dtop
  have tile:d*d+d≤2^s:=by
    have lt:=pow2mono (show u+1≤u+1+(u+1) by omega)
    have eq:s=(u+1+(u+1))+1:=by dsimp [s];omega
    rw [eq,Nat.pow_succ];omega
  have small:2*(d*d+d)<b:=by
    have eq:2^s*2=2^(s+1):=(Nat.pow_succ ..).symm
    have hi:=pow2mono (show s+2≤d by dsimp [s];omega)
    rw [show s+2=s+1+1 by omega,Nat.pow_succ] at hi
    have pos:=Nat.two_pow_pos s;omega
  have sqb:b*b=2^(d+d):=by rw [←bb,pow2mul]
  have fit₀:64*(b*b)≤m:=by
    rw [sqb,show (64:Nat)=2^6 by decide,pow2mul,←mm]
    exact pow2mono (by omega)
  have fit₁:32*b*d≤32*(b*b):=by rw [Nat.mul_assoc];exact Nat.mul_le_mul_left 32 (Nat.mul_le_mul_left b (by omega))
  have Mhalf:2^(b-1)+2^(b-1)=m:=by
    have z:2^(b-1+1)=2^(b-1)*2:=Nat.pow_succ ..;rw [show b-1+1=b by omega,mm] at z;omega
  have gpage (j:Nat) (hj:j≤b):2^j*2^(b-j)=m:=by rw [pow2mul,Nat.add_sub_cancel' hj,mm]
  have page:=gpage 2 (by omega);have qval:=gpage 5 (by omega)
  have jval:=gpage 4 (by omega)
  have kg:8≤K:=by have z:=pow2mono hr;dsimp [K];omega
  have vbig:8*K+16≤2^K:=exp_grows kg
  have Kp:K+1≤2^v:=by dsimp [K];omega
  have hle:h≤2^K:=by
    have z:=exp_grows (show 8≤h by omega)
    have hh:h≤K:=by dsimp [K];omega
    omega
  have wsmall:w≤2^(K+K):=by dsimp [w];rw [←pow2mul];exact Nat.mul_le_mul_left _ hle
  have ww:16*2^(K+K)≤u:=by
    have e:4+(K+K)≤v:=by dsimp [K];omega
    have z:=pow2mono e;rw [←pow2mul] at z;omega
  have mg:2^K*(2*2^w)≤2^l:=by
    rw [show (2:Nat)*2^w=2^(w+1) by rw [Nat.pow_succ,Nat.mul_comm],pow2mul]
    apply pow2mono;dsimp [l,K] at *;omega
  have ssmall:s≤2^(v+3):=by
    have top:u<2^(v+1):=Nat.lt_log2_self
    rw [show v+3=v+1+1+1 by omega,Nat.pow_succ,Nat.pow_succ];dsimp [s];omega
  have sep:(K+1)*(K*s)≤2^(v+(v+(v+3))):=by
    rw [←pow2mul,←pow2mul];exact Nat.mul_le_mul Kp (Nat.mul_le_mul (by omega) ssmall)
  have limit:2^l*2^l + (K+1)*(K*s)<d:=by
    have z:=pow2mono (show v+(v+(v+3))≤u-2 by omega)
    have z':=pow2mono (show l+l≤u-2 by dsimp [l];omega)
    have uu:2^(u-2)*4=2^u:=by rw [show (4:Nat)=2^2 by decide,pow2mul,show u-2+2=u by omega]
    have :=Nat.two_pow_pos (u-2);rw [pow2mul];omega
  have t1:4*2^(h-4)≤K:=by
    have z:16*2^(h-4)=2^h:=by rw [show (16:Nat)=2^4 by decide,pow2mul,show 4+(h-4)=h by omega]
    dsimp [K];omega
  have q2index:K+4≤b:=by dsimp [K];omega
  have p2 (t:Nat) (he:t+4≤b):2^t*2^(b-4-t)=2^(b-4):=by rw [pow2mul,show t+(b-4-t)=b-4 by omega]
  have end₁:(2^m)^h≤((2^(h-4))^(2^(b-5)))^64:=by
    simp only [←Nat.pow_mul]
    apply pow2mono
    change m*h≤((h-4)*2^(b-5))*64
    have e:32*2^(b-5)=m:=qval
    rw [←e];have z:=Nat.mul_le_mul_left (2^(b-5)) (show 32*h≤(h-4)*64 by omega)
    simpa only [Nat.mul_assoc,Nat.mul_left_comm,Nat.mul_comm] using z
  have end₂:(2^m)^h≤((2^w)^(2^(b-4-K)))^64:=by
    simp only [←Nat.pow_mul];apply pow2mono
    have e:=p2 K q2index
    have base:16*2^(b-4)=m:=jval
    calc
      m*h=(w*2^(b-4-K))*16:=by rw [←base,←e];dsimp [w];ac_rfl
      _≤_:=Nat.mul_le_mul_left _ (by decide : 16≤64)
  refine ⟨⟨2^(b-1),2^(b-2),K,2^l,s,2^(b-4),2^(b-5),2^(b-4-K),2^(h-4),2^w,
    Mhalf,by omega,?_,by omega,by dsimp [s];omega,tile,small,limit,?_,?_,?_,p2 K q2index ▸ Nat.le_refl _,t1,mg,
    ⟨Nat.two_pow_pos _,Nat.two_pow_pos _⟩,⟨Nat.two_pow_pos _,Nat.two_pow_pos _⟩,end₁,end₂⟩⟩
  · rw [←mm,pow2mul];apply pow2mono;rw [mm];omega
  · rw [←bb];apply pow2mono;dsimp [l];omega
  · have:=Nat.two_pow_pos (b-4);change 4*2^(b-2)=m at page;change 16*2^(b-4)=m at jval;omega
  · change 32*2^(b-5)=m at qval;change 16*2^(b-4)=m at jval;omega
end SISA.Rate
