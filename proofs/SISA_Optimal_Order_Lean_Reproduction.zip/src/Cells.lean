import Combine
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.Shadow HWB.Circuit

inductive Shape where
 | empty
 | short
 | double (g:Nat)
deriving DecidableEq

def cell (m b d M q:Nat):Shape:=
  let c:=(q*(4*b))%m
  let u:=c-M
  if M≤c ∧ u/(32*b)<d then
    if u%(32*b)=4*b then .double (highGap d (u/(32*b)))
    else if u%(32*b)=8*b then .empty else .short
  else .short

def shadowed (b d s k:Nat) (sh:Shape) (x:Nat):Prop:=match sh with
  | .empty=>False
  | .short=>x<b+(d*d+d)
  | .double g=>x<2*b+g ∧ interior b g (clippedAnchors d s g).1 (d-s) k x=false

theorem add_below_multiple {x t w:Nat} (xd:w∣x) (td:w∣t) (lt:x<t):x+w≤t:=by
  obtain ⟨q,rfl⟩:=xd;obtain ⟨r,rfl⟩:=td
  have h:=Nat.mul_le_mul_left w (Nat.lt_of_mul_lt_mul_left lt);rwa [Nat.mul_succ] at h

theorem double_next {m b d M q g:Nat} (bm:b>0) (_mm:4*b∣m) (_mpos:0<m)
    (half:M+M=m) (fits:32*b*d≤M) (dbl:cell m b d M q=.double g):
    cell m b d M (q+1)=.empty:=by
  let C:=(q*(4*b))%m
  let U:=C-M
  have addr:M≤C ∧ U/(32*b)<d ∧ U%(32*b)=4*b:=by
    unfold cell at dbl;dsimp only at dbl
    split at dbl
    · rename_i hb;split at dbl
      · exact ⟨hb.1,hb.2,by assumption⟩
      · split at dbl <;> contradiction
    · contradiction
  have rep:=Nat.mod_add_div U (32*b)
  have cap:=Nat.mul_le_mul_left (32*b) addr.2.1;rw [Nat.mul_succ] at cap
  have Cu:C=M+U:=by dsimp [U];omega
  have csmall:C+4*b<m:=by omega
  have next:((q+1)*(4*b))%m=C+4*b:=by rw [Nat.succ_mul,←Nat.mod_add_mod];exact Nat.mod_eq_of_lt csmall
  have dec:C+4*b-M=8*b+U/(32*b)*(32*b):=by rw [Nat.mul_comm (U/(32*b))];omega
  have z:8*b<32*b:=by omega
  have modv:(C+4*b-M)%(32*b)=8*b:=by rw [dec,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt z]
  have divv:(C+4*b-M)/(32*b)=U/(32*b):=by rw [dec,Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt z,Nat.zero_add]
  simp [cell,next,divv,modv,show M≤C+4*b by omega,addr.2.1,show 8*b≠4*b by omega]

/-- Each actual dark site lies in the shadow specified for its 4b-cell. -/
theorem actual_dark {m b d M s k q x:Nat} (bp:0<b) (mp:0<m) (half:M+M=m)
    (align:4*b∣M) (sm:2*(d*d+d)<b) (xw:x<4*b)
    (bad:clipped m b d M d k s (highGap d) (q*(4*b)+x)=false):
    shadowed b d s k (cell m b d M q) x:=by
  let c:=(q*(4*b))%m
  have divM:4*b∣m:=half ▸ Nat.dvd_add align align
  have dc:4*b∣c:=((Nat.dvd_mod_iff divM).mpr (Nat.dvd_mul_left ..))
  have cm:c<m:=Nat.mod_lt _ mp
  have fits:=add_below_multiple dc divM cm
  have rem:(q*(4*b)+x)%m=c+x:=by rw [←Nat.mod_add_mod];exact Nat.mod_eq_of_lt (by omega)
  by_cases front:c<M
  · have cf:=add_below_multiple dc align front
    have front':c+x<M:=by omega
    have C:cell m b d M q=.short:=by simp [cell,show ¬M≤(q*(4*b))%m from by change ¬M≤c;omega]
    rw [C];change x<b+(d*d+d)
    obtain ⟨t,et⟩:=dc
    have residue':(c+x)%(4*b)=x:=by rw [et,Nat.add_comm,Nat.mul_comm (4*b) t,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt xw]
    by_cases near:c+x<b
    · omega
    · simp [clipped,early,rem,show ¬M≤c+x by omega,front',near,residue'] at bad;omega
  · let u:=c-M
    let j:=u/(32*b)
    let l:=u%(32*b)
    let g:=highGap d j
    have du:4*b∣u:=Nat.dvd_sub dc align
    have divides:4*b∣32*b:=⟨8,by omega⟩
    have dl:4*b∣l:=(Nat.dvd_mod_iff divides).mpr du
    have ll:l<32*b:=Nat.mod_lt _ (by omega)
    have cap:=add_below_multiple dl divides ll
    have norm:c+x-M=l+x+j*(32*b):=by
      have h:=Nat.mod_add_div u (32*b);change l+32*b*j=u at h;rw [Nat.mul_comm j];dsimp [u] at *;omega
    have qr:(c+x-M)/(32*b)=j:=by rw [norm,Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt (by omega : l+x<32*b),Nat.zero_add]
    have rr:(c+x-M)%(32*b)=l+x:=by rw [norm,Nat.add_mul_mod_self_right,Nat.mod_eq_of_lt (by omega : l+x<32*b)]
    have sh:cell m b d M q=(if j<d then (if l=4*b then .double g else if l=8*b then .empty else .short) else .short):=by
      simp [cell,c,u,j,l,g,show M≤(q*(4*b))%m by change M≤c;omega]
    rw [sh]
    by_cases live:j<d
    · have gb:g≤d*d+d:=by dsimp [g,highGap];split <;> omega
      have band (h:4*b≤l+x ∧ l+x<6*b+g):l=4*b:=by
        by_cases lt:l<4*b
        · have lz:l=0:=by have:=Nat.eq_zero_of_dvd_of_lt dl lt;omega
          omega
        · by_cases same:l=4*b;exact same
          have lim:=add_below_multiple (Nat.dvd_refl (4*b)) dl (show 4*b<l by omega);omega
      by_cases at4:l=4*b
      · simp only [live,↓reduceIte,at4,shadowed]
        by_cases ins:x<2*b+g
        · refine ⟨ins,?_⟩
          simpa [clipped,rem,show M≤c+x by omega,qr,rr,live,at4,show 4*b+x<6*b+g by omega,g,clippedAnchors] using bad
        · have mid:¬(4*b≤l+x ∧ l+x<6*b+g):=by omega
          have bottom:b≤c+x ∧ M+b≤c+x:=by have e:=Nat.mod_add_div u (32*b);change l+32*b*j=u at e;dsimp [u] at *;omega
          have hbad:=bad
          simp [clipped,early,rem,show M≤c+x by omega,qr,rr,live,show ¬d≤j by omega,
            show ¬c+x<b by omega,show ¬c+x<M+b by omega,show ¬c+x<M by omega,
            show highGap d j=g from rfl,mid] at hbad
          omega
      · have mid:¬(4*b≤l+x ∧ l+x<6*b+g):=fun h=>at4 (band h)
        have readBad:x<b ∨ (12*b≤l+x ∧ l+x<13*b+g) ∨ (16*b≤l+x ∧ l+x<17*b+g):=by
          by_cases near:c+x<M+b
          · left;omega
          · right
            simp [clipped,early,rem,show M≤c+x by omega,qr,rr,live,show ¬d≤j by omega,
              show ¬c+x<b by omega,near,show ¬c+x<M by omega,show highGap d j=g from rfl,mid] at bad;omega
        by_cases at8:l=8*b
        · simp only [live,at8,↓reduceIte,shadowed]
          have bottom:M+b≤c+x:=by have e:=Nat.mod_add_div u (32*b);change l+32*b*j=u at e;dsimp [u] at *;omega
          simp [clipped,early,rem,show M≤c+x by omega,qr,rr,live,show ¬d≤j by omega,
            show ¬c+x<b by omega,show ¬c+x<M+b by omega,show ¬c+x<M by omega,
            show highGap d j=g from rfl,mid] at bad;omega
        · simp only [live,at4,at8,↓reduceIte,shadowed]
          have lane (t:Nat) (lo:t*(4*b)≤l+x) (hi:l+x<t*(4*b)+b+g):l=t*(4*b):=by
            have dv:4*b∣t*(4*b):=Nat.dvd_mul_left .. 
            rcases Nat.lt_trichotomy l (t*(4*b)) with low|eq|high
            · have:=add_below_multiple dl dv low;omega
            · exact eq
            · have:=add_below_multiple dv dl high;omega
          rcases readBad with h|h|h
          · omega
          · have:=lane 3 (by omega) (by omega);omega
          · have:=lane 4 (by omega) (by omega);omega
    · simp only [live,↓reduceIte,shadowed]
      by_cases near:c+x<M+b
      · omega
      · simp [clipped,early,rem,show M≤c+x by omega,qr,live,show d≤j by omega,
          show ¬c+x<b by omega,near,show ¬c+x<M by omega] at bad
#print axioms double_next
#print axioms actual_dark
end SISA.Rate
