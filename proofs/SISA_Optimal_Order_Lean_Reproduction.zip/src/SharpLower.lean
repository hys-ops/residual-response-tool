import EscapeOrders
import RateNumbers
namespace SISA.Rate
open HWB.Circuit SISA.Escape SISA.FixedWord SISA.Cut SISA.ShortBands

/-- Integer form of the all-order Omega rate, with all numeric budgets discharged. -/
theorem sharp_lower {d b m N:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m)
    {rank name:Nat→Nat} (order:∀ i<2^m+m,name (rank i)=i)
    (G:DAG N) (root:State N)
    (ok:∀ w,G.eval w root=true ↔ fixedAt (fun a=>a/m<m ∧ a%m<b) m
      (word .double m b (m/2) d (highGap d)) rank w):
    (2^m)^(depth d) ≤ (N+2)^64:=by
  obtain ⟨c⟩:=chooseNumbers large bb mm
  have half:c.M=m/2:=by have:=c.half;omega
  have dp:0<d:=by obtain ⟨_,_,hd,_⟩:=log_envelope large;omega
  have bounds:=high_all_orders c.half c.fits c.room c.pages mm bb dp c.sd c.tile c.small c.budget c.lb
    c.pg c.sz₁ c.sz₂ c.m₁ c.m₂ c.qpos c.tpos order G root (half.symm ▸ ok)
  rcases bounds with h|h
  · exact Nat.le_trans c.gain₁ (Nat.pow_le_pow_left h _)
  · exact Nat.le_trans c.gain₂ (Nat.pow_le_pow_left h _)

def tower (k:Nat):Nat:=2^(2^(2^k))

theorem tower_le_depth {d k:Nat} (cut:tower k≤d):k≤depth d:=by
  unfold tower at cut
  have p:0<2^(2^k):=Nat.two_pow_pos _
  have p':0<2^(2^(2^k)):=Nat.two_pow_pos _
  have a:2^(2^k)≤d.log2:=(Nat.le_log2 (by omega)).mpr cut
  have b:2^k≤d.log2.log2:=(Nat.le_log2 (by omega)).mpr a
  have q:=Nat.two_pow_pos k
  exact (Nat.le_log2 (by omega)).mpr b

/-- Every prescribed polynomial exponent is eventually exceeded on every physical order. -/
theorem superpolynomial {d b m N c:Nat} (cut:tower (64*(c+2))≤d) (bb:2^d=b) (mm:2^b=m)
    {rank name:Nat→Nat} (order:∀ i<2^m+m,name (rank i)=i)
    (G:DAG N) (root:State N)
    (ok:∀ w,G.eval w root=true ↔ fixedAt (fun a=>a/m<m ∧ a%m<b) m (word .double m b (m/2) d (highGap d)) rank w):
    (2^m)^c<N:=by
  have h:=tower_le_depth cut
  have a:=sharp_lower (by omega : 10≤depth d) bb mm order G root ok
  have lower:=Nat.le_trans (Nat.pow_le_pow_right (Nat.two_pow_pos m) h) a
  rw [Nat.mul_comm 64,Nat.pow_mul] at lower
  have bnd:=(Nat.pow_le_pow_iff_left (by decide : (64:Nat)≠0)).mp lower
  rw [Nat.pow_add] at bnd
  have mp:0<m:=mm ▸ Nat.two_pow_pos _
  have npos:2≤2^m:=Nat.one_lt_two_pow (by omega)
  have fact:4≤(2^m)^2:=Nat.pow_le_pow_left npos 2
  have pos:0<(2^m)^c:=Nat.pow_pos (Nat.two_pow_pos m)
  have step:=Nat.mul_le_mul_left ((2^m)^c) fact
  omega

#print axioms sharp_lower
#print axioms superpolynomial
end SISA.Rate
