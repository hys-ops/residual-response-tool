import Cells
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.Shadow HWB.Circuit

theorem cell_gap {m b d M q g:Nat} (sh:cell m b d M q=.double g) (_dp:0<d):
    d≤g ∧ g≤d*d+d:=by
  unfold cell at sh;dsimp only at sh;split at sh
  · rename_i act;split at sh
    · simp at sh;subst g;have sq:=Nat.le_mul_self d;have nonneg:=Nat.zero_le ((q*(4*b)%m-M)/(32*b));unfold highGap;split <;> omega
    · split at sh <;> contradiction
  · contradiction

/-- Two dark sites in any interval of length 2b belong to the very same
    4b-cell, even across the half-word or physical-page seam. -/
theorem one_cell {m b d M s k x y:Nat} (half:M+M=m) (fits:32*b*d≤M) (mp:0<m) (bp:0<b)
    (al:4*b∣M) (small:2*(d*d+d)<b) (_dp:0<d) (lo:x≤y) (dist:y<x+2*b)
    (black:clipped m b d M d k s (highGap d) x=false) (dark:clipped m b d M d k s (highGap d) y=false):
    x/(4*b)=y/(4*b):=by
  let w:=4*b
  let q:=x/w
  let t:=y/w
  let a:=x%w
  let z:=y%w
  have wa:a<w:=Nat.mod_lt _ (by dsimp [w];omega)
  have wz:z<w:=Nat.mod_lt _ (by dsimp [w];omega)
  have xx:q*w+a=x:=by dsimp [a,q];rw [Nat.mul_comm,Nat.div_add_mod]
  have yy:t*w+z=y:=by dsimp [z,t];rw [Nat.mul_comm,Nat.div_add_mod]
  have B:=actual_dark bp mp half al small wa (xx.symm ▸ black)
  have D:=actual_dark bp mp half al small wz (yy.symm ▸ dark)
  change shadowed b d s k (cell m b d M q) a at B
  change shadowed b d s k (cell m b d M t) z at D
  have qt:q≤t:=Nat.div_le_div_right lo
  apply Classical.byContradiction;intro ne
  have step:q+1≤t:=Nat.lt_of_le_of_ne qt ne
  have mul:=Nat.mul_le_mul_right w step;rw [Nat.succ_mul] at mul
  cases eq:cell m b d M q with
  | empty=>simp [eq,shadowed] at B
  | short=>simp [eq,shadowed] at B;dsimp [w] at *;omega
  | double g=>
    have next:=double_next bp (half ▸ Nat.dvd_add al al) mp half fits eq
    have diff:q+2≤t:=by
      by_cases same:t=q+1
      · rw [same,next] at D;exact False.elim D
      · omega
    have safe:=Nat.mul_le_mul_right w diff
    rw [Nat.add_mul] at safe;dsimp [w] at *;omega

theorem known_run {n Y j start L t k:Nat} (rank:Nat→Nat) (fit:t+k≤L)
    (seen:∀ z<k,rank ((Y+(start+(t+z)))%n)<j):
    k≤knownCount rank n Y j start L:=by
  let f:=fun v:Fin k=>(⟨t+v.val,by have:=v.isLt;omega⟩:Fin L)
  have inj:Function.Injective f:=by intro a b eq;apply Fin.ext;have:=congrArg Fin.val eq;change t+a.val=t+b.val at this;omega
  have nd:=SISA.Escape.distinct_map (List.finRange k) (List.nodup_finRange _) f inj
  have sub:(List.finRange k).map f⊆(List.finRange L).filter (fun v=>decide (rank ((Y+(start+v.val))%n)<j)):=by
    intro x hx;obtain ⟨v,_,rfl⟩:=List.mem_map.mp hx
    exact List.mem_filter.mpr ⟨List.mem_finRange _,decide_eq_true (seen _ v.isLt)⟩
  simpa [knownCount] using nd.length_le_of_subset sub

/-- A whole run of k early sites lies in one of the two translated free
    fields. The low s offset bits are never used for this conclusion. -/
theorem run_in_fields {m b d M s k B:Nat} (half:M+M=m) (fits:32*b*d≤M) (mp:0<m) (bp:0<b)
    (al:4*b∣M) (small:2*(d*d+d)<b) (room:4*s+2≤d) (db:d≤b)
    (wide:s+2*k≤d) (kp:0<k):
    let first:=clipped m b d M d k s (highGap d)
    ∃ F L, ((F=B ∧ L=b) ∨ (F=B+(2*b-d) ∧ L=d-s)) ∧
      ∃ t,t+k≤L ∧ ∀ z<k,first (F+(t+z))=true:=by
  let first:=clipped m b d M d k s (highGap d)
  let H:=B+(2*b-d)
  let U:=H+(d-s)
  let Page:Prop:=∃ t,t+k≤b ∧ ∀ z<k,first (B+(t+z))=true
  let Off:Prop:=∃ t,t+k≤d-s ∧ ∀ z<k,first (H+(t+z))=true
  suffices good:Page ∨ Off by
    rcases good with h|h
    · exact ⟨B,b,Or.inl ⟨rfl,rfl⟩,h⟩
    · exact ⟨H,d-s,Or.inr ⟨rfl,rfl⟩,h⟩
  apply Classical.byContradiction;intro nogood
  have np:¬Page:=fun h=>nogood (Or.inl h)
  have no:¬Off:=fun h=>nogood (Or.inr h)
  have failure (F L:Nat) (bad:¬∃ t,t+k≤L ∧ ∀ z<k,first (F+(t+z))=true) (t:Nat) (tl:t+k≤L):
      ∃ x,F+t≤x ∧ x<F+t+k ∧ first x=false:=by
    apply Classical.byContradiction;intro nope
    apply bad;refine ⟨t,tl,?_⟩;intro z zk
    cases h:first (F+(t+z))
    · exact False.elim (nope ⟨_,by omega,by omega,h⟩)
    · rfl
  obtain ⟨x,xl,xu,xb⟩:=failure B b np 0 (by omega)
  obtain ⟨y,yl,yu,yb⟩:=failure H (d-s) no (d-s-k) (by omega)
  have ext:U=B+2*b-s:=by dsimp [U,H];omega
  have dp:0<d:=by omega
  let w:=4*b
  let q:=x/w
  let C:=q*w
  have every {i:Nat} (lo:B≤i) (up:i<U) (dark:first i=false):
      shadowed b d s k (cell m b d M q) (i-C) ∧ C≤i:=by
    have same:i/w=q:=by
      rcases Nat.le_total i x with le|le
      · exact one_cell half fits mp bp al small dp le (by omega) dark xb
      · exact (one_cell half fits mp bp al small dp le (by omega) xb dark).symm
    have dec:C+i%w=i:=by
      dsimp [C];rw [←same,Nat.mul_comm,Nat.div_add_mod]
    have low:i%w<w:=Nat.mod_lt _ (by dsimp [w];omega)
    have sh:=actual_dark bp mp half al small low (dec.symm ▸ dark)
    have ix:i-C=i%w:=by omega
    exact ⟨ix ▸ sh,by omega⟩
  have fx:=every (i:=x) (by omega) (by dsimp [H,U] at *;omega) xb
  have fy:=every (i:=y) (by dsimp [H] at *;omega) (by dsimp [U];omega) yb
  cases eq:cell m b d M q with
  | empty=>simp [eq,shadowed] at fx
  | short=>
    simp [eq,shadowed] at fy
    have _:d*d+d≥d:=by omega
    dsimp [U,H] at *;omega
  | double g=>
    have gr:=cell_gap eq dp
    have sm:2*g<b:=by omega
    let A:=(clippedAnchors d s g).1
    let T:=d-s
    let E:=C+2*b+g
    have fit:=anchors_fit (by omega : 2*s<d) gr.1
    change A<g ∧ 0<T ∧ T≤g ∧ T≤d-s ∧ g+s≤A+T at fit
    have shadow {i:Nat} (iB:B≤i) (iU:i<U) (ib:first i=false):
        C≤i ∧ i<E ∧ k≤(i-C)+1 ∧ k≤E-i ∧
        ¬((i-C)<A+k ∧ A<(i-C)+k) ∧
        ¬((i-C)<(2*b+g-T)+k ∧ (2*b+g-T)<(i-C)+k):=by
      have hit:=every iB iU ib
      rw [eq] at hit
      change ((i-C<2*b+g) ∧ interior b g A T k (i-C)=false) ∧ C≤i at hit
      simp [interior,nearby] at hit
      dsimp [E];omega
    have sx:=shadow (i:=x) (by omega) (by dsimp [U,H] at *;omega) xb
    have sy:=shadow (i:=y) (by dsimp [H] at *;omega) (by dsimp [U] at *;omega) yb
    have Cb:C≤B:=by omega
    have eU:U≤E:=by dsimp [U] at *;omega
    let v:=B-C
    have vfit:v≤g+s:=by dsimp [v,U,H,E] at *;omega
    have hit:=@clipped_hit (b:Int) (d:Int) (s:Int) (g:Int) (A:Int) (T:Int) (v:Int)
      (by omega) (by omega) (by dsimp [T] at *;omega) (by omega) (by omega)
    have mark (F L Z:Nat) (fl:B≤F ∧ F+L≤U) (long:k≤L) (inmark:F≤Z ∧ Z<F+L)
        (atmark:Z=C+A ∨ Z=C+(2*b+g-T)):
        ∃ t,t+k≤L ∧ ∀ z<k,first (F+(t+z))=true:=by
      let t:=min (Z-F) (L-k)
      refine ⟨t,by dsimp [t];omega,?_⟩;intro z zk
      let i:=F+(t+z)
      have near:i<Z+k ∧ Z<i+k:=by dsimp [i,t];omega
      have ins:B≤i ∧ i<U:=by dsimp [i,t];omega
      cases ib:first i
      · have fail:=shadow ins.1 ins.2 ib;omega
      · rfl
    rcases hit with left|right
    · apply np;apply mark B b (C+A) (by dsimp [U,H];omega) (by omega) _ (Or.inl rfl)
      dsimp [v] at *;omega
    · apply no;apply mark H (d-s) (C+(2*b+g-T)) (by dsimp [U,H];omega) (by omega) _ (Or.inr rfl)
      dsimp [v,H,T] at *;omega

/-- Every prefix that contains a late site has disclosed at least k of the
    page bits and high offset bits of every pointer, including circular reads. -/
theorem disclosed {n m b d M s k j Y:Nat} (mn:m∣n) (half:M+M=m) (fits:32*b*d≤M) (np:0<n) (mp:0<m) (bp:0<b)
    (al:4*b∣M) (small:2*(d*d+d)<b) (room:4*s+2≤d) (db:d≤b)
    (wide:s+2*k≤d) (kp:0<k) (mb:2*b≤m):
    let first:=clipped m b d M d k s (highGap d)
    let rank:=(schedule n m b d first).idxOf
    (∃ l<n,first l=false ∧ rank l<j) →
    k≤knownCount rank n Y j (m-2*b) b + knownCount rank n Y j (m-d) (d-s):=by
  dsimp only
  let first:=clipped m b d M d k s (highGap d)
  let rank:=(schedule n m b d first).idxOf
  rintro ⟨l,ll,late,read⟩
  change first l=false at late
  change k≤knownCount rank n Y j (m-2*b) b + knownCount rank n Y j (m-d) (d-s)
  have visible (i:Nat) (on:first i=true):rank (i%n)<j:=by
    have same:first (i%n)=first i:=by
      simp only [first,clipped,Nat.mod_mod_of_dvd _ mn,early]
    have ph:phase m b d first (i%n)<phase m b d first l:=by simp [phase,same,on,late];omega
    exact Nat.lt_trans (phase_precedes first (Nat.mod_lt _ np) ll ph) read
  obtain ⟨F,L,part,t,tl,vis⟩:=run_in_fields (B:=Y+(m-2*b)) half fits mp bp al small room db wide kp
  rcases part with ⟨eq1,eq2⟩|⟨eq1,eq2⟩
  · rw [eq1] at vis;rw [eq2] at tl
    have count:=known_run (n:=n) (Y:=Y) (start:=m-2*b) rank tl (fun z hz=>by rw [←Nat.add_assoc];exact visible _ (vis z hz))
    omega
  · rw [eq1] at vis;rw [eq2] at tl
    have eq:Y+(m-2*b)+(2*b-d)=Y+(m-d):=by omega
    rw [eq] at vis
    have count:=known_run (n:=n) (Y:=Y) (start:=m-d) rank tl (fun z hz=>by rw [←Nat.add_assoc];exact visible _ (vis z hz))
    omega

#print axioms run_in_fields
#print axioms disclosed
end SISA.Rate
