import DisclosureRate
import SharpLower
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow SISA.FixedWord HWB.Circuit HWB.ResidualCompiler

structure UpperScales (d b m:Nat):Prop where
  half:m/2+m/2=m
  fits:32*b*d≤m/2
  bm:b≤m/2
  db:d≤b
  bp:0<b
  mp:0<m
  aligned:4*b∣m/2
  bmdiv:b∣m
  mn:m∣2^m
  room:m*m+b≤2^m
  small:2*(d*d+d)<b
  setup:4*tileBits d+2≤d
  wide:tileBits d+2*radius d≤d

theorem upper_scales {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):UpperScales d b m:=by
  obtain ⟨c⟩:=chooseNumbers large bb mm
  obtain ⟨vw,ul,dl,du,uv,_⟩:=log_envelope large
  have grow:=exp_grows (by omega : 8≤d.log2)
  have growv:=exp_grows (by omega : 8≤d.log2.log2)
  have growd:=exp_grows (by omega : 8≤d)
  have bpos:=bb ▸ Nat.two_pow_pos d
  have growb:=exp_grows (by omega : 8≤b)
  have mp:=mm ▸ Nat.two_pow_pos b
  have half:c.M=m/2:=by have:=c.half;omega
  have halfeq:m/2+m/2=m:=half ▸ c.half
  have little:2^(b-1)=m/2:=by
    have eq:2^(b-1)*2=m:=by rw [←Nat.pow_succ,show (b-1).succ=b by omega,mm]
    omega
  have al:4*b∣m/2:=by
    rw [←little,←show 2^(2+d)=4*b by rw [Nat.pow_add,bb]]
    exact Nat.pow_dvd_pow 2 (by omega)
  have bm:b∣m:=halfeq ▸ Nat.dvd_add (Nat.dvd_trans (Nat.dvd_mul_left ..) al) (Nat.dvd_trans (Nat.dvd_mul_left ..) al)
  have mn:m∣2^m:=by rw [←mm];exact Nat.pow_dvd_pow 2 (Nat.le_of_lt Nat.lt_two_pow_self)
  have ms:m*m=2^(b+b):=by rw [Nat.pow_add,mm]
  have cap:=pow2mono (show b+b+1≤m by omega)
  rw [Nat.pow_succ,←ms] at cap
  have lower:b≤m*m:=Nat.le_trans (by omega : b≤m) (Nat.le_mul_self m)
  refine ⟨halfeq,half ▸ c.fits,by omega,by omega,bpos,mp,al,bm,mn,by omega,c.small,?_,?_⟩
  · unfold tileBits;omega
  · unfold tileBits radius;omega

theorem all_layers {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m)
    (y:List Bool) (j:Nat):
    let n:=2^m
    let ord:=schedule n m b d (chosenMask m b d)
    (attained (highModel n m b d (m/2) (tileBits d) (radius d) y ord.idxOf) j).length≤n^(depth d+43):=by
  dsimp only
  let n:=2^m
  let first:=chosenMask m b d
  let ord:=schedule n m b d first
  let rank:=ord.idxOf
  let e:=knownCount rank n (beValue y) j (m-2*b) b
  let v:=knownCount rank n (beValue y) j (m-d) (d-tileBits d)
  let J:=(residuesRead n m b j first rank).length
  let S:=highModel n m b d (m/2) (tileBits d) (radius d) y rank
  have sc:=upper_scales large bb mm
  have small (i:Nat) (hd:i<d):2*highGap d i<b:=by have:=sc.small;unfold highGap;split <;> omega
  have cov:d≤2^tileBits d:=Nat.le_of_lt Nat.lt_log2_self
  have align:b∣m/2:=Nat.dvd_trans (Nat.dvd_mul_left ..) sc.aligned
  have grid:J≤4*(e+1):=phases_by_known first (Nat.two_pow_pos _) bb sc.bmdiv sc.mn
  by_cases late:∃ l<n,first l=false ∧ rank l<j
  · have dis:radius d≤e+v:=disclosed sc.mn sc.half sc.fits (Nat.two_pow_pos _) sc.mp sc.bp sc.aligned sc.small
      sc.setup sc.db sc.wide (by unfold radius;omega) (by have:=sc.bm;have:=sc.half;omega) late
    apply Nat.le_trans (attained_product S j)
    have h (z:List Bool):((List.finRange (2^b)).map (pageCost S j z)).prod≤n^(depth d+42):=by
      obtain ⟨P,X,pp,xp,vx,count⟩:=header_factor (n:=n) (j:=j) (k:=radius d) sc.half sc.bm align bb mm sc.setup cov sc.db small y z rank
      exact Nat.le_trans count (cost_arithmetic large grid dis pp xp vx)
    apply Nat.le_trans (sum_budget _ _ _ (fun z _=>h z))
    rw [words_len];change n*n^(depth d+42)≤n^(depth d+43);rw [←Nat.pow_succ'];exact Nat.le_refl _
  · have bound:=early_records (n:=n) (j:=j) (k:=radius d) sc.half sc.bm sc.setup small bb mm y rank
      (by intro i ib ij;change first i=true;cases h:first i;exact False.elim (late ⟨i,ib,h,ij⟩);rfl)
    apply Nat.le_trans bound
    have pp:=Nat.pow_le_pow_left (radius_scale d) m
    apply Nat.le_trans (Nat.mul_le_mul_left (2^m) pp)
    rw [←Nat.pow_mul,Nat.mul_comm (depth d+12) m,Nat.pow_mul,←Nat.pow_succ']
    exact Nat.pow_le_pow_right (Nat.two_pow_pos m) (by omega)

/-- Finite-input whole-circuit upper bound with its concrete visiting order. -/
theorem sharp_upper_words {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):
    let n:=2^m
    let ord:=schedule n m b d (chosenMask m b d)
    let W:=word .double m b (m/2) d (highGap d)
    ∃ N,N≤n^(depth d+46) ∧ ∃ (G:DAG N) (r:State N),∀ y x:List Bool,y.length=m → x.length=n →
      (G.eval (wordInput (y++x)) r=true ↔ checked n m b y W (memory n ord.idxOf x)):=by
  dsimp only
  let n:=2^m
  let ord:=schedule n m b d (chosenMask m b d)
  let W:=word .double m b (m/2) d (highGap d)
  let Q:=n^(depth d+43)
  have sc:=upper_scales large bb mm
  have qp:0<Q:=Nat.pow_pos (Nat.two_pow_pos _)
  obtain ⟨G,r,ok⟩:=compile_banks (n:=n) (d:=m) (Q:=Q)
    (fun y=>highModel n m b d (m/2) (tileBits d) (radius d) y ord.idxOf)
    qp (fun y _ j _=>all_layers large bb mm y j)
  refine ⟨(m+n)*(Q*2^m),?_,G,r,?_⟩
  · have up:m≤n:=Nat.le_of_lt Nat.lt_two_pow_self
    have two:2≤n:=Nat.one_lt_two_pow (by have:=sc.mp;omega)
    have nn:2*n≤n*n:=Nat.mul_le_mul_right n two
    calc
      _ ≤ (n*n)*(Q*n) := Nat.mul_le_mul_right _ (by omega)
      _ = n^(depth d+46) := by dsimp [Q];rw [show depth d+46=(depth d+43)+3 by omega,Nat.pow_add];simp [Nat.pow_succ,Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm]
  · intro y x yl xl
    apply (ok y x yl xl).trans
    exact original_accepts W y x (by simp [W,word]) yl ord.idxOf (chosenMask m b d) sc.bm sc.half sc.db bb mm
      (Nat.two_pow_pos _) sc.room
#print axioms all_layers
#print axioms sharp_upper_words
end SISA.Rate
