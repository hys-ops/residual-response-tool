import LateCosts
import EarlyRate
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

def inPool [DecidableEq α] (all pool:List α):List α:=all.filter (fun x=>decide (x∈pool))

theorem inPool_le [DecidableEq α] (all pool:List α) (nd:all.Nodup):
    (inPool all pool).length≤pool.length:=by
  have n:(inPool all pool).Nodup:=List.Pairwise.filter _ nd
  exact n.length_le_of_subset (by intro x hx;exact of_decide_eq_true (List.mem_filter.mp hx).2)

def shiftPool {P:Nat} (b:Nat) (sus:List Nat):List (Fin P):=
  sus.flatMap fun t=>(List.range (P/b)).filterMap (fun q=>if h:q*b+t<P then some ⟨q*b+t,h⟩ else none)

theorem shiftPool_len {P b:Nat} (sus:List Nat):
    (shiftPool (P:=P) b sus).length≤sus.length*(P/b):=by
  apply SISA.Escape.upper_flat;intro x _
  exact Nat.le_trans (List.length_filterMap_le _ _) (Nat.le_of_eq List.length_range)

theorem in_shiftPool {P b:Nat} (bp:0<b) (divide:b∣P) (sus:List Nat) (p:Fin P) (mem:p.val%b∈sus):
    p∈shiftPool b sus:=by
  obtain ⟨q,qq⟩:=divide
  have full:P/b=q:=by rw [qq,Nat.mul_div_cancel_left _ bp]
  have idx:p.val/b<P/b:=by rw [full];apply (Nat.div_lt_iff_lt_mul bp).mpr;rw [Nat.mul_comm q b,←qq];exact p.isLt
  have eq:p.val/b*b+p.val%b=p.val:=by rw [Nat.mul_comm (p.val/b),Nat.div_add_mod]
  apply List.mem_flatMap.mpr;refine ⟨_,mem,List.mem_filterMap.mpr ⟨_,List.mem_range.mpr idx,?_⟩⟩
  simp [eq,p.isLt]

theorem product_on_classes [DecidableEq α] (pages viable extra:List α) (cost:α→Nat) (B C D:Nat)
    (one:∀ p∈pages,p∉viable → cost p≤B)
    (regular:∀ p∈pages,p∈viable → p∉extra → cost p≤B*C)
    (both:∀ p∈pages,p∈viable → p∈extra → cost p≤B*C*D):
    (pages.map cost).prod≤B^pages.length*C^(inPool pages viable).length*D^(inPool (inPool pages viable) extra).length:=by
  induction pages with
  | nil=>simp [inPool]
  | cons p ps ih=>
    have rest:=ih (fun t h=>one t (by simp [h])) (fun t h=>regular t (by simp [h])) (fun t h=>both t (by simp [h]))
    by_cases vp:p∈viable
    · by_cases xp:p∈extra
      · have bound:=Nat.mul_le_mul (both p (by simp) vp xp) rest
        simpa [inPool,vp,xp,Nat.pow_succ,Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using bound
      · have bound:=Nat.mul_le_mul (regular p (by simp) vp xp) rest
        simpa [inPool,vp,xp,Nat.pow_succ,Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using bound
    · have bound:=Nat.mul_le_mul (one p (by simp) vp) rest
      simpa [inPool,vp,Nat.pow_succ,Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using bound

/-- The exact contribution of a fixed observed header is bounded by three
    powers, with cardinality guarantees on their exponents. -/
theorem header_factor {n m b d M s k j:Nat} (half:M+M=m) (bm:b≤M) (align:b∣M)
    (bb:2^d=b) (mm:2^b=m) (room:4*s+2≤d) (cover:d≤2^s) (db:d≤b)
    (small:∀ i<d,2*highGap d i<b) (y z:List Bool) (rank:Nat→Nat):
    let S:=highModel n m b d M s k y rank
    let J:=(residuesRead n m b j (clipped m b d M d k s (highGap d)) rank).length
    let e:=knownCount rank n (beValue y) j (m-2*b) b
    let v:=knownCount rank n (beValue y) j (m-d) (d-s)
    ∃ P X, P*2^e≤m ∧ X≤P ∧ X*2^v≤4*m*J ∧
       ((List.finRange (2^b)).map (pageCost S j z)).prod
          ≤(2*(2+6*(2*k+1)))^m*(2^(3*J))^P*(2+J*(d+1))^X:=by
  classical
  dsimp only
  let S:=highModel n m b d M s k y rank
  let J:=(residuesRead n m b j (clipped m b d M d k s (highGap d)) rank).length
  let pool:=pagePool (b:=b) (mask rank n (beValue y) j (m-2*b) b z)
  let sus:=suspect n m b d M s k j y z rank
  let pages:=List.finRange (2^b)
  let extra:=shiftPool (P:=2^b) b sus
  let viable:=inPool pages pool
  let exceptions:=inPool viable extra
  have nd:pages.Nodup:=List.nodup_finRange _
  have div:b∣2^b:=mm ▸ half ▸ Nat.dvd_add align align
  have bp:0<b:=bb ▸ Nat.two_pow_pos d
  have fit:2*b≤m:=by omega
  have vp:viable.length≤pool.length:=inPool_le _ _ nd
  have se:exceptions.length≤extra.length:=inPool_le _ _ (List.Pairwise.filter _ nd)
  refine ⟨viable.length,exceptions.length,?_,List.length_filter_le ..,?_,?_⟩
  · exact Nat.le_trans (Nat.mul_le_mul_right _ vp) (Nat.le_of_eq ((page_pool_budget y z rank).trans mm))
  · have h:=Nat.le_trans se (shiftPool_len (P:=2^b) (b:=b) sus)
    have hs:=suspect_budget (m:=m) (n:=n) (M:=M) (k:=k) (s:=s) (j:=j) (by omega : s≤d) bb y z rank
    have q:(2^b/b)*b=2^b:=Nat.div_mul_cancel div
    calc
      _ ≤ (sus.length*(2^b/b))*2^(knownCount rank n (beValue y) j (m-d) (d-s)) := Nat.mul_le_mul_right _ h
      _ = (2^b/b)*(sus.length*2^(knownCount rank n (beValue y) j (m-d) (d-s))) := by ac_rfl
      _ ≤ (2^b/b)*(4*b*J) := Nat.mul_le_mul_left _ hs
      _ = 4*((2^b/b)*b)*J := by ac_rfl
      _ = _ := by rw [q,mm]
  · have good (p:Fin (2^b)) (ok:∃ a,allowed S j z p a):p∈pool:=by
      obtain ⟨a,ha⟩:=ok;exact physical_page fit y z rank p a ha
    have ed (p:Fin (2^b)):=edge_budget (n:=n) (d:=d) (s:=s) (k:=k) (j:=j) half bm align bp y rank p
    have ear (p:Fin (2^b)):=early_dictionary (n:=n) (k:=k) half room small bb y z rank j p
    have late (p:Fin (2^b)):=late_dictionary (n:=n) (s:=s) (k:=k) (j:=j) half align bb small y z rank p
    have len:pages.length=m:=List.length_finRange.trans mm
    rw [←show (2*(2+6*(2*k+1)))^pages.length=(2*(2+6*(2*k+1)))^m from congrArg _ len]
    apply product_on_classes pages pool extra
    · intro p _ no
      have h:¬∃ a,allowed S j z p a:=fun h=>no (good p h)
      simp [pageCost,h,S] at * <;> omega
    · intro p _ _ no
      have out:p.val%b∉sus:=fun h=>no (in_shiftPool bp div _ p h)
      have one:=late_outside (by exact half) align bb (by omega) fit db (by omega) cover small y z rank p out
      change (dictionary S j z p false).length≤1 at one
      change pageCost S j z p≤_
      unfold pageCost;split
      · have u:=ear p;change (dictionary S j z p true).length≤_ at u
        calc
          _ ≤ 2*((2+6*(2*k+1))*2^(3*J)) := Nat.mul_le_mul (by omega) (Nat.mul_le_mul (by omega) (pow2mono (ed p)))
          _ = _ := by ac_rfl
      · have pp:=Nat.two_pow_pos (3*J);exact Nat.mul_pos (by omega) pp
    · intro p _ _ _;change pageCost S j z p≤_
      unfold pageCost;split
      · have u:=ear p;have l:=late p
        change (dictionary S j z p true).length≤_ at u;change (dictionary S j z p false).length≤1+J*(d+1) at l
        have est:=Nat.mul_le_mul (show (dictionary S j z p false).length+1≤2+J*(d+1) by omega)
          (Nat.mul_le_mul (show (dictionary S j z p true).length+1≤2*(2+6*(2*k+1)) by omega) (pow2mono (ed p)))
        simpa [Nat.mul_assoc,Nat.mul_comm,Nat.mul_left_comm] using est
      · exact Nat.mul_pos (Nat.mul_pos (by omega) (Nat.two_pow_pos _)) (by omega)
#print axioms header_factor
end SISA.Rate
