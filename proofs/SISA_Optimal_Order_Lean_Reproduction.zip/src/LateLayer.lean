import EarlyLayer
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

def edits (d:Nat):List Nat:=0::(List.range d).map (highGap d)

theorem edited_residue {m b d M i:Nat} (align:b∣M) (im:i<m)
    (small:∀ j<d,2*highGap d j<b)
    (edit:get (word .double m b M d (highGap d)) i≠decide (M≤i)):
    i%b∈edits d:=by
  by_cases lo:i<M
  · have e:i%(4*b)=0 ∧ i/(4*b)<8*d:=by simpa [word,get,im,lo,show ¬M≤i by omega] using edit
    have divides:b∣4*b:=⟨4,Nat.mul_comm ..⟩
    have v:=Nat.mod_mod_of_dvd i divides
    rw [e.1,Nat.zero_mod] at v;simp [edits,←v]
  · let u:=i-M
    let j:=u/(32*b)
    let g:=highGap d j
    let r:=u%(32*b)
    have e:j<d ∧ holes .double b g r=true:=by
      simpa [word,get,im,lo,show M≤i by omega,j,u,r,g] using edit
    have rem:i%b=r%b:=by
      obtain ⟨v,hv⟩:=align
      have irep:i=u+v*b:=by dsimp [u];rw [Nat.mul_comm v b,←hv];omega
      rw [irep,Nat.add_mul_mod_self_right];exact (Nat.mod_mod_of_dvd u (show b∣32*b from ⟨32,Nat.mul_comm ..⟩)).symm
    have gmem:g∈edits d:=List.mem_cons.mpr (Or.inr (List.mem_map.mpr ⟨j,List.mem_range.mpr e.1,rfl⟩))
    have sm:=small j e.1
    have gl:g<b:=by change 2*g<b at sm;omega
    have val:=e.2
    simp only [holes,starts,List.any_cons,List.any_nil,Bool.or_false,Bool.or_eq_true,decide_eq_true_eq] at val
    rw [rem]
    rcases val with (z|z)|(z|z)|(z|z)|(z|z)
    all_goals rw [z]
    all_goals first | solve | simp [edits] | simpa [Nat.mul_add_mod_self_left,Nat.mod_eq_of_lt gl,Nat.add_comm] using gmem

def residue (m b i:Nat):Nat:=(i%b+b-(i/m)%b)%b

/-- Exact phase residues represented anywhere in the observed late core or boundary. -/
noncomputable def residuesRead (n m b j:Nat) (first:Nat→Bool) (rank:Nat→Nat):List Nat:=
  (((List.range n).filter (fun i=> !(first i) && decide (rank i<j))).map (residue m b)).eraseDups

def shiftOffsets (b t:Nat) (rs es:List Nat):List Nat:=
  rs.flatMap (fun r=>es.map (fun e=>(t+r+(b-e))%b))

theorem shiftOffsets_len (b t:Nat) (rs es:List Nat):
    (shiftOffsets b t rs es).length=rs.length*es.length:=by
  unfold shiftOffsets;apply flatMap_count;intro r;simp

theorem rotate_residue {p i m b:Nat} (ib:p*m≤i) (endPage:i<p*m+m) (bp:0<b) (align:b∣m):
    (p%b+residue m b i)%b=(i-p*m)%b:=by
  let u:=i-p*m
  have um:u<m:=by dsimp [u];omega
  have eq:i=u+p*m:=by dsimp [u];omega
  have im:i/m=p:=by rw [eq,Nat.add_mul_div_right _ _ (by omega),Nat.div_eq_of_lt um,Nat.zero_add]
  have pm:b∣p*m:=Nat.dvd_mul_left_of_dvd align _
  have loc:i%b=u%b:=by obtain ⟨q,h⟩:=pm;rw [eq,h,Nat.mul_comm b q,Nat.add_mul_mod_self_right]
  have t:=Nat.mod_lt p bp
  unfold residue
  rw [im,Nat.add_mod_mod,show p%b+(i%b+b-p%b)=i%b+b by omega,Nat.add_mod_right,loc,Nat.mod_mod]

private theorem shift_cancel {b t r u a e:Nat} (au:a≤u) (ab:a<b) (eb:e<b)
    (rr:(t+r)%b=u%b) (ec:(u-a)%b=e):
    (t+r+(b-e))%b=a:=by
  have eq:(a+e)%b=(t+r)%b:=by rw [←ec,Nat.add_mod_mod,Nat.add_sub_of_le au,rr]
  rw [←Nat.mod_add_mod,←eq,Nat.mod_add_mod,Nat.add_assoc,Nat.add_sub_of_le (Nat.le_of_lt eb),
    Nat.add_mod_right,Nat.mod_eq_of_lt ab]

def lateBase (m M p:Nat) (sites:List Nat):List Bool:=sites.map (fun i=>decide (p*m+M≤i))

/-- For the original literal word, a nonbaseline late signature pins its offset
    to an explicitly listed phase/edit pair. The phase list is computed from
    the actual prefix, including any incomplete phase. -/
theorem late_witness {n m b d M s k j:Nat} (half:M+M=m) (align:b∣M) (bb:2^d=b)
    (small:∀ z<d,2*highGap d z<b) (y:List Bool) (rank:Nat→Nat) (p:Fin (2^b)) (a:Fin (2^d)):
    let first:=clipped m b d M d k s (highGap d)
    let S:=highModel n m b d M s k y rank
    let sites:=seen S j (S.core p false)
    signature S j p false a≠lateBase m M p.val sites →
    ∃ r∈residuesRead n m b j first rank,∃ e∈edits d,
       e<b ∧ r<b ∧ a.val=(p.val%b+r+(b-e))%b ∧ (a.val+e+(b-r))%b=p.val%b:=by
  dsimp only;intro bad
  classical
  let S:=highModel n m b d M s k y rank
  let W:=word .double m b M d (highGap d)
  let first:=clipped m b d M d k s (highGap d)
  let sites:=seen S j (S.core p false)
  obtain ⟨i,hi,ne⟩:∃ i∈sites,get W (i-(p.val*m+a.val))≠decide (p.val*m+M≤i):=by
    apply Classical.byContradiction;intro no;apply bad
    apply List.map_congr_left;intro i hi;exact Classical.byContradiction (fun ne=>no ⟨i,hi,ne⟩)
  have ⟨hs,obs⟩:=List.mem_filter.mp hi
  have ⟨hn,hc⟩:=List.mem_filter.mp hs
  have ins:=List.mem_range.mp hn
  have split:coreSite m b M p.val i ∧ first i=false:=by simpa [S,highModel,physical,first] using hc
  let u:=i-p.val*m
  have core:(b≤u ∧ u<M) ∨ (M+b≤u ∧ u<m):=by dsimp [u];have:=split.1;unfold coreSite at this;omega
  have phys:p.val*m≤i ∧ i<p.val*m+m:=by have:=split.1;unfold coreSite at this;omega
  have av:a.val<b:=bb ▸ a.isLt
  have bp:0<b:=by omega
  have te:(M≤u-a.val) ↔ p.val*m+M≤i:=by dsimp [u];rcases core with h|h <;> dsimp [u] at h <;> omega
  let e:=(u-a.val)%b
  have em:e∈edits d:=by
    apply edited_residue (m:=m) (i:=u-a.val) align (by omega) small
    simpa [W,u,te,show i-(p.val*m+a.val)=u-a.val by dsimp [u];omega] using ne
  let r:=residue m b i
  have rr:(p.val%b+r)%b=u%b:=rotate_residue phys.1 phys.2 bp (half ▸ Nat.dvd_add align align)
  have rm:r∈residuesRead n m b j first rank:=by
    apply List.mem_eraseDups.mpr;apply List.mem_map.mpr;refine ⟨i,List.mem_filter.mpr ⟨hn,?_⟩,rfl⟩
    simpa [split.2,S,highModel,physical] using obs
  have eb:e<b:=Nat.mod_lt _ bp
  have rb:r<b:=Nat.mod_lt _ bp
  have eql:(a.val+e)%b=(p.val%b+r)%b:=by dsimp [e];rw [Nat.add_mod_mod,Nat.add_sub_of_le (by omega),rr]
  refine ⟨r,rm,e,em,eb,rb,(shift_cancel (by omega) av eb rr rfl).symm,?_⟩
  rw [←Nat.mod_add_mod,eql,Nat.mod_add_mod,Nat.add_assoc,Nat.add_sub_of_le (by omega),Nat.add_mod_right,Nat.mod_mod]

theorem late_dictionary {n m b d M s k j:Nat} (half:M+M=m) (align:b∣M) (bb:2^d=b)
    (small:∀ z<d,2*highGap d z<b) (y z:List Bool) (rank:Nat→Nat) (p:Fin (2^b)):
    let R:=residuesRead n m b j (clipped m b d M d k s (highGap d)) rank
    (dictionary (highModel n m b d M s k y rank) j z p false).length≤1+R.length*(d+1):=by
  dsimp only
  let S:=highModel n m b d M s k y rank
  let R:=residuesRead n m b j (clipped m b d M d k s (highGap d)) rank
  let base:=lateBase m M p.val (seen S j (S.core p false))
  let sig:=fun t:Nat=>signature S j p false ⟨t%2^d,Nat.mod_lt _ (Nat.two_pow_pos _)⟩
  let book:=base::(shiftOffsets b (p.val%b) R (edits d)).map sig
  have len:book.length=1+R.length*(d+1):=by simp [book,shiftOffsets_len,edits,Nat.add_comm]
  rw [←len];apply dict_cover;intro a _
  by_cases eq:signature S j p false a=base
  · exact List.mem_cons.mpr (Or.inl eq)
  · obtain ⟨r,hr,e,he,_,_,id,_⟩:=late_witness half align bb small y rank p a eq
    apply List.mem_cons.mpr;right;apply List.mem_map.mpr
    refine ⟨a.val,List.mem_flatMap.mpr ⟨r,hr,List.mem_map.mpr ⟨e,he,id.symm⟩⟩,?_⟩
    simp [sig,S,Nat.mod_eq_of_lt a.isLt]

#print axioms late_witness
#print axioms late_dictionary
end SISA.Rate
