import SharpUpper
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow SISA.FixedWord HWB.Circuit HWB.ResidualCompiler

private def capState (G:DAG N) (L:Nat):State N→State N
  | .term z=>.term z
  | .node i=>if G.level i<L then .node i else .term (G.eval (fun _=>false) (.node i))

private theorem cap_height (G:DAG N) (L:Nat) (s:State N):(capState G L s).height≤s.height:=by
  cases s with | term z=>exact Nat.le_refl _ | node i=>simp [capState];split <;> simp [State.height]

/-- Compile a padded finite-input promise into an ordinary diagram with every
    node level in the physical input. Padding is folded to terminal values. -/
private def cap (G:DAG N) (L:Nat):DAG N where
  level i:=if G.level i<L then G.level i else 0
  child i z:=if G.level i<L then capState G L (G.child i z) else .term false
  drops i z:=by split;exact Nat.lt_of_le_of_lt (cap_height ..) (G.drops i z);simp [State.height]
  advances i z j e:=by
    split at e
    · rename_i li
      cases c:G.child i z with
      | term q=>simp [c,capState] at e
      | node t=>
        simp only [c,capState] at e;split at e
        · rename_i bound;cases e;simp [li,bound,G.advances i z j c]
        · contradiction
    · contradiction

private theorem eval_tail {G:DAG N} {L:Nat} (v:Input) (vanish:∀ i,L≤i → v i=false)
    (i:Fin N) (out:L≤G.level i):G.eval v (.node i)=G.eval (fun _=>false) (.node i):=by
  rw [DAG.eval,DAG.eval,vanish _ out]
  cases c:G.child i false with
  | term z=>simp [DAG.eval]
  | node t=>exact eval_tail v vanish t (Nat.le_trans out (Nat.le_of_lt (G.advances i false t c)))
termination_by i.val
decreasing_by have:=G.drops i false;rw [c] at this;simpa [State.height] using this

private theorem cap_eval (G:DAG N) (L:Nat) (v:Input) (s:State N):
    (cap G L).eval v (capState G L s)=G.eval (fun i=>if i<L then v i else false) s:=by
  cases s with
  | term z=>simp [capState,DAG.eval]
  | node i=>
    by_cases inside:G.level i<L
    · simp only [capState,inside,↓reduceIte]
      rw [DAG.eval,DAG.eval];simp only [cap,inside,↓reduceIte]
      exact cap_eval G L v _
    · simp only [capState,inside,↓reduceIte]
      rw [DAG.eval]
      exact (eval_tail (fun i=>if i<L then v i else false) (fun i hi=>by simp [Nat.not_lt.mpr hi]) i (Nat.le_of_not_gt inside)).symm
termination_by s.height
decreasing_by exact G.drops .. 

private def headInput (w:Input) (m:Nat):List Bool:=List.ofFn fun i:Fin m=>w i.val
private def dataInput (w:Input) (m n:Nat):List Bool:=List.ofFn fun i:Fin n=>w (m+i.val)

private theorem padded {m n:Nat} (w:Input):
    wordInput (headInput w m++dataInput w m n)=(fun i=>if i<m+n then w i else false):=by
  funext i
  by_cases h:i<m
  · simp [wordInput,headInput,dataInput,h,show i<m+n by omega]
  · simp only [wordInput,headInput,dataInput,List.getElem?_append_right (by simpa using (Nat.le_of_not_gt h) :
        (List.ofFn fun a:Fin m=>w a.val).length≤i),List.length_ofFn,List.getElem?_ofFn]
    by_cases endp:i<m+n <;> simp [endp,show (i-m<n) ↔ i<m+n by omega] <;> congr 1 <;> omega

private theorem fixed_check {m b:Nat} (w:Input) (W:List Bool) (ord:List Nat) (perm:ord.Perm (List.range (2^m))):
    fixedAt (fun a=>a/m<m ∧ a%m<b) m W (rankOf (2^m) m ord) w ↔
    checked (2^m) m b (headInput w m) W (memory (2^m) ord.idxOf (dataInput w m (2^m))):=by
  let n:=2^m
  have Y:(List.ofFn fun i:Fin m=>w (rankOf n m ord (n+i.val)))=headInput w m:=by
    unfold headInput;apply congrArg List.ofFn;funext i;simp [rankOf,show ¬n+i.val<n by omega]
  have X:(List.ofFn fun i:Fin n=>w (rankOf n m ord i.val))=memory n ord.idxOf (dataInput w m n):=by
    unfold memory;apply congrArg List.ofFn;funext i
    have mem:=perm.mem_iff.mpr (List.mem_range.mpr i.isLt)
    have len:ord.length=n:=perm.length_eq.trans List.length_range
    have lt:ord.idxOf i.val<n:=Nat.lt_of_lt_of_eq (List.idxOf_lt_length_of_mem mem) len
    simp [rankOf,i.isLt,dataInput,get,lt]
  unfold fixedAt
  rw [show (List.ofFn fun i:Fin m=>w (rankOf (2^m) m ord (2^m+i.val)))=_ from Y,
    show (List.ofFn fun i:Fin (2^m)=>w (rankOf (2^m) m ord i.val))=_ from X]
  simp [checked,SISA.Disclosure.address,headInput,n,and_assoc]

def correct (m b d:Nat) (rank:Nat→Nat) (G:DAG N) (r:State N):Prop:=
  ∀ w,G.eval w r=true ↔ fixedAt (fun a=>a/m<m ∧ a%m<b) m (word .double m b (m/2) d (highGap d)) rank w

/-- A bounded-level physical OBDD for precisely the predicate of sharp_lower. -/
theorem sharp_upper {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):
    let n:=2^m
    let ord:=schedule n m b d (chosenMask m b d)
    ord.Perm (List.range n) ∧
    ∃ N,N≤n^(depth d+46) ∧ ∃ (G:DAG N) (r:State N),
      (∀ i,G.level i<m+n) ∧ correct m b d (rankOf n m ord) G r:=by
  let n:=2^m
  let ord:=schedule n m b d (chosenMask m b d)
  have perm:ord.Perm (List.range n):=schedule_perm ..
  obtain ⟨N,bound,G,r,dec⟩:=sharp_upper_words large bb mm
  refine ⟨perm,N,bound,cap G (m+n),capState G (m+n) r,?_,?_⟩
  · intro i;dsimp [cap];split;assumption;have:=Nat.two_pow_pos m;omega
  · intro w
    rw [cap_eval,←padded (m:=m) (n:=n)]
    exact (dec (headInput w m) (dataInput w m n) (by simp [headInput]) (by simp [dataInput,n])).trans (fixed_check w _ ord perm).symm

def realizes (m b d N:Nat):Prop:=
  ∃ (rank name:Nat→Nat), (∀ i<2^m+m,name (rank i)=i) ∧
    (∀ i<2^m+m,rank i<2^m+m) ∧
    ∃ (G:DAG N) (r:State N), (∀ i,G.level i<m+2^m) ∧ correct m b d rank G r

/-- A single finite statement pins the size of the smallest physical diagram.
    Both ends use the same adversarial Boolean input, address rule and word. -/
theorem optimal_sandwich {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):
    ∃ opt, realizes m b d opt ∧ (∀ N,realizes m b d N → opt≤N) ∧
      (2^m)^(depth d)≤(opt+2)^64 ∧ opt≤(2^m)^(depth d+46):=by
  classical
  obtain ⟨perm,N,bound,G,r,lev,ok⟩:=sharp_upper large bb mm
  let ord:=schedule (2^m) m b d (chosenMask m b d)
  have bounded (i:Nat) (hi:i<2^m+m):rankOf (2^m) m ord i<2^m+m:=by
    by_cases mem:i<2^m
    · have v:=List.idxOf_lt_length_of_mem (perm.mem_iff.mpr (List.mem_range.mpr mem))
      have e:ord.length=2^m:=perm.length_eq.trans List.length_range
      change ord.idxOf i<ord.length at v
      simp only [rankOf,mem,↓reduceIte];omega
    · simp only [rankOf,mem,↓reduceIte];exact Nat.lt_of_le_of_lt (Nat.sub_le i _) hi
  have real:realizes m b d N:=⟨_,_,inverse perm,bounded,G,r,lev,ok⟩
  have least (k:Nat) (existsHere:realizes m b d k):∃ opt,realizes m b d opt ∧ ∀ t,realizes m b d t → opt≤t:=by
    induction k using Nat.strongRecOn with
    | ind k ih=>
      by_cases smaller:∃ t,t<k ∧ realizes m b d t
      · obtain ⟨t,lt,ok⟩:=smaller;exact ih t lt ok
      · exact ⟨k,existsHere,fun t ht=>Nat.le_of_not_gt (fun lt=>smaller ⟨t,lt,ht⟩)⟩
  obtain ⟨opt,yes,minimum⟩:=least N real
  obtain ⟨rank,name,inv,_,A,root,_,it⟩:=show realizes m b d opt from yes
  exact ⟨opt,yes,minimum,sharp_lower large bb mm inv A root it,Nat.le_trans (minimum N real) bound⟩
/-- Integer-power form of the matching asymptotic order, with no terminal
    offset and with physical ranks restricted to the actual input domain. -/
theorem optimal_rate {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):
    ∃ opt, realizes m b d opt ∧ (∀ N,realizes m b d N → opt≤N) ∧
      (2^m)^(depth d)≤opt^128 ∧ opt≤(2^m)^(6*depth d):=by
  obtain ⟨opt,yes,minimal,lo,hi⟩:=optimal_sandwich large bb mm
  have dl:10≤d:=(log_envelope large).2.2.1
  have bigb:=pow2mono dl
  have long:128≤m:=by have:=Nat.lt_two_pow_self (n:=b);omega
  have nlower:=pow2mono long
  have np:=Nat.two_pow_pos m
  have hn:2^m≤(2^m)^(depth d):=by simpa using Nat.pow_le_pow_right np (show 1≤depth d by omega)
  have two:2≤opt:=by
    apply Classical.byContradiction;intro no
    have low:opt+2≤3:=by omega
    have up:=Nat.pow_le_pow_left low 64
    have impossible:¬((2:Nat)^128≤3^64):=by decide
    exact impossible (Nat.le_trans nlower (Nat.le_trans hn (Nat.le_trans lo up)))
  have square:opt+2≤opt*opt:=by have:=Nat.mul_le_mul_right opt two;omega
  have boost:=Nat.pow_le_pow_left square 64
  rw [←Nat.pow_two,←Nat.pow_mul] at boost
  exact ⟨opt,yes,minimal,Nat.le_trans lo boost,Nat.le_trans hi (Nat.pow_le_pow_right np (by omega))⟩
/-- Exceeds every fixed power of the total number of physical input bits. -/
theorem superpolynomial_total {d b m N c:Nat} (cut:tower (64*(2*c+2))≤d) (bb:2^d=b) (mm:2^b=m)
    (cert:realizes m b d N):(2^m+m)^c<N:=by
  obtain ⟨rank,name,inv,_,G,r,_,ok⟩:=cert
  have bound:=superpolynomial cut bb mm inv G r ok
  have mpos:0<m:=mm ▸ Nat.two_pow_pos _
  have npos:2≤2^m:=Nat.one_lt_two_pow (by omega)
  have ml:=Nat.lt_two_pow_self (n:=m)
  have cap:=Nat.mul_le_mul_right (2^m) npos
  have prod:2^m+m≤(2^m)^2:=by rw [Nat.pow_two];omega
  exact Nat.lt_of_le_of_lt (Nat.pow_le_pow_left prod c) (by rwa [←Nat.pow_mul])
#print axioms superpolynomial_total
#print axioms optimal_rate
#print axioms sharp_upper
#print axioms optimal_sandwich
end SISA.Rate
