import PhaseGrid
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.Shadow HWB.Circuit

/-- The two disclosure counts and the number of phases control the
    compiled header product. The estimates work for partial phases. -/
theorem cost_arithmetic {d m J e v P X:Nat} (large:10≤depth d) (grid:J≤4*(e+1))
    (disclose:radius d≤e+v) (pP:P*2^e≤m) (xp:X≤P) (vx:X*2^v≤4*m*J):
    (2*(2+6*(2*radius d+1)))^m*(2^(3*J))^P*(2+J*(d+1))^X≤(2^m)^(depth d+42):=by
  let u:=d.log2
  let w:=u.log2
  have ⟨wl,ul,_,_,_,_⟩:=log_envelope large
  change 10≤w at wl;change 10≤u at ul
  have eu:e+1≤2^e:=Nat.lt_two_pow_self
  have cJ:J≤2^(e+2):=by rw [Nat.pow_add];change J≤2^e*4;omega
  have ud:d+1≤2^(u+1):=Nat.lt_log2_self
  have inner:J*(d+1)≤2^(e+2+(u+1)):=Nat.le_trans (Nat.mul_le_mul cJ ud) (Nat.le_of_eq (pow2mul ..))
  have pos2:2≤2^(e+2+(u+1)):=Nat.one_lt_two_pow (by omega)
  have field:2+J*(d+1)≤2^(e+u+4):=by rw [show e+u+4=(e+2+(u+1))+1 by omega,Nat.pow_succ];omega
  have jmul:P*J≤4*m:=by
    have h:=Nat.mul_le_mul_left P (show J≤2^e*4 by omega)
    have z:=Nat.mul_le_mul_right 4 pP
    rw [←Nat.mul_assoc] at h;rw [Nat.mul_comm 4 m];omega
  have bound:X*(e+u+4)≤16*m:=by
    have uw:u+1≤2^(w+1):=Nat.lt_log2_self
    by_cases big:4*(w+4)≤e
    · have pu:=pow2mono (show w+1≤e by omega)
      have z:=Nat.mul_le_mul_right (2^e) xp
      have M:=Nat.mul_le_mul_left X (show e+u+4≤4*2^e by omega)
      rw [Nat.mul_comm 4 (2^e),←Nat.mul_assoc] at M;omega
    · have vv:4*(w+4)≤v:=by change 8*(w+4)≤e+v at disclose;omega
      have jlim:J≤2^(w+3):=by
        have g:=exp_grows (show 8≤w by omega)
        rw [Nat.pow_add];change J≤2^w*8;omega
      have alim:e+u+4≤2^(w+3):=by
        have g:=exp_grows (show 8≤w by omega);rw [Nat.pow_succ] at uw
        rw [Nat.pow_add];change e+u+4≤2^w*8;omega
      have gr:J*(e+u+4)≤2^v:=Nat.le_trans (Nat.mul_le_mul jlim alim)
        (Nat.le_trans (Nat.le_of_eq (pow2mul ..)) (pow2mono (by omega)))
      by_cases zero:J=0
      · rw [zero,Nat.mul_zero] at vx;have pos:=Nat.two_pow_pos v
        have xx:X=0:=by simpa [Nat.mul_eq_zero,show 2^v≠0 by omega] using (Nat.eq_zero_of_le_zero vx)
        simp [xx]
      · have term:=Nat.le_trans (Nat.mul_le_mul_left X gr) vx
        have eq:X*(J*(e+u+4))=(X*(e+u+4))*J:=by ac_rfl
        rw [eq] at term
        have :=Nat.le_of_mul_le_mul_right term (by omega);omega
  have early:=Nat.pow_le_pow_left (radius_scale d) m
  have late:=Nat.pow_le_pow_left field X
  have total:=Nat.mul_le_mul (Nat.mul_le_mul_right ((2^(3*J))^P) early) late
  apply Nat.le_trans total
  rw [←Nat.pow_mul,←Nat.pow_mul,←Nat.pow_mul,←Nat.pow_add,←Nat.pow_add,←Nat.pow_mul]
  apply pow2mono
  rw [Nat.add_mul,Nat.mul_add];rw [Nat.mul_comm (depth d) m,Nat.mul_comm (e+u+4) X]
  have eq:3*J*P=3*(P*J):=by ac_rfl
  omega

#print axioms cost_arithmetic
end SISA.Rate
