import EarlyLayer
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.Shadow HWB.Circuit

def tileBits (d:Nat):Nat:=d.log2+1
def radius (d:Nat):Nat:=8*(d.log2.log2+4)
def chosenMask (m b d:Nat):Nat→Bool:=clipped m b d (m/2) d (radius d) (tileBits d) (highGap d)

theorem radius_scale (d:Nat):2*(2+6*(2*radius d+1))≤2^(depth d+12):=by
  have z:d.log2.log2<2^(depth d+1):=Nat.lt_log2_self
  rw [Nat.pow_succ] at z
  have h:=Nat.two_pow_pos (depth d)
  rw [Nat.pow_add];change _≤2^(depth d)*4096
  unfold radius;omega

/-- Unconditional sharp-exponent bound throughout the entire initial scan of
    the actual sorted order, with concrete parameters of the literal family. -/
theorem scheduled_early_rate {d b m:Nat} (large:10≤depth d) (bb:2^d=b) (mm:2^b=m):
    let n:=2^m
    let first:=chosenMask m b d
    let ord:=schedule n m b d first
    ∃ t, (∀ i<n,ord.idxOf i<t ↔ first i=true) ∧
    ∀ y:List Bool,∀ j≤t,
       (attained (highModel n m b d (m/2) (tileBits d) (radius d) y ord.idxOf) j).length≤n^(depth d+13):=by
  dsimp only
  let n:=2^m
  let first:=chosenMask m b d
  let ord:=schedule n m b d first
  obtain ⟨cut,atCut⟩:=phase_cut n m b d first
  have ranks (i:Nat) (ib:i<n):ord.idxOf i<cut-m ↔ first i=true:=by
    have e:=atCut i ib
    change rankOf n m ord i<cut ↔ first i=true at e
    simp only [rankOf,ib,↓reduceIte] at e;rw [←e];omega
  refine ⟨cut-m,ranks,?_⟩
  intro y j hj
  obtain ⟨c⟩:=chooseNumbers large bb mm
  have half:m/2+m/2=m:=by have:=c.half;omega
  have bm:b≤m/2:=by
    have u:=c.fits;have dpos:=log_envelope large
    have h:=Nat.le_mul_of_pos_right (32*b) (show 0<d by omega)
    have:=c.half;omega
  obtain ⟨_,ul,_,ud,_,_⟩:=log_envelope large
  have grow:=exp_grows (show 8≤d.log2 by omega)
  have room:4*tileBits d+2≤d:=by unfold tileBits;omega
  have small (i:Nat) (id:i<d):2*highGap d i<b:=by have h:=c.small;unfold highGap;split <;> omega
  have bound:=early_records (n:=n) (k:=radius d) (j:=j) half bm room small bb mm y ord.idxOf
    (fun i ib seen=>(ranks i ib).mp (Nat.lt_of_lt_of_le seen hj))
  apply Nat.le_trans bound
  have cp:=Nat.pow_le_pow_left (radius_scale d) m
  apply Nat.le_trans (Nat.mul_le_mul_left (2^m) cp)
  rw [←Nat.pow_mul,show (depth d+12)*m=m*(depth d+12) by ac_rfl,Nat.pow_mul,←Nat.pow_succ']
  exact Nat.le_refl _
#print axioms scheduled_early_rate
end SISA.Rate
