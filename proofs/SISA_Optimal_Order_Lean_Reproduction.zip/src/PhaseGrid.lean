import LayerBudget
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

theorem reverse_small {d x:Nat} (bound:x<2^d):bitReverse d x<2^d:=by
  induction d generalizing x with
  | zero=>simp [bitReverse]
  | succ d ih=>
    rw [Nat.pow_succ] at bound ⊢
    have prev:=ih (x:=x/2) (by omega)
    change x%2*2^d+bitReverse d (x/2)<_
    rcases (show x%2=0 ∨ x%2=1 by omega) with v|v <;> rw [v] <;> simp <;> omega

theorem reverse_inj {d x y:Nat} (hx:x<2^d) (hy:y<2^d) (eq:bitReverse d x=bitReverse d y):x=y:=by
  induction d generalizing x y with
  | zero=>simp at hx hy;omega
  | succ d ih=>
    rw [Nat.pow_succ] at hx hy
    have xl:x/2<2^d:=by omega
    have yl:y/2<2^d:=by omega
    have xlo:=reverse_small xl;have ylo:=reverse_small yl
    simp only [bitReverse] at eq
    have same:x%2=y%2:=by
      rcases (show x%2=0 ∨ x%2=1 by omega) with v|v <;> rcases (show y%2=0 ∨ y%2=1 by omega) with w|w <;> simp_all <;> omega
    have div:=ih xl yl (by rw [same] at eq;omega)
    omega

theorem rev_grid (g a q:Nat):bitReverse (g+a) (2^g*q)=bitReverse a q:=by
  induction g with
  | zero=>simp
  | succ g ih=>
    rw [Nat.succ_add,Nat.pow_succ]
    have eq:2^g*2*q=(2^g*q)*2:=by ac_rfl
    simp [eq,bitReverse,ih]

theorem phase_precedes {n m b d:Nat} (first:Nat→Bool) {i l:Nat} (il:i<n) (ll:l<n)
    (earlier:phase m b d first i<phase m b d first l):
    (schedule n m b d first).idxOf i<(schedule n m b d first).idxOf l:=by
  let ord:=schedule n m b d first
  have sorted:ord.Pairwise (fun i j=>decide (phase m b d first i≤phase m b d first j)):=by
    apply List.pairwise_mergeSort
    · intro u v w h e;exact decide_eq_true (Nat.le_trans (of_decide_eq_true h) (of_decide_eq_true e))
    · intro u v;rcases Nat.le_total (phase m b d first u) (phase m b d first v) with a|a <;> simp [a]
  have wi:=List.idxOf_lt_length_of_mem ((schedule_perm n m b d first).mem_iff.mpr (List.mem_range.mpr il))
  have wl:=List.idxOf_lt_length_of_mem ((schedule_perm n m b d first).mem_iff.mpr (List.mem_range.mpr ll))
  change ord.idxOf i<ord.length at wi;change ord.idxOf l<ord.length at wl
  apply Classical.byContradiction;intro no
  rcases Nat.lt_or_eq_of_le (Nat.le_of_not_gt no) with lt|eq
  · have h:=of_decide_eq_true (List.pairwise_iff_getElem.mp sorted _ _ wl wi lt)
    simp only [List.getElem_idxOf] at h;omega
  · have same:=congrArg (fun x=>ord[x]?) eq
    change ord[ord.idxOf l]?=ord[ord.idxOf i]? at same
    rw [List.getElem?_eq_getElem wl,List.getElem?_eq_getElem wi,List.getElem_idxOf,List.getElem_idxOf] at same
    have same:=Option.some.inj same
    subst i;omega

/-- From an aligned half-block inside a b-bit pointer field, extract as many
    already-read page bits as there are stride intervals in that half. -/
theorem grid_field {n m b d Y j start a g:Nat} (first:Nat→Bool)
    (pos:0<n) (sz:2^d=b) (power:g+(a+1)=d) (bm:b∣m) (mn:m∣n)
    (seen:∃ l<n,first l=false ∧ (schedule n m b d first).idxOf l<j ∧
        2^(a+1)≤bitReverse d (residue m b l)):
    2^a≤knownCount (schedule n m b d first).idxOf n Y j start b:=by
  let h:=2^g
  let c:=2^a
  let B:=c*h
  have hp:0<h:=Nat.two_pow_pos _
  have cp:0<c:=Nat.two_pow_pos _
  have Bp:0<B:=Nat.mul_pos cp hp
  have size:b=2*B:=by rw [←sz,←power,Nat.pow_add,Nat.pow_succ];dsimp [B,c,h];ac_rfl
  have Bm:B∣m:=Nat.dvd_trans (show B∣b from ⟨2,by rw [size,Nat.mul_comm]⟩) bm
  have Bn:=Nat.dvd_trans Bm mn
  have ad:b∣n:=Nat.dvd_trans bm mn
  obtain ⟨site,ls,lf,lr,rv⟩:=seen
  let base:=Y+start
  let aligned:=base+(B-base%B)
  have almod:=Nat.mod_lt base Bp
  have lower:base≤aligned:=by dsimp [aligned];omega
  have upper:aligned+B≤base+b:=by dsimp [aligned];omega
  have bd:B∣aligned:=by
    refine ⟨base/B+1,?_⟩;rw [Nat.mul_add,Nat.mul_one]
    have:=Nat.mod_add_div base B;dsimp [aligned];omega
  let A:=aligned%n
  have Ap:A<n:=Nat.mod_lt aligned pos
  have adB:B∣A:=Nat.dvd_mod_iff Bn |>.mpr bd
  have modB:B∣A%m:=Nat.dvd_mod_iff Bm |>.mpr adB
  have noCross {x t:Nat} (xd:B∣x) (td:B∣t) (lt:x<t):x+B≤t:=by
    obtain ⟨q,rfl⟩:=xd;obtain ⟨r,rfl⟩:=td
    have qr:q<r:=Nat.lt_of_mul_lt_mul_left lt
    have e:=Nat.mul_le_mul_left B qr;rw [Nat.mul_succ] at e;exact e
  have mp:0<m:=by cases m with | zero=>simp at mn;omega | succ _=>omega
  have An:=noCross adB Bn Ap
  have Am:=noCross modB Bm (Nat.mod_lt A mp)
  let shift:=(A/m)%b
  let off:=(shift+h-A%h)%h
  have off_lt:off<h:=Nat.mod_lt _ hp
  have hk:h∣b:=⟨2*c,by rw [size];dsimp [B];ac_rfl⟩
  have off_mod:(A+off)%h=shift%h:=by
    have remLt:=Nat.mod_lt A hp
    unfold off
    rw [Nat.add_mod_mod,←Nat.mod_add_mod,Nat.add_comm (A%h),Nat.sub_add_cancel (by omega),Nat.add_mod_right]
  let point:=fun t:Fin c=>off+t.val*h
  have within (t:Fin c):point t<B:=by
    have lim:=Nat.mul_le_mul_right h t.isLt;rw [Nat.succ_mul] at lim;dsimp [point,B];omega
  let digit:=fun t:Fin c=>(⟨aligned+point t-base,by have:=within t;omega⟩:Fin b)
  let all:=(List.finRange c).map digit
  have inj:Function.Injective digit:=by
    intro x y eq;have z:=congrArg Fin.val eq
    change aligned+(off+x.val*h)-base=aligned+(off+y.val*h)-base at z
    apply Fin.ext;apply Nat.eq_of_mul_eq_mul_right hp;omega
  have nd:all.Nodup:=SISA.Escape.distinct_map _ (List.nodup_finRange _) _ inj
  have cover:all⊆(List.finRange b).filter (fun i=>decide ((schedule n m b d first).idxOf ((Y+(start+i.val))%n)<j)):=by
    intro i hi;obtain ⟨t,_,rfl⟩:=List.mem_map.mp hi
    have pl:=within t
    have idx:Y+(start+(digit t).val)=aligned+point t:=by dsimp [digit,base] at *;omega
    have rem:(aligned+point t)%n=A+point t:=by rw [←Nat.mod_add_mod];exact Nat.mod_eq_of_lt (by omega)
    have below:A+point t<n:=by omega
    have page:(A+point t)/m=A/m:=by
      have eq:A+point t=(A%m+point t)+(A/m)*m:=by have:=Nat.div_add_mod A m;rw [Nat.mul_comm (A/m)];omega
      rw [eq,Nat.add_mul_div_right _ _ mp,Nat.div_eq_of_lt (by omega),Nat.zero_add]
    have step:(A+point t)%h=shift%h:=by dsimp [point];rw [←Nat.add_assoc,Nat.add_mul_mod_self_right,off_mod]
    let r:=residue m b (A+point t)
    have rb:r<b:=Nat.mod_lt _ (by omega)
    have dz:r%h=0:=by
      dsimp [r,residue];rw [Nat.mod_mod_of_dvd _ hk,page]
      change (((A+point t)%b+b)-shift)%h=0
      have tlt:shift<b:=Nat.mod_lt _ (by omega)
      have sum:((A+point t)%b+b-shift)+shift=(A+point t)%b+b:=by omega
      have hEq:=congrArg (·%h) sum
      have rhs:((A+point t)%b+b)%h=shift%h:=by
        rw [Nat.add_mod,Nat.mod_mod_of_dvd _ hk,Nat.mod_eq_zero_of_dvd hk,Nat.add_zero,step,Nat.mod_mod]
      rw [rhs] at hEq
      have eq:((A+point t)%b+b-shift)%h=0:=by
        have divp:=Nat.mod_add_div shift h
        have tot:=Nat.mod_add_div (((A+point t)%b+b-shift)+shift) h
        rw [hEq] at tot
        apply Nat.mod_eq_zero_of_dvd
        refine ⟨(((A+point t)%b+b-shift)+shift)/h-shift/h,?_⟩
        rw [Nat.mul_sub];omega
      exact eq
    obtain ⟨v,hv⟩:=Nat.dvd_of_mod_eq_zero dz
    have qb:v<2^(a+1):=by
      rw [hv] at rb;rw [←sz,←power,Nat.pow_add] at rb;exact Nat.lt_of_mul_lt_mul_left rb
    have rev:bitReverse d r<2^(a+1):=by rw [hv,←power,rev_grid];exact reverse_small qb
    have ph:phase m b d first (A+point t)<phase m b d first site:=by
      change bitReverse d (residue m b site)≥2^(a+1) at rv
      change (if first (A+point t) then 0 else 1+bitReverse d r)<(if first site then 0 else 1+bitReverse d (residue m b site))
      cases zz:first (A+point t) <;> simp [lf] <;> omega
    exact List.mem_filter.mpr ⟨List.mem_finRange _,decide_eq_true (by rw [idx,rem];exact Nat.lt_trans (phase_precedes first below ls ph) lr)⟩
  have ans:=nd.length_le_of_subset cover
  simpa [all,knownCount] using ans

#print axioms grid_field
end SISA.Rate
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

theorem phases_by_known {n m b d j Y start:Nat} (first:Nat→Bool)
    (np:0<n) (bb:2^d=b) (bm:b∣m) (mn:m∣n):
    let rank:=(schedule n m b d first).idxOf
    (residuesRead n m b j first rank).length≤4*(knownCount rank n Y j start b+1):=by
  let rank:=(schedule n m b d first).idxOf
  let R:=residuesRead n m b j first rank
  let codes:=R.map (bitReverse d)
  let e:=knownCount rank n Y j start b
  have witness (r:Nat) (mem:r∈R):
      ∃ l<n,first l=false ∧ rank l<j ∧ residue m b l=r:=by
    obtain ⟨l,hl,id⟩:=List.mem_map.mp (List.mem_eraseDups.mp mem)
    have h:=List.mem_filter.mp hl
    have f:first l=false ∧ rank l<j:=by simpa using h.2
    exact ⟨l,List.mem_range.mp h.1,f.1,f.2,id⟩
  have rsmall (r:Nat) (hr:r∈R):r<2^d:=by
    obtain ⟨l,_,_,_,id⟩:=witness r hr;rw [←id,bb];exact Nat.mod_lt _ (bb ▸ Nat.two_pow_pos _)
  have nd:codes.Nodup:=by
    apply List.pairwise_map.mpr
    exact (dedupND _ : R.Nodup).imp_of_mem (fun {x z} hx hz ne eq=>ne (reverse_inj (rsmall x hx) (rsmall z hz) eq))
  by_cases empty:codes=[]
  · have zero:codes.length=0:=by rw [empty];rfl
    change R.length≤4*(e+1)
    have zl:R.length=0:=List.length_map (f:=bitReverse d) |>.symm.trans zero
    omega
  · let q:=codes.max empty
    obtain ⟨r,hr,eq⟩:=List.mem_map.mp (List.max_mem empty)
    change bitReverse d r=q at eq
    have maxlt:q<2^d:=eq ▸ reverse_small (rsmall r hr)
    have bound:R.length≤q+1:=by
      have sub:codes⊆List.range (q+1):=fun {_} hx=>List.mem_range.mpr (Nat.lt_succ_of_le (List.le_max_of_mem hx))
      simpa [codes] using nd.length_le_of_subset sub
    by_cases little:q<2
    · change R.length≤4*(e+1);omega
    · let a:=q.log2-1
      have lg:0<q.log2:=(Nat.le_log2 (by omega)).mpr (by omega : 2^1≤q)
      have aa:a+1=q.log2:=by dsimp [a];omega
      have qr:2^(a+1)≤q:=by rw [aa];exact Nat.log2_self_le (by omega)
      have dl:a+1≤d:=Nat.le_of_lt ((Nat.pow_lt_pow_iff_right (by decide : 1<(2:Nat))).mp (Nat.lt_of_le_of_lt qr maxlt))
      obtain ⟨l,hl,lf,lr,id⟩:=witness r hr
      have grid:2^a≤e:=grid_field (g:=d-(a+1)) first np bb (Nat.sub_add_cancel dl) bm mn
        ⟨l,hl,lf,lr,by rw [id,eq];exact qr⟩
      have up:q<2^(q.log2+1):=Nat.lt_log2_self
      rw [←aa,Nat.pow_succ,Nat.pow_succ] at up
      change R.length≤4*(e+1);omega
#print axioms phases_by_known
end SISA.Rate
