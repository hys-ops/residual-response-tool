import EarlyBook
import RateNumbers
namespace SISA.Rate
open SISA.Balanced SISA.Cut SISA.ShortBands SISA.Shadow HWB.Circuit

noncomputable def highModel (n m b d M s k:Nat) (y:List Bool) (rank:Nat→Nat):Model (2^b) (2^d) m:=
  physical n m b d M (word .double m b M d (highGap d)) y rank
    (clipped m b d M d k s (highGap d))

theorem dict_cover {P A h:Nat} (S:Model P A h) (j:Nat) (z:List Bool) (p:Fin P) (k:Bool)
    (book:List (List Bool)) (covers:∀ a∈offsetsFor S j z p,signature S j p k a∈book):
    (dictionary S j z p k).length≤book.length:=by
  apply (dedupND _).length_le_of_subset
  intro v mem;obtain ⟨a,ha,rfl⟩:=List.mem_map.mp (List.mem_eraseDups.mp mem);exact covers a ha

theorem early_dictionary {n m b d M s k:Nat} (half:M+M=m) (room:4*s+2≤d)
    (small:∀ i<d,2*highGap d i<b) (bb:2^d=b)
    (y z:List Bool) (rank:Nat→Nat) (j:Nat) (p:Fin (2^b)):
    (dictionary (highModel n m b d M s k y rank) j z p true).length≤1+6*(2*k+1):=by
  classical
  let S:=highModel n m b d M s k y rank
  let sites:=seen S j (S.core p true)
  let base:=sites.map (fun i=>decide (p.val*m+M≤i))
  let addr:=fun t:Nat=>signature S j p true ⟨t%2^d,Nat.mod_lt _ (Nat.two_pow_pos _)⟩
  let book:=base::(labels b d s k).map addr
  have len:book.length=1+6*(2*k+1):=by simp [book,labels_length,Nat.add_comm]
  rw [←len];apply dict_cover
  intro a _
  by_cases mem:a.val∈labels b d s k
  · apply List.mem_cons.mpr;right;apply List.mem_map.mpr;refine ⟨_,mem,?_⟩
    simp [addr,Nat.mod_eq_of_lt a.isLt,S]
  · apply List.mem_cons.mpr;left;apply List.map_congr_left;intro i hi
    have hs:coreSite m b M p.val i ∧ clipped m b d M d k s (highGap d) i=true:=by
      have hh: i∈S.core p true:=(List.mem_filter.mp hi).1
      simpa [S,highModel,physical] using (List.mem_filter.mp hh).2
    apply Classical.byContradiction;intro neg
    exact mem (early_edit_label half room small (by rw [←bb];exact a.isLt) hs.1 hs.2 neg)

theorem clipped_boundary {m b d M s k p i:Nat} (half:M+M=m) (bm:b≤M)
    (lo:p*m≤i) (hi:i<p*m+m+b) (bd:¬coreSite m b M p i):
    clipped m b d M d k s (highGap d) i=false:=by
  let u:=i-p*m
  have de:i=u+p*m:=by dsimp [u];omega
  have rem:i%m=u%m:=(congrArg (·%m) de).trans (Nat.add_mul_mod_self_right ..)
  have strips:u<b ∨ (M≤u ∧ u<M+b) ∨ (m≤u ∧ u<m+b):=by unfold coreSite at bd;dsimp [u];omega
  have small (x:Nat) (atX:i%m=x) (onEdge:x<b ∨ (M≤x ∧ x<M+b)):
      clipped m b d M d k s (highGap d) i=false:=by
    by_cases back:M≤x
    · have bound:x-M<b:=by omega
      have ub:(x-M)%(32*b)<4*b:=by have:=Nat.mod_le (x-M) (32*b);omega
      simp [clipped,early,atX,show ¬4*b≤(x-M)%(32*b) by omega,onEdge]
    · simp [clipped,early,atX,back,show x<b by omega]
  rcases strips with h|h|h
  · exact small u (rem.trans (Nat.mod_eq_of_lt (by omega))) (Or.inl h)
  · exact small u (rem.trans (Nat.mod_eq_of_lt (by omega))) (Or.inr h)
  · have al:u=(u-m)+m:=by omega
    have um:u%m=(u-m)%m:=(congrArg (·%m) al).trans (Nat.add_mod_right ..)
    exact small (u-m) (rem.trans (um.trans (Nat.mod_eq_of_lt (by omega)))) (Or.inl (by omega))

theorem prod_budget (l:List α) (f:α→Nat) (B:Nat) (bound:∀ x∈l,f x≤B):
    (l.map f).prod≤B^l.length:=by
  induction l with
  | nil=>simp
  | cons a l ih=>
    simp only [List.map_cons,List.prod_cons,List.length_cons,Nat.pow_succ]
    rw [Nat.mul_comm (B^l.length)]
    exact Nat.mul_le_mul (bound a (by simp)) (ih (fun x mem=>bound x (by simp [mem])))

theorem sum_budget (l:List α) (f:α→Nat) (B:Nat) (bound:∀ x∈l,f x≤B):
    (l.map f).sum≤l.length*B:=by
  induction l with
  | nil=>simp
  | cons a l ih=>
    simp only [List.map_cons,List.sum_cons,List.length_cons,Nat.succ_mul]
    have h:=ih (fun x mem=>bound x (by simp [mem]));have e:=bound a (by simp);omega

/-- Actual state bound at every memory prefix that has reached only early sites. -/
theorem early_records {n m b d M s k j:Nat} (half:M+M=m) (bm:b≤M) (room:4*s+2≤d)
    (small:∀ i<d,2*highGap d i<b) (bb:2^d=b) (mm:2^b=m) (y:List Bool) (rank:Nat→Nat)
    (earlyOnly:∀ i<n,rank i<j → clipped m b d M d k s (highGap d) i=true):
    (attained (highModel n m b d M s k y rank) j).length≤2^m*(2*(2+6*(2*k+1)))^m:=by
  classical
  let S:=highModel n m b d M s k y rank
  apply Nat.le_trans (attained_product S j)
  calc
    _ ≤ (words m).length * (2*(2+6*(2*k+1)))^m := by
      apply sum_budget;intro z _
      apply Nat.le_trans _ (Nat.le_of_eq (congrArg ((2*(2+6*(2*k+1)))^·) ((List.length_finRange).trans mm)))
      apply prod_budget;intro p _
      change pageCost S j z p≤_
      have noneLate:seen S j (S.core p false)=[]:=by
        apply List.eq_nil_iff_forall_not_mem.mpr;intro i hw
        have ⟨ic,lr⟩:=List.mem_filter.mp hw
        have ck:=List.mem_filter.mp ic
        have range:=List.mem_range.mp ck.1
        have val:clipped m b d M d k s (highGap d) i=false:=(of_decide_eq_true ck.2).2
        have actual:=earlyOnly i range (of_decide_eq_true lr);simp_all
      have noEdges:seen S j (S.edge p)=[]:=by
        apply List.eq_nil_iff_forall_not_mem.mpr;intro i hw
        have ⟨ic,lr⟩:=List.mem_filter.mp hw
        have ck:=List.mem_filter.mp ic
        have range:=List.mem_range.mp ck.1
        have prop:=of_decide_eq_true ck.2
        have val:=clipped_boundary (d:=d) (s:=s) (k:=k) half bm prop.1 prop.2.1 prop.2.2
        have actual:=earlyOnly i range (of_decide_eq_true lr);simp_all
      have one:(dictionary S j z p false).length≤1:=by
        apply dict_cover _ _ _ _ _ [[]];intro a _;simp [signature,noneLate,projected]
      have early:=early_dictionary (n:=n) (k:=k) half room small bb y z rank j p
      change (dictionary S j z p true).length≤_ at early
      unfold pageCost;split
      · rw [noEdges];simp only [List.length_nil,Nat.pow_zero,Nat.mul_one]
        exact Nat.mul_le_mul (by omega) (by omega)
      · omega
    _ = _ := by rw [words_len]

#print axioms early_dictionary
#print axioms early_records
end SISA.Rate
