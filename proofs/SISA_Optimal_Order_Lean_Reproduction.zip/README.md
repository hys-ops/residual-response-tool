# Optimal OBDD size for the high-cluster indirect-address word

## 검증 결과

최종 선언은 `src/OptimalOrder.lean`의 `SISA.Rate.optimal_rate`이다. 메모리가 n비트이고 외부 주소가 m비트일 때, 모든 n+m개 입력 변수의 읽기 순서에서 최소 내부 노드 수를 B라고 하자. b=2^d, m=2^b, n=2^m이며 h는 d에 세 번 적용한 바닥 이진로그이다. h≥10에서 Lean은 다음 두 부등식을 동시에 증명한다.

    n^h ≤ B^128                 B ≤ n^(6h)

이것이 B = n^{Θ(log₂ log₂ log₂ d)}의 정수 거듭제곱 표현이다. 별도 선언 `superpolynomial_total`은 임의의 고정 자연수 c에서 충분히 큰 d이면 실제 입력 비트 수에 대해서도 (n+m)^c < B임을 증명한다. h≥10은 점근 증명을 위해 택한 충분조건이다. 상수와 적용 시작점의 최적성, 이 원고의 다른 예제, 선행 연구상의 최초성은 검증 대상 밖이다.

## Input and size

An m-bit outer address selects m consecutive bits of a circular n-bit memory. Their big-endian value selects the starting point of the word test in that same memory. A legal inner address has the form pm+a with 0≤p<m and 0≤a<b. The required m-bit word starts from the two halves of zeros and ones. In the first half, set bits 4bt for 0≤t<8d to one. In the second half, group j starts at m/2+32bj. In its b-bit blocks 4, 5, 12 and 16 set positions 0 and gⱼ to zero, where g₀=d²+d and gⱼ=d²+j for 1≤j<d. The Lean predicate is `SISA.FixedWord.fixedAt` with precisely this word and address filter.

Diagrams have a common level order, permit skipping levels, and share two terminals. B counts internal nodes. The predicate `realizes` requires a left inverse for the physical ranks as well as a range bound on all n+m physical variables. Hence these ranks restrict to a permutation of the finite input. Every node level in the witnessing diagram belongs to the real input. Correctness quantifies over all Boolean assignments.

## Main declarations

| Declaration in SISA.Rate | What it establishes |
| --- | --- |
| sharp_lower | Every correct diagram and every injective physical ranking satisfy n^h ≤ (N+2)^64. |
| scheduled_early_rate | Every layer of the early scan has at most n^(h+13) distinct records. |
| header_factor | For each observed header, bounds its physical record product using surviving pages, potentially exceptional pages, actually observed late residues, and the boundary bits. |
| phases_by_known | If J distinct late residues have been seen, J ≤ 4(e+1), where e counts observed bits in the b-bit page field. This includes circular wrap and partial phases. |
| run_in_fields, disclosed | A translate of the two free fields contains a run of k consecutive early bits in one field. Every prefix containing a late site therefore knows at least k page and high offset bits in total. |
| all_layers | For this explicit physical schedule and every external header and prefix length, the actual record count is at most n^(h+43). |
| sharp_upper | A correct physical diagram on the stated common order has at most n^(h+46) internal nodes and uses only physical input levels. |
| optimal_sandwich, optimal_rate | A minimum exists across all physical orders and diagrams. The first keeps the finite terminal correction, the second gives the displayed matching powers. |
| superpolynomial_total | For a fixed natural c and d ≥ tower(64(2c+2)), every correct physical diagram requires more than (n+m)^c nodes, with tower(k)=2^(2^(2^k)). |

The upper witness chooses s=⌊log₂ d⌋+1 and k=8(⌊log₂⌊log₂ d⌋⌋+4). These explicit choices allow slack relative to the ceilings in the written proof. They are parameters of the reading order. Both sides use the same original Boolean function.

The header estimate is independently inspectable in `LayerBudget.lean`. With P surviving pages and X potentially exceptional surviving pages, P·2^e≤m, X≤P and X·2^v≤4mJ, where v counts observed high offset bits. The record product is at most

    [2(2+6(2k+1))]^m · [2^(3J)]^P · [2+J(d+1)]^X.

`cost_arithmetic` combines these estimates with the disclosure and phase bounds. `OptimalOrder.lean` converts the finite-word compiler into an all-assignments diagram with bounded physical levels and identifies its predicate with the lower-bound predicate. The top theorem assumes only the scale equalities and h≥10.

## Reproduce

Use Python 3 and the release in `lean-toolchain`, Lean 4.34.1. The recorded Linux toolchain commit is `5045d0056413266e57c625dcd7c365b10e377c52`. If using elan, run inside the extracted directory so the pin takes effect. The proof uses the standard distribution. From the archive root run

```sh
sha256sum -c SHA256SUMS
python3 replay.py --lean lean
```

A complete run ends with `Completed 60 source modules in a fresh object directory.` An absolute Lean executable can be supplied after `--lean`. `logs/full-build.txt` contains the compiler output. `src/Audit.lean` prints exact top-level types, the physical-input definitions, and the kernel's axiom sets. The top declarations depend on propext, Classical.choice and Quot.sound. The check does not enumerate finite examples. A separate human review is outside this record.

## Provenance

The predecessor proof bundle supplied the finite all-order lower bound, clipped physical compiler and auxiliary lemmas. Its 43 project source modules are byte-for-byte preserved in `vendor/`. `PREDECESSOR.tsv` lists archive paths and SHA-256 values. The 17 modules in `src/` include the new proofs and audit module.

