# Lean checks for generalized-code

Finite capacity with a prescribed Boolean entry, including n=128. The substituted circuit and OBDD restriction argument are written proofs.

Use the pinned Lean 4.34.1 toolchain. From the extracted directory, run:

```sh
sha256sum -c SHA256SUMS
lake update
lake exe cache get
lake env lean TagCapacity.lean
```
