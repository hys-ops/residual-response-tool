import Mathlib.Data.Fintype.EquivFin
import Mathlib.Data.Fintype.BigOperators

namespace TagCapacity
/-- The entry at none is prescribed, and u remaining entries can be chosen. -/
def Codes (u : Nat) (b : Bool) := { f : Option (Fin u) → Bool // f none = b }

def freeEntries (u : Nat) (b : Bool) : Codes u b ≃ (Fin u → Bool) where
  toFun f i := f.val (some i)
  invFun g := ⟨fun key => match key with | none => b | some i => g i, rfl⟩
  left_inv f := by
    apply Subtype.ext
    funext key
    cases key with
    | none => exact f.property.symm
    | some i => rfl
  right_inv g := rfl

noncomputable instance (u : Nat) (b : Bool) : Fintype (Codes u b) :=
  Fintype.ofEquiv _ (freeEntries u b).symm

theorem capacity (u : Nat) (b : Bool) : Fintype.card (Codes u b) = 2^u := by
  rw [Fintype.card_congr (freeEntries u b)]
  simp

theorem enough_labels (n u : Nat) (b : Bool) :
    Nonempty (Fin n ↪ Codes u b) ↔ n ≤ 2^u := by
  rw [Function.Embedding.nonempty_iff_card_le, capacity, Fintype.card_fin]

theorem three_suffice_for_128 : Nonempty (Fin 128 ↪ Codes (2^3-1) true) := by
  exact (enough_labels _ _ _).mpr (by decide)
theorem two_fail_for_128 : ¬ Nonempty (Fin 128 ↪ Codes (2^2-1) true) := by
  rw [enough_labels]
  decide
#print axioms enough_labels
#print axioms three_suffice_for_128
#print axioms two_fail_for_128
end TagCapacity
