import PaperSemantics
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
noncomputable def orArcs (D : DAG f a) (o : Fin f) : List (Fin a × Fin f) := by
  classical
  exact ((List.finRange f).flatMap fun i=>if Ancestor D o i then (uses D i).map (fun g=>(g,i)) else []).eraseDups
noncomputable def andArcs (D : DAG f a) (o : Fin f) : List (Fin f × Fin a) :=
  ((active D o).flatMap (fun g=>[((D.pins g).1,g),((D.pins g).2,g)])).eraseDups
noncomputable def size (D : DAG f a) (o : Fin f) := (orArcs D o).length+(andArcs D o).length

theorem orArc_iff (D : DAG f a) : (g,i)∈orArcs D o ↔ Ancestor D o i ∧ g∈uses D i := by
  classical
  constructor
  · intro h
    obtain ⟨v,_,hv⟩:=List.mem_flatMap.mp (List.mem_eraseDups.mp h)
    split at hv
    · obtain ⟨k,km,e⟩:=List.mem_map.mp hv;cases e;exact ⟨by assumption,km⟩
    · simp at hv
  · rintro ⟨hr,hm⟩;apply List.mem_eraseDups.mpr
    apply List.mem_flatMap.mpr
    exact ⟨i,List.mem_finRange _,by simp [hr,hm]⟩
theorem andArc_iff (D : DAG f a) : (i,g)∈andArcs D o ↔ Used D o g ∧ (i=(D.pins g).1 ∨ i=(D.pins g).2) := by
  constructor
  · intro h;obtain ⟨v,hm,hv⟩:=List.mem_flatMap.mp (List.mem_eraseDups.mp h)
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at hv
    rcases hv with ⟨h,rfl⟩|⟨h,rfl⟩
    · exact ⟨memActive.mp hm,.inl h⟩
    · exact ⟨memActive.mp hm,.inr h⟩
  · rintro ⟨used,side⟩;apply List.mem_eraseDups.mpr;apply List.mem_flatMap.mpr
    exact ⟨g,memActive.mpr used,by simpa using side⟩
theorem nativeOrArc (G : Graph f a) : (g,i)∈andOrWires G ↔ g∈fanin G i := by
  constructor
  · intro h;obtain ⟨v,_,hv⟩:=List.mem_flatMap.mp (List.mem_eraseDups.mp h)
    obtain ⟨k,km,e⟩:=List.mem_map.mp hv;cases e;exact km
  · intro h;exact List.mem_eraseDups.mpr (List.mem_flatMap.mpr ⟨i,List.mem_finRange _,by simp [h]⟩)
theorem nativeAndArc (G : Graph f a) : (i,g)∈inputWires G ↔ i=(G.inputs g).1 ∨ i=(G.inputs g).2 := by
  constructor
  · intro h;obtain ⟨v,_,hv⟩:=List.mem_flatMap.mp (List.mem_eraseDups.mp h)
    simp only [List.mem_cons,List.not_mem_nil,or_false,Prod.mk.injEq] at hv
    rcases hv with ⟨h,rfl⟩|⟨h,rfl⟩
    · exact .inl h
    · exact .inr h
  · intro side;exact List.mem_eraseDups.mpr (List.mem_flatMap.mpr ⟨g,List.mem_finRange _,by simpa using side⟩)
theorem dedupND [BEq α] [LawfulBEq α] (xs : List α) : xs.eraseDups.Nodup := by
  match xs with
  | [] => simp
  | x::xs => rw [List.eraseDups_cons,List.nodup_cons];exact ⟨by simp,dedupND _⟩
termination_by xs.length
decreasing_by simpa using Nat.lt_succ_of_le (List.length_filter_le _ _)

theorem ndGet {xs : List α} (nd : xs.Nodup) {i j : Fin xs.length} (e : xs.get i=xs.get j) : i=j :=
  Fin.ext (nd.eq_of_getElem_eq i.isLt j.isLt e)
theorem activeND (D : DAG f a) (o : Fin f) : (active D o).Nodup := by
  classical exact (List.nodup_finRange _).filter _
theorem mapND {xs : List α} (nd : xs.Nodup) (f : α→β) (inj : ∀ {x y}, f x=f y→x=y) : (xs.map f).Nodup :=
  (List.pairwise_map.mpr (nd.imp (fun ne e=>ne (inj e))))
theorem mapCount {xs : List α} {ys : List β} (f : α→β) (inj : ∀ {x y}, f x=f y→x=y)
    (nd : xs.Nodup) (cov : ∀ x∈xs, f x∈ys) : xs.length≤ys.length := by
  have sub : xs.map f ⊆ ys := by intro v h;obtain ⟨x,hx,rfl⟩:=List.mem_map.mp h;exact cov x hx
  simpa using (mapND nd f inj).length_le_of_subset sub

namespace Task
variable (C : Task f a)
theorem fanEquiv (i : Fin f) (g : Fin C.pool.length) :
    g∈fanin C.compile i ↔ Ancestor C.dag C.out i ∧ C.pool.get g∈uses C.dag i := by
  by_cases hr : Ancestor C.dag C.out i
  · cases op : C.dag.label i with
    | truth b => simp [fanin,C.opTruth hr op,uses,op]
    | literal z b => simp [fanin,(C.opLit hr op).1,uses,op]
    | any L =>
      simp only [fanin,C.opAny hr op,uses,op,hr,true_and]
      constructor
      · intro h;obtain ⟨j,rfl⟩:=List.mem_iff_get.mp h
        rw [decodeSlot];exact List.get_mem ..
      · intro m;obtain ⟨j,e⟩:=List.mem_iff_get.mp m
        apply List.mem_iff_get.mpr
        refine ⟨backSlot (C.hasInputs hr op) j,ndGet (activeND ..) ?_⟩
        rw [decodeSlot];exact e
  · simp [fanin,C.inactive hr,hr]

theorem compile_size : wireCount C.compile=size C.dag C.out := by
  let liftO (x : Fin C.pool.length × Fin f) := (C.pool.get x.1,x.2)
  let liftA (x : Fin f × Fin C.pool.length) := (x.1,C.pool.get x.2)
  have io : ∀ {x y},liftO x=liftO y→x=y := fun e=>Prod.ext (ndGet (activeND ..) (congrArg Prod.fst e)) (congrArg (fun u : Fin a × Fin f=>u.2) e)
  have ia : ∀ {x y},liftA x=liftA y→x=y := fun e=>Prod.ext (congrArg (fun u : Fin f × Fin a=>u.1) e) (ndGet (activeND ..) (congrArg Prod.snd e))
  have oo (x : Fin C.pool.length × Fin f) : x∈andOrWires C.compile ↔ liftO x∈orArcs C.dag C.out :=
    (nativeOrArc _).trans ((C.fanEquiv _ _).trans (orArc_iff _).symm)
  have aa (x : Fin f × Fin C.pool.length) : x∈inputWires C.compile ↔ liftA x∈andArcs C.dag C.out := by
    change (x.1,x.2)∈inputWires _ ↔ (x.1,C.pool.get x.2)∈andArcs _ _
    rw [nativeAndArc,andArc_iff]
    have h : Used C.dag C.out (C.pool.get x.2) := memActive.mp (List.get_mem ..)
    change (_ ∨ _) ↔ Used _ _ _ ∧ (_ ∨ _)
    simp only [h,true_and]
    change (_ = (roles _ (direction _ _ _)).1 ∨ _ = (roles _ (direction _ _ _)).2) ↔ _
    cases direction C.dag C.tree (C.pool.get x.2) <;> simp [roles,or_comm]
  have eqO : (andOrWires C.compile).length=(orArcs C.dag C.out).length := by
    apply Nat.le_antisymm (mapCount liftO io (dedupND _) (fun x h=>(oo x).1 h))
    have sub : orArcs C.dag C.out ⊆ (andOrWires C.compile).map liftO := by
      intro ⟨g,i⟩ h
      obtain ⟨hr,mem⟩:=(orArc_iff _).1 h
      obtain ⟨k,eq⟩:=List.mem_iff_get.mp (memActive.mpr (show Used C.dag C.out g from ⟨i,hr,mem⟩))
      have ee : liftO (k,i)=(g,i) := Prod.ext eq rfl
      exact List.mem_map.mpr ⟨(k,i),(oo _).2 (ee ▸ h),ee⟩
    have nd : (orArcs C.dag C.out).Nodup := dedupND _
    have h:=nd.length_le_of_subset sub
    rw [List.length_map] at h;exact h
  have eqA : (inputWires C.compile).length=(andArcs C.dag C.out).length := by
    apply Nat.le_antisymm (mapCount liftA ia (dedupND _) (fun x h=>(aa x).1 h))
    have sub : andArcs C.dag C.out ⊆ (inputWires C.compile).map liftA := by
      intro ⟨i,g⟩ h
      obtain ⟨hr,_⟩:=(andArc_iff _).1 h
      obtain ⟨k,eq⟩:=List.mem_iff_get.mp (memActive.mpr hr)
      have ee : liftA (i,k)=(i,g) := Prod.ext rfl eq
      exact List.mem_map.mpr ⟨(i,k),(aa _).2 (ee ▸ h),ee⟩
    have nd : (andArcs C.dag C.out).Nodup := dedupND _
    have h:=nd.length_le_of_subset sub
    rw [List.length_map] at h;exact h
  unfold wireCount size;rw [eqO,eqA]
end Task
end HWB.Paper
