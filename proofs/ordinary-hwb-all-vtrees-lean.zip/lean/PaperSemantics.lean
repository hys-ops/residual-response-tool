import PaperLower
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
theorem paperTruth {D : DAG f a} (e : D.label i=.truth b) :
    Value D X i ↔ b=true := by
  constructor
  · intro v;cases v <;> simp_all
  · rintro rfl;exact .truth e
theorem paperLit {D : DAG f a} (e : D.label i=.literal z b) :
    Value D X i ↔ X z=b := by
  constructor
  · intro v;cases v <;> simp_all
  · exact .lit e
theorem nativeTruth {G : Graph f a} (e : (G.fn i).op=.const b) : Holds G X i ↔ b=true := by
  constructor
  · intro v;cases v <;> simp_all
  · rintro rfl;exact .constTrue e
theorem nativeLit {G : Graph f a} (e : (G.fn i).op=.lit b) (t : (G.fn i).scope=.leaf z) :
    Holds G X i ↔ X z=b := by
  constructor
  · intro v;cases v <;> simp_all
  · exact .lit e t

theorem swapConj (P : α → Prop) (p : α × α) (b : Bool) :
    (P (roles p b).1 ∧ P (roles p b).2) ↔ (P p.1 ∧ P p.2) := by cases b <;> simp [roles,and_comm]
theorem paperOr {D : DAG f a} (e : D.label i=.any L) (sw : Fin L.length → Bool) :
    Value D X i ↔ ∃ j : Fin L.length, Value D X (roles (D.pins (L.get j)) (sw j)).1 ∧
      Value D X (roles (D.pins (L.get j)) (sw j)).2 := by
  constructor
  · intro v;cases v with
    | truth op => simp_all
    | lit op => simp_all
    | any op j p s => rw [e] at op;cases op;exact ⟨j,(swapConj ..).2 ⟨p,s⟩⟩
  · rintro ⟨j,h⟩;have w:=(swapConj ..).1 h;exact .any e j w.1 w.2
theorem nativeOr {G : Graph f a} (e : (G.fn i).op=.disj L) :
    Holds G X i ↔ ∃ j : Fin L.length, Holds G X (G.inputs (L.get j)).1 ∧ Holds G X (G.inputs (L.get j)).2 := by
  constructor
  · intro v;cases v with
    | constTrue op => simp_all
    | lit op => simp_all
    | disj op j p s => rw [e] at op;cases op;exact ⟨j,p,s⟩
  · rintro ⟨j,p,s⟩;exact .disj e j p s

namespace Task
variable (C : Task f a)
theorem pinsSlot (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.any L)
    (k : Fin (packed _ L (C.hasInputs reach op)).length) :
    C.compile.inputs ((packed _ L (C.hasInputs reach op)).get k)=
      C.ports (L.get (slot (C.hasInputs reach op) k)) :=
  congrArg C.ports (decodeSlot _ _)
theorem nativeRow (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.any L) :
    Holds C.compile X i ↔ ∃ j : Fin L.length, Holds C.compile X (C.ports (L.get j)).1 ∧
      Holds C.compile X (C.ports (L.get j)).2 := by
  rw [nativeOr (C.opAny reach op)]
  constructor
  · rintro ⟨k,h⟩;rw [C.pinsSlot reach op k] at h;exact ⟨_,h⟩
  · rintro ⟨j,h⟩
    refine ⟨backSlot (C.hasInputs reach op) j,?_⟩
    rw [C.pinsSlot reach op];exact h

theorem semanticsAt (q : AtNode C.dag i t) (reach : Ancestor C.dag C.out i) (st : Sub t C.tree) :
    Holds C.compile X i ↔ Value C.dag X i := by
  induction q with
  | truth op => exact (nativeTruth (C.opTruth reach op)).trans (paperTruth op).symm
  | lit op => exact (nativeLit (C.opLit reach op).1 (C.opLit reach op).2).trans (paperLit op).symm
  | @any i L l r op ar sw lc rc bl br p s law ip isub =>
    have orient j := occursOrientation C.distinct st ar law
      (fun j=>⟨_,bl j,p j⟩) (fun j=>⟨_,br j,s j⟩) j
    rw [C.nativeRow reach op,paperOr op sw]
    apply exists_congr;intro j
    change (Holds _ (X) (roles _ (direction _ _ _)).1 ∧ Holds _ X (roles _ (direction _ _ _)).2) ↔ _
    rw [orient j]
    have e:=roleEdge C.dag op j (sw j)
    exact and_congr (ip j (.input reach e.1) (transSub (underL (bl j) _) st))
      (isub j (.input reach e.2) (transSub (underR (br j) _) st))

theorem semantics (reach : Ancestor C.dag C.out i) : Holds C.compile X i ↔ Value C.dag X i := by
  obtain ⟨t,st,q⟩:=ancestorRespects C.derivation reach
  exact C.semanticsAt q reach st

theorem compression : NativeCompressed C.compile ∧ LivePrimes C.compile := by
  have core i K (e : (C.compile.fn i).op=.disj K) :
      (∀ X, ∃ j : Fin K.length, Holds C.compile X (C.compile.inputs (K.get j)).1 ∧
        ∀ k : Fin K.length,Holds C.compile X (C.compile.inputs (K.get k)).1 → k=j) ∧
      (∀ j k : Fin K.length,(∀ X,Holds C.compile X (C.compile.inputs (K.get j)).2 ↔
         Holds C.compile X (C.compile.inputs (K.get k)).2) → j=k) ∧
      (∀ j : Fin K.length, ∃ X,Holds C.compile X (C.compile.inputs (K.get j)).1) := by
    by_cases hr : Ancestor C.dag C.out i
    · cases op : C.dag.label i with
      | truth b => simp [C.opTruth hr op] at e
      | literal z b => simp [(C.opLit hr op).1] at e
      | any L =>
        rw [C.opAny hr op] at e;cases e
        obtain ⟨_,_,_,_,law,_⟩:=C.rowData hr op
        let ok := C.hasInputs hr op
        have ps (j : Fin L.length) := roleEdge C.dag op j (direction C.dag C.tree (L.get j))
        have prim (k : Fin (packed _ L ok).length) (X) :
            Holds C.compile X (C.compile.inputs ((packed _ L ok).get k)).1 ↔
            Value C.dag X (C.ports (L.get (slot ok k))).1 := by
          rw [C.pinsSlot hr op];exact C.semantics (.input hr (ps _).1)
        have subs (k : Fin (packed _ L ok).length) (X) :
            Holds C.compile X (C.compile.inputs ((packed _ L ok).get k)).2 ↔
            Value C.dag X (C.ports (L.get (slot ok k))).2 := by
          rw [C.pinsSlot hr op];exact C.semantics (.input hr (ps _).2)
        refine ⟨?_,?_,?_⟩
        · intro X;obtain ⟨j,pj⟩:=law.cover X
          refine ⟨backSlot ok j,(prim _ X).2 pj,?_⟩
          intro k pk
          apply Fin.ext
          by_cases eq : slot ok k=j
          · exact congrArg (fun x : Fin L.length => x.val) eq
          · exact False.elim (law.disjoint _ _ eq X ((prim k X).1 pk) pj)
        · intro j k same
          by_cases eq : slot ok j=slot ok k
          · exact Fin.ext (congrArg (fun x : Fin L.length => x.val) eq)
          · obtain ⟨X,bad⟩:=law.compress _ _ eq
            exact False.elim (bad ((subs j X).symm.trans ((same X).trans (subs k X))))
        · intro j;obtain ⟨X,h⟩:=law.live (slot ok j)
          exact ⟨X,(prim j X).2 h⟩
    · simp [C.inactive hr] at e
  exact ⟨fun i L e=>⟨(core i L e).1,(core i L e).2.1⟩,fun i L e=>(core i L e).2.2⟩
end Task
end HWB.Paper
