import PaperChoices
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
def Used (D : DAG f a) (o : Fin f) (g : Fin a) := ∃ i, Ancestor D o i ∧ g ∈ uses D i
noncomputable def active (D : DAG f a) (o : Fin f) : List (Fin a) := by
  classical exact (List.finRange a).filter (fun g=>decide (Used D o g))
theorem memActive {D : DAG f a} : g∈active D o ↔ Used D o g := by classical simp [active]
def encode (xs : List α) [DecidableEq α] (x : α) (h : x∈xs) : Fin xs.length :=
  ⟨xs.idxOf x,List.idxOf_lt_length_iff.mpr h⟩
theorem decodeEncode (xs : List α) [DecidableEq α] (x : α) (h : x∈xs) :
    xs.get (encode xs x h)=x := by
  simp [encode,List.get_eq_getElem,List.getElem_idxOf]
def packed (xs : List (Fin a)) (L : List (Fin a)) (ok : L ⊆ xs) : List (Fin xs.length) :=
  List.ofFn fun j : Fin L.length => encode xs (L.get j) (ok (List.get_mem _ _))
theorem packLen : (packed xs L ok).length=L.length := by simp [packed]
def slot {xs L : List (Fin a)} (ok : L⊆xs) (k : Fin (packed xs L ok).length) : Fin L.length :=
  ⟨k.val,by have h:=k.isLt; simpa only [packLen] using h⟩
def backSlot {xs L : List (Fin a)} (ok : L⊆xs) (j : Fin L.length) : Fin (packed xs L ok).length :=
  ⟨j.val,by rw [packLen];exact j.isLt⟩
theorem decodeSlot {xs L : List (Fin a)} (ok : L⊆xs) (k : Fin (packed xs L ok).length) :
    xs.get ((packed xs L ok).get k)=L.get (slot ok k) := by
  have e : (packed xs L ok).get k = encode xs (L.get (slot ok k)) (ok (List.get_mem ..)) := by
    change (List.ofFn _)[k.val]'(k.isLt) = _
    exact @List.getElem_ofFn _ _ _ (fun j : Fin L.length => encode xs (L.get j) (ok (List.get_mem ..))) k.isLt
  rw [e,decodeEncode]

structure Task (f a : Nat) where
  dag : DAG f a
  out : Fin f
  tree : Tree
  distinct : (rawLabels tree).Nodup
  derivation : Respects dag out tree

namespace Task
variable (C : Task f a)
abbrev Dg := C.dag
noncomputable abbrev pool := active C.dag C.out
noncomputable abbrev scope (i : Fin f) := home C.dag C.out C.tree C.distinct C.derivation i
noncomputable abbrev ports (g : Fin a) := roles (C.dag.pins g) (direction C.dag C.tree g)
theorem hasInputs (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.any L) : L⊆C.pool :=
  fun g hg=>memActive.mpr ⟨i,reach,by simpa [uses,op] using hg⟩

noncomputable def opcode (i : Fin f) : Op C.pool.length := by
  classical
  exact if hr : Ancestor C.dag C.out i then
    match e : C.dag.label i with
    | .truth b => .const b
    | .literal _ b => .lit b
    | .any L => .disj (packed C.pool L (C.hasInputs hr e))
    else .const false
noncomputable def compile : Graph f C.pool.length :=
  ⟨fun i=>⟨C.scope i,C.opcode i⟩,fun k=>C.ports (C.pool.get k)⟩

theorem opAny (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.any L) :
    (C.compile.fn i).op=.disj (packed _ L (C.hasInputs reach op)) := by
  change C.opcode i=_; unfold opcode; simp only [reach, dite_true];split <;> rename_i eq <;> rw [op] at eq <;> cases eq <;> rfl
theorem opLit (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.literal z b) :
    (C.compile.fn i).op=.lit b ∧ (C.compile.fn i).scope=.leaf z := by
  constructor
  · change C.opcode i=_;unfold opcode;simp only [reach, dite_true];split <;> simp_all
  · have q:=(homeSpec C.distinct C.derivation reach).2.1
    change C.scope i=.leaf z
    generalize ee : C.scope i=t at *
    change AtNode C.dag i (C.scope i) at q
    rw [ee] at q
    cases q <;> simp_all
theorem opTruth (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.truth b) :
    (C.compile.fn i).op=.const b := by
  change C.opcode i=_;unfold opcode;simp only [reach, dite_true];split <;> simp_all
theorem inactive (dead : ¬Ancestor C.dag C.out i) : (C.compile.fn i).op=.const false := by
  simp [compile,opcode,dead]

theorem positioned (reach : Ancestor C.dag C.out i) (st : Sub t C.tree) (h : Respects C.dag i t) :
    Fits C.compile i t := by
  rcases (homeSpec C.distinct C.derivation reach).2.2 t st h with ⟨b,op⟩|hs
  · exact .inl ⟨b,C.opTruth reach op⟩
  · exact .inr hs

theorem rowData (reach : Ancestor C.dag C.out i) (op : C.dag.label i=.any L) :
    ∃ l r, C.scope i=.fork l r ∧ 2≤L.length ∧
      Laws C.dag L (fun j=>direction C.dag C.tree (L.get j)) ∧
      ∀ j : Fin L.length, Fits C.compile (C.ports (L.get j)).1 l ∧ Fits C.compile (C.ports (L.get j)).2 r := by
  have spec:=homeSpec C.distinct C.derivation reach
  obtain ⟨st,q,_⟩:=spec
  change Sub (C.scope i) C.tree at st
  change AtNode C.dag i (C.scope i) at q
  generalize he : C.scope i=t at q st
  cases q with
  | truth e => simp_all
  | lit e => simp_all
  | @any _ K l r e ar sw lc rc bl br p s laws =>
    rw [op] at e;cases e
    have ps j : Respects C.dag (roles (C.dag.pins (L.get j)) (sw j)).1 l := ⟨_,bl j,p j⟩
    have ss j : Respects C.dag (roles (C.dag.pins (L.get j)) (sw j)).2 r := ⟨_,br j,s j⟩
    have ee : (fun j=>direction C.dag C.tree (L.get j))=sw :=
      funext (occursOrientation C.distinct st ar laws ps ss)
    refine ⟨l,r,rfl,ar,ee ▸ laws,?_⟩
    intro j
    have side:=roleEdge C.dag op j (sw j)
    change Fits _ (roles _ ((fun j=>direction C.dag C.tree (L.get j)) j)).1 _ ∧
      Fits _ (roles _ ((fun j=>direction C.dag C.tree (L.get j)) j)).2 _
    rw [ee]
    exact ⟨C.positioned (.input reach side.1) (transSub (underL (selfSub _) _) st) (ps j),
      C.positioned (.input reach side.2) (transSub (underR (selfSub _) _) st) (ss j)⟩

theorem scopeAndStrict : WellScoped C.compile ∧ BovaAudit.Strict C.compile := by
  constructor
  · intro i
    by_cases hr : Ancestor C.dag C.out i
    · cases op : C.dag.label i with
      | truth b => simp [C.opTruth hr op]
      | literal z b => exact (by rw [(C.opLit hr op).1]; exact ⟨_,(C.opLit hr op).2⟩)
      | any L =>
        rw [C.opAny hr op]
        obtain ⟨l,r,el,_,_,kids⟩:=C.rowData hr op
        refine ⟨l,r,el,fun k=>?_⟩
        change Fits _ (C.ports (C.pool.get _)).1 l ∧ Fits _ (C.ports (C.pool.get _)).2 r
        rw [decodeSlot];exact kids _
    · simp [C.inactive hr]
  · intro i K e
    by_cases hr : Ancestor C.dag C.out i
    · cases op : C.dag.label i with
      | truth b => simp [C.opTruth hr op] at e
      | literal z b => simp [(C.opLit hr op).1] at e
      | any L =>
        rw [C.opAny hr op] at e;cases e;rw [packLen];exact (C.rowData hr op).choose_spec.choose_spec.2.1
    · simp [C.inactive hr] at e
end Task
end HWB.Paper
