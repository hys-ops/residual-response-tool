import PaperUpper
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
theorem nodupBelow {s t : Tree} (st : Sub s t) (nd : (rawLabels t).Nodup) : (rawLabels s).Nodup := by
  induction t with
  | leaf z => have h : s=.leaf z := by simpa [Sub,inTree] using st
              exact h ▸ nd
  | fork l r pl pr =>
    obtain ⟨nl,nr,_⟩:=List.nodup_append.mp nd
    rcases splitSub st with rfl|h|h
    · exact nd
    · exact pl h nl
    · exact pr h nr

/-- Tests over the actual variables of a child subtree. -/
abbrev Local (t : Tree) := {z : Nat // z∈rawLabels t} → Bool
def restrictTo (t : Tree) (X : Assignment) : Local t := fun z=>X z.val
def extendFrom (t : Tree) (x : Local t) : Assignment := fun z=>if h : z∈rawLabels t then x ⟨z,h⟩ else false
theorem localValue {D : DAG f a} (sc : Respects D i t) (X : Assignment) :
    Value D (extendFrom t (restrictTo t X)) i ↔ Value D X i := by
  have e z (m : Mentions D i z) : extendFrom t (restrictTo t X) z=X z := by
    simp [extendFrom,restrictTo,within sc z m]
  exact ⟨fun h=>valueTransfer h e,fun h=>valueTransfer h (fun z m=>(e z m).symm)⟩

structure LocalLaws (D : DAG f a) (L : List (Fin a)) (sw : Fin L.length→Bool) (l r : Tree) : Prop where
  live (j) : ∃ x : Local l,Value D (extendFrom l x) (roles (D.pins (L.get j)) (sw j)).1
  disjoint (j k) : j≠k → ∀ x : Local l,Value D (extendFrom l x) (roles (D.pins (L.get j)) (sw j)).1 →
      Value D (extendFrom l x) (roles (D.pins (L.get k)) (sw k)).1 → False
  cover (x : Local l) : ∃ j,Value D (extendFrom l x) (roles (D.pins (L.get j)) (sw j)).1
  compressed (j k) : j≠k → ∃ x : Local r, ¬(Value D (extendFrom r x) (roles (D.pins (L.get j)) (sw j)).2 ↔
      Value D (extendFrom r x) (roles (D.pins (L.get k)) (sw k)).2)

theorem localLaws_iff {D : DAG f a} {L : List (Fin a)} {sw : Fin L.length→Bool}
    (p : ∀ j,Respects D (roles (D.pins (L.get j)) (sw j)).1 l)
    (s : ∀ j,Respects D (roles (D.pins (L.get j)) (sw j)).2 r) :
    LocalLaws D L sw l r ↔ Laws D L sw := by
  constructor
  · intro h;refine ⟨?_,?_,?_,?_⟩
    · intro j;obtain ⟨x,v⟩:=h.live j;exact ⟨_,v⟩
    · intro j k neq X v w;exact h.disjoint _ _ neq (restrictTo l X) ((localValue (p j) X).2 v) ((localValue (p k) X).2 w)
    · intro X;obtain ⟨j,v⟩:=h.cover (restrictTo l X);exact ⟨j,(localValue (p j) X).1 v⟩
    · intro j k neq;obtain ⟨x,e⟩:=h.compressed j k neq;exact ⟨_,e⟩
  · intro h;refine ⟨?_,?_,?_,?_⟩
    · intro j;obtain ⟨X,v⟩:=h.live j;exact ⟨restrictTo l X,(localValue (p j) X).2 v⟩
    · intro j k ne x;exact h.disjoint j k ne _
    · intro x;exact h.cover _
    · intro j k ne;obtain ⟨X,e⟩:=h.compress j k ne
      exact ⟨restrictTo r X, fun h=>e ((localValue (s j) X).symm.trans (h.trans (localValue (s k) X)))⟩

abbrev Vertex (f a : Nat) := Sum (Fin f) (Fin a)
def Arc (D : DAG f a) (o : Fin f) : Vertex f a → Vertex f a → Prop
  | .inl i,.inr g => (i,g)∈andArcs D o
  | .inr g,.inl i => (g,i)∈orArcs D o
  | _,_ => False
def Live (D : DAG f a) (o : Fin f) : Vertex f a → Prop
  | .inl i => Ancestor D o i
  | .inr g => Used D o g
inductive Path {V : Type} (E : V→V→Prop) : V→V→Prop
  | refl (x) : Path E x x
  | cons (arc : E x y) (tail : Path E y z) : Path E x z

theorem rootedPaths (D : DAG f a) (o : Fin f) (v : Vertex f a) :
    Live D o v ↔ Path (Arc D o) v (.inl o) := by
  have pathF (i : Fin f) (hi : Ancestor D o i) : Path (Arc D o) (.inl i) (.inl o) := by
    induction hi with
    | root => exact .refl _
    | @input i k h e ih =>
      obtain ⟨g,mem,side⟩:=e
      exact .cons (show Arc D o (.inl k) (.inr g) from (andArc_iff D).2 ⟨⟨i,h,mem⟩,side⟩) (.cons (show Arc D o (.inr g) (.inl i) from (orArc_iff D).2 ⟨h,mem⟩) ih)
  constructor
  · intro h;cases v with
    | inl i => exact pathF i h
    | inr g => obtain ⟨i,hr,hm⟩:=h;exact .cons (show Arc D o (.inr g) (.inl i) from (orArc_iff D).2 ⟨hr,hm⟩) (pathF _ hr)
  · intro h;cases h with
    | refl => exact Ancestor.root
    | @cons x y _ e _ =>
      cases v with
      | inr g =>
        cases y with
        | inr => contradiction
        | inl i => have q:=(orArc_iff D).1 e;exact ⟨i,q⟩
      | inl k =>
        cases y with
        | inl => contradiction
        | inr g =>
          obtain ⟨⟨i,hr,hm⟩,side⟩:=(andArc_iff D).1 e
          exact Ancestor.input hr ⟨g,hm,side⟩

def nRank (G : Graph f a) (i : Fin f) : Nat := match (G.fn i).op with
  | .const _ => 0
  | _ => depth (G.fn i).scope+1
theorem fitRank {G : Graph f a} (fit : Fits G i t) : nRank G i≤depth t+1 := by
  rcases fit with ⟨b,e⟩|st
  · simp [nRank,e]
  · have h:=depthSub st;cases e : (G.fn i).op <;> simp [nRank,e] <;> omega

namespace Task
variable (C : Task f a)
theorem smaller (reach : Ancestor C.dag C.out i) (e : edge C.dag k i) : nRank C.compile k<nRank C.compile i := by
  obtain ⟨g,hm,side⟩:=e
  cases op : C.dag.label i with
  | truth b => simp [uses,op] at hm
  | literal z b => simp [uses,op] at hm
  | any L =>
    simp [uses,op] at hm
    obtain ⟨j,rfl⟩:=List.mem_iff_get.mp hm
    obtain ⟨l,r,eq,_,_,kids⟩:=C.rowData reach op
    have ⟨pl,sr⟩:=kids j
    have dp:=fitRank pl;have ds:=fitRank sr
    have base : nRank C.compile i=depth l+depth r+2 := by
      simp only [nRank,C.opAny reach op];change depth (C.scope i)+1=_;rw [eq];simp [depth,Nat.add_assoc]
    have sides : k=(C.ports (L.get j)).1 ∨ k=(C.ports (L.get j)).2 := by
      unfold ports;cases direction C.dag C.tree (L.get j) <;> first | exact side | exact side.symm
    rcases sides with rfl|rfl <;> omega

noncomputable def vRank (v : Vertex f a) : Nat := match v with
  | .inl i => 2*nRank C.compile i
  | .inr g => 2*max (nRank C.compile (C.dag.pins g).1) (nRank C.compile (C.dag.pins g).2)+1

theorem acyclicRank {u v : Vertex f a} (e : Arc C.dag C.out u v) : C.vRank u<C.vRank v := by
  cases u with
  | inl k =>
    cases v with
    | inl => contradiction
    | inr g =>
      obtain ⟨_,side⟩:=(andArc_iff _).1 e
      simp only [vRank];rcases side with rfl|rfl <;> omega
  | inr g =>
    cases v with
    | inr => contradiction
    | inl i =>
      obtain ⟨hr,hm⟩:=(orArc_iff _).1 e
      have p:=C.smaller hr ⟨g,hm,Or.inl rfl⟩;have s:=C.smaller hr ⟨g,hm,Or.inr rfl⟩
      simp only [vRank];omega

theorem uniqueSink (v : Vertex f a) (live : Live C.dag C.out v) :
    (∀ w,¬Arc C.dag C.out v w) ↔ v=.inl C.out := by
  have mono {a b : Vertex f _} (p : Path (Arc C.dag C.out) a b) : C.vRank a≤C.vRank b := by
    induction p with
    | refl => exact Nat.le_refl _
    | cons e _ ih => exact Nat.le_trans (Nat.le_of_lt (C.acyclicRank e)) ih
  constructor
  · intro sink;cases (rootedPaths _ _ _).1 live with
    | refl => rfl
    | cons e _ => exact False.elim (sink _ e)
  · rintro rfl w e
    have lw : Live C.dag C.out w := by
      cases w with
      | inl => contradiction
      | inr g => exact ((andArc_iff _).1 e).1
    have h:=mono ((rootedPaths _ _ _).1 lw);have lt:=C.acyclicRank e;omega
end Task
end HWB.Paper
