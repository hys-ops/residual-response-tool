import PaperGrammar
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper

theorem chooseScope {D : DAG f a} (nd : (rawLabels T).Nodup) (h : Respects D i T) :
    ∃ s, Sub s T ∧ AtNode D i s ∧
      (∀ t, Sub t T → Respects D i t → (∃ b,D.label i=.truth b) ∨ Sub s t) := by
  let P (k : Nat) := ∃ u, Sub u T ∧ AtNode D i u ∧ depth u=k
  obtain ⟨u,hu,au⟩:=h
  have ex : ∃ k,P k := ⟨_,u,hu,au,rfl⟩
  obtain ⟨k,⟨s,hs,atS,eq⟩,least⟩:=Growth.minWitness ex
  refine ⟨s,hs,atS,?_⟩
  intro t ht hit
  by_cases hc : ∃ b,D.label i=.truth b
  · exact .inl hc
  right
  obtain ⟨v,hv,av⟩:=hit
  obtain ⟨z,m⟩:=hasAnchor atS (fun b e=>hc ⟨b,e⟩)
  have vT:=transSub hv ht
  rcases chain nd hs vT (localMentions atS _ m) (localMentions av _ m) with sub|back
  · exact transSub sub hv
  · have le : depth s≤depth v := by
      apply Classical.byContradiction;intro bad
      have lt : depth v<k := by omega
      exact least _ lt ⟨v,vT,av,rfl⟩
    have same:=eqOfDepth back le; simpa [← same] using hv

noncomputable def home (D : DAG f a) (o : Fin f) (T : Tree) (nd : (rawLabels T).Nodup)
    (h : Respects D o T) (i : Fin f) : Tree := by
  classical
  exact if reach : Ancestor D o i then
    (chooseScope nd (ancestorRespects h reach)).choose else T

theorem homeSpec {D : DAG f a} (nd : (rawLabels T).Nodup) (h : Respects D o T) (reach : Ancestor D o i) :
    let s:=home D o T nd h i
    Sub s T ∧ AtNode D i s ∧
    (∀ t, Sub t T → Respects D i t → (∃ b,D.label i=.truth b) ∨ Sub s t) := by
  simpa [home,reach] using (chooseScope nd (ancestorRespects h reach)).choose_spec

def CanOrient (D : DAG f a) (T : Tree) (g : Fin a) (b : Bool) := ∃ l r,
  Sub (.fork l r) T ∧ (∃ z,Mentions D (roles (D.pins g) b).1 z) ∧
  mentionedIn D (roles (D.pins g) b).1 l ∧ mentionedIn D (roles (D.pins g) b).2 r

theorem orientationUnique {D : DAG f a} (nd : (rawLabels T).Nodup)
    (u : CanOrient D T g false) (v : CanOrient D T g true) : False := by
  obtain ⟨l,r,a,⟨x,mx⟩,pl,sr⟩:=u
  obtain ⟨j,k,b,⟨y,my⟩,pj,sk⟩:=v
  exact noCross nd a b (pl _ mx) (sr _ my) (pj _ my) (sk _ mx)

noncomputable def direction (D : DAG f a) (T : Tree) (g : Fin a) : Bool := by
  classical
  exact if CanOrient D T g false then false else true

theorem direction_eq {D : DAG f a} (nd : (rawLabels T).Nodup) (can : CanOrient D T g b) :
    direction D T g=b := by
  cases b with
  | false => simp [direction,can]
  | true =>
    have no : ¬CanOrient D T g false := fun h=>orientationUnique nd h can
    simp [direction,no]

theorem occursOrientation {D : DAG f a} {flip : Fin L.length → Bool}
    (nd : (rawLabels T).Nodup) (ht : Sub (.fork l r) T) (ar : 2≤L.length)
    (law : Laws D L flip) (p : ∀ j,Respects D (roles (D.pins (L.get j)) (flip j)).1 l)
    (s : ∀ j,Respects D (roles (D.pins (L.get j)) (flip j)).2 r) (j) :
    direction D T (L.get j)=flip j :=
  direction_eq nd ⟨l,r,ht,primeAnchor ar law j,within (p j),within (s j)⟩
end HWB.Paper
