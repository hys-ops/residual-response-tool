import PaperTree
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper

/-- Input terminals carry their variable names. No function gate carries a scope. -/
inductive Symbol (a : Nat)
  | truth (v : Bool)
  | literal (name : Nat) (positive : Bool)
  | any (terms : List (Fin a))

/-- Both ports of a conjunction are ordinary gate references. Their storage order
has no logical prime/sub meaning. Different ORs may name the same conjunction. -/
structure DAG (f a : Nat) where
  label : Fin f → Symbol a
  pins : Fin a → Fin f × Fin f

def roles (p : α × α) : Bool → α × α
  | false => p
  | true => (p.2,p.1)

def uses (D : DAG f a) (i : Fin f) : List (Fin a) := match D.label i with
  | .any L => L
  | _ => []

inductive Value (D : DAG f a) (X : Assignment) : Fin f → Prop
  | truth (h : D.label i=.truth true) : Value D X i
  | lit (h : D.label i=.literal z b) (v : X z=b) : Value D X i
  | any (h : D.label i=.any L) (j : Fin L.length)
      (p : Value D X (D.pins (L.get j)).1) (s : Value D X (D.pins (L.get j)).2) : Value D X i

def edge (D : DAG f a) (k i : Fin f) : Prop := ∃ g∈uses D i, k=(D.pins g).1 ∨ k=(D.pins g).2
inductive Mentions (D : DAG f a) : Fin f → Nat → Prop
  | lit (h : D.label i=.literal z b) : Mentions D i z
  | up (e : edge D k i) (h : Mentions D k z) : Mentions D i z
inductive Ancestor (D : DAG f a) (out : Fin f) : Fin f → Prop
  | root : Ancestor D out out
  | input (hi : Ancestor D out i) (e : edge D k i) : Ancestor D out k

def mentionedIn (D : DAG f a) (i : Fin f) (t : Tree) := ∀ z, Mentions D i z → z∈rawLabels t

theorem rawEdge (D : DAG f a) (e : D.label i=.any L) (j : Fin L.length) :
    edge D (D.pins (L.get j)).1 i ∧ edge D (D.pins (L.get j)).2 i := by
  have m : L.get j∈uses D i := by simp [uses,e]
  exact ⟨⟨_,m,.inl rfl⟩,⟨_,m,.inr rfl⟩⟩
theorem roleEdge (D : DAG f a) (e : D.label i=.any L) (j : Fin L.length) (b : Bool) :
    edge D (roles (D.pins (L.get j)) b).1 i ∧ edge D (roles (D.pins (L.get j)) b).2 i := by
  cases b
  · exact rawEdge D e j
  · exact (rawEdge D e j).symm

theorem valueTransfer {D : DAG f a} {X Y : Assignment} (h : Value D X i)
    (agree : ∀ z, Mentions D i z → X z=Y z) : Value D Y i := by
  induction h with
  | truth e => exact .truth e
  | lit e hit => exact .lit e ((agree _ (.lit e)).symm.trans hit)
  | any e j _ _ ip isub =>
    exact .any e j (ip (fun z m=>agree z (.up (rawEdge D e j).1 m)))
      (isub (fun z m=>agree z (.up (rawEdge D e j).2 m)))

/-- Pointwise form of (S3), (S4), (S5) and (C), in that order. -/
structure Laws (D : DAG f a) (L : List (Fin a)) (flip : Fin L.length → Bool) : Prop where
  live (j) : ∃ X, Value D X (roles (D.pins (L.get j)) (flip j)).1
  disjoint (j k) : j≠k → ∀ X, Value D X (roles (D.pins (L.get j)) (flip j)).1 →
      Value D X (roles (D.pins (L.get k)) (flip k)).1 → False
  cover (X) : ∃ j, Value D X (roles (D.pins (L.get j)) (flip j)).1
  compress (j k) : j≠k → ∃ X, ¬(Value D X (roles (D.pins (L.get j)) (flip j)).2 ↔
      Value D X (roles (D.pins (L.get k)) (flip k)).2)

/-- A derivation locates this occurrence. Shared gates can have different
derivations, splits and port permutations at different occurrences. -/
inductive AtNode (D : DAG f a) : Fin f → Tree → Prop
  | truth (h : D.label i=.truth b) : AtNode D i t
  | lit (h : D.label i=.literal z b) : AtNode D i (.leaf z)
  | any (h : D.label i=.any L) (arity : 2≤L.length) (flip : Fin L.length → Bool)
      {lc rc : Fin L.length → Tree} (left : ∀ j, Sub (lc j) l) (right : ∀ j, Sub (rc j) r)
      (prime : ∀ j, AtNode D (roles (D.pins (L.get j)) (flip j)).1 (lc j))
      (sub : ∀ j, AtNode D (roles (D.pins (L.get j)) (flip j)).2 (rc j))
      (laws : Laws D L flip) : AtNode D i (.fork l r)
def Respects (D : DAG f a) (i : Fin f) (T : Tree) := ∃ u, Sub u T ∧ AtNode D i u

theorem localMentions {D : DAG f a} (h : AtNode D i t) : mentionedIn D i t := by
  intro z m
  induction m generalizing t with
  | lit e => cases h with
             | truth op => simp_all
             | lit op => simp_all [rawLabels]
             | any op => simp_all
  | @up k i z e m ih =>
    obtain ⟨g,hg,side⟩:=e
    cases h with
    | truth op => simp [uses,op] at hg
    | lit op => simp [uses,op] at hg
    | @any _ L _ _ op ar flip _ _ left right p s law =>
      simp only [uses,op] at hg
      obtain ⟨j,rfl⟩:=List.mem_iff_get.mp hg
      have hh : k=(roles (D.pins (L.get j)) (flip j)).1 ∨ k=(roles (D.pins (L.get j)) (flip j)).2 := by
        cases flip j <;> simp only [roles] <;> first | exact side | exact side.symm
      rcases hh with rfl|rfl
      · have atU:=p j
        have hu:=left j
        exact List.mem_append_left _ (labelsSub hu (ih atU))
      · have atV:=s j
        have hv:=right j
        exact List.mem_append_right _ (labelsSub hv (ih atV))

theorem within {D : DAG f a} (h : Respects D i t) : mentionedIn D i t := by
  obtain ⟨_,sub,atN⟩:=h
  exact fun z m=>labelsSub sub (localMentions atN z m)

theorem primeAnchor {D : DAG f a} {L : List (Fin a)} {flip : Fin L.length → Bool} (ar : 2≤L.length)
    (law : Laws D L flip) (j : Fin L.length) :
    ∃ z, Mentions D (roles (D.pins (L.get j)) (flip j)).1 z := by
  classical
  let k : Fin L.length := if j.val=0 then ⟨1,by omega⟩ else ⟨0,by omega⟩
  have ne : j≠k := by intro eq;have h:=congrArg Fin.val eq;dsimp [k] at h;split at h <;> simp only at h <;> omega
  obtain ⟨X,hX⟩:=law.live j
  obtain ⟨Y,hY⟩:=law.live k
  apply Classical.byContradiction;intro none
  exact law.disjoint j k ne Y (valueTransfer hX (fun z mz=>False.elim (none ⟨z,mz⟩))) hY

theorem hasAnchor {D : DAG f a} (q : AtNode D i t) (nc : ∀ b,D.label i≠.truth b) :
    ∃ z,Mentions D i z := by
  cases q with
  | truth e => exact False.elim (nc _ e)
  | lit e => exact ⟨_,.lit e⟩
  | @any _ L _ _ e ar flip _ _ left right p s law =>
    let j : Fin L.length := ⟨0,by omega⟩
    obtain ⟨z,m⟩:=primeAnchor ar law j
    exact ⟨z,.up (roleEdge D e j (flip j)).1 m⟩

theorem childRespects {D : DAG f a} (hi : Respects D i T) (e : edge D k i) : Respects D k T := by
  obtain ⟨u,below,atU⟩:=hi
  obtain ⟨g,mem,side⟩:=e
  cases atU with
  | truth op => simp [uses,op] at mem
  | lit op => simp [uses,op] at mem
  | @any i L l r op ar flip lc rc left right p s law =>
    simp [uses,op] at mem
    obtain ⟨j,rfl⟩:=List.mem_iff_get.mp mem
    have ss : k=(roles (D.pins (L.get j)) (flip j)).1 ∨ k=(roles (D.pins (L.get j)) (flip j)).2 := by
      cases flip j <;> first | exact side | exact side.symm
    rcases ss with rfl|rfl
    · exact ⟨_,transSub (underL (left j) _) below,p j⟩
    · exact ⟨_,transSub (underR (right j) _) below,s j⟩

theorem ancestorRespects {D : DAG f a} (hr : Respects D o T) (reach : Ancestor D o i) : Respects D i T := by
  induction reach with
  | root => exact hr
  | input _ e ih => exact childRespects ih e

end HWB.Paper
