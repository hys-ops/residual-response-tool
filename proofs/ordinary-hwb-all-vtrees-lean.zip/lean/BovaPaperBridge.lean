import PaperRooted
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
namespace Task
variable (C : Task f a)

/-- Repeating an AND at one OR would repeat its sub, even when the independent
source derivations initially allow occurrence-specific port orientations. -/
theorem distinctTerms (hr : Ancestor C.dag C.out i) (op : C.dag.label i=.any L) : L.Nodup := by
  obtain ⟨_,_,_,_,law,_⟩:=C.rowData hr op
  apply List.nodup_iff_eq_of_getElem_eq.mpr
  intro j k hj hk e
  by_cases eq : j=k
  · exact eq
  · have ne : (⟨j,hj⟩ : Fin L.length)≠⟨k,hk⟩ := fun h=>eq (congrArg Fin.val h)
    obtain ⟨X,bad⟩:=law.compress _ _ ne
    apply False.elim;apply bad
    change Value C.dag X (C.ports (L[j])).2 ↔ Value C.dag X (C.ports (L[k])).2
    rw [e]

theorem distinctPins (hg : Used C.dag C.out g) : (C.dag.pins g).1≠(C.dag.pins g).2 := by
  obtain ⟨i,hr,mem⟩:=hg
  obtain ⟨t,ht,q⟩:=ancestorRespects C.derivation hr
  cases q with
  | truth op => simp [uses,op] at mem
  | lit op => simp [uses,op] at mem
  | @any _ L l r op ar sw lc rc bl br p s laws =>
    simp [uses,op] at mem
    obtain ⟨j,rfl⟩:=List.mem_iff_get.mp mem
    obtain ⟨z,m⟩:=primeAnchor ar laws j
    intro same
    have eq : (roles (C.dag.pins (L.get j)) (sw j)).1=(roles (C.dag.pins (L.get j)) (sw j)).2 := by
      cases sw j <;> first | exact same | exact same.symm
    have left := labelsSub (bl j) (localMentions (p j) z m)
    have right := labelsSub (br j) (localMentions (s j) z (eq ▸ m))
    exact apartLabels (nodupBelow ht C.distinct) left right

/-- The output scope may be below the supplied vtree root. Fin f keeps the
original function IDs. One reachable source AND has one packed ID everywhere. -/
theorem lower_translation :
    WellScoped C.compile ∧ NativeCompressed C.compile ∧ LivePrimes C.compile ∧
    BovaAudit.Strict C.compile ∧ Fits C.compile C.out C.tree ∧
    (∀ i, Ancestor C.dag C.out i → ∀ X, Holds C.compile X i ↔ Value C.dag X i) ∧
    wireCount C.compile=size C.dag C.out := by
  exact ⟨C.scopeAndStrict.1,C.compression.1,C.compression.2,C.scopeAndStrict.2,
    C.positioned .root (selfSub _) C.derivation,fun _ hr _=>C.semantics hr,C.compile_size⟩

theorem sharing (g : Fin a) (used : Used C.dag C.out g) :
    ∃ k : Fin C.pool.length, C.pool.get k=g ∧
    (∀ k',C.pool.get k'=g→k'=k) ∧
    (∀ i,k∈fanin C.compile i ↔ Ancestor C.dag C.out i ∧ g∈uses C.dag i) ∧
    C.compile.inputs k=C.ports g := by
  obtain ⟨k,eq⟩:=List.mem_iff_get.mp (memActive.mpr used)
  refine ⟨k,eq,fun k' e=>ndGet (activeND ..) (e.trans eq.symm),?_,congrArg C.ports eq⟩
  intro i;exact (C.fanEquiv i k).trans (by rw [eq])
end Task

/-- This is an independently well-formed, rooted source circuit on the same tree.
Its untouched wire endpoints are characterized by orArc_iff and andArc_iff. -/
theorem upper_translation (G : Graph f a) (o : Fin f) (T : Tree) (nd : (rawLabels T).Nodup)
    (sc : WellScoped G) (cp : NativeCompressed G) (live : LivePrimes G)
    (st : BovaAudit.Strict G) (fit : Fits G o T) :
    Respects (forget G) o T ∧ (∀ X i,Value (forget G) X i ↔ Holds G X i) ∧
    size (forget G) o=(liveOrWires G o).length+(liveInputWires G o).length ∧
    size (forget G) o≤wireCount G ∧
    (∀ v, Live (forget G) o v → ((∀ w,¬Arc (forget G) o v w) ↔ v=.inl o)) ∧
    (∃ rank : Vertex f a→Nat, ∀ u v,Arc (forget G) o u v→rank u<rank v) := by
  have ok:=readRespects sc cp live st o T fit
  let C : Task f a := ⟨forget G,o,T,nd,ok⟩
  exact ⟨ok,fun _ _=>forgetValue sc,(forgetSize G o).1,(forgetSize G o).2,
    C.uniqueSink,⟨C.vRank,fun _ _ e=>C.acyclicRank e⟩⟩

/-- Paper input alphabet, distinct from the (possibly larger) vtree alphabet. -/
def ReadsOnly (D : DAG f a) (o : Fin f) (allowed : Nat → Prop) :=
  ∀ i, Ancestor D o i → ∀ z b, D.label i=.literal z b → allowed z

theorem readsOnTree (C : Task f a) : ReadsOnly C.dag C.out (fun z=>z∈rawLabels C.tree) :=
  fun _ hr z _ e=>within (ancestorRespects C.derivation hr) z (.lit e)

def PaperHWB (n w : Nat) : Prop := ∃ (f a : Nat) (C : Task f a),
  ReadsOnly C.dag C.out (fun z=>1≤z ∧ z≤n) ∧
  (∀ X,Value C.dag X C.out ↔ numberedHWB n X) ∧ size C.dag C.out=w

theorem eligible_of_paper (C : Task f a) (correct : ∀ X,Value C.dag X C.out ↔ numberedHWB n X) :
    BovaAudit.Eligible n (size C.dag C.out) := by
  obtain ⟨s,c,l,ar,fit,sem,cost⟩:=C.lower_translation
  exact ⟨_,_,C.compile,C.tree,C.out,C.distinct,s,c,l,ar,fit,fun X=>(sem _ .root X).trans (correct X),cost⟩

/-- Apply the existing lower to the source grammar. No bound on extra leaves. -/
theorem bova_question_paper (A d : Nat) : ∃ n₀,∀ n≥n₀,∀ w,PaperHWB n w→A*(n+1)^d<w := by
  obtain ⟨n₀,h⟩:=BovaAudit.bova_question A d
  refine ⟨n₀,?_⟩
  rintro n hn w ⟨_,_,C,_,correct,rfl⟩
  exact h n hn _ (eligible_of_paper C correct)

theorem paper_upper_original (n : Nat) (hn : 0<n) :
    ∃ (f a : Nat) (C : Task f a), (rawLabels C.tree).Perm (List.range' 1 n) ∧
      ReadsOnly C.dag C.out (fun z=>1≤z ∧ z≤n) ∧
      (∀ X,Value C.dag X C.out ↔ numberedHWB n X) ∧ size C.dag C.out≤2*(mainCost n (D n))^3 := by
  obtain ⟨f,a,G,t,o,perm,sc,cp,live,st,fit,sem,bound⟩:=BovaAudit.strict_on_original n hn
  let C : Task f a := ⟨forget G,o,t,perm.nodup_iff.mpr (List.nodup_range' ..),readRespects sc cp live st o t fit⟩
  refine ⟨f,a,C,perm,?_,fun X=>(forgetValue sc).trans (sem X),Nat.le_trans (forgetSize G o).2 bound⟩
  intro i hr z b e
  have mem:=perm.mem_iff.mp (readsOnTree C i hr z b e)
  simp [List.mem_range'_1] at mem;omega

/-- Match both finite estimates on the minimum for actual paper-input circuits. -/
theorem sharp_paper_minimum (n : Nat) (hn : 32≤n.log2.log2) :
    ∃ s, PaperHWB n s ∧ (∀ w,PaperHWB n w→s≤w) ∧
      n.log2*n.log2≤274877906944*(s+2).log2 ∧ (s+2).log2≤8192*(n.log2*n.log2) := by
  have ll:=Nat.log2_le_self n;have l:=Nat.log2_le_self n.log2
  obtain ⟨f,a,C,_,reads,sem,cost⟩:=paper_upper_original n (by omega)
  have q : PaperHWB n (size C.dag C.out) := ⟨f,a,C,reads,sem,rfl⟩
  obtain ⟨s,good,least⟩:=Growth.minWitness (show ∃ w,PaperHWB n w from ⟨_,q⟩)
  have minW w (hw : PaperHWB n w) : s≤w := by
    by_cases h : s≤w
    · exact h
    · exact False.elim (least _ (by omega) hw)
  obtain ⟨lo,el,oldmin,lower,_⟩:=BovaAudit.sharp_minimum n hn
  have elig : BovaAudit.Eligible n s := by
    obtain ⟨_,_,P,_,corr,eq⟩:=good;exact eq ▸ eligible_of_paper P corr
  have ls:=oldmin s elig
  have lg : (lo+2).log2≤(s+2).log2 := (Nat.le_log2 (by omega)).2
    (Nat.le_trans ((Nat.le_log2 (show lo+2≠0 by omega)).1 (Nat.le_refl _)) (by omega))
  exact ⟨s,good,minW,Nat.le_trans lower (Nat.mul_le_mul_left _ lg),
    Optimum.physical_log_cap n s (by omega) (Nat.le_trans (minW _ q) cost)⟩
end HWB.Paper
