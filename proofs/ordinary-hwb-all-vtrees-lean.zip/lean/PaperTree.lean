import BovaAudit
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
abbrev Sub (s t : Tree) := inTree s t = true
theorem selfSub (t : Tree) : Sub t t := in_self t
theorem underL {s l : Tree} (h : Sub s l) (r : Tree) : Sub s (.fork l r) := by
  simp [Sub,inTree,h]
theorem underR {s r : Tree} (h : Sub s r) (l : Tree) : Sub s (.fork l r) := by
  simp [Sub,inTree,h]
theorem splitSub {s l r : Tree} (h : Sub s (.fork l r)) : s=.fork l r ∨ Sub s l ∨ Sub s r := by
  simp only [Sub,inTree,Bool.or_eq_true,decide_eq_true_eq] at *
  exact or_assoc.mp h
theorem transSub {s u t : Tree} (a : Sub s u) (b : Sub u t) : Sub s t := by
  induction t with
  | leaf j => have e : u=.leaf j := by simpa [Sub,inTree] using b
              exact e ▸ a
  | fork l r il ir =>
    rcases splitSub b with e|h|h
    · exact e ▸ a
    · exact underL (il h) r
    · exact underR (ir h) l
theorem labelsSub {s t : Tree} (h : Sub s t) : rawLabels s ⊆ rawLabels t := by
  induction t with
  | leaf j => have e : s=.leaf j := by simpa [Sub,inTree] using h
              rw [e]; exact fun _ a=>a
  | fork l r il ir =>
    rcases splitSub h with rfl|h|h
    · exact fun _ a=>a
    · exact fun _ a=>List.mem_append_left _ (il h a)
    · exact fun _ a=>List.mem_append_right _ (ir h a)
theorem depthSub {s t : Tree} (h : Sub s t) : depth s ≤ depth t := by
  induction t with
  | leaf j => have e : s=.leaf j := by simpa [Sub,inTree] using h
              rw [e];exact Nat.le_refl _
  | fork l r il ir =>
    rcases splitSub h with rfl|h|h
    · exact Nat.le_refl _
    · have := il h; simp only [depth];omega
    · have := ir h; simp only [depth];omega
theorem eqOfDepth {s t : Tree} (h : Sub s t) (le : depth t ≤ depth s) : s=t := by
  cases t with
  | leaf j => simpa [Sub,inTree] using h
  | fork l r =>
    rcases splitSub h with e|h|h
    · exact e
    · have := depthSub h;simp only [depth] at le;omega
    · have := depthSub h;simp only [depth] at le;omega
theorem apartLabels {l r : Tree} (nd : (rawLabels (.fork l r)).Nodup) (a : x∈rawLabels l) (b : x∈rawLabels r) : False :=
  (List.nodup_append.mp nd).2.2 _ a _ b rfl
theorem chain {s u t : Tree} (nd : (rawLabels t).Nodup) (a : Sub s t) (b : Sub u t)
    (xs : x ∈ rawLabels s) (xu : x ∈ rawLabels u) : Sub s u ∨ Sub u s := by
  induction t with
  | leaf j =>
    have e : s=.leaf j := by simpa [Sub,inTree] using a
    exact .inr (e ▸ b)
  | fork l r il ir =>
    have n:=List.nodup_append.mp nd
    rcases splitSub a with rfl|al|ar
    · exact .inr b
    · rcases splitSub b with rfl|bl|br
      · exact .inl a
      · exact il n.1 al bl
      · exact False.elim (apartLabels nd (labelsSub al xs) (labelsSub br xu))
    · rcases splitSub b with rfl|bl|br
      · exact .inl a
      · exact False.elim (apartLabels nd (labelsSub bl xu) (labelsSub ar xs))
      · exact ir n.2.1 ar br

/-- Two ordered cuts of a distinctly labelled tree cannot reverse a pair of leaves. -/
theorem noCross {l r u v t : Tree} (nd : (rawLabels t).Nodup)
    (a : Sub (.fork l r) t) (b : Sub (.fork u v) t)
    (xl : x∈rawLabels l) (yr : y∈rawLabels r) (yu : y∈rawLabels u) (xv : x∈rawLabels v) : False := by
  induction t with
  | leaf j => simp [Sub,inTree] at a
  | fork p q ip iq =>
    have n:=List.nodup_append.mp nd
    rcases splitSub a with e|al|ar
    · cases e
      rcases splitSub b with e|bl|br
      · cases e; exact apartLabels nd xl xv
      · exact apartLabels nd (labelsSub bl (List.mem_append_left _ yu)) yr
      · exact apartLabels nd xl (labelsSub br (List.mem_append_right _ xv))
    · rcases splitSub b with e|bl|br
      · cases e;exact apartLabels nd (labelsSub al (List.mem_append_left _ xl)) xv
      · exact ip n.1 al bl
      · exact apartLabels nd (labelsSub al (List.mem_append_left _ xl)) (labelsSub br (List.mem_append_right _ xv))
    · rcases splitSub b with e|bl|br
      · cases e;exact apartLabels nd yu (labelsSub ar (List.mem_append_right _ yr))
      · exact apartLabels nd (labelsSub bl (List.mem_append_right _ xv)) (labelsSub ar (List.mem_append_left _ xl))
      · exact iq n.2.1 ar br
end HWB.Paper
