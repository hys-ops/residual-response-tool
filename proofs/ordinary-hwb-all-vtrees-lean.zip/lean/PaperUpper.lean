import PaperWires
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
def leafName : Tree→Nat
  | .leaf z => z
  | .fork _ _ => 0

/-- Forget scope annotations and logical port roles. The rooted output is the
induced ancestor circuit of this table of physical gate names. -/
def forget (G : Graph f a) : DAG f a where
  pins := G.inputs
  label i := match (G.fn i).op with
    | .const b => .truth b
    | .lit b => .literal (leafName (G.fn i).scope) b
    | .disj L => .any L

theorem usesForget (G : Graph f a) : uses (forget G) i=fanin G i := by
  cases op : (G.fn i).op <;> simp [uses,fanin,forget,op]

theorem forgetValue {G : Graph f a} (sc : WellScoped G) : Value (forget G) X i ↔ Holds G X i := by
  constructor
  · intro h;induction h with
    | @truth i e =>
      cases op : (G.fn i).op <;> simp_all [forget]
      exact .constTrue (by assumption)
    | @lit i z b e v =>
      cases op : (G.fn i).op <;> simp_all [forget]
      obtain ⟨z',hz⟩:=show ∃ z',(G.fn i).scope=.leaf z' by simpa [op] using sc i
      exact .lit op hz (by simp_all [leafName])
    | @any i L e j _ _ ip isub =>
      cases op : (G.fn i).op <;> simp_all [forget]
      exact .disj (by assumption) j ip isub
  · intro h;induction h with
    | constTrue e => exact .truth (by simp [forget,e])
    | lit e t v => exact .lit (by simp [forget,e,t,leafName]) v
    | disj e j _ _ ip isub => exact .any (by simp [forget,e]) j ip isub

theorem sourceLaws {G : Graph f a} (sc : WellScoped G) (cp : NativeCompressed G) (live : LivePrimes G)
    (e : (G.fn i).op=.disj L) : Laws (forget G) L (fun _=>false) := by
  classical
  obtain ⟨part,neq⟩:=cp i L e
  refine ⟨?_,?_,?_,?_⟩
  · intro j;obtain ⟨X,v⟩:=live i L e j;exact ⟨X,(forgetValue sc).2 v⟩
  · intro j k diff X p q;obtain ⟨u,_,unique⟩:=part X
    exact diff ((unique j ((forgetValue sc).1 p)).trans (unique k ((forgetValue sc).1 q)).symm)
  · intro X;obtain ⟨j,h,_⟩:=part X;exact ⟨j,(forgetValue sc).2 h⟩
  · intro j k diff;apply Classical.byContradiction;intro h
    apply diff;apply neq
    intro X
    have eq : Value (forget G) X (G.inputs (L.get j)).2 ↔ Value (forget G) X (G.inputs (L.get k)).2 :=
      Classical.byContradiction fun n=>h ⟨X,n⟩
    exact (forgetValue sc).symm.trans (eq.trans (forgetValue sc))

theorem readRespects {G : Graph f a} (sc : WellScoped G) (cp : NativeCompressed G) (live : LivePrimes G)
    (strict : BovaAudit.Strict G) (i : Fin f) (t : Tree) (fit : Fits G i t) : Respects (forget G) i t := by
  cases op : (G.fn i).op with
  | const b => exact ⟨t,selfSub _,.truth (b:=b) (by simp [forget,op])⟩
  | lit b =>
    obtain ⟨z,hz⟩:=show ∃ z,(G.fn i).scope=.leaf z by simpa [op] using sc i
    rcases fit with ⟨_,e⟩|st
    · simp [op] at e
    · exact ⟨.leaf z,hz ▸ st,.lit (b:=b) (by simp [forget,op,hz,leafName])⟩
  | disj L =>
    obtain ⟨l,r,eq,kids⟩:=show ∃ l r, (G.fn i).scope=.fork l r ∧ ∀ j : Fin L.length,
      Fits G (G.inputs (L.get j)).1 l ∧ Fits G (G.inputs (L.get j)).2 r by simpa [op] using sc i
    have st : Sub (.fork l r) t := by
      rcases fit with ⟨_,e⟩|h
      · simp [op] at e
      · exact eq ▸ h
    have d:=depthSub st;simp only [depth] at d
    have dl : depth l < depth t := by omega
    have dr : depth r < depth t := by omega
    have p j:=readRespects sc cp live strict _ l (kids j).1
    have s j:=readRespects sc cp live strict _ r (kids j).2
    classical
    refine ⟨.fork l r,st,.any (by simp [forget,op]) (strict i L op) (fun _=>false)
      (lc:=fun j=>(p j).choose) (rc:=fun j=>(s j).choose)
      (fun j=>(p j).choose_spec.1) (fun j=>(s j).choose_spec.1)
      (fun j=>(p j).choose_spec.2) (fun j=>(s j).choose_spec.2) (sourceLaws sc cp live op)⟩
termination_by depth t
decreasing_by all_goals assumption

/-- Count precisely the original native incidences whose destinations feed the
output, including the input arcs of ANDs shared by multiple live decisions. -/
noncomputable def liveOrWires (G : Graph f a) (o : Fin f) : List (Fin a × Fin f) := by
  classical exact (andOrWires G).filter (fun w=>decide (Ancestor (forget G) o w.2))
noncomputable def liveInputWires (G : Graph f a) (o : Fin f) : List (Fin f × Fin a) := by
  classical exact (inputWires G).filter (fun w=>decide (Used (forget G) o w.2))

theorem forgetSize (G : Graph f a) (o : Fin f) :
    size (forget G) o=(liveOrWires G o).length+(liveInputWires G o).length ∧ size (forget G) o≤wireCount G := by
  classical
  have oo (x : Fin a × Fin f) : x∈orArcs (forget G) o ↔ x∈liveOrWires G o := by
    rcases x with ⟨g,i⟩
    simp [orArc_iff,liveOrWires,nativeOrArc,usesForget,and_comm]
  have aa (x : Fin f × Fin a) : x∈andArcs (forget G) o ↔ x∈liveInputWires G o := by
    rcases x with ⟨i,g⟩
    rw [andArc_iff];simp only [liveInputWires,List.mem_filter,nativeAndArc,decide_eq_true_eq];exact and_comm
  have nd₁ : (orArcs (forget G) o).Nodup := dedupND _
  have nd₂ : (andArcs (forget G) o).Nodup := dedupND _
  have nd₃ : (liveOrWires G o).Nodup := (show (andOrWires G).Nodup from dedupND _).filter _
  have nd₄ : (liveInputWires G o).Nodup := (show (inputWires G).Nodup from dedupND _).filter _
  have h : size (forget G) o=(liveOrWires G o).length+(liveInputWires G o).length := by
    unfold size
    rw [((List.perm_ext_iff_of_nodup nd₁ nd₃).2 oo).length_eq,
        ((List.perm_ext_iff_of_nodup nd₂ nd₄).2 aa).length_eq]
  refine ⟨h,?_⟩;rw [h]
  exact Nat.add_le_add (List.length_filter_le ..) (List.length_filter_le ..)
end HWB.Paper
