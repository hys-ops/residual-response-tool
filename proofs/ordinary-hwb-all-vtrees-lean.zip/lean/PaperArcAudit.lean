import BovaPaperBridge
namespace HWB.Paper
open ActualPath Physical GlobalWires Upper
theorem retained_arcs (G : Graph f a) (o : Fin f) :
    (∀ g i, Arc (forget G) o (.inr g) (.inl i) ↔
      (g,i)∈andOrWires G ∧ Ancestor (forget G) o i) ∧
    (∀ i g, Arc (forget G) o (.inl i) (.inr g) ↔
      (i,g)∈inputWires G ∧ Used (forget G) o g) := by
  constructor
  · intro g i
    change (g,i)∈orArcs _ _ ↔ _
    rw [orArc_iff,usesForget,nativeOrArc];exact and_comm
  · intro i g
    change (i,g)∈andArcs _ _ ↔ _
    rw [andArc_iff,nativeAndArc];exact and_comm

theorem exact_if_all_wires_live (G : Graph f a) (o : Fin f)
    (funLive : ∀ x∈andOrWires G,Ancestor (forget G) o x.2)
    (andLive : ∀ x∈inputWires G,Used (forget G) o x.2) :
    size (forget G) o=wireCount G := by
  classical
  have a : liveOrWires G o=andOrWires G :=
    List.filter_eq_self.mpr (fun x h=>decide_eq_true (funLive x h))
  have b : liveInputWires G o=inputWires G :=
    List.filter_eq_self.mpr (fun x h=>decide_eq_true (andLive x h))
  rw [(forgetSize G o).1,a,b];rfl

/-- Two constants and one unused binary conjunction in the allocation table.
The selected constant has a one-vertex cone and no wires. -/
def spare : Graph 2 1 := ⟨fun _=>⟨.leaf 1,.const true⟩,fun _=>(0,1)⟩

theorem unused_wire_example : WellScoped spare ∧ NativeCompressed spare ∧ LivePrimes spare ∧
    BovaAudit.Strict spare ∧ Fits spare 0 (.leaf 1) ∧ wireCount spare=2 ∧ size (forget spare) 0=0 := by
  have none (g : Fin 1) : ¬Used (forget spare) 0 g := by
    rintro ⟨i,_,mem⟩;simp [uses,forget,spare] at mem
  have a : orArcs (forget spare) 0=[] := by
    apply List.eq_nil_iff_forall_not_mem.mpr
    rintro ⟨g,i⟩ h;have v:=(orArc_iff _).1 h
    simpa [uses,forget,spare] using v.2
  have b : andArcs (forget spare) 0=[] := by
    apply List.eq_nil_iff_forall_not_mem.mpr
    rintro ⟨i,g⟩ h;exact none g ((andArc_iff _).1 h).1
  exact ⟨fun _=>True.intro,fun _ _ h=>by contradiction,fun _ _ h=>by contradiction,
    fun _ _ h=>by contradiction,Or.inl ⟨true,rfl⟩,by decide,by simp [size,a,b]⟩
end HWB.Paper
