# From Bova’s compressed SDDs to the HWB wire bounds

This archive formalizes the translation between the compressed SDDs in §2 of Simone Bova’s *SDDs Are Exponentially More Succinct than OBDDs* (AAAI 2016) and the finite, annotated circuits used by `HWB.BovaAudit`. A shared conjunction may occur below several OR gates. Giving it separate copies could invalidate a wire lower bound. The forward translation assigns it one name for all of those uses and preserves the exact number of wires. The reverse translation preserves the endpoints and number of all wires in the circuit leading to the designated output.

The ten new Lean modules are in `lean/`. The original sixty modules in `vendor/` are byte-for-byte copies of the earlier audit. The new results use the old bounds as theorems. [Published paper, §2, pp. 930–931 and §4, p. 934](https://cdn.aaai.org/ojs/10107/10107-13-13635-1-2-20201228.pdf).

## Which paper objects are represented?

| Published definition | Representation in namespace `HWB.Paper` | What a reviewer can check |
|---|---|---|
| §2, p. 930. Finite DAG, one output sink, subcircuit induced by paths to its output. NNF input gates may be constants or signed literals. | `Symbol`, `DAG`, `Value`, `Ancestor`, `Used`, `Live`, `Arc`, `Path`. | An OR lists physical AND gate names. Each AND stores two function-gate names. A literal has an explicit variable name and sign. `rootedPaths`, `Task.acyclicRank`, and `Task.uniqueSink` prove the path, acyclicity, and unique-sink properties for the represented circuit. |
| §2, pp. 930–931. Ordered full binary vtree, distinct leaf variables, possibly more leaves than input variables actually read. | The shared datatype `Tree`, the subtree relation `Sub`, and `Task.distinct`. The formal input predicate `ReadsOnly` is separate from the list of tree labels. | `Respects D o T` permits an output below the root. A literal can respect any subtree containing its leaf. A constant can respect any vtree. The lower translation takes the supplied tree unchanged with no bound on padding or choice of shape. |
| §2, p. 931, Eq. (2), (S1)–(S2). An OR has at least two AND children. Each prime and sub respects a subtree on the appropriate side of one split. | `AtNode.any` includes `2 ≤ L.length`, one split for the OR occurrence and a local assignment of roles to the two stored ports of each term. `Respects` existentially locates the split. | A shared OR may initially have a different witness at each use. Port order alone does not confer a prime/sub role. `chooseScope` and `occursOrientation` discharge the two global compatibility obligations of the annotated model. |
| (S3)–(S5). On the variables of the left child the primes form a partition into nonempty classes. (C). The subs are pairwise inequivalent on the variables of the right child. | `Laws` gives the pointwise encoding. `LocalLaws` tests precisely assignments to the child subtree. `localLaws_iff` proves equivalence under the two child-scope conditions. | Distinct sub functions are witnessed by an actual assignment distinguishing them. Adding unused leaves and extending an assignment outside a child's variables preserve the tests. |
| §2, p. 930. Size counts the arcs of the DAG. | `orArcs` counts AND-to-OR pairs and `andArcs` counts input-to-AND pairs in the output cone. `size` adds their lengths. | `Task.distinctTerms` rules out the same AND twice in one OR. `Task.distinctPins` rules out coincident inputs at a used AND. A shared AND has two incoming arcs once, and one outgoing arc to each distinct parent. |

A source input `Task` has just the two gate tables, an output name, a tree, distinct leaf labels and an inductive proof that the output respects that tree. The paper syntax and its truth relation are defined independently of `Graph`, `Holds`, `WellScoped` and `NativeCompressed`. The common variable assignments and ordered tree type let us state preservation on exactly the same assignment and tree.

## Forward translation and sharing

In `Task.lower_translation`, the universally quantified source is any such task. Its compiled circuit is well scoped, compressed, has live primes, satisfies the strict OR arity, and fits at the same tree. For every gate upstream of the output and every assignment, its native value is equivalent to its paper value. The size identity is

```lean
wireCount C.compile = size C.dag C.out
```

Two observations make this possible.

1. A prime mentions a variable. Indeed, it accepts some assignment, and a different prime in the same row accepts another. If the first prime mentioned no variable, agreement on all its mentioned variables would transfer acceptance to the second assignment, violating disjointness. Every OR therefore mentions a variable. All feasible placements of any fixed nonconstant gate contain a common leaf. Such subtrees form a chain. Choosing the smallest feasible subtree gives a single placement inside every required context. Constants fit everywhere.
2. Suppose the ports of one AND could exchange prime/sub roles at different uses. Each possible prime would mention a leaf, say $x$ and $y$. One feasible split would put $x$ on the left and $y$ on the right. Another would reverse the same leaves. The order and distinct labels of a single vtree preclude this. So one choice of the prime port works at every use.

The compiler uses classical choice for a feasible placement. It is a mathematical construction. Function gates keep their IDs. Each used AND gets one packed ID, with every parent reference and both ports preserved up to the proven orientation. `Task.sharing` states uniqueness of this ID and a biconditional for all parents. Unused function-table slots become constants and carry no arcs.

## Reverse translation and the two wire counts

`upper_translation G o T` takes a native graph, an output and a distinct-labelled tree together with `WellScoped G`, `NativeCompressed G`, `LivePrimes G`, `BovaAudit.Strict G`, and `Fits G o T`. Erasing the annotations gives a derivation of `Respects (forget G) o T`. Gate values agree on every assignment. The underlying rows and pin names are reused. At every reachable OR the given strictness supplies the two-term minimum. The paper graph has an increasing rank along wires and the designated unique sink.

For any native graph, the exact identity at output $o$ is

```lean
size (forget G) o = (liveOrWires G o).length + (liveInputWires G o).length
```

`retained_arcs` identifies each retained wire by its original two endpoints. Thus the right-hand side is at most `wireCount G`. When every allocated wire reaches the output, `exact_if_all_wires_live` proves equality with `wireCount G` itself. For a minimal example of the distinction, allocate two true constants and an unreferenced AND fed by them. Select the first constant as the output. The allocation contains two wires. The selected circuit is a single vertex with zero wires. `unused_wire_example` verifies both counts and all the strict native admissibility hypotheses. Applying the previous upper bound requires just the inequality and incurs no loss.

## Consequence for the original HWB

For variables $x_1,\ldots,x_n$, HWB returns $x_k$ for Hamming weight $k>0$, and returns false at weight zero. `PaperHWB n w` asks for a paper circuit of size $w$ whose reachable literals read only names 1 through $n$, with this output on every assignment. Its vtree may contain extra leaves. `eligible_of_paper` transfers such a witness to the native lower-bound theorem at exactly the same cost. `paper_upper_original` transports the native construction to a paper circuit and also proves that its tree labels are a permutation of 1 through $n$.

Starting with the existing estimates, `bova_question_paper` rules out every polynomial wire upper bound for this class. `sharp_paper_minimum` exhibits an attained minimum $s$ over the paper circuits. For $32 \le \lfloor\log_2(\lfloor\log_2 n\rfloor)\rfloor$ its exact integer estimates are

```lean
n.log2 * n.log2 ≤ 274877906944 * (s+2).log2
(s+2).log2 ≤ 8192 * (n.log2 * n.log2)
```

In ordinary asymptotic notation the minimum is $n^{\Theta(\log n)}$. This is the previous growth rate, now stated on the paper-side class itself.

## Reproduce the check

Use Python 3.10 or later and the official Lean 4.34.1 toolchain (commit `5045d0056413266e57c625dcd7c365b10e377c52`). No mathlib or precompiled project modules are required. From the extracted directory, on a machine with the pinned toolchain installed under elan, run

```sh
sha256sum -c SHA256SUMS
python3 replay.py --lean "$(elan which lean)" --fresh-kernel --log-dir replay-logs
```

With a standalone Lean installation, supply the physical path to its `bin/lean` with its sibling `bin/leanchecker`. The driver checks the release commit, creates an empty temporary directory, builds all seventy modules from source, then runs `Audit.lean` and `leanchecker -v --fresh PaperArcAudit`. The latter replays the imported and defined constants in a fresh Lean kernel. The build log retains four style or deprecation warnings in the unchanged Rows and Realize modules. The toolchain and Lean kernel are the trusted implementation. This check does not involve a second proof assistant.

| Record bundled in this archive | Use |
|---|---|
| `logs/build.log` and `logs/module-order.txt` | Exact release, clean compilation transcript and full import order. |
| `Audit.lean` and `logs/statements-and-axioms.log` | Six printed definitions and the Lean-printed theorem types and transitive axiom reports for 23 declarations. |
| `logs/kernel.log` | Fresh kernel command, replay and exit status. |
| `VENDOR.tsv` and `SHA256SUMS` | Map of the 60 original source paths and hashes and integrity of this distribution. The predecessor is `HWB_Bova_Question_Audit_Lean.zip`, SHA-256 `74c9f1d6ee70527fbed0b91b0e5b71159fdf523cdb1105100ac4dbd23e342dc0`. |

## What remains a reading of the paper?

A reviewer can compare §2 directly with the five rows of the first table. The remaining interpretation is the choice of the formal vocabulary for the printed definition: finite names enumerated by two disjoint index sets, variable names represented by naturals, an arbitrary stored ordering of an OR’s incoming arcs, and the paper’s stated literal-input convention. Lean checks the mathematical consequences of that encoding, including compatibility of local witnesses and preservation of every reachable wire. It cannot certify that a natural-language publication was interpreted as its author intended. The formalization and accompanying comparison were AI-prepared. No independent human review is recorded in this archive.
