import PaperArcAudit

#print HWB.Paper.DAG
#print HWB.Paper.AtNode
#print HWB.Paper.LocalLaws
#print HWB.Paper.Task
#print HWB.Paper.ReadsOnly
#print HWB.Paper.PaperHWB

#check @HWB.Paper.chooseScope
#print axioms HWB.Paper.chooseScope

#check @HWB.Paper.orientationUnique
#print axioms HWB.Paper.orientationUnique

#check @HWB.Paper.occursOrientation
#print axioms HWB.Paper.occursOrientation

#check @HWB.Paper.localLaws_iff
#print axioms HWB.Paper.localLaws_iff

#check @HWB.Paper.rootedPaths
#print axioms HWB.Paper.rootedPaths

#check @HWB.Paper.Task.acyclicRank
#print axioms HWB.Paper.Task.acyclicRank

#check @HWB.Paper.Task.uniqueSink
#print axioms HWB.Paper.Task.uniqueSink

#check @HWB.Paper.Task.distinctTerms
#print axioms HWB.Paper.Task.distinctTerms

#check @HWB.Paper.Task.distinctPins
#print axioms HWB.Paper.Task.distinctPins

#check @HWB.Paper.Task.sharing
#print axioms HWB.Paper.Task.sharing

#check @HWB.Paper.Task.lower_translation
#print axioms HWB.Paper.Task.lower_translation

#check @HWB.Paper.Task.compile_size
#print axioms HWB.Paper.Task.compile_size

#check @HWB.Paper.forgetValue
#print axioms HWB.Paper.forgetValue

#check @HWB.Paper.readRespects
#print axioms HWB.Paper.readRespects

#check @HWB.Paper.retained_arcs
#print axioms HWB.Paper.retained_arcs

#check @HWB.Paper.forgetSize
#print axioms HWB.Paper.forgetSize

#check @HWB.Paper.upper_translation
#print axioms HWB.Paper.upper_translation

#check @HWB.Paper.exact_if_all_wires_live
#print axioms HWB.Paper.exact_if_all_wires_live

#check @HWB.Paper.unused_wire_example
#print axioms HWB.Paper.unused_wire_example

#check @HWB.Paper.eligible_of_paper
#print axioms HWB.Paper.eligible_of_paper

#check @HWB.Paper.bova_question_paper
#print axioms HWB.Paper.bova_question_paper

#check @HWB.Paper.paper_upper_original
#print axioms HWB.Paper.paper_upper_original

#check @HWB.Paper.sharp_paper_minimum
#print axioms HWB.Paper.sharp_paper_minimum
