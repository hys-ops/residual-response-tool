"""Rebuild the independent Bova circuit grammar, bridges and their pinned dependency closure."""
import argparse
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
TARGET = "PaperArcAudit"
SOURCES = {p.stem: p for folder in ("lean", "vendor") for p in (ROOT / folder).glob("*.lean")}

def order(target):
    result = []
    seen = set()
    def visit(name):
        if name in seen:
            return
        seen.add(name)
        for line in SOURCES[name].read_text().splitlines():
            if line.startswith("import "):
                for dep in line.split()[1:]:
                    if dep not in {"Std", "Init", "Lean"}:
                        visit(dep)
        result.append(name)
    visit(target)
    return result

def command(args, cwd, env):
    p = subprocess.run(args, cwd=cwd, env=env, text=True, encoding="utf-8",
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    if p.returncode:
        sys.stderr.write(p.stdout)
        p.check_returncode()
    return p.stdout

def rebuild(lean_name, logs, fresh):
    binary = shutil.which(lean_name)
    if not binary:
        raise RuntimeError("Lean executable not found")
    lean = Path(binary).resolve()
    logs.mkdir(exist_ok=True, parents=True)
    for name in order(TARGET):
        if re.search(r"\b(?:sorry|admit|sorryAx|native_decide|axiom)\b", SOURCES[name].read_text()):
            raise ValueError("Unexpected proof placeholder, axiom or native proof in " + name)
    with tempfile.TemporaryDirectory(prefix="bova-paper-bridge-") as temp:
        work = Path(temp)
        env = dict(os.environ, LEAN_PATH=temp, PATH=str(lean.parent) + os.pathsep + os.environ["PATH"])
        version = command([lean, "--version"], work, env)
        if "5045d0056413266e57c625dcd7c365b10e377c52" not in version:
            raise RuntimeError("Toolchain mismatch: " + version)
        modules = order(TARGET)
        with (logs / "build.log").open("w") as out:
            out.write(version)
            for name in modules:
                filename = name + ".lean"
                shutil.copyfile(SOURCES[name], work / filename)
                out.write(f"$ lean -j 1 -o {name}.olean {filename}\n")
                trace = command([lean, "-j", "1", "-o", name + ".olean", filename], work, env)
                if re.search(r"\bsorryAx\b", trace):
                    raise ValueError("Proof placeholder in audit: " + name)
                out.write(trace)
                out.flush()
            out.write(f"PASS: {len(modules)} source modules.\n")
        audit = work / "Audit.lean"
        audit.write_text((ROOT / "Audit.lean").read_text())
        trace = command([lean, "-j", "1", "Audit.lean"], work, env)
        (logs / "statements-and-axioms.log").write_text(trace)
        ax = re.findall(r"depends on axioms: \[(.*?)\]", trace)
        allowed = {"propext", "Classical.choice", "Quot.sound"}
        expected = [line.split()[-1] for line in audit.read_text().splitlines() if line.startswith("#print axioms ")]
        for name in expected:
            if not (f"'{name}' depends on axioms:" in trace or f"'{name}' does not depend on any axioms" in trace):
                raise RuntimeError("Missing axiom report for " + name)
        if any(not set(t.split(", ")).issubset(allowed) for t in ax):
            raise RuntimeError("Unexpected proof dependencies. Read statements-and-axioms.log.")
        (logs / "module-order.txt").write_text("\n".join(modules) + "\n")
        if fresh:
            trace = command([lean.with_name("leanchecker"), "-v", "--fresh", TARGET], work, env)
            (logs / "kernel.log").write_text("leanchecker -v --fresh PaperArcAudit\n" + trace + "exit 0\n")
    print(f"Clean build passed with {len(modules)} modules.")

if __name__ == "__main__":
    opts = argparse.ArgumentParser(description=__doc__)
    opts.add_argument("--lean", default="lean")
    opts.add_argument("--fresh-kernel", action="store_true")
    opts.add_argument("--log-dir", type=Path, default=Path("replay-logs"))
    args = opts.parse_args()
    rebuild(args.lean, args.log_dir.resolve(), args.fresh_kernel)
