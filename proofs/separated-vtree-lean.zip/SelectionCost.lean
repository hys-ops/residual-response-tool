import Std
namespace SelectionCost

/- Partitions indexed by their actual response functions. -/
theorem class_iff_response {A B C I : Type} (f : A → B → C)
    (choose : A → I) (response : I → B → C)
    (sound : ∀ a, f a = response (choose a))
    (unique : ∀ i j, response i = response j → i = j) (a : A) (i : I) :
    choose a = i ↔ f a = response i := by
  constructor
  · intro h
    rw [← h, sound a]
  · intro h
    exact unique _ _ ((sound a).symm.trans h)

def rowL {B : Type} (mark : Bool) (left target : Nat)
    (right : B → Nat) (y : B) : Bool := mark && decide (left + right y = target)

def exactRow {B : Type} (right : B → Nat) (k : Nat) (y : B) : Bool :=
  decide (right y = k)

theorem marked_left_fibre {B : Type} (mark : Bool) (left t k : Nat)
    (right : B → Nat) (witness : B) (hw : right witness = k) :
    (rowL mark left (t+k) right = exactRow right k) ↔
        mark = true ∧ left = t := by
  constructor
  · intro eq
    have hv := congrFun eq witness
    cases mark <;> simp [rowL, exactRow, hw] at hv ⊢
    exact hv
  · rintro ⟨rfl, rfl⟩
    funext y
    simp [rowL, exactRow]

theorem marked_right_row {B : Type} (mark : B → Bool)
    (right : B → Nat) (a t : Nat) :
    (fun y => mark y && decide (a + right y = a+t)) =
    (fun y => mark y && decide (right y = t)) := by
  funext y
  simp

-- A fixed feasible total t and two capacities p,q have these inclusive counts.
theorem split_count (p q t : Nat) (h : t ≤ p+q) :
    min p t + 1 - (t-q) = 1 + min (min p q) (min t (p+q-t)) := by omega

-- Finite estimates used at a split after setting the marked bit to 1.
theorem per_gate_left (p q t k : Nat) (hp : 0 < p) (hq : 0 < q)
    (hk : 0 < k) (ht : k ≤ t) (ht' : t+k ≤ p+q) :
    min (min p q) k ≤
      1 + min (min (p-1) q) (min (t-1) (p+q-t)) := by omega

theorem per_gate_right (p q t k : Nat) (hp : 0 < p) (hq : 0 < q)
    (hk : 0 < k) (ht : k ≤ t) (ht' : t+k ≤ p+q) :
    min (min p q) k ≤
      1 + min (min p (q-1)) (min (t-1) (p+q-t)) := by omega

-- Range of positive counts kept at a medium-sized subtree.
theorem many_targets (n m i k : Nat) (hk : 0 < k)
    (hi : 4*k ≤ i) (hi' : i+4*k ≤ n)
    (hm : 4*k ≤ m) (hm' : m+4*k ≤ n) :
    2*k ≤ min (min m i) (m-k) + 1 - max (i-(n-m)) k := by omega

#print axioms class_iff_response
#print axioms marked_left_fibre
#print axioms marked_right_row
#print axioms split_count
#print axioms per_gate_left
#print axioms per_gate_right
#print axioms many_targets
end SelectionCost
