# Lean checks for separated-vtree

Local forced-class, marked-weight and counting lemmas. The global shared-DAG and summation arguments are written proofs.

Use the pinned Lean 4.34.1 toolchain. From the extracted directory, run:

```sh
sha256sum -c SHA256SUMS
lean SelectionCost.lean
```
