# Lean checks for raw-controls

The scalar prefix, freezing, recurrence and selected compiler identities. The raw-coordinate realization and complete extremal theorem are written proofs.

Use the pinned Lean 4.34.1 toolchain. From the extracted directory, run:

```sh
sha256sum -c SHA256SUMS
lake update
lake exe cache get
lake env lean PrefixWords.lean
```
