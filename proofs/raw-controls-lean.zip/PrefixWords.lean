import Mathlib.Data.Fintype.BigOperators
import Mathlib.Tactic

namespace PrefixWords
variable {A : Type} [Fintype A] [DecidableEq A]

/-- Final prefix, followed by one common live entry. -/
def words : List A → Finset (List A)
  | [] => {[]}
  | a :: tail =>
    ((words tail).image (fun w => a :: w)) ∪
    ((Finset.univ.erase a).image (fun b => b :: List.replicate tail.length b))

theorem diag (l : List A) (x : A) : List.replicate l.length x ∈ words l := by
  induction l with
  | nil => simp [words]
  | cons a l ih =>
    simp only [List.length_cons, List.replicate_succ, words, Finset.mem_union, Finset.mem_image]
    by_cases h : x = a
    · subst a
      exact Or.inl ⟨_, ih, rfl⟩
    · exact Or.inr ⟨x, by simp [h], rfl⟩

theorem pref (a : A) (l w : List A) (hw : w ∈ words l) : a :: w ∈ words (a :: l) := by
  apply Finset.mem_union_left
  exact Finset.mem_image.mpr ⟨w,hw,rfl⟩

theorem exact_card (l : List A) :
    (words l).card = 1 + l.length*(Fintype.card A-1) := by
  induction l with
  | nil => simp [words]
  | cons a l ih =>
    unfold words
    have hd : Disjoint ((words l).image (fun w => a :: w))
          ((Finset.univ.erase a).image (fun b => b :: List.replicate l.length b)) := by
      rw [Finset.disjoint_left]
      intro z h1 h2
      obtain ⟨w,_,rfl⟩ := Finset.mem_image.mp h1
      obtain ⟨b,hb,e⟩ := Finset.mem_image.mp h2
      have : b = a := (List.cons.inj e).1
      exact (Finset.mem_erase.mp hb).1 this
    rw [Finset.card_union_of_disjoint hd]
    rw [Finset.card_image_of_injective _ (fun _ _ e => (List.cons.inj e).2)]
    rw [Finset.card_image_of_injective _ (fun _ _ e => (List.cons.inj e).1)]
    rw [Finset.card_erase_of_mem (Finset.mem_univ a), Finset.card_univ, ih]
    simp [Nat.add_mul, Nat.add_assoc]

omit [Fintype A] [DecidableEq A] in
private theorem all_live (l : List (Nat × A)) (u : Nat) (x : A)
    (hh : ∀ a ∈ l, u < a.1) :
    l.map (fun a => if a.1 ≤ u then a.2 else x) = List.replicate l.length x := by
  induction l with
  | nil => rfl
  | cons a l ih =>
    have ha := hh a (by simp)
    have hl : ∀ b ∈ l, u < b.1 := fun b hb => hh b (by simp [hb])
    simp [Nat.not_le_of_lt ha, ih hl, List.replicate_succ]

/-- Key 0 for an already constant branch, D+1 for a branch freezing at cap D.
    The order of the branch assignments is independent of u. -/
theorem gate_below_endpoint (l : List (Nat × A))
    (ordered : l.Pairwise (fun a b => a.1 ≤ b.1)) (u : Nat) (x : A) :
    l.map (fun a => if a.1 ≤ u then a.2 else x) ∈ words (l.map Prod.snd) := by
  induction l with
  | nil => simp [words]
  | cons a l ih =>
    obtain ⟨ho,ht⟩ := List.pairwise_cons.mp ordered
    by_cases h : a.1 ≤ u
    · simp only [List.map_cons, ite_eq_left h]
      exact pref _ _ _ (ih ht)
    · have al : ∀ b ∈ a::l, u < b.1 := by
        intro b hb
        rcases List.mem_cons.mp hb with rfl | hb
        · omega
        · have := ho b hb
          omega
      rw [all_live _ _ _ al]
      simpa using diag ((a::l).map Prod.snd) x

theorem with_endpoint (l : List A) (e : List A) :
    (insert e (words l)).card ≤ 2 + l.length*(Fintype.card A-1) := by
  have h := Finset.card_insert_le e (words l)
  rw [exact_card] at h
  omega

theorem saturation_has_diagonals (U : Finset (List A)) (l : List A) (e : List A)
    (sub : U ⊆ insert e (words l))
    (sat : U.card = 2+l.length*(Fintype.card A-1)) (x : A) :
    List.replicate l.length x ∈ U := by
  have same : U = insert e (words l) := Finset.eq_of_subset_of_card_le sub (by
    rw [sat]; exact with_endpoint l e)
  rw [same]
  exact Finset.mem_insert_of_mem (diag l x)


theorem augmented_bound (U : Finset (List A)) (l : List A) (e : List A)
    (sub : U ⊆ insert e (words l)) (oldZero oldOne : A) :
    (insert (List.replicate l.length oldZero) (insert (List.replicate l.length oldOne) U)).card
        ≤ 2+l.length*(Fintype.card A-1) := by
  apply le_trans (Finset.card_le_card (t := insert e (words l)) ?_) (with_endpoint l e)
  intro v hv
  simp only [Finset.mem_insert] at hv
  rcases hv with rfl | rfl | hh
  · exact Finset.mem_insert_of_mem (diag l oldZero)
  · exact Finset.mem_insert_of_mem (diag l oldOne)
  · exact sub hh

-- This stage-count lemma is independent of the type of the response alphabet.
theorem stage_budget (q g K : Nat) (gpos : 0 < g) (Kpos : 0 < K)
    (old : K ≤ 2^(q+1)) : 2 + 2^g*(K-1) ≤ 2^(q+g+1) := by
  have two : 2 ≤ 2^g := by
    calc 2 = 2^(1:Nat) := by decide
         _ ≤ 2^g := Nat.pow_le_pow_right (by decide) gpos
  have exp : 2^(q+g+1) = 2^g * 2^(q+1) := by
    rw [show q+g+1 = g+(q+1) by omega, pow_add]
  rw [exp]
  calc 2 + 2^g*(K-1) ≤ 2^g + 2^g*(K-1) := by omega
       _ = 2^g*K := by
         nth_rw 1 [show 2^g = 2^g*1 by simp]
         rw [← Nat.mul_add]
         congr 1
         omega
       _ ≤ 2^g*2^(q+1) := Nat.mul_le_mul_left _ old

theorem anchored_count {β : Type} [DecidableEq β] (U : Finset β)
    (P : β → Prop) [DecidablePred P] (z : β) (hz : z ∈ U) (hn : ¬P z) :
    (U.filter P).card < U.card := by
  apply Finset.card_lt_card
  refine Finset.ssubset_iff_subset_ne.mpr ⟨Finset.filter_subset _ _, ?_⟩
  intro eq
  have mem : z ∈ U.filter P := eq.symm ▸ hz
  exact hn (Finset.mem_filter.mp mem).2

/-- Pull a whole table through a full-cap reflection with chosen endpoint. -/
def extWord {α : Type} (w : List α) (s : α) := w.reverse ++ [s]

theorem two_pads {α : Type} (w : List α) (a b : α) :
    extWord (extWord w a) b = a :: (w ++ [b]) := by
  simp [extWord]

def atReversed {β : Type} (T : Nat → β → Bool) (D u : Nat)
    (b : Bool) (v : β) := T (if b then u else min D u) v

theorem choice_without_bit {β : Type} (T : Nat → β → Bool) (D u : Nat)
    (hu : u ≤ D) (b : Bool) (v : β) :
    atReversed T D u b v = T u v := by
  cases b <;> simp [atReversed, Nat.min_eq_right hu]

theorem choice_with_bit {β : Type} (T : Nat → β → Bool) (D u : Nat)
    (hu : D < u) (sink : ∀ v, T D v = false) (b : Bool) (v : β) :
    atReversed T D u b v = (b && T u v) := by
  cases b <;> simp [atReversed, Nat.min_eq_left (Nat.le_of_lt hu), sink]

#print axioms two_pads
#print axioms choice_with_bit
#print axioms choice_without_bit

/-- Given the scalar budget at each cap stage, keep the global bound for any length.
    A zero-control stage only restricts the old augmented alphabet. -/
inductive Budget : Nat → Nat → Prop
  | root : Budget 0 2
  | fixed {q K J} : Budget q K → J ≤ K → Budget q J
  | controlled {q K g J} : Budget q K → 0 < K → 0 < g →
      J ≤ 2 + 2^g*(K-1) → Budget (q+g) J

theorem budget_all_depths {q K : Nat} (h : Budget q K) :
    K ≤ 2^(q+1) := by
  induction h with
  | root => decide
  | fixed _ hj ih => exact hj.trans ih
  | controlled _ hk hg hj ih => exact hj.trans (stage_budget _ _ _ hg hk ih)

theorem six_cannot_supply_128 {K N : Nat} (run : Budget 6 K) (miss : N < K) :
    N < 128 := by
  have h := budget_all_depths run
  norm_num at h
  omega

#print axioms budget_all_depths
#print axioms six_cannot_supply_128

#print axioms augmented_bound
#print axioms stage_budget
#print axioms anchored_count

#print axioms exact_card
#print axioms gate_below_endpoint
#print axioms saturation_has_diagonals
end PrefixWords
