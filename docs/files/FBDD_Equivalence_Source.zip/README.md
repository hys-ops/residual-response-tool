# A deterministic subexponential-time equivalence test for free binary decision diagrams

This source package accompanies the public research manuscript by hys-ops, dated 24 November 2026. hys-ops directed the research, starting from the question of what the rest of a computation can learn about a block of unfixed input. ChatGPT and Codex contributed to developing the mathematical arguments, drafting the manuscript, and writing the Lean formalization.

## Typeset the paper

Run the following commands in this directory with a standard TeX Live installation. The diagram and references are included in the source.

    pdflatex -halt-on-error FBDD_Equivalence.tex
    pdflatex -halt-on-error FBDD_Equivalence.tex

## Check the formal development

The FBDD_Paper1 directory contains the companion Lean 4.19.0 project. See FBDD_Paper1/README.md for the verification commands and declaration-level index. FBDD_Paper1/verification.txt records the supplied verification run. Appendix C of the manuscript identifies the hypotheses and costs covered by each part. In particular the complete bit-time accounting and the assembly of the expander and routing constructions are written proofs.

Section 2 of this manuscript and the companion Lean implementation both use a bottom-up recurrence. The manuscript specifies its own prime choice and interleaved bit-time algorithm.
