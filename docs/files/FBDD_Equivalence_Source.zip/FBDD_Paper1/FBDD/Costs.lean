import FBDD.Automatic

namespace FBDD
variable {V F : Type} [DecidableEq V] [Fintype V] [Field F] [Fintype F] [DecidableEq F]

theorem listed_length {m} (p : Net V m) (K : Nat) (b : BlockSpec V) :
    ((listed p K b : Chunk V F).choices.length) = 2*((K+1)*(K+2))+2 := by
  classical
  unfold listed localChunk localList
  simp only [List.length_map]
  apply (greedy_spec ..).1

theorem product_length_exact {m} (p : Net V m) (K : Nat) (heavy : List V) (bs : List (BlockSpec V)) :
    (grids (schedule p K heavy bs) (fun _ => (0:F))).length =
      2^heavy.length * (2*((K+1)*(K+2))+2)^bs.length := by
  rw [grid_length]
  have lower : ∀ bs : List (BlockSpec V), productSize (bs.map (listed (F := F) p K)) =
      (2*((K+1)*(K+2))+2)^bs.length := by
    intro bs; induction bs with
    | nil => rfl
    | cons b bs ih => simp [productSize,listed_length,ih,pow_succ,Nat.mul_comm]
  induction heavy with
  | nil => simpa [schedule] using lower bs
  | cons v vs ih =>
    change 2 * productSize (schedule (F := F) p K vs bs) = _
    rw [ih,List.length_cons,pow_succ]; ring

/-- A discrete cube-root regime. For a capacity k with N ≤ k³ and n ≤ N,
there are at most 2k²+1 light blocks and heavy bits combined. -/
theorem field_point_budget {m} (p : Net V m) (k : Nat) (hn : Fintype.card V ≤ m)
    (hc : m ≤ k^3) (hk : 0 < k) :
    (autoGrid (F := F) p k).length ≤ (2*((2*k+1)*(2*k+2))+2)^(2*k^2+1) := by
  let H := (heavy p k (names V)).length
  let B := (bins p k (names V)).length
  have pos : 0 < B := by simp [B,bins]
  have amt := (packing_budget p k hk).1
  change (H + (B-1))*k ≤ m + Fintype.card V at amt
  have j : H + (B-1) ≤ 2*k^2 := by
    apply Nat.le_of_mul_le_mul_left (c := k)
    · nlinarith [amt,hc,hn]
    · exact hk
  let R := 2*((2*k+1)*(2*k+2))+2
  have R2 : 2 ≤ R := by dsimp [R]; omega
  unfold autoGrid
  rw [product_length_exact,List.length_map]
  change 2^H * R^B ≤ _
  calc
    _ ≤ R^H * R^B := Nat.mul_le_mul_right _ (Nat.pow_le_pow_left R2 H)
    _ = R^(H+B) := (pow_add ..).symm
    _ ≤ _ := Nat.pow_le_pow_right (by omega) (by omega)

end FBDD
