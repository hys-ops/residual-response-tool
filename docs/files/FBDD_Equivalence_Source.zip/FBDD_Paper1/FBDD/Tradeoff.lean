import FBDD.Marks
namespace FBDD.Barrier
open Real
/-- The three mutually sufficient outcomes in the restricted-model argument.
These are conclusions that the graph/layout construction must supply. -/
inductive LayoutEvidence (r C T : Nat) : Prop where
  | span (u : Nat) : r^3 ≤ C*u → 2^u ≤ T → LayoutEvidence r C T
  | catalogue (u p : Nat) : r^2 ≤ C*u → 1+r ≤ p → p^u ≤ T → LayoutEvidence r C T
  | small (ts : List Nat) : (∀ t ∈ ts, t ≤ r) → r^3 ≤ C*ts.sum → localProduct ts ≤ T → LayoutEvidence r C T

theorem three_cases {r C T : Nat} (rp : 0 < r) (cp : 0 < C) (e : LayoutEvidence r C T) :
    (r:ℝ)^2 * log (1+r) ≤ C * log T := by
  have R : (0:ℝ) < r := by exact_mod_cast rp
  have P : (0:ℝ) < C := by exact_mod_cast cp
  cases e with
  | small _ sm supply charge => exact log_factor _ _ _ rp cp _ sm supply charge
  | catalogue u p supply base charge =>
    have h₁ : (r:ℝ)^2 ≤ C*u := by exact_mod_cast supply
    have h₂ := log_le_log (show 0 < 1+(r:ℝ) by positivity) (show 1+(r:ℝ) ≤ p by exact_mod_cast base)
    have ppos : (0:ℝ) < p := by exact_mod_cast (show 0 < p by omega)
    have h₃ := log_le_log (pow_pos ppos u) (show (p:ℝ)^u ≤ T by exact_mod_cast charge)
    rw [log_pow] at h₃
    have non : 0 ≤ log (1+(r:ℝ)) := log_nonneg (le_add_of_nonneg_right R.le)
    have un : (0:ℝ) ≤ u := Nat.cast_nonneg u
    nlinarith [mul_le_mul_of_nonneg_right h₁ non,
      mul_le_mul_of_nonneg_left h₂ (mul_nonneg P.le un),mul_le_mul_of_nonneg_left h₃ P.le]
  | span u supply charge =>
    have h₁ : (r:ℝ)^3 ≤ C*u := by exact_mod_cast supply
    have b (n : Nat) : 1+n ≤ 2^n := by
      induction n with
      | zero => decide
      | succ n ih => rw [pow_succ]; omega
    have h₂ := log_le_log (show 0 < (1+(r:ℝ)) by positivity) (show 1+(r:ℝ) ≤ (2:ℝ)^r by exact_mod_cast b r)
    have h₃ := log_le_log (show 0 < (2:ℝ)^u by positivity) (show (2:ℝ)^u ≤ T by exact_mod_cast charge)
    rw [log_pow] at h₂ h₃
    have lz : 0 ≤ log (2:ℝ) := log_nonneg (by norm_num)
    nlinarith [mul_le_mul_of_nonneg_right h₁ lz,mul_le_mul_of_nonneg_left h₂ (sq_nonneg (r:ℝ)),
      mul_le_mul_of_nonneg_left h₃ P.le]
end FBDD.Barrier
