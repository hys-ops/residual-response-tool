import FBDD.Dense
import Mathlib.Algebra.Field.ZMod
namespace FBDD
def tab {V F : Type} [CommRing F] (x : V → F) : {m : Nat} → Net V m → Vector F m
  | _, .empty => #v[]
  | _, .leaf p b => (tab x p).push (bit b)
  | _, .gate p i l h =>
    let a := tab x p
    let lo := a[l.rev.val]
    a.push (lo + x i * (a[h.rev.val] - lo))

theorem tab_correct {V F : Type} [CommRing F] {m} (p : Net V m) (x : V → F) (r : Fin m) :
    (tab x p)[r.rev.val] = p.val x r := by
  induction p with
  | empty => exact Fin.elim0 r
  | leaf p b ih =>
    refine Fin.cases ?_ (fun j => ?_) r
    · simp [tab,Net.val,bit]
    · simpa only [tab,Net.val,Fin.cases_succ,Fin.rev_succ,Fin.coe_castSucc,Vector.getElem_push_lt j.rev.isLt] using ih j
  | gate p i l h ih =>
    refine Fin.cases ?_ (fun j => ?_) r
    · simp only [tab,Fin.rev_zero,Fin.val_last,Vector.getElem_push_eq,Net.val,Fin.cases_zero,ih]
    · simpa only [tab,Net.val,Fin.cases_succ,Fin.rev_succ,Fin.coe_castSucc,Vector.getElem_push_lt j.rev.isLt] using ih j

def allTuples {A : Type} (values : List A) : (d : Nat) → List (Fin d → A)
  | 0 => [Fin.elim0]
  | d+1 => values.flatMap (fun v => (allTuples values d).map (fun tail => Fin.cases v tail))

theorem tuples_complete {A} (values : List A) (full : ∀ a, a ∈ values) (d) (x : Fin d → A) :
    x ∈ allTuples values d := by
  induction d with
  | zero =>
    have e : x = Fin.elim0 := funext (fun i => Fin.elim0 i)
    simp [allTuples,e]
  | succ d ih =>
    apply List.mem_flatMap.mpr
    refine ⟨x 0,full _,List.mem_map.mpr ⟨fun j => x j.succ,ih _,?_⟩⟩
    funext i; exact Fin.cases rfl (fun _ => rfl) i

theorem tuples_length {A} (values : List A) (d) :
    (allTuples values d).length = values.length^d := by
  induction d with
  | zero => simp [allTuples]
  | succ d ih => simp [allTuples,List.length_flatMap,ih,List.sum_replicate,pow_succ,Nat.mul_comm]

def residues (p : Nat) := (List.finRange p).map (fun i => (i.val : ZMod p))

theorem residues_full (p : Nat) [NeZero p] (x : ZMod p) : x ∈ residues p :=
  List.mem_map.mpr ⟨⟨x.val,x.val_lt⟩,by simp,ZMod.natCast_zmod_val x⟩

variable {V F : Type} [DecidableEq V] [Field F] [Fintype F] [DecidableEq F]
def enumChunk {m} (p : Net V m) (K : Nat) (values : List F) (b : BlockSpec V) : Chunk V F :=
  localChunk b.idx (localList (Finset.univ : Finset (Description (Fin b.width) F (blockCount b.idx p)))
    (allTuples values b.width) (2*((K+1)*(K+2))+2))

def enumGrid {m} (p : Net V m) (k : Nat) (ns : List V) (values : List F) : List (V → F) :=
  grids ((heavy p k ns).map booleanChunk ++
       ((bins p k ns).map specOf).map (enumChunk p (2*k) values)) (fun _ => 0)

theorem enumGrid_correct [Fintype V] {m} (p : Net V m) (r s : Fin m) (fr : p.free)
    (k : Nat) (hk : 0 < k) (hp : (2*k)*(2*k) < Fintype.card F)
    (ns : List V) (hn : ∀ i, i ∈ ns) (nd : ns.Nodup) (values : List F) (full : ∀ i, i ∈ values) :
    (∀ b, p.boolVal b r = p.boolVal b s) ↔ ∀ x ∈ enumGrid p k ns values, delta p r s x = 0 := by
  have pack := ordered_packing p k hk ns hn nd
  apply equivalence_iff_grid p fr r s ns hn
  · intro c hc
    rcases List.mem_append.mp hc with hh|hb
    · obtain ⟨i,_,rfl⟩ := List.mem_map.mp hh
      exact boolean_good _ _ (delta_affine _ fr _ _ i)
    · obtain ⟨b,hm,rfl⟩ := List.mem_map.mp hb
      obtain ⟨ls,hl,rfl⟩ := List.mem_map.mp hm
      have bds := pack.2.2 ls hl
      apply local_good p r s _ (specOf ls).name (specOf ls).inverse bds.1
        (bds.2.trans (by nlinarith)) hp (by nlinarith) _ (tuples_complete values full _) _ (by simp)
  · intro i
    rcases pack.2.1 i with hh|⟨ls,hm,hi⟩
    · exact ⟨booleanChunk i, List.mem_append_left _ (List.mem_map.mpr ⟨i,hh,rfl⟩),by simp [booleanChunk]⟩
    · exact ⟨_,List.mem_append_right _ (List.mem_map.mpr ⟨specOf ls,List.mem_map.mpr ⟨ls,hm,rfl⟩,rfl⟩),
          (spec_mem ls i).mpr hi⟩

def testPair {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (p k : Nat) [Fact p.Prime] : Bool :=
  let j := join a b
  let points := enumGrid j.net k (List.finRange v) (residues p)
  points.all (fun x =>
    let vs := tab x j.net
    decide (vs[(j.left r).rev.val] = vs[(j.right s).rev.val]))

theorem testPair_spec {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (ha : a.free) (hb : b.free) (p k : Nat) [Fact p.Prime] (hk : 0 < k) (hp : (2*k)*(2*k) < p) :
    testPair a b r s p k = true ↔ ∀ z, a.boolVal z r = b.boolVal z s := by
  have h := enumGrid_correct (join a b).net ((join a b).left r) ((join a b).right s)
    (join_free a b ha hb) k hk (by simpa using hp : (2*k)*(2*k) < Fintype.card (ZMod p))
    (List.finRange v) (by simp) (List.nodup_finRange v) (residues p) (residues_full p)
  simpa only [testPair,List.all_eq_true,decide_eq_true_eq,tab_correct,delta,sub_eq_zero,
      (join_bool a b _).1,(join_bool a b _).2] using h.symm
end FBDD
