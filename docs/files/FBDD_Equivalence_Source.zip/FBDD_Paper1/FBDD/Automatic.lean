import FBDD.Packing
namespace FBDD
open Finset
variable {V F : Type} [DecidableEq V] [Fintype V] [Field F] [Fintype F] [DecidableEq F]
  {m : Nat}

noncomputable def names (V : Type) [Fintype V] : List V := Finset.univ.toList

def bins {V} [DecidableEq V] {m} (p : Net V m) (k : Nat) (ns : List V) : List (List V) :=
  let w := fun i => max 1 (count i p)
  let packed := pack w k (light p k ns)
  packed.1 :: packed.2

theorem ordered_packing (p : Net V m) (k) (hk : 0 < k) (ns : List V)
    (all : ∀ i, i ∈ ns) (nd : ns.Nodup) :
    let hs := heavy p k ns
    let bs := bins p k ns
    (hs.length + (bs.length-1))*k ≤ m + Fintype.card V ∧
    (∀ i, i ∈ hs ∨ ∃ b ∈ bs, i ∈ b) ∧
    ∀ b ∈ bs, blockCount (specOf b).idx p ≤ 2*k ∧ b.length ≤ 2*k := by
  classical
  let w := fun i => max 1 (count i p)
  let ls := light p k ns
  let q := pack w k ls
  have hsmall (v) (hv : v ∈ ls) : w v ≤ k := by simpa [ls,light,w] using (List.mem_filter.mp hv).2
  have inv := pack_spec w k hk ls hsmall
  obtain ⟨flat,small,full⟩ := inv
  change q.1 ++ q.2.flatten = ls at flat
  change mass w q.1 < k at small
  change ∀ b ∈ q.2, k ≤ mass w b ∧ mass w b ≤ 2*k at full
  have hm : mass w ns ≤ m + Fintype.card V := by
    change (ns.map w).sum ≤ _
    rw [← List.sum_toFinset _ nd, Finset.eq_univ_of_forall (s := ns.toFinset) (fun i => List.mem_toFinset.mpr (all i))]
    calc
      _ ≤ ∑ v, (count v p + 1) := sum_le_sum (fun v _ => show max 1 (count v p) ≤ count v p + 1 by omega)
      _ = _ := by rw [sum_add_distrib]; simp
      _ ≤ _ := Nat.add_le_add_right (count_total p) _
  have hl := mass_flatten_lb w k q.2 (fun b hb => (full b hb).1)
  have htot := heavy_mass w k ns
  change (heavy p k ns).length*k + mass w ls ≤ mass w ns at htot
  have hls : mass w q.1 + mass w q.2.flatten = mass w ls := by rw [← mass_append,flat]
  constructor
  · change ((heavy p k ns).length + ((q.1::q.2).length-1))*k ≤ _
    simp only [List.length_cons,Nat.add_sub_cancel,Nat.add_mul]; omega
  constructor
  · intro i
    by_cases h : k < w i
    · left; apply List.mem_filter.mpr; exact ⟨all i,by simpa [w] using h⟩
    · right
      have hi : i ∈ ls := List.mem_filter.mpr ⟨all i,by simpa [w] using (not_lt.mp h)⟩
      rw [← flat,List.mem_append] at hi
      rcases hi with hd|ht
      · exact ⟨q.1,List.mem_cons_self,hd⟩
      · obtain ⟨b,hb,hbi⟩ := List.mem_flatten.mp ht
        exact ⟨b,List.mem_cons_of_mem _ hb,hbi⟩
  · intro b hb
    have hb' : mass w b ≤ 2*k := by
      rcases List.mem_cons.mp hb with rfl|rest
      · change mass w q.1 ≤ _; omega
      · exact (full b rest).2
    exact ⟨(blockCount_eq p b).le.trans ((sum_to_mass _ w (fun i => le_max_right ..) b).trans hb'),
           (mass_dom w b (fun i _ => le_max_left ..)).trans hb'⟩

theorem packing_budget (p : Net V m) (k) (hk : 0 < k) :
    let ns := names V
    let hs := heavy p k ns
    let bs := bins p k ns
    (hs.length + (bs.length-1))*k ≤ m + Fintype.card V ∧
    (∀ i, i ∈ hs ∨ ∃ b ∈ bs, i ∈ b) ∧
    ∀ b ∈ bs, blockCount (specOf b).idx p ≤ 2*k ∧ b.length ≤ 2*k := by
  exact ordered_packing p k hk (names V) (by simp [names]) (Finset.nodup_toList _)

noncomputable def autoGrid (p : Net V m) (k : Nat) : List (V → F) :=
  grids (schedule p (2*k) (heavy p k (names V)) ((bins p k (names V)).map specOf)) (fun _ => 0)

theorem automatic_equivalence {m n} (a : Net V m) (b : Net V n)
    (r : Fin m) (s : Fin n) (ha : a.free) (hb : b.free) (k : Nat)
    (hk : 0 < k) (hp : (2*k)*(2*k) < Fintype.card F) :
    (∀ x, a.boolVal x r = b.boolVal x s) ↔ ∀ x ∈ autoGrid (F := F) (join a b).net k,
      delta (join a b).net ((join a b).left r) ((join a b).right s) x = 0 := by
  have h := packing_budget (join a b).net k hk
  apply pair_test a b r s ha hb (names V) _ _ (2*k) (by simp [names]) _ _ hp (by nlinarith)
  · intro i
    rcases h.2.1 i with hh|⟨ls,hm,hi⟩
    · exact Or.inl hh
    · exact Or.inr ⟨specOf ls,List.mem_map.mpr ⟨ls,hm,rfl⟩,(spec_mem ls i).mpr hi⟩
  · intro sp hm
    obtain ⟨ls,hl,rfl⟩ := List.mem_map.mp hm
    have w := h.2.2 ls hl
    exact ⟨w.1, w.2.trans (by nlinarith)⟩

end FBDD
