import FBDD.Budgets
namespace FBDD.Barrier
open Real

theorem chord {r t : ℝ} (hr : 0 < r) (ht : 0 ≤ t) (le : t ≤ r) :
    t * log (1+r) ≤ r * log (1+t) := by
  have w : t/r ≤ 1 := (div_le_one hr).mpr le
  have c := strictConcaveOn_log_Ioi.concaveOn.2
    (show (1:ℝ) ∈ Set.Ioi 0 by norm_num)
    (show 1+r ∈ Set.Ioi (0:ℝ) by exact show 0 < 1+r by linarith)
    (show 0 ≤ 1-t/r by linarith) (div_nonneg ht hr.le) (by ring)
  simp only [smul_eq_mul,log_one,mul_zero,zero_add,mul_one] at c
  have e : 1-t/r + t/r*(1+r) = 1+t := by field_simp; ring
  rw [e] at c
  have z := mul_le_mul_of_nonneg_left c hr.le
  convert z using 1 <;> field_simp

def localProduct : List Nat → Nat
  | [] => 1
  | m::ms => (1+m)*localProduct ms

theorem small_blocks (r : Nat) (hr : 0 < r) (ts : List Nat) (bound : ∀ t ∈ ts, t ≤ r) :
    (ts.sum : ℝ)*log (1+r) ≤ r*log (localProduct ts) := by
  induction ts with
  | nil => simp [localProduct]
  | cons t ts ih =>
    have h := chord (r := (r:ℝ)) (t := (t:ℝ)) (by exact_mod_cast hr) (by positivity)
      (by exact_mod_cast bound t (by simp))
    have z := ih (fun y hy => bound y (by simp [hy]))
    have p (xs : List Nat) : 0 < localProduct xs := by
      induction xs with
      | nil => decide
      | cons a l ih => exact Nat.mul_pos (by omega) ih
    simp only [List.sum_cons,Nat.cast_add,localProduct,Nat.cast_mul,Nat.cast_one]
    rw [log_mul (by positivity) (by exact_mod_cast (p ts).ne')]
    nlinarith [h,z]

/-- In the small-catalogue-block case r^3 marks up to constant C force an
r^2 log(1+r) lower bound. Both the mark supply and the list requirement are explicit premises. -/
theorem log_factor (r C T : Nat) (hr : 0 < r) (Cpos : 0 < C)
    (ts : List Nat) (small : ∀ t ∈ ts, t ≤ r) (supply : r^3 ≤ C*ts.sum)
    (charged : localProduct ts ≤ T) :
    (r:ℝ)^2 * log (1+r) ≤ C * log T := by
  have h := small_blocks r hr ts small
  have pos (xs : List Nat) : 0 < localProduct xs := by
    induction xs with
    | nil => decide
    | cons a xs ih => exact Nat.mul_pos (by omega) ih
  have l := Real.log_le_log (show 0 < (localProduct ts:ℝ) by exact_mod_cast pos ts)
    (show (localProduct ts:ℝ) ≤ (T:ℝ) by exact_mod_cast charged)
  have raw : (r:ℝ)^3 ≤ C*(ts.sum:ℝ) := by exact_mod_cast supply
  have non : 0 ≤ log (1+(r:ℝ)) := Real.log_nonneg (by exact le_add_of_nonneg_right (Nat.cast_nonneg r))
  have rp : (0:ℝ) < r := by exact_mod_cast hr
  have cp : (0:ℝ) < C := by exact_mod_cast Cpos
  apply le_of_mul_le_mul_left (a := (r:ℝ)) _ rp
  nlinarith [mul_le_mul_of_nonneg_right raw non,mul_le_mul_of_nonneg_left h cp.le,
    mul_le_mul_of_nonneg_left l (mul_nonneg cp.le rp.le)]
end FBDD.Barrier
