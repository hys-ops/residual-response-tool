import FBDD.Budgets
namespace FBDD
/-- Explicit base-two bound, keeping k and the separate node budget N visible. -/
theorem exponent_budget (N k p : Nat) (hn : 0 < N) (hk : 0 < k) (le : k ≤ N) (hp : p ≤ 8*N^2) :
    let K := 2*k
    let R := listBudget K
    let L := Nat.clog 2 (N+2)
    p^((K+1)*(K+2)+K)*(R+1) + R^(2*k^2+1) ≤ 2^(200*k^2*(L+1)) := by
  let L := Nat.clog 2 (N+2)
  let b := 2^L
  have bn : N+2 ≤ b := Nat.le_pow_clog (by decide) _
  have bpos : 2 ≤ b := by omega
  have pbound : p ≤ b^5 := by
    have s := Nat.pow_le_pow_left (show N ≤ b by omega) 2
    have e := Nat.pow_le_pow_left bpos 3
    calc
      p ≤ 8*N^2 := hp
      _ ≤ b^3*b^2 := Nat.mul_le_mul e s
      _ = _ := by ring
  let R := listBudget (2*k)
  have Rbound : R+1 ≤ b^6 := by
    have high : R+1 ≤ 32*(N+2)^2 := by unfold R listBudget; nlinarith [Nat.pow_le_pow_left le 2]
    have zz : 32*(N+2)^2 ≤ b^6 := by
      have z : 2 ≤ N+2 := by omega
      have qb := Nat.pow_le_pow_left (show 3 ≤ b by omega) 4
      have nb := Nat.pow_le_pow_left bn 2
      calc
        _ ≤ b^4*b^2 := Nat.mul_le_mul (by omega) nb
        _ = _ := by ring
    exact high.trans zz
  have E : (2*k+1)*(2*k+2)+2*k ≤ 16*k^2 := by nlinarith [Nat.mul_self_le_mul_self hk, Nat.mul_le_mul_left k hk]
  have top : p^((2*k+1)*(2*k+2)+2*k)*(R+1) ≤ b^(90*k^2) := by
    calc
      _ ≤ (b^5)^(16*k^2) * b^6 := Nat.mul_le_mul
        ((Nat.pow_le_pow_left pbound _).trans (Nat.pow_le_pow_right (by positivity) E)) Rbound
      _ = b^(5*(16*k^2)+6) := by rw [pow_add,pow_mul b 5 (16*k^2)]
      _ ≤ _ := Nat.pow_le_pow_right (by omega) (by nlinarith [Nat.mul_self_le_mul_self hk])
  have bot : R^(2*k^2+1) ≤ b^(90*k^2) := by
    calc
      _ ≤ (b^6)^(2*k^2+1) := Nat.pow_le_pow_left (by omega) _
      _ = b^(6*(2*k^2+1)) := (pow_mul ..).symm
      _ ≤ _ := Nat.pow_le_pow_right (by omega) (by nlinarith [Nat.mul_self_le_mul_self hk])
  change _ + R^(2*k^2+1) ≤ 2^(200*k^2*(L+1))
  calc
    _ ≤ b^(90*k^2)+b^(90*k^2) := Nat.add_le_add top bot
    _ = 2^(L*(90*k^2)+1) := by unfold b; rw [pow_succ 2 (L*(90*k^2)), pow_mul 2 L (90*k^2)]; omega
    _ ≤ _ := Nat.pow_le_pow_right (by decide) (by nlinarith [Nat.mul_self_le_mul_self hk])

theorem root_scale (N k : Nat) (hn : 0 < N) (hk : 0 < k) (minimal : (k-1)^3 < N) : k^3 ≤ 8*N := by
  by_cases h : k = 1
  · subst k; simpa using (show 1 ≤ 8*N by omega)
  have zero : k-1+1=k := by omega
  have z : k ≤ 2*(k-1) := by omega
  calc
    _ ≤ (2*(k-1))^3 := Nat.pow_le_pow_left z 3
    _ = 8*(k-1)^3 := by ring
    _ ≤ _ := Nat.mul_le_mul_left _ minimal.le
end FBDD
