import FBDD.Universal
import Mathlib.NumberTheory.Bertrand
namespace FBDD
open Finset
theorem flatMap_budget {A B} (l : List A) (f : A → List B) (C : Nat)
    (h : ∀ a ∈ l, (f a).length ≤ C) : (l.flatMap f).length ≤ l.length*C := by
  induction l with
  | nil => simp
  | cons a l ih =>
    have ha := h a (by simp)
    have hl := ih (fun b hb => h b (by simp [hb]))
    simp only [List.flatMap_cons,List.length_append,List.length_cons,Nat.add_mul,one_mul]; omega

variable {V F : Type} [DecidableEq V] [Field F] [Fintype F] [DecidableEq F]
def listBudget (K : Nat) := 2*((K+1)*(K+2))+2

theorem coded_length (K t) (values : List F) (ns : List V) :
    (codedChunk K t values ns).choices.length = listBudget K := by
  unfold codedChunk localChunk localList
  simp only [List.length_map]
  apply (greedy_spec ..).1

theorem shape_length (K : Nat) (values : List F) (ns hv : List V) (cs : List (Nat×Nat)) :
    (shapeGrid K values ns hv cs).length = 2^hv.length * (listBudget K)^cs.length := by
  rw [shapeGrid,grid_length]
  have e (w : List V) (qs : List (Nat×Nat)) :
      productSize (decode K values qs w) = (listBudget K)^qs.length := by
    induction qs generalizing w with
    | nil => rfl
    | cons a q ih => rcases a with ⟨d,t⟩; simp [decode,productSize,coded_length,ih,pow_succ,Nat.mul_comm]
  generalize ns.filter _ = ls
  induction hv with
  | nil => simpa using e ls cs
  | cons i hv ih => simp [productSize,booleanChunk,ih,pow_succ,Nat.mul_comm,Nat.mul_left_comm]

theorem words_size_of_mem {A} {xs : List A} {w : List A} {d} (h : w ∈ words xs d) :
    w.length ≤ d := by
  induction d generalizing w with
  | zero => simp [words] at h; simp [h]
  | succ d ih =>
    rcases List.mem_cons.mp h with rfl|inl
    · simp
    · obtain ⟨a,_,ht⟩ := List.mem_flatMap.mp inl
      obtain ⟨t,hm,rfl⟩ := List.mem_map.mp ht
      exact Nat.succ_le_succ (ih hm)

theorem universal_size (k D) (vals : List F) (ns : List V) :
    (universalGrid k D vals ns).length ≤
      ((ns.length+1)*(1+(2*k+1)^2)*2*listBudget (2*k))^D := by
  let A := shapeAlphabet (2*k)
  let R := listBudget (2*k)
  have a : A.length = (2*k+1)^2 := by simp [A,shapeAlphabet,List.length_flatMap,List.sum_replicate,pow_two]
  have rpos : 0 < R := by simp [R,listBudget]
  have g (h : List V) (hh : h ∈ words ns D) (c : List (Nat×Nat)) (hc : c ∈ words A D) :
      (shapeGrid (2*k) vals ns h c).length ≤ 2^D*R^D := by
    rw [shape_length]
    exact Nat.mul_le_mul (Nat.pow_le_pow_right (by decide) (words_size_of_mem hh))
      (Nat.pow_le_pow_right rpos (words_size_of_mem hc))
  have g' (h : List V) (hh : h ∈ words ns D) :=
    flatMap_budget (words A D) (shapeGrid (2*k) vals ns h) _ (g h hh)
  have tot := flatMap_budget (words ns D) (fun h => (words A D).flatMap (shapeGrid (2*k) vals ns h))
    ((words A D).length*(2^D*R^D)) g'
  refine tot.trans ?_
  have aa := words_length A D
  rw [a, Nat.add_comm ((2*k+1)^2)] at aa
  calc
    _ ≤ (ns.length+1)^D * ((1+(2*k+1)^2)^D*(2^D*R^D)) :=
      Nat.mul_le_mul (words_length ns D) (Nat.mul_le_mul_right _ aa)
    _ = _ := by simp only [Nat.mul_pow,R]; ring

/-- Local live-row filtering and a scan of the finite evaluation table per greedy round.
The units here are table entries scanned, before charging arithmetic within an entry. -/
theorem local_table_budget {d t K} (ht : t ≤ K) (hd : d ≤ K) (hp : K ≤ Fintype.card F) :
    Fintype.card (Description (Fin d) F t) * (Fintype.card F)^d * (listBudget K+1)
    ≤ (Fintype.card F)^((K+1)*(K+2)+K) * (listBudget K+1) := by
  apply Nat.mul_le_mul_right
  rw [pow_add]
  exact Nat.mul_le_mul (description_card (by simpa using hd.trans hp) Fintype.card_pos ht)
    (Nat.pow_le_pow_right Fintype.card_pos hd)

theorem field_exists (N k : Nat) (hk : 0 < k) (hkN : k ≤ N) :
    ∃ p, Nat.Prime p ∧ (2*k)*(2*k) < p ∧ p ≤ 8*N^2 := by
  have hN : 0 < N := hk.trans_le hkN
  obtain ⟨p,pp,lo,hi⟩ := Nat.exists_prime_lt_and_le_two_mul ((2*N)*(2*N)) (by positivity)
  exact ⟨p,pp,lt_of_le_of_lt (Nat.mul_self_le_mul_self (by omega)) lo,by nlinarith⟩

theorem cube_exists (N : Nat) (h : 0 < N) :
    ∃ k, 0 < k ∧ N ≤ k^3 ∧ (k-1)^3 < N ∧ k ≤ N := by
  have hpow : N ≤ N^3 := by nlinarith [Nat.mul_self_le_mul_self h]
  have ex : ∃ k : Nat, N ≤ k^3 := ⟨N,hpow⟩
  let k := Nat.find ex
  have h₀ : N ≤ k^3 := Nat.find_spec ex
  have pos : 0 < k := by
    by_contra! z
    have e : k = 0 := by omega
    have hz : N ≤ 0 := by simpa [e] using h₀
    omega
  exact ⟨k,pos,h₀,lt_of_not_ge (Nat.find_min ex (show k-1 < k by omega)), Nat.find_min' ex hpow⟩
end FBDD
