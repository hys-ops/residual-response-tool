import FBDD.Barrier
import FBDD.Output
namespace FBDD.Marks
open Finset
variable {F : Type} [Field F]
def mux (u v w : F) := (1-u)*v+u*w
theorem mux_u (a u : F) : mux u (-a) (1-a) = u-a := by unfold mux; ring
theorem mux_v (c a v : F) (hc : 1-c=c) : mux c v (-a) = c*(v-a) := by unfold mux; rw [hc]; ring
theorem mux_w (c a w : F) (hc : 1-c=c) : mux c (-a) w = c*(w-a) := by unfold mux; rw [hc]; ring

def factors {t : Nat} (a x : Fin t → F) := ∏ i, (x i - a i)

/-- One independent marked factor kills one specified point. The same product is
nonzero at the vector obtained by incrementing every chosen root. -/
theorem miss_all {t} (H : List (Fin t → F)) (len : H.length ≤ t) :
    ∃ a : Fin t → F, (∀ x ∈ H, factors a x = 0) ∧ (∃ x, factors a x ≠ 0) := by
  classical
  let a (i : Fin t) := if h : i.val < H.length then (H.get ⟨i.val,h⟩) i else 0
  refine ⟨a,?_,?_⟩
  · intro x hx
    obtain ⟨j,eq⟩ := List.mem_iff_get.mp hx
    let i : Fin t := ⟨j,lt_of_lt_of_le j.isLt len⟩
    apply Finset.prod_eq_zero (mem_univ i)
    change x i - a i = 0
    have ha : a i = (H.get j) i := dif_pos j.isLt
    rw [ha,eq,sub_self]
  · exact ⟨fun i => a i + 1,by simp [factors]⟩

def spike {t} (b : Fin t → Bool) (x : Fin t → F) := ∏ i, if b i then x i else 1-x i

theorem spike_boolean {t} (a b : Fin t → Bool) :
    spike (F := F) a (fun i => bit (b i)) = if a=b then 1 else 0 := by
  classical
  by_cases h : a=b
  · subst a; rw [if_pos rfl]
    apply prod_eq_one
    intro j _
    cases h : b j <;> simp [h,bit]
  · rw [if_neg h]
    obtain ⟨j,ne⟩ : ∃ j, a j ≠ b j := by by_contra! z; exact h (funext z)
    apply prod_eq_zero (mem_univ j)
    cases ha : a j <;> cases hb : b j <;> simp_all [bit]

def combined {t} (c : (Fin t → Bool) → F) (x : Fin t → F) := ∑ b, c b * spike b x

theorem independent_values {t} (c : (Fin t → Bool) → F) (z : Fin t → Bool) :
    combined c (fun i => bit (z i)) = c z := by
  classical
  simp [combined,spike_boolean,mul_ite]

theorem span_probes [Fintype F] {t} (H : List (Fin t → F)) (separates :
    ∀ c : (Fin t → Bool) → F, (∀ x ∈ H, combined c x = 0) → c = 0) :
    2^t ≤ H.length := by
  classical
  let code (c : (Fin t → Bool) → F) (j : Fin H.length) := combined c (H.get j)
  have inj : Function.Injective code := by
    intro c d eq
    apply sub_eq_zero.mp
    apply separates
    intro x hx
    obtain ⟨j,hj⟩ := List.mem_iff_get.mp hx
    have z := congrFun eq j
    change combined c (H.get j) = combined d (H.get j) at z
    rw [hj] at z
    simpa [combined,sub_mul,sum_sub_distrib] using sub_eq_zero.mpr z
  have card := Fintype.card_le_of_injective code inj
  simp only [Fintype.card_fun,Fintype.card_fin,Fintype.card_bool] at card
  by_contra! hn
  exact (not_lt_of_ge card) (Nat.pow_lt_pow_right Fintype.one_lt_card hn)
end FBDD.Marks
