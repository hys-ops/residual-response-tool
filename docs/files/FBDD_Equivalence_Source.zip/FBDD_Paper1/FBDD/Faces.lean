import FBDD.Dense
namespace FBDD
/-- A face is specified by its fixed coordinates and their values. -/
def Extends {V} (fixed : Finset V) (v x : V → Bool) := ∀ i ∈ fixed, x i = v i
def completion {V} [DecidableEq V] (fixed : Finset V) (v : V → Bool) :
    {x : V → Bool // Extends fixed v x} ≃ ({i : V // i ∉ fixed} → Bool) where
  toFun x j := x.val j.val
  invFun y := ⟨fun j => if h : j ∈ fixed then v j else y ⟨j,h⟩,fun i hi => dif_pos hi⟩
  left_inv x := by
    apply Subtype.ext; funext j
    by_cases h : j ∈ fixed
    · simp [h]; exact (x.property j h).symm
    · simp [h]
  right_inv y := by funext j; simp [j.property]

theorem face_size {V} [Fintype V] [DecidableEq V] (fixed : Finset V) (v : V → Bool) :
    Nat.card {x : V → Bool // Extends fixed v x} = 2^(Fintype.card V-fixed.card) := by
  classical
  rw [Nat.card_congr (completion fixed v),Nat.card_eq_fintype_card,Fintype.card_fun,Fintype.card_bool]
  congr 1
  have eq : Fintype.card {i : V // i ∉ fixed} = fixedᶜ.card := by simpa using Fintype.card_coe fixedᶜ
  rw [eq,Finset.card_compl]
end FBDD
