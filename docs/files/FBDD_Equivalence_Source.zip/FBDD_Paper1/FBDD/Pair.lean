import FBDD.Test
namespace FBDD
variable {V : Type}
structure Join (V : Type) (m n : Nat) where
  net : Net V (m+n)
  left : Fin m → Fin (m+n)
  right : Fin n → Fin (m+n)

def join {m} (a : Net V m) : {n : Nat} → Net V n → Join V m n
  | _, .empty => ⟨a,id,Fin.elim0⟩
  | _, .leaf b v =>
    let j := join a b
    ⟨.leaf j.net v,fun u => (j.left u).succ,Fin.cases 0 (fun u => (j.right u).succ)⟩
  | _, .gate b i l h =>
    let j := join a b
    ⟨.gate j.net i (j.right l) (j.right h),fun u => (j.left u).succ,Fin.cases 0 (fun u => (j.right u).succ)⟩

theorem join_bool {m n} (a : Net V m) (b : Net V n) (x : V → Bool) :
    (∀ r, (join a b).net.boolVal x ((join a b).left r) = a.boolVal x r) ∧
    (∀ r, (join a b).net.boolVal x ((join a b).right r) = b.boolVal x r) := by
  induction b with
  | empty => exact ⟨fun _ => rfl, fun u => Fin.elim0 u⟩
  | leaf b v ih =>
    exact ⟨ih.1, fun r => Fin.cases rfl (fun u => ih.2 u) r⟩
  | gate b i l h ih =>
    refine ⟨ih.1, fun r => Fin.cases ?_ (fun u => ih.2 u) r⟩
    simp [join,Net.boolVal,ih.2]

theorem join_uses {m n} (a : Net V m) (b : Net V n) (i : V) (r : Fin n) :
    (join a b).net.uses i ((join a b).right r) ↔ b.uses i r := by
  induction b with
  | empty => exact Fin.elim0 r
  | leaf b v ih => exact Fin.cases Iff.rfl (fun u => ih u) r
  | gate b j l h ih =>
    refine Fin.cases ?_ (fun u => ih u) r
    simp [join,Net.uses,ih]

theorem join_free {m n} (a : Net V m) (b : Net V n) (ha : a.free) (hb : b.free) :
    (join a b).net.free := by
  induction b with
  | empty => exact ha
  | leaf b v ih => exact ih hb
  | gate b i l h ih =>
    exact ⟨ih hb.1, fun hu => hb.2.1 ((join_uses a b i l).mp hu),
                     fun hu => hb.2.2 ((join_uses a b i h).mp hu)⟩

theorem pair_test {F : Type} [Field F] [Fintype F] [DecidableEq F] [DecidableEq V]
    {m n} (a : Net V m) (b : Net V n) (r : Fin m) (s : Fin n) (ha : a.free) (hb : b.free)
    (is heavy : List V) (bs : List (BlockSpec V)) (K : Nat)
    (all : ∀ i, i ∈ is) (cover : ∀ i, i ∈ heavy ∨ ∃ b ∈ bs, (b.idx i).isSome = true)
    (size : ∀ c ∈ bs, blockCount c.idx (join a b).net ≤ K ∧ c.width ≤ Fintype.card F)
    (hk : K*K < Fintype.card F) (hp : 1 < Fintype.card F) :
    (∀ x, a.boolVal x r = b.boolVal x s) ↔
      ∀ x ∈ grids (schedule (join a b).net K heavy bs) (fun _ => (0:F)),
        delta (join a b).net ((join a b).left r) ((join a b).right s) x = 0 := by
  have eqn := test_correct (F := F) (join a b).net ((join a b).left r) ((join a b).right s)
      (join_free a b ha hb) is heavy bs K all cover size hk hp
  simpa only [(join_bool a b _).1, (join_bool a b _).2] using eqn
end FBDD
