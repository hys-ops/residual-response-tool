import FBDD.Global

namespace FBDD
variable {V F : Type} [Field F] [Fintype F] [DecidableEq F] [DecidableEq V] {m : Nat}

/-- A block's variables are assigned local names. Outside labels are unmarked. -/
def blockCount {d} (idx : V → Option (Fin d)) : {m : Nat} → Net V m → Nat
  | _, .empty => 0
  | _, .leaf p _ => blockCount idx p
  | _, .gate p i _ _ => match idx i with
    | none => blockCount idx p
    | some _ => blockCount idx p + 1

def tags {d} (idx : V → Option (Fin d)) (x : V → F) (i : V) : Fin d ⊕ F :=
  match idx i with
  | none => .inr (x i)
  | some j => .inl j

theorem occ_tags {d} (idx : V → Option (Fin d)) (x : V → F) (p : Net V m) :
    occ (tags idx x) p = blockCount idx p := by
  induction p with
  | empty => rfl
  | leaf p b ih => exact ih
  | gate p i l h ih => cases e : idx i <;> simp [tags,occ,blockCount,e,ih]

def localChunk {d} (idx : V → Option (Fin d)) (H : List (Grid d F)) : Chunk V F :=
  ⟨fun i => (idx i).isSome, H.map (fun z i => (idx i).elim 0 z)⟩

theorem local_good {d K} (p : Net V m) (r s : Fin m) (idx : V → Option (Fin d))
    (name : Fin d → V) (inv : ∀ i j, idx i = some j → name j = i)
    (bound : blockCount idx p ≤ K) (hd : d ≤ Fintype.card F)
    (hk : K*K < Fintype.card F) (hp : 1 < Fintype.card F)
    (cols : List (Grid d F)) (full : ∀ x, x ∈ cols)
    (rows : Finset (Description (Fin d) F (blockCount idx p))) (hr : ∀ a, a ∈ rows) :
    Adequate (delta p r s) (localChunk idx (localList rows cols (2*((K+1)*(K+2))+2))) := by
  intro x hx
  let H := localList rows cols (2*((K+1)*(K+2))+2)
  have hxrep := restriction_as_tri (tags idx x) p r s
  rw [occ_tags] at hxrep
  obtain ⟨t,a,rep⟩ := hxrep
  have mixed (z : Grid d F) : (fun i => (tags idx x i).elim z id) =
      (localChunk idx H).put x (fun i => (idx i).elim 0 z) := by
    funext i; cases e : idx i <;> simp [Chunk.put,localChunk,tags,e]
  have start : (fun i => (tags idx x i).elim (fun j => x (name j)) id) = x := by
    funext i; cases e : idx i with
    | none => simp [tags,e]
    | some j => simp [tags,e,inv i j e]
  have notzero : Form.ev a (t.run (fun j => x (name j))) ≠ 0 := by
    rw [← eval_output,rep,start]; exact hx
  obtain ⟨z,hz,hn⟩ := (localList_spec bound hd hk hp cols full rows hr).2 (t,a) ⟨_,notzero⟩
  refine ⟨fun i => (idx i).elim 0 z, List.mem_map.mpr ⟨z,hz,rfl⟩, ?_⟩
  change Form.ev a (t.run z) ≠ 0 at hn
  rw [← eval_output,rep,mixed] at hn
  exact hn

structure BlockSpec (V : Type) where
  width : Nat
  idx : V → Option (Fin width)
  name : Fin width → V
  inverse : ∀ i j, idx i = some j → name j = i

noncomputable def listed (p : Net V m) (K : Nat) (b : BlockSpec V) : Chunk V F := by
  classical
  exact localChunk b.idx (localList (Finset.univ : Finset (Description (Fin b.width) F (blockCount b.idx p)))
    (Finset.univ.toList : List (Grid b.width F)) (2*((K+1)*(K+2))+2))

noncomputable def schedule (p : Net V m) (K : Nat) (heavy : List V) (bs : List (BlockSpec V)) :
    List (Chunk V F) := heavy.map booleanChunk ++ bs.map (listed p K)

theorem test_correct (p : Net V m) (r s : Fin m) (free : p.free)
    (is heavy : List V) (bs : List (BlockSpec V)) (K : Nat)
    (all : ∀ i, i ∈ is)
    (cover : ∀ i, i ∈ heavy ∨ ∃ b ∈ bs, (b.idx i).isSome = true)
    (size : ∀ b ∈ bs, blockCount b.idx p ≤ K ∧ b.width ≤ Fintype.card F)
    (hk : K*K < Fintype.card F) (hp : 1 < Fintype.card F) :
    (∀ a, p.boolVal a r = p.boolVal a s) ↔
      ∀ x ∈ grids (schedule p K heavy bs) (fun _ => (0:F)), delta p r s x = 0 := by
  classical
  apply equivalence_iff_grid _ free _ _ is all
  · intro c hc
    rcases List.mem_append.mp hc with hc|hc
    · obtain ⟨i,_,rfl⟩ := List.mem_map.mp hc
      exact boolean_good _ _ (delta_affine _ free _ _ i)
    · obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hc
      exact local_good p r s b.idx b.name b.inverse (size b hb).1 (size b hb).2 hk hp
        _ (by simp) _ (by simp)
  · intro i
    rcases cover i with hi|⟨b,hb,ha⟩
    · exact ⟨booleanChunk i, List.mem_append_left _ (List.mem_map.mpr ⟨i,hi,rfl⟩), by simp [booleanChunk]⟩
    · exact ⟨listed p K b, List.mem_append_right _ (List.mem_map.mpr ⟨b,hb,rfl⟩),ha⟩

end FBDD
