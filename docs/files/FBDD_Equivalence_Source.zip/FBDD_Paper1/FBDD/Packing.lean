import FBDD.Pair

namespace FBDD
open Finset
variable {V : Type}
def mass (w : V → Nat) (l : List V) := (l.map w).sum
def pack (w : V → Nat) (k : Nat) : List V → List V × List (List V)
  | [] => ([],[])
  | v::vs =>
    let (a,bs) := pack w k vs
    if k ≤ mass w (v::a) then ([],(v::a)::bs) else (v::a,bs)

theorem pack_spec (w : V → Nat) (k : Nat) (hk : 0 < k) (l : List V)
    (light : ∀ v ∈ l, w v ≤ k) :
    let q := pack w k l
    q.1 ++ q.2.flatten = l ∧ mass w q.1 < k ∧
    ∀ b ∈ q.2, k ≤ mass w b ∧ mass w b ≤ 2*k := by
  induction l with
  | nil => simpa [pack,mass]
  | cons v vs ih =>
    obtain ⟨flat,small,bounds⟩ := ih (fun i hi => light i (by simp [hi]))
    have hv := light v (by simp)
    have val : mass w (v::(pack w k vs).1) = w v + mass w (pack w k vs).1 := by simp [mass]
    simp only [pack]; split
    · refine ⟨by simp [flat],by simpa [mass],?_⟩
      intro b hb; rcases List.mem_cons.mp hb with rfl|h
      · exact ⟨by assumption,by omega⟩
      · exact bounds _ h
    · exact ⟨by simp [flat],by dsimp; omega,bounds⟩

theorem mass_append (w : V → Nat) (a b) : mass w (a++b) = mass w a + mass w b := by simp [mass]
theorem mass_flatten_lb (w : V → Nat) (k : Nat) (bs : List (List V))
    (h : ∀ b ∈ bs, k ≤ mass w b) : bs.length*k ≤ mass w bs.flatten := by
  induction bs with
  | nil => simp [mass]
  | cons b bs ih =>
    have h₁ := h b (by simp); have h₂ := ih (fun v hv => h v (by simp [hv]))
    simp only [List.length_cons,List.flatten_cons,mass_append,Nat.add_mul,one_mul]; omega

def count [DecidableEq V] (v : V) : {m : Nat} → Net V m → Nat
  | _, .empty => 0
  | _, .leaf d _ => count v d
  | _, .gate d i _ _ => count v d + if v=i then 1 else 0

theorem count_total [DecidableEq V] [Fintype V] {m} (d : Net V m) :
    (∑ v, count v d) ≤ m := by
  induction d with
  | empty => simp [count]
  | leaf p b ih => exact Nat.le_succ_of_le ih
  | gate p i l h ih => simp [count,Finset.sum_add_distrib]; omega

def specOf [DecidableEq V] (l : List V) : BlockSpec V where
  width := l.length
  idx i := if h : i ∈ l then some ⟨l.idxOf i,List.idxOf_lt_length_iff.mpr h⟩ else none
  name := l.get
  inverse i j := by
    split
    · intro eq; cases eq; simp
    · simp

theorem spec_mem [DecidableEq V] (l : List V) (i : V) :
    ((specOf l).idx i).isSome = true ↔ i ∈ l := by by_cases hi : i ∈ l <;> simp [specOf,hi]

theorem blockCount_eq [DecidableEq V] {m} (p : Net V m) (l : List V) :
    blockCount (specOf l).idx p = ∑ i ∈ l.toFinset, count i p := by
  induction p with
  | empty => simp [blockCount,count]
  | leaf p b ih => exact ih
  | gate p i low high ih =>
    by_cases hi : i ∈ l <;> simp [blockCount,specOf,count,Finset.sum_add_distrib,hi] at ih ⊢ <;> exact ih

def heavy [DecidableEq V] {m} (p : Net V m) (k : Nat) (names : List V) :=
  names.filter (fun i => k < max 1 (count i p))
def light [DecidableEq V] {m} (p : Net V m) (k : Nat) (names : List V) :=
  names.filter (fun i => max 1 (count i p) ≤ k)

theorem mass_dom (w : V → Nat) (l : List V) (h : ∀ v ∈ l, 1 ≤ w v) : l.length ≤ mass w l := by
  induction l with
  | nil => simp [mass]
  | cons i is ih =>
    have a := h i (by simp); have b := ih (fun j hj => h j (by simp [hj]))
    simp only [mass,List.map_cons,List.sum_cons,List.length_cons] at *; omega

theorem sum_to_mass [DecidableEq V] (f g : V → Nat) (h : ∀ i, f i ≤ g i) (l : List V) :
    ∑ i ∈ l.toFinset, f i ≤ mass g l := by
  induction l with
  | nil => simp [mass]
  | cons v vs ih =>
    simp only [List.toFinset_cons,mass,List.map_cons,List.sum_cons]
    by_cases hv : v ∈ vs
    · rw [Finset.insert_eq_of_mem (List.mem_toFinset.mpr hv)]
      exact ih.trans (Nat.le_add_left ..)
    · rw [Finset.sum_insert (by simpa using hv)]; exact Nat.add_le_add (h v) ih

theorem heavy_mass (w : V → Nat) (k : Nat) (l : List V) :
    (l.filter (fun i => k < w i)).length * k + mass w (l.filter (fun i => w i ≤ k)) ≤ mass w l := by
  induction l with
  | nil => simp [mass]
  | cons i is ih =>
    by_cases hi : k < w i
    · simpa [mass,List.filter_cons,hi,not_le.mpr hi,Nat.add_mul] using
        (show ((_ :: _).length * k + _ ≤ _) from (by simp only [List.length_cons,Nat.add_mul,one_mul]; unfold mass at *; omega) : ((i::(is.filter (fun j => k < w j))).length*k + mass w (is.filter (fun j => w j ≤ k)) ≤ w i + mass w is))
    · simp [mass,List.filter_cons,hi,not_lt.mp hi] at *; omega

end FBDD
