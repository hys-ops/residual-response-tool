import FBDD.Executable
namespace FBDD
def words {A} (alphabet : List A) : Nat → List (List A)
  | 0 => [[]]
  | k+1 => [] :: alphabet.flatMap (fun a => (words alphabet k).map (a::·))

theorem mem_words {A} {alphabet : List A} {n} (xs : List A)
    (size : xs.length ≤ n) (uses : ∀ x ∈ xs, x ∈ alphabet) : xs ∈ words alphabet n := by
  induction n generalizing xs with
  | zero => have : xs = [] := List.length_eq_zero_iff.mp (by omega); simp [this,words]
  | succ n ih =>
    cases xs with
    | nil => simp [words]
    | cons x xs =>
      right
      exact List.mem_flatMap.mpr ⟨x,uses _ (by simp),List.mem_map.mpr
        ⟨xs,ih xs (by simpa using size) (fun y hy => uses _ (by simp [hy])),rfl⟩⟩

theorem words_length {A} (alph : List A) (n) : (words alph n).length ≤ (alph.length+1)^n := by
  induction n with
  | zero => simp [words]
  | succ n ih =>
    simp only [words,List.length_cons,List.length_flatMap,List.length_map,Function.comp_def,
      List.map_const',List.sum_replicate,pow_succ]
    have p : 0 < (alph.length+1)^n := pow_pos (by omega) _
    simp only [nsmul_eq_mul] 
    nlinarith [Nat.mul_le_mul_left alph.length ih]

variable {V F : Type} [DecidableEq V] [Field F] [Fintype F] [DecidableEq F]
def codedChunk (K t : Nat) (values : List F) (ns : List V) : Chunk V F :=
  localChunk (specOf ns).idx (localList (Finset.univ : Finset (Description (Fin ns.length) F t))
    (allTuples values ns.length) (2*((K+1)*(K+2))+2))

def decode (K : Nat) (values : List F) : List (Nat × Nat) → List V → List (Chunk V F)
  | [], _ => []
  | (d,t)::cs, ns => (codedChunk K t values (ns.take d)) :: (decode K values cs (ns.drop d))

def encode {m} (p : Net V m) (bs : List (List V)) : List (Nat × Nat) :=
  bs.map (fun b => (b.length,blockCount (specOf b).idx p))

theorem decode_encode {m} (p : Net V m) (K : Nat) (values : List F) (bs : List (List V)) :
    decode K values (encode p bs) bs.flatten = (bs.map specOf).map (enumChunk p K values) := by
  induction bs with
  | nil => rfl
  | cons b bs ih => simp [decode,encode] at ih ⊢; exact ⟨rfl,ih⟩

theorem bins_flatten {m} (p : Net V m) (k : Nat) (hk : 0 < k) (ns : List V) :
    (bins p k ns).flatten = ns.filter (fun i => i ∉ heavy p k ns) := by
  let w := fun i => max 1 (count i p)
  let ls := light p k ns
  have h := (pack_spec w k hk ls (fun i hi => by simpa [ls,light,w] using (List.mem_filter.mp hi).2)).1
  apply h.trans
  apply List.filter_congr
  intro x hx
  simp [light,heavy,hx,hk.ne',show 1 ≤ k by omega]

def shapeGrid (K : Nat) (values : List F) (ns heavyNames : List V) (cs : List (Nat × Nat)) :=
  grids ((heavyNames.map booleanChunk) ++ decode K values cs (ns.filter (fun i => i ∉ heavyNames))) (fun _ => 0)

def shapeAlphabet (K : Nat) : List (Nat × Nat) :=
  (List.range (K+1)).flatMap (fun w => (List.range (K+1)).map (fun t => (w,t)))

def universalGrid (k budget : Nat) (values : List F) (ns : List V) : List (V → F) :=
  (words ns budget).flatMap (fun hv => (words (shapeAlphabet (2*k)) budget).flatMap
    (shapeGrid (2*k) values ns hv))

theorem contains_auto {v m} (p : Net (Fin v) m) (values : List F) (k : Nat)
    (hk : 0 < k) (hs : m + v ≤ 2*k^3) :
    ∀ x ∈ enumGrid p k (List.finRange v) values,
      x ∈ universalGrid k (2*k^2+1) values (List.finRange v) := by
  let ns := List.finRange v
  let H := heavy p k ns
  let B := bins p k ns
  let C := encode p B
  have pack := ordered_packing p k hk ns (by simp [ns]) (List.nodup_finRange v)
  have amt := pack.1
  simp only [Fintype.card_fin] at amt
  change (H.length + (B.length-1))*k ≤ m+v at amt
  have lim : H.length + (B.length-1) ≤ 2*k^2 := by
    apply Nat.le_of_mul_le_mul_left (c := k) _ hk
    nlinarith [amt,hs]
  have wH : H ∈ words ns (2*k^2+1) :=
    mem_words _ (by omega) (fun i hi => (List.mem_filter.mp hi).1)
  have wC : C ∈ words (shapeAlphabet (2*k)) (2*k^2+1) := by
    apply mem_words
    · simp only [C,encode,List.length_map]; omega
    · intro z hz
      obtain ⟨b,hb,rfl⟩ := List.mem_map.mp hz
      have bds := pack.2.2 b hb
      apply List.mem_flatMap.mpr
      exact ⟨b.length,List.mem_range.mpr (by omega), List.mem_map.mpr
        ⟨_,List.mem_range.mpr (Nat.lt_succ_of_le bds.1),rfl⟩⟩
  intro x hx
  apply List.mem_flatMap.mpr
  refine ⟨H,wH,List.mem_flatMap.mpr ⟨C,wC,?_⟩⟩
  unfold shapeGrid
  rw [← bins_flatten p k hk ns,decode_encode]
  exact hx

theorem universal_correct {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (ha : a.free) (hb : b.free) (values : List F) (full : ∀ z, z ∈ values)
    (k : Nat) (hk : 0 < k) (hp : (2*k)*(2*k) < Fintype.card F) (size : m+n+v ≤ 2*k^3) :
    (∀ z, a.boolVal z r = b.boolVal z s) ↔
    ∀ x ∈ universalGrid k (2*k^2+1) values (List.finRange v), a.val x r = b.val x s := by
  let j := join a b
  have eq (x : Fin v → F) : delta j.net (j.left r) (j.right s) x = a.val x r - b.val x s := by
    simp [delta,j,(join_val a b x).1,(join_val a b x).2]
  have fr := join_free a b ha hb
  have h := enumGrid_correct j.net (j.left r) (j.right s) fr k hk hp (List.finRange v)
    (by simp) (List.nodup_finRange v) values full
  simp only [j,(join_bool a b _).1,(join_bool a b _).2] at h
  constructor
  · intro e x _
    by_contra ne
    have w := witness_of_field j.net fr (j.left r) (j.right s) (List.finRange v) (by simp) x
      (by rw [eq]; exact sub_ne_zero.mpr ne)
    simp only [j,(join_bool a b _).1,(join_bool a b _).2] at w
    exact w (e _)
  · intro e
    apply h.mpr
    intro x hx
    exact (eq x).trans (sub_eq_zero.mpr (e x (contains_auto j.net values k hk size x hx)))
end FBDD
