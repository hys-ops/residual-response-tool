import FBDD.Catalogue
namespace FBDD
variable {V F : Type}
structure Chunk (V F : Type) where
  active : V → Bool
  choices : List (V → F)

def Chunk.put (c : Chunk V F) (x v : V → F) : V → F := fun i => if c.active i then v i else x i
def grids : List (Chunk V F) → (V → F) → List (V → F)
  | [], x => [x]
  | c::cs, x => c.choices.flatMap (fun v => grids cs (c.put x v))

def Adequate [Zero F] (D : (V → F) → F) (c : Chunk V F) :=
  ∀ x, D x ≠ 0 → ∃ v ∈ c.choices, D (c.put x v) ≠ 0

theorem grids_hit [Zero F] (D : (V → F) → F) (cs : List (Chunk V F))
    (good : ∀ c ∈ cs, Adequate D c) (x : V → F) (hx : D x ≠ 0) :
    ∃ y ∈ grids cs x, D y ≠ 0 := by
  induction cs generalizing x with
  | nil => exact ⟨x,by simp [grids],hx⟩
  | cons c cs ih =>
    obtain ⟨v,hv,hn⟩ := good c (by simp) x hx
    obtain ⟨y,hy,hn'⟩ := ih (fun b hb => good b (by simp [hb])) _ hn
    exact ⟨y,List.mem_flatMap.mpr ⟨v,hv,hy⟩,hn'⟩

theorem grids_congr (cs : List (Chunk V F)) (x y : V → F)
    (agree : ∀ i, x i = y i ∨ ∃ c ∈ cs, c.active i = true) : grids cs x = grids cs y := by
  induction cs generalizing x y with
  | nil =>
    have h : x = y := funext fun i => (agree i).resolve_right (by simp)
    rw [h]
  | cons c cs ih =>
    simp only [grids]
    apply congrArg (fun f => List.flatMap f c.choices)
    funext v
    apply ih
    intro i
    by_cases h : c.active i = true
    · exact Or.inl (by simp [Chunk.put,h])
    · rcases agree i with eq | ⟨s,hs,ha⟩
      · exact Or.inl (by simp [Chunk.put,h,eq])
      · rcases List.mem_cons.mp hs with rfl|hs
        · exact False.elim (h ha)
        · exact Or.inr ⟨s,hs,ha⟩

def productSize : List (Chunk V F) → Nat
  | [] => 1
  | c::cs => c.choices.length * productSize cs

theorem grid_length (cs : List (Chunk V F)) (x : V → F) :
    (grids cs x).length = productSize cs := by
  induction cs generalizing x with
  | nil => rfl
  | cons c cs ih =>
    simp only [grids,productSize,List.length_flatMap]
    simp [ih,List.sum_replicate]

section Diagrams
variable [Field F] [DecidableEq F] [DecidableEq V] {m : Nat}
def delta (d : Net V m) (r s : Fin m) (x : V → F) := d.val x r - d.val x s

theorem delta_affine (d : Net V m) (h : d.free) (r s : Fin m) (i : V) :
    AffineAt (F := F) (delta d r s) i := by
  intro x
  unfold delta
  have hr := d.affine (F := F) h r i x
  have hs := d.affine (F := F) h s i x
  dsimp only at hr hs
  rw [hr, hs]; ring

/-- Recover a Boolean witness by at most two field evaluations per coordinate. -/
def endpoints (D : (V → F) → F) : List V → (V → F) → (V → F)
  | [], x => x
  | i::is, x =>
    let z := Function.update x i 0
    endpoints D is (if D z = 0 then Function.update x i 1 else z)

theorem endpoints_ok (D : (V → F) → F) (aff : ∀ i, AffineAt D i)
    (is : List V) (x : V → F) (hx : D x ≠ 0) :
    D (endpoints D is x) ≠ 0 ∧
    ∀ i, i ∈ is ∨ x i = 0 ∨ x i = 1 → endpoints D is x i = 0 ∨ endpoints D is x i = 1 := by
  induction is generalizing x with
  | nil => simp [endpoints,hx]
  | cons i is ih =>
    let z := Function.update x i 0
    let y := if D z = 0 then Function.update x i 1 else z
    have hy : D y ≠ 0 := by
      dsimp [y]; split
      · intro h; apply hx; rw [aff i x]
        simp_all [z]
      · assumption
    obtain ⟨hn,hb⟩ := ih y hy
    refine ⟨hn,?_⟩
    intro j hj
    apply hb
    by_cases e : j = i
    · subst j; right; dsimp [y,z]; split <;> simp
    · have he : y j = x j := by dsimp [y,z]; split <;> simp [Function.update_of_ne e]
      simpa [he,e] using hj

def boolOf (v : V → F) : V → Bool := fun i => decide (v i = 1)
theorem witness_of_field (d : Net V m) (hf : d.free) (r s : Fin m)
    (is : List V) (every : ∀ i, i ∈ is) (x : V → F) (hne : delta d r s x ≠ 0) :
    let b := boolOf (endpoints (delta d r s) is x)
    d.boolVal b r ≠ d.boolVal b s := by
  let y := endpoints (delta d r s) is x
  obtain ⟨hn,hb⟩ := endpoints_ok _ (delta_affine d hf r s) is x hne
  have eq : (fun i => bit (F := F) (boolOf y i)) = y := by
    funext i
    rcases hb i (Or.inl (every i)) with h|h <;> change y i = _ at h <;> simp [boolOf,bit,h]
  change d.boolVal (boolOf y) r ≠ d.boolVal (boolOf y) s
  intro he; apply hn
  change d.val y r - d.val y s = 0
  rw [← eq, d.val_bit, d.val_bit, he, sub_self]

def booleanChunk (i : V) : Chunk V F := ⟨fun j => decide (j=i), [fun _ => 0, fun _ => 1]⟩

theorem boolean_good (D : (V → F) → F) (i : V) (aff : AffineAt D i) :
    Adequate D (booleanChunk i) := by
  intro x hx
  have put (a : F) : (booleanChunk i).put x (fun _ => a) = Function.update x i a := by
    funext j; by_cases h : j=i <;> simp [Chunk.put,booleanChunk,Function.update,h]
  by_cases h : D (Function.update x i 0) = 0
  · refine ⟨fun _ => 1,by simp [booleanChunk],?_⟩
    rw [put]; intro h'; apply hx; rw [aff x,h,h']; ring
  · exact ⟨fun _ => 0,by simp [booleanChunk],by simpa [put] using h⟩

/-- Equivalence via the product, including the direction from a field
discrepancy back to a genuine Boolean input. -/
theorem equivalence_iff_grid (d : Net V m) (hf : d.free) (r s : Fin m)
    (is : List V) (every : ∀ i, i ∈ is) (cs : List (Chunk V F))
    (good : ∀ c ∈ cs, Adequate (delta d r s) c)
    (cover : ∀ i, ∃ c ∈ cs, c.active i = true) :
    (∀ b, d.boolVal b r = d.boolVal b s) ↔
    ∀ x ∈ grids cs (fun _ => 0), delta d r s x = 0 := by
  constructor
  · intro he x _; by_contra hn
    exact witness_of_field d hf r s is every x hn (he _)
  · intro hg b
    by_contra hb
    let x : V → F := fun i => bit (b i)
    have hx : delta d r s x ≠ 0 := by
      simp only [delta,x,Net.val_bit,sub_ne_zero]
      cases h₁ : d.boolVal b r <;> cases h₂ : d.boolVal b s <;> simp_all [bit]
    obtain ⟨y,hy,hn⟩ := grids_hit _ cs good x hx
    rw [grids_congr cs x (fun _ => 0) (fun i => Or.inr (cover i))] at hy
    exact hn (hg y hy)
end Diagrams
end FBDD
