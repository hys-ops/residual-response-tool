import FBDD.Costs
namespace FBDD
open Finset
variable {F : Type} [Field F] [Fintype F]
abbrev MatrixData (r s : Nat) (F : Type) := Fin r → Fin s → F
abbrev BiPoint (r s : Nat) (F : Type) := (Fin r → F) × (Fin s → F)

def bilinear {r s} (A : MatrixData r s F) (v : BiPoint r s F) :=
  ∑ i, ∑ j, A i j * v.1 i * v.2 j

def basisPair {r s} (i : Fin r) (j : Fin s) : BiPoint r s F :=
  (fun a => if i=a then 1 else 0,fun b => if j=b then 1 else 0)

theorem at_basis {r s} (A : MatrixData r s F) (i j) : bilinear A (basisPair i j) = A i j := by
  classical
  simp [bilinear,basisPair,mul_ite,ite_mul]

def MatrixHits {r s} (L : List (BiPoint r s F)) :=
  ∀ A : MatrixData r s F, A ≠ 0 → ∃ v ∈ L, bilinear A v ≠ 0

theorem matrix_lower {r s} (L : List (BiPoint r s F)) (h : MatrixHits L) : r*s ≤ L.length := by
  classical
  let code (A : MatrixData r s F) (i : Fin L.length) := bilinear A (L.get i)
  have inject : Function.Injective code := by
    intro a b eq
    by_contra hn
    obtain ⟨v,hv,hne⟩ := h (a-b) (sub_ne_zero.mpr hn)
    obtain ⟨i,hi⟩ := List.mem_iff_get.mp hv
    have h₁ := congrFun eq i
    change bilinear a (L.get i) = bilinear b (L.get i) at h₁
    rw [hi] at h₁
    apply hne
    simpa [bilinear,sub_mul,Finset.sum_sub_distrib] using sub_eq_zero.mpr h₁
  have hc := Fintype.card_le_of_injective code inject
  simp only [MatrixData,Fintype.card_fun,Fintype.card_fin,← pow_mul] at hc
  have p : 1 < Fintype.card F := Fintype.one_lt_card
  by_contra! hn
  exact (not_lt_of_ge hc) (Nat.pow_lt_pow_right p (by simpa [Nat.mul_comm] using hn))

noncomputable def matrixBasis (r s : Nat) : List (BiPoint r s F) :=
  (Finset.univ : Finset (Fin r × Fin s)).toList.map (fun ij => basisPair ij.1 ij.2)

theorem matrix_exact (r s : Nat) :
    (matrixBasis (F := F) r s).length = r*s ∧ MatrixHits (matrixBasis (F := F) r s) := by
  classical
  constructor
  · simp [matrixBasis]
  · intro a ha
    by_contra! h
    apply ha
    funext i j
    have mem : basisPair i j ∈ matrixBasis (F := F) r s :=
      List.mem_map.mpr ⟨(i,j),by simp,rfl⟩
    simpa [at_basis] using h _ mem
end FBDD
