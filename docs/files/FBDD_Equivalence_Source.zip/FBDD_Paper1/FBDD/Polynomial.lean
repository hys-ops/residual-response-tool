import FBDD.Block

namespace FBDD
open MvPolynomial
variable {I F : Type} [Field F]
abbrev Poly (I F : Type) [Field F] := MvPolynomial I F

noncomputable def Form.pol : {k : Nat} → Form F k → (Fin k → Poly I F) → Poly I F
  | 0, a, _ => C a
  | _+1, a, v => C a.1 * v 0 + Form.pol a.2 (fun j => v j.succ)

theorem Form.pol_eval (x : I → F) {k} (a : Form F k) (v : Fin k → Poly I F) :
    eval x (Form.pol a v) = Form.ev a (fun j => eval x (v j)) := by
  induction k with
  | zero => simp [Form.pol,Form.ev]
  | succ k ih => simp [Form.pol, Form.ev, ih]

theorem Form.pol_degree {k d} (a : Form F k) (v : Fin k → Poly I F)
    (h : ∀ j, (v j).totalDegree ≤ d) : (Form.pol a v).totalDegree ≤ d := by
  induction k with
  | zero => simp [Form.pol]
  | succ k ih =>
    apply (totalDegree_add _ _).trans
    apply max_le
    · exact (totalDegree_mul _ _).trans (by simpa using h 0)
    · exact ih _ _ (fun j => h j.succ)

noncomputable def Tri.polys : {k : Nat} → Tri I F k → Fin k → Poly I F
  | _, .nil => Fin.elim0
  | _, .step t i a => Fin.cases (X i * Form.pol a t.polys) t.polys

theorem Tri.eval_polys (x : I → F) {k} (t : Tri I F k) (j : Fin k) :
    eval x (t.polys j) = t.run x j := by
  induction t with
  | nil => exact Fin.elim0 j
  | step t i a ih =>
    refine Fin.cases ?_ (fun q => ih q) j
    simp [Tri.polys,Tri.run,Form.pol_eval,ih]

theorem Tri.degree_polys {k} (t : Tri I F k) (j : Fin k) :
    (t.polys j).totalDegree ≤ k := by
  induction t with
  | nil => exact Fin.elim0 j
  | step t i a ih =>
    refine Fin.cases ?_ (fun q => Nat.le_succ_of_le (ih q)) j
    apply (totalDegree_mul _ _).trans
    simpa [Nat.add_comm] using Nat.succ_le_succ (Form.pol_degree a _ ih)

noncomputable def polyOutput {k} (t : Tri I F k) (a : Form F k) :=
  a.pol t.polys

theorem output_degree {k} (t : Tri I F k) (a : Form F k) :
    (polyOutput t a).totalDegree ≤ k := Form.pol_degree a _ t.degree_polys

theorem eval_output {k} (t : Tri I F k) (a : Form F k) (x : I → F) :
    eval x (polyOutput t a) = a.ev (t.run x) := by simp [polyOutput,Form.pol_eval,Tri.eval_polys]

/-- Two roots in one topological listing; terminal sharing plays no role. -/
theorem restriction_as_tri {V} (s : V → I ⊕ F) {m} (d : Net V m) (r₁ r₂ : Fin m) :
    ∃ (t : Tri I F (occ s d)) (a : Form F (occ s d)), ∀ x,
       eval x (polyOutput t a) =
       d.val (fun i => (s i).elim x id) r₁ - d.val (fun i => (s i).elim x id) r₂ := by
  rw [← compile_length s d]
  refine ⟨(compile s d).code, Form.diff ((compile s d).reg r₁) ((compile s d).reg r₂), ?_⟩
  intro x
  rw [eval_output, Form.ev_diff]
  exact congrArg₂ (· - ·) (compile_correct s x d r₁) (compile_correct s x d r₂)

end FBDD
