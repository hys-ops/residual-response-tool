import FBDD.Diagram

namespace FBDD
/-- The last scalar is the bias; each added coordinate introduces one coefficient. -/
def Form (F : Type) : Nat → Type
  | 0 => F
  | k+1 => F × Form F k

namespace Form
variable {F : Type} [CommRing F]
def const (c : F) : (k : Nat) → Form F k
  | 0 => c
  | k+1 => (0, const c k)
def add : {k : Nat} → Form F k → Form F k → Form F k
  | 0, a, b => (show F from a) + (show F from b)
  | _+1, a, b => (a.1 + b.1, add a.2 b.2)
def scale (c : F) : {k : Nat} → Form F k → Form F k
  | 0, a => c * (show F from a)
  | _+1, a => (c*a.1, scale c a.2)
def ev : {k : Nat} → Form F k → (Fin k → F) → F
  | 0, a, _ => a
  | _+1, a, v => a.1 * v 0 + ev a.2 (fun j => v j.succ)

@[simp] theorem ev_const (c : F) (k : Nat) (v : Fin k → F) :
    ev (const c k) v = c := by induction k with
  | zero => rfl
  | succ k ih => simp [const, ev, ih]
@[simp] theorem ev_add {k} (a b : Form F k) (v : Fin k → F) :
    ev (add a b) v = ev a v + ev b v := by induction k with
  | zero => rfl
  | succ k ih => simp [ev, add, ih]; ring
@[simp] theorem ev_scale (c : F) {k} (a : Form F k) (v : Fin k → F) :
    ev (scale c a) v = c * ev a v := by induction k with
  | zero => rfl
  | succ k ih => simp [ev, scale, ih]; ring

def diff {k} (a b : Form F k) : Form F k := add a (scale (-1) b)
@[simp] theorem ev_diff {k} (a b : Form F k) (v) :
    ev (diff a b) v = ev a v - ev b v := by simp [diff,sub_eq_add_neg]
end Form

/-- A k-update triangular recurrence, independent of the size of the original DAG. -/
inductive Tri (I F : Type) : Nat → Type where
  | nil : Tri I F 0
  | step : Tri I F k → I → Form F k → Tri I F (k+1)

def Tri.run {I F} [CommRing F] (x : I → F) : {k : Nat} → Tri I F k → Fin k → F
  | _, .nil => Fin.elim0
  | _, .step c i a => let old := c.run x; Fin.cases (x i * (Form.ev a old)) old

variable {V I F : Type} [CommRing F]
/-- A left tag retains a local variable; a right tag fixes an arbitrary field value. -/
def occ (s : V → I ⊕ F) : {m : Nat} → Net V m → Nat
  | _, .empty => 0
  | _, .leaf d _ => occ s d
  | _, .gate d i _ _ => match s i with
    | .inl _ => occ s d + 1
    | .inr _ => occ s d

structure Compiled (I F : Type) (m : Nat) where
  k : Nat
  code : Tri I F k
  reg : Fin m → Form F k

def compile (s : V → I ⊕ F) : {m : Nat} → Net V m → Compiled I F m
  | _, .empty => ⟨0, .nil, Fin.elim0⟩
  | _, .leaf d b =>
    let q := compile s d
    ⟨q.k, q.code, Fin.cases (Form.const (bit b) _) q.reg⟩
  | _, .gate d i l h =>
    let q := compile s d
    let a := Form.diff (q.reg h) (q.reg l)
    match s i with
    | .inl j => ⟨q.k+1, .step q.code j a, Fin.cases (1, q.reg l) (fun u => (0,q.reg u))⟩
    | .inr t => ⟨q.k, q.code, Fin.cases (Form.add (q.reg l) (Form.scale t a)) q.reg⟩

theorem compile_length (s : V → I ⊕ F) {m} (d : Net V m) :
    (compile s d).k = occ s d := by
  induction d with
  | empty => rfl
  | leaf d b ih => exact ih
  | gate d i l h ih => cases e : s i <;> simp [compile, occ, e, ih]

def Compiled.read (q : Compiled I F m) (x : I → F) (r : Fin m) :=
  Form.ev (q.reg r) (q.code.run x)

theorem compile_correct (s : V → I ⊕ F) (x : I → F) {m} (d : Net V m) (r : Fin m) :
    (compile s d).read x r =
      d.val (fun i => (s i).elim x id) r := by
  induction d with
  | empty => exact Fin.elim0 r
  | leaf d b ih =>
    refine Fin.cases ?_ (fun j => ih j) r
    simp [compile, Compiled.read, Net.val, bit]
  | gate d i l h ih =>
    unfold Compiled.read at ih
    cases e : s i with
    | inl j =>
      refine Fin.cases ?_ ?_ r
      · simp only [compile, e]; simp [Compiled.read, Form.ev, Tri.run, Net.val, e, ih]
        ring
      · intro u; simp only [compile,e]; simp [Compiled.read,Form.ev,Tri.run,Net.val,e,ih]
    | inr t =>
      refine Fin.cases ?_ ?_ r
      · simp only [compile,e]; simp [Compiled.read,Net.val,e,ih]
      · intro u; simp only [compile,e]; simp [Compiled.read,Net.val,e,ih]

end FBDD
