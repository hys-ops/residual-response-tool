import FBDD.Catalogue
import FBDD.ReadOnce
namespace FBDD
variable {I F : Type} [Field F] [Fintype F] [DecidableEq F]
theorem pad_description (i : I) {t K} (h : t ≤ K) (a : Description I F t) :
    ∃ b : Description I F K, ∀ x, b.2.ev (b.1.run x) = a.2.ev (a.1.run x) := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le h
  induction k with
  | zero => exact ⟨a,fun _ => rfl⟩
  | succ k ih =>
    obtain ⟨b,eq⟩ := ih (by omega)
    refine ⟨(.step b.1 i (Form.const 0 _),(0,b.2)),fun x => ?_⟩
    simpa [Form.ev,Tri.run] using eq x

theorem common_local (K : Nat) (hk : 0 < K) (hf : K*K < Fintype.card F)
    (grid : List (Grid K F)) (all : ∀ x, x ∈ grid) :
    ∃ H : List (Grid K F), H.length = 2*((K+1)*(K+2))+2 ∧
      ∀ (t : Nat) (a : Description (Fin K) F t), t ≤ K →
        (∃ x, a.2.ev (a.1.run x) ≠ 0) → ∃ y ∈ H, a.2.ev (a.1.run y) ≠ 0 := by
  classical
  have base := localList_spec (F := F) (t := K) (K := K) le_rfl (show K ≤ Fintype.card F by nlinarith) hf
    Fintype.one_lt_card grid all Finset.univ (fun _ => Finset.mem_univ _)
  refine ⟨_,base.1,?_⟩
  intro t a ht nz
  obtain ⟨b,eq⟩ := pad_description (⟨0,hk⟩ : Fin K) ht a
  obtain ⟨x,hx⟩ := nz
  obtain ⟨y,hy,hn⟩ := base.2 b ⟨x,by simpa [eq x] using hx⟩
  exact ⟨y,hy,by simpa only [eq y] using hn⟩

/-- For every budget K≥2 this one graph has at most K data queries
and needs floor(K/2)^2 points. q can be any scalar other than 0 and 1. -/
theorem sharp_graph (K : Nat) (q : F) (q0 : q ≠ 0) (q1 : 1-q ≠ 0) :
    let r := K/2
    r+r ≤ K ∧ (∀ xs, Selector.Path r (.row r) xs → xs.Nodup) ∧
    ∀ H : List (BiPoint r r F), (∀ A : MatrixData r r F,
      (∃ xy, Selector.semantics r (Selector.inputs q A xy) (.row r) ≠ 0) →
      ∃ xy ∈ H, Selector.semantics r (Selector.inputs q A xy) (.row r) ≠ 0) →
      r*r ≤ H.length := by
  dsimp only
  exact ⟨by omega,Selector.root_read_once _ _,fun H => Selector.fixed_graph_lower q q0 q1 H⟩
end FBDD
