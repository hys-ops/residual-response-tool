import FBDD.Bilinear
namespace FBDD
open Finset
def emptyIso (V : Type) : Net V 0 ≃ Unit where
  toFun _ := ()
  invFun _ := .empty
  left_inv d := by cases d; rfl
  right_inv u := by cases u; rfl

def netStep (V : Type) (m : Nat) : Net V (m+1) ≃ Net V m × (Bool ⊕ (V × Fin m × Fin m)) where
  toFun
    | .leaf d b => (d, .inl b)
    | .gate d i l h => (d, .inr (i,l,h))
  invFun
    | (d,.inl b) => .leaf d b
    | (d,.inr (i,l,h)) => .gate d i l h
  left_inv d := by cases d <;> rfl
  right_inv q := by rcases q with ⟨d,b|⟨i,l,h⟩⟩ <;> rfl

instance netFintype (V : Type) [Fintype V] : (m : Nat) → Fintype (Net V m)
  | 0 => Fintype.ofEquiv _ (emptyIso V).symm
  | m+1 => by
    letI := netFintype V m
    exact Fintype.ofEquiv _ (netStep V m).symm

theorem net_card (N m p : Nat) (hm : m ≤ N) (hN : 2 ≤ N) (hp : N*N < p) :
    Fintype.card (Net (Fin N) m) ≤ p^(2*m) := by
  induction m with
  | zero => simp [Fintype.card_congr (emptyIso _)]
  | succ m ih =>
    rw [Fintype.card_congr (netStep _ _),Fintype.card_prod,Fintype.card_sum,
        Fintype.card_prod,Fintype.card_prod,Fintype.card_bool,Fintype.card_fin,Fintype.card_fin]
    have h₂ : m*m ≤ N*N := Nat.mul_le_mul (by omega) (by omega)
    have hn : N ≤ p := by nlinarith [Nat.mul_self_le_mul_self hN]
    have hbound : 2+N*(m*m) ≤ p*p := by
      have e := Nat.mul_le_mul_left N h₂
      nlinarith [Nat.mul_le_mul hn hp.le, Nat.mul_le_mul_left N hp, Nat.mul_self_le_mul_self hN]
    calc
      _ ≤ p^(2*m)*(p*p) := Nat.mul_le_mul (ih (by omega)) hbound
      _ = _ := by rw [show 2*(m+1) = 2*m+2 by omega,pow_add,pow_two]

theorem occ_le {I V F : Type} (s : V → I ⊕ F) {m} (d : Net V m) : occ s d ≤ m := by
  induction d with
  | empty => rfl
  | leaf d b ih => exact Nat.le_succ_of_le ih
  | gate d i l h ih => cases e : s i <;> simp [occ,e] <;> omega

abbrev FingerRow (N : Nat) := Net (Fin N) N × Fin N × Fin N

theorem advice_exact_size {F : Type} [Field F] [Fintype F] [DecidableEq F] (N : Nat)
    (hN : 2 ≤ N) (hp : N*N < Fintype.card F) :
    ∃ H : List (Fin N → F), H.length = 4*N+6 ∧
      ∀ (a : FingerRow N), (∃ x : Fin N → F, delta a.1 a.2.1 a.2.2 x ≠ 0) →
        ∃ y ∈ H, delta a.1 a.2.1 a.2.2 y ≠ 0 := by
  classical
  let p := Fintype.card F
  let test := fun (a : FingerRow N) (x : Fin N → F) => decide (delta a.1 a.2.1 a.2.2 x = 0)
  let U := (univ : Finset (FingerRow N)).filter (fun a => ∃ x, delta a.1 a.2.1 a.2.2 (F := F) x ≠ 0)
  let xs : List (Fin N → F) := univ.toList
  let G := greedy test xs (fun _ => 0) (4*N+6) U
  have gs := greedy_spec test xs (fun _ => 0) (4*N+6) U
  refine ⟨G.1,gs.1,?_⟩
  have hz (a : FingerRow N) (ha : a ∈ U) :
      p*(univ.filter (fun x => test a x)).card ≤ N*Fintype.card (Fin N → F) := by
    let tag := fun i : Fin N => (Sum.inl i : Fin N ⊕ F)
    obtain ⟨t,b,rep⟩ := restriction_as_tri tag a.1 a.2.1 a.2.2
    have eq (x) : MvPolynomial.eval x (polyOutput t b) = delta a.1 a.2.1 a.2.2 x := rep x
    obtain ⟨x,hx⟩ := (mem_filter.mp ha).2
    have ne : polyOutput t b ≠ 0 := by
      intro h
      apply hx
      rw [← eq,h,map_zero]
    have z := zero_count (polyOutput t b) ne ((output_degree ..).trans (occ_le tag a.1))
    simpa [test,eq] using z
  have hs := greedy_shrink test xs (fun _ => 0) (by simp [xs]) p N (4*N+6) U hz
  have small : U.card ≤ p^(2*N+2) := by
    apply (card_le_univ _).trans
    rw [Fintype.card_prod,Fintype.card_prod,Fintype.card_fin]
    calc
      _ ≤ p^(2*N)*(p*p) := Nat.mul_le_mul (net_card N N p le_rfl hN hp)
        (Nat.mul_le_mul (by dsimp [p]; nlinarith) (by dsimp [p]; nlinarith))
      _ = _ := by rw [pow_add,pow_two]
  have st := rounds (e := 2*N+2) hp (show 1 < p by dsimp [p]; nlinarith)
  rw [show 2*(2*N+2)+2 = 4*N+6 by omega] at st
  have lt := (Nat.mul_le_mul_left (N^(4*N+6)) small).trans_lt st
  intro a ha
  by_contra! h
  have hr : a ∈ G.2 := (gs.2 a).mpr ⟨mem_filter.mpr ⟨mem_univ _,ha⟩,fun x hx => by simp [test,h x hx]⟩
  have pos := Finset.card_pos.mpr ⟨a,hr⟩
  have one := Nat.mul_le_mul_left (p^(4*N+6)) pos
  change p^(4*N+6)*1 ≤ p^(4*N+6)*G.2.card at one
  rw [Nat.mul_one] at one
  exact (not_lt_of_ge (one.trans hs)) lt

theorem pad_roots {V : Type} {F : Type} [CommRing F] {m N} (h : m ≤ N)
    (d : Net V m) (r s : Fin m) :
    ∃ (d' : Net V N) (r' s' : Fin N), ∀ x : V → F,
      d'.val x r' - d'.val x s' = d.val x r - d.val x s := by
  obtain ⟨k,rfl⟩ := Nat.exists_eq_add_of_le h
  induction k with
  | zero => exact ⟨d,r,s,fun _ => rfl⟩
  | succ k ih =>
    obtain ⟨d',r',s',e⟩ := ih (by omega)
    exact ⟨.leaf d' false,r'.succ,s'.succ,e⟩

theorem join_val {V F : Type} [CommRing F] {m n} (a : Net V m) (b : Net V n) (x : V → F) :
    (∀ r, (join a b).net.val x ((join a b).left r) = a.val x r) ∧
    (∀ r, (join a b).net.val x ((join a b).right r) = b.val x r) := by
  induction b with
  | empty => exact ⟨fun _ => rfl,fun j => Fin.elim0 j⟩
  | leaf b v ih => exact ⟨ih.1,fun j => Fin.cases rfl (fun u => ih.2 u) j⟩
  | gate b i l h ih =>
    refine ⟨ih.1,fun j => Fin.cases ?_ (fun u => ih.2 u) j⟩
    simp [join,Net.val,ih.2]

theorem linear_advice {F : Type} [Field F] [Fintype F] [DecidableEq F] (N : Nat)
    (hN : 2 ≤ N) (hp : N*N < Fintype.card F) :
    ∃ H : List (Fin N → F), H.length = 4*N+6 ∧
      ∀ {m n} (a : Net (Fin N) m) (b : Net (Fin N) n) (r : Fin m) (s : Fin n),
        m+n ≤ N → a.free → b.free →
        ((∀ z, a.boolVal z r = b.boolVal z s) ↔ ∀ y ∈ H, a.val y r = b.val y s) := by
  obtain ⟨H,len,hit⟩ := advice_exact_size (F := F) N hN hp
  refine ⟨H,len,?_⟩
  intro m n a b r s hs ha hb
  let j := join a b
  have eq (x : Fin N → F) : delta j.net (j.left r) (j.right s) x = a.val x r - b.val x s := by
    simp [delta,j,(join_val a b x).1,(join_val a b x).2]
  obtain ⟨d,u,v,he⟩ := pad_roots (F := F) hs j.net (j.left r) (j.right s)
  constructor
  · intro h y _
    by_contra hh
    have w := witness_of_field j.net (join_free a b ha hb) (j.left r) (j.right s)
      (names (Fin N)) (by simp [names]) y (by rw [eq]; exact sub_ne_zero.mpr hh)
    simp only [j,(join_bool a b _).1,(join_bool a b _).2] at w
    exact w (h _)
  · intro h z
    by_contra ne
    let x : Fin N → F := fun i => bit (z i)
    have neq : a.val x r ≠ b.val x s := by
      simp only [x,Net.val_bit]
      cases qa : a.boolVal z r <;> cases qb : b.boolVal z s <;> simp_all [bit]
    have same (y) : delta d u v y = a.val y r - b.val y s := (he y).trans (eq y)
    obtain ⟨y,hy,no⟩ := hit (d,u,v) ⟨x,by change delta d u v x ≠ 0; rw [same]; exact sub_ne_zero.mpr neq⟩
    exact no ((same y).trans (sub_eq_zero.mpr (h y hy)))
end FBDD
