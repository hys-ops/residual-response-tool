import FBDD.Budgets
namespace FBDD
def fastDelta {V F : Type} [CommRing F] {m} (d : Net V m) (r s : Fin m) (x : V → F) :=
  let a := tab x d
  a[r.rev.val] - a[s.rev.val]

theorem fastDelta_eq {V F : Type} [Field F] {m} (d : Net V m) (r s : Fin m) :
    fastDelta (F := F) d r s = delta d r s := by funext x; simp only [fastDelta,delta,tab_correct]

def capacity (N : Nat) := Nat.find (p := fun k => 0 < k ∧ N ≤ k^3)
  (show ∃ k : Nat, 0 < k ∧ N ≤ k^3 from ⟨N+1,by omega,(Nat.le_succ N).trans (Nat.le_pow (by decide))⟩)

theorem cap_spec (N) : 0 < capacity N ∧ N ≤ (capacity N)^3 := Nat.find_spec (p := fun k => 0 < k ∧ N ≤ k^3) _

def primeFor (k : Nat) := Nat.find (p := fun p => Nat.Prime p ∧ (2*k)*(2*k) < p)
  (by obtain ⟨p,h,pp⟩ := Nat.exists_infinite_primes ((2*k)*(2*k)+1); exact ⟨p,pp,h⟩)

theorem prime_spec (k) : Nat.Prime (primeFor k) ∧ (2*k)*(2*k) < primeFor k := Nat.find_spec (p := fun p => Nat.Prime p ∧ (2*k)*(2*k) < p) _

theorem parameter_budget (N) (h : 0 < N) :
    (capacity N-1)^3 < N ∧ capacity N ≤ N ∧ primeFor (capacity N) ≤ 8*N^2 := by
  obtain ⟨k,pos,cap,minimal,le⟩ := cube_exists N h
  have ek : capacity N ≤ k := Nat.find_min' _ ⟨pos,cap⟩
  have e := cap_spec N
  have same : k = capacity N := by
    by_contra hn
    have H := Nat.pow_le_pow_left (show capacity N ≤ k-1 by omega) 3
    omega
  subst k
  obtain ⟨p,pp,lo,hi⟩ := field_exists N (capacity N) e.1 le
  exact ⟨minimal,le,(show primeFor (capacity N) ≤ p from Nat.find_min' _ ⟨pp,lo⟩).trans hi⟩

def blockResult {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (p k : Nat) [Fact p.Prime] : Option (Fin v → Bool) :=
  let j := join a b
  let D := fastDelta (F := ZMod p) j.net (j.left r) (j.right s)
  let ns := List.finRange v
  let points := enumGrid j.net k ns (residues p)
  (points.find? (fun x => decide (D x ≠ 0))).map (fun x => boolOf (endpoints D ns x))

def ResultSpec {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n) :
    Option (Fin v → Bool) → Prop
  | none => ∀ z, a.boolVal z r = b.boolVal z s
  | some z => a.boolVal z r ≠ b.boolVal z s

theorem blockResult_spec {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (ha : a.free) (hb : b.free) (p k : Nat) [Fact p.Prime] (hk : 0 < k) (hp : (2*k)*(2*k) < p) :
    ResultSpec a b r s (blockResult a b r s p k) := by
  let j := join a b
  let D := delta (F := ZMod p) j.net (j.left r) (j.right s)
  let ns := List.finRange v
  let ps := enumGrid j.net k ns (residues p)
  let condition := fun x => decide (D x ≠ 0)
  simp only [blockResult,fastDelta_eq]
  change ResultSpec a b r s ((ps.find? condition).map _)
  cases e : ps.find? condition with
  | none =>
    have h := List.find?_eq_none.mp e
    have eq := (enumGrid_correct j.net (j.left r) (j.right s) (join_free a b ha hb) k hk
      (by simpa using hp : (2*k)*(2*k) < Fintype.card (ZMod p)) ns (by simp [ns])
      (List.nodup_finRange v) (residues p) (residues_full p)).mpr (by simpa [condition,D,ps] using h)
    simpa only [ResultSpec,Option.map_none,j,(join_bool a b _).1,(join_bool a b _).2] using eq
  | some x =>
    have he : condition x = true := List.find?_some (p := condition) e
    have good : D x ≠ 0 := by simpa [condition] using he
    have w := witness_of_field j.net (join_free a b ha hb) (j.left r) (j.right s) ns
      (by simp [ns]) x good
    simpa only [ResultSpec,Option.map_some,j,(join_bool a b _).1,(join_bool a b _).2,ns] using w

def brute {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n) :=
  (allTuples [false,true] v).find? (fun x => decide (a.boolVal x r ≠ b.boolVal x s))

theorem brute_spec {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n) :
    ResultSpec a b r s (brute a b r s) := by
  unfold brute
  cases e : (allTuples [false,true] v).find? (fun x => decide (a.boolVal x r ≠ b.boolVal x s))
  · intro z
    have mem := tuples_complete [false,true] (by intro x; cases x <;> simp) v z
    simpa using List.find?_eq_none.mp e z mem
  · have hh := List.find?_some (p := fun x => decide (a.boolVal x r ≠ b.boolVal x s)) e
    simpa [ResultSpec] using hh

/-- The threshold compares exhaustive Boolean evaluations with an explicit
conservative estimate of catalogue work and field tests. -/
def solve {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n) :=
  let k := capacity (m+n)
  let p := primeFor k
  let _ : Fact p.Prime := ⟨(prime_spec k).1⟩
  let K := 2*k
  let estimated := p^((K+1)*(K+2)+K) * (listBudget K+1) + (listBudget K)^(2*k^2+1)
  if 2^v ≤ estimated then brute a b r s else blockResult a b r s p k

theorem solve_spec {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (ha : a.free) (hb : b.free) : ResultSpec a b r s (solve a b r s) := by
  letI : Fact (primeFor (capacity (m+n))).Prime := ⟨(prime_spec _).1⟩
  unfold solve; dsimp only; split
  · exact brute_spec a b r s
  · exact blockResult_spec a b r s ha hb _ _ (cap_spec _).1 (prime_spec _).2
end FBDD
