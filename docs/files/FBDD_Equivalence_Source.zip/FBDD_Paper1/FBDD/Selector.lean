import FBDD.Bilinear
import Mathlib.Tactic.FieldSimp
namespace FBDD.Selector
/-- The same row, column and data destinations are shared whenever referenced. -/
inductive Node where
  | sink : Bool → Node
  | row : Nat → Node
  | x : Nat → Node
  | col : Nat → Nat → Node
  | z : Nat → Nat → Node
  | y : Nat → Node
  deriving DecidableEq

inductive Label where
  | row : Nat → Label
  | x : Nat → Label
  | col : Nat → Nat → Label
  | z : Nat → Nat → Label
  | y : Nat → Label
  deriving DecidableEq

inductive Action where
  | stop : Bool → Action
  | ask : Label → Node → Node → Action

def step (s : Nat) : Node → Action
  | .sink b => .stop b
  | .row 0 => .stop false
  | .row (i+1) => .ask (.row i) (.row i) (.x i)
  | .x i => .ask (.x i) (.sink false) (.col i s)
  | .col _ 0 => .stop false
  | .col i (j+1) => .ask (.col i j) (.col i j) (.z i j)
  | .z i j => .ask (.z i j) (.sink false) (.y j)
  | .y j => .ask (.y j) (.sink false) (.sink true)

def owner : Label → Node
  | .row i => .row (i+1)
  | .x i => .x i
  | .col i j => .col i (j+1)
  | .z i j => .z i j
  | .y j => .y j

def rank (s : Nat) : Node → Nat
  | .sink _ => 0
  | .y _ => 1
  | .z _ _ => 2
  | .col _ j => 3+j
  | .x _ => s+4
  | .row i => s+5+i

def legal (r s : Nat) : Node → Prop
  | .sink _ => True
  | .row i => i ≤ r
  | .x i => i < r
  | .col i j => i < r ∧ j ≤ s
  | .z i j => i < r ∧ j < s
  | .y j => j < s

theorem edge_certificate {r s v i l h} (ok : legal r s v) (e : step s v = .ask i l h) :
    v = owner i ∧ rank s l < rank s v ∧ rank s h < rank s v ∧ legal r s l ∧ legal r s h := by
  cases v with
  | sink b => simp [step] at e
  | row j => cases j <;> simp [step] at e; obtain ⟨rfl,rfl,rfl⟩ := e; simp [owner,rank,legal] at *; omega
  | col a j => cases j <;> simp [step] at e; obtain ⟨rfl,rfl,rfl⟩ := e; simp [owner,rank,legal] at *; omega
  | x j => simp [step] at e; obtain ⟨rfl,rfl,rfl⟩ := e; simp_all [owner,rank,legal] <;> omega
  | y j => simp [step] at e; obtain ⟨rfl,rfl,rfl⟩ := e; simp_all [owner,rank,legal]
  | z a b => simp [step] at e; obtain ⟨rfl,rfl,rfl⟩ := e; simp_all [owner,rank,legal]

def queryNodes (r s : Nat) : List Node :=
  [.sink false,.sink true] ++ (List.range (r+1)).map Node.row ++ (List.range r).map Node.x ++
  (List.range r).flatMap (fun i => (List.range (s+1)).map (Node.col i)) ++
  (List.range r).flatMap (fun i => (List.range s).map (Node.z i)) ++ (List.range s).map Node.y

theorem legal_list {r s} (v : Node) : v ∈ queryNodes r s ↔ legal r s v := by
  cases v <;> simp [queryNodes,legal] <;> omega

theorem graph_size (r s : Nat) : (queryNodes r s).length = 2*r*s + 3*r + s + 3 := by
  simp [queryNodes,List.length_flatMap,List.sum_replicate]; ring

def data : Label → Bool
  | .x _ | .y _ => true
  | _ => false

theorem data_owners (r s : Nat) :
    ((List.range r).map Node.x ++ (List.range s).map Node.y).length = r+s ∧
    ∀ v i l h, legal r s v → step s v = .ask i l h → data i = true →
      v ∈ (List.range r).map Node.x ++ (List.range s).map Node.y := by
  refine ⟨by simp,?_⟩
  intro v i l h ok e hd
  have o := (edge_certificate ok e).1
  cases i <;> simp_all [data,owner,legal]

variable {F : Type} [Field F]
def scan (z a : Nat → F) : Nat → F
  | 0 => 0
  | k+1 => (1-z k)*scan z a k + z k*a k

def semantics (s : Nat) (v : Label → F) : Node → F
  | .sink b => bit b
  | .y j => v (.y j)
  | .z i j => v (.z i j)*v (.y j)
  | .col i k => scan (fun j => v (.col i j)) (fun j => v (.z i j)*v (.y j)) k
  | .x i => v (.x i)*scan (fun j => v (.col i j)) (fun j => v (.z i j)*v (.y j)) s
  | .row k => scan (fun i => v (.row i)) (fun i => v (.x i)*
      scan (fun j => v (.col i j)) (fun j => v (.z i j)*v (.y j)) s) k

theorem respects_edges (s : Nat) (v : Label → F) (a : Node) :
    semantics s v a = (match step s a with
    | .stop b => bit b
    | .ask i l h => (1-v i)*semantics s v l + v i*semantics s v h) := by
  cases a with
  | sink b => rfl
  | row i => cases i <;> rfl
  | col i j => cases j <;> rfl
  | x i => simp [semantics,step,bit]
  | y j => simp [semantics,step,bit]
  | z i j => simp [semantics,step,bit]

def weight (q : F) (n i : Nat) := q*(1-q)^(n-1-i)
theorem scan_sum (q : F) (a : Nat → F) (n) :
    scan (fun _ => q) a n = ∑ i ∈ Finset.range n, weight q n i * a i := by
  induction n with
  | zero => simp [scan]
  | succ n ih =>
    rw [scan,ih,Finset.mul_sum,Finset.sum_range_succ]
    congr 1
    · apply Finset.sum_congr rfl
      intro i hi
      have lt := Finset.mem_range.mp hi
      rw [weight,weight,show n+1-1-i=(n-1-i)+1 by omega,pow_succ]; ring
    · simp [weight]

def extra {r s : Nat} (q : F) (A : MatrixData r s F) : Label → F
  | .row _ | .col _ _ => q
  | .z i j => if hi : i < r then if hj : j < s then
      A ⟨i,hi⟩ ⟨j,hj⟩ / (weight q r i * weight q s j) else 0 else 0
  | _ => 0

def inputs {r s : Nat} (q : F) (A : MatrixData r s F) (xy : BiPoint r s F) : Label → F
  | .x i => if hi : i < r then xy.1 ⟨i,hi⟩ else 0
  | .y j => if hj : j < s then xy.2 ⟨j,hj⟩ else 0
  | v => extra q A v

theorem represents {r s} (q : F) (q0 : q ≠ 0) (q1 : 1-q ≠ 0)
    (A : MatrixData r s F) (xy : BiPoint r s F) :
    semantics s (inputs q A xy) (.row r) = bilinear A xy := by
  classical
  simp only [semantics,inputs,extra,scan_sum,bilinear,← Fin.sum_univ_eq_sum_range]
  rw [Finset.sum_congr rfl (g := fun i : Fin r => ∑ j : Fin s, A i j * xy.1 i * xy.2 j) (by
    intro i _
    rw [← mul_assoc,Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro j _
    simp only [dif_pos i.isLt,dif_pos j.isLt]
    have a : weight q r i ≠ 0 := mul_ne_zero q0 (pow_ne_zero _ q1)
    have b : weight q s j ≠ 0 := mul_ne_zero q0 (pow_ne_zero _ q1)
    field_simp
    <;> ring)]

theorem fixed_graph_lower {r s} [Fintype F] (q : F) (q0 : q ≠ 0) (q1 : 1-q ≠ 0)
    (H : List (BiPoint r s F)) (hits : ∀ A : MatrixData r s F,
      (∃ xy, semantics s (inputs q A xy) (.row r) ≠ 0) →
      ∃ xy ∈ H, semantics s (inputs q A xy) (.row r) ≠ 0) : r*s ≤ H.length := by
  apply matrix_lower H
  intro A hA
  simp only [represents q q0 q1] at hits
  apply hits A
  obtain ⟨v,_,hv⟩ := (matrix_exact (F := F) r s).2 A hA
  exact ⟨v,hv⟩
end FBDD.Selector
