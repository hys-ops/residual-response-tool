import FBDD.Polynomial

namespace FBDD
open Finset
/-- Deterministic minimizer with a fixed tie policy and enumeration order. -/
def best {X} (cost : X → Nat) (fallback : X) : List X → X
  | [] => fallback
  | x::xs => let b := best cost fallback xs; if cost x ≤ cost b then x else b

theorem best_le {X} (c : X → Nat) (x₀ : X) (xs : List X) (x : X) (hx : x ∈ xs) :
    c (best c x₀ xs) ≤ c x := by
  induction xs with
  | nil => simp at hx
  | cons y ys ih =>
    simp only [best]
    split <;> rcases List.mem_cons.mp hx with rfl | ht
    · rfl
    · exact le_trans (by assumption) (ih ht)
    · omega
    · exact ih ht

variable {R X : Type} (miss : R → X → Bool)
def remRows (U : Finset R) (x : X) := U.filter (fun r => miss r x)
def greedy (xs : List X) (x₀ : X) : Nat → Finset R → List X × Finset R
  | 0, U => ([], U)
  | t+1, U =>
    let x := best (fun y => (remRows miss U y).card) x₀ xs
    let (H,W) := greedy xs x₀ t (remRows miss U x)
    (x::H,W)

theorem greedy_spec (xs : List X) (x₀ : X) (t) (U : Finset R) :
    (greedy miss xs x₀ t U).1.length = t ∧
    ∀ r, r ∈ (greedy miss xs x₀ t U).2 ↔ r ∈ U ∧ ∀ x ∈ (greedy miss xs x₀ t U).1, miss r x := by
  induction t generalizing U with
  | zero => simp [greedy]
  | succ t ih =>
    let x := best (fun y => (remRows miss U y).card) x₀ xs
    obtain ⟨hlen,hs⟩ := ih (remRows miss U x)
    refine ⟨congrArg Nat.succ hlen, ?_⟩
    intro r
    change r ∈ (greedy miss xs x₀ t (remRows miss U x)).2 ↔ r ∈ U ∧
      ∀ y ∈ x :: (greedy miss xs x₀ t (remRows miss U x)).1, miss r y
    rw [hs]; simp [remRows, and_assoc]

theorem count_step [Fintype X] [Nonempty X] (xs : List X) (x₀ : X) (all : ∀ x, x ∈ xs)
    (U : Finset R) (p k : Nat)
    (hz : ∀ r ∈ U, p * (univ.filter (fun x => miss r x)).card ≤ k * Fintype.card X) :
    p * (remRows miss U (best (fun y => (remRows miss U y).card) x₀ xs)).card ≤ k * U.card := by
  classical
  let c := fun x => (remRows miss U x).card
  let b := best c x₀ xs
  have e : ∑ x : X, c x = ∑ r ∈ U, (univ.filter (fun x => miss r x)).card := by
    simp only [c,remRows,Finset.card_filter]; rw [Finset.sum_comm]
  apply Nat.le_of_mul_le_mul_left (c := Fintype.card X) _ Fintype.card_pos
  calc
    Fintype.card X * (p * c b) = ∑ _ : X, p * c b := by simp
    _ ≤ ∑ x : X, p * c x := Finset.sum_le_sum (fun x _ => Nat.mul_le_mul_left _ (best_le c x₀ xs x (all x)))
    _ = ∑ r ∈ U, p * (univ.filter (fun x => miss r x)).card := by rw [← Finset.mul_sum,e,Finset.mul_sum]
    _ ≤ ∑ _ ∈ U, k * Fintype.card X := Finset.sum_le_sum hz
    _ = _ := by simp; ring

theorem greedy_shrink [Fintype X] [Nonempty X] (xs : List X) (x₀ : X) (all : ∀ x, x ∈ xs)
    (p k : Nat) (t) (U : Finset R)
    (hz : ∀ r ∈ U, p * (univ.filter (fun x => miss r x)).card ≤ k * Fintype.card X) :
    p^t * (greedy miss xs x₀ t U).2.card ≤ k^t * U.card := by
  induction t generalizing U with
  | zero => simp [greedy]
  | succ t ih =>
    let b := best (fun y => (remRows miss U y).card) x₀ xs
    let W := remRows miss U b
    have hw := ih W (fun r hr => hz r ((Finset.mem_filter.mp hr).1))
    have h := count_step miss xs x₀ all U p k hz
    change p^(t+1) * (greedy miss xs x₀ t W).2.card ≤ k^(t+1) * U.card
    calc
      _ = p * (p^t * (greedy miss xs x₀ t W).2.card) := by rw [pow_succ]; ring
      _ ≤ p * (k^t * W.card) := Nat.mul_le_mul_left _ hw
      _ = k^t * (p * W.card) := by ring
      _ ≤ k^t * (k * U.card) := Nat.mul_le_mul_left _ h
      _ = _ := by rw [pow_succ]; ring

theorem rounds {p k e : Nat} (hk : k*k < p) (hp : 1 < p) :
    k^(2*e+2) * p^e < p^(2*e+2) := by
  have h₂ : k^2 ≤ p := by simpa [pow_two] using hk.le
  have h₁ : k^(2*e+2) ≤ p^(e+1) := by
    rw [show 2*e+2 = 2*(e+1) by omega,pow_mul]
    exact Nat.pow_le_pow_left h₂ _
  calc
    _ ≤ p^(e+1)*p^e := Nat.mul_le_mul_right _ h₁
    _ = p^(e+1+e) := (pow_add ..).symm
    _ < _ := Nat.pow_lt_pow_right hp (by omega)

theorem zero_count {F : Type} [Field F] [Fintype F] [DecidableEq F] {d k : Nat}
    (f : Poly (Fin d) F) (hf : f ≠ 0) (hd : f.totalDegree ≤ k) :
    Fintype.card F * (univ.filter (fun x : Fin d → F => MvPolynomial.eval x f = 0)).card
      ≤ k * Fintype.card (Fin d → F) := by
  classical
  have h := MvPolynomial.schwartz_zippel_totalDegree hf (Finset.univ : Finset F)
  simp only [Fintype.piFinset_univ,Finset.card_univ] at h
  have hp : (0 : NNRat) < Fintype.card F := by exact_mod_cast Fintype.card_pos
  have hq : (0 : NNRat) < (Fintype.card F : NNRat)^d := pow_pos hp _
  have hnat : (univ.filter (fun x : Fin d → F => MvPolynomial.eval x f = 0)).card * Fintype.card F
      ≤ f.totalDegree * (Fintype.card F)^d := by
    exact_mod_cast (div_le_div_iff₀ (by positivity) (by positivity)).mp h
  simpa [Nat.mul_comm, Fintype.card_fun] using hnat.trans (Nat.mul_le_mul_right _ hd)

end FBDD
