import FBDD.Run
namespace FBDD.Examples
def base : Net (Fin 2) 2 := .leaf (.leaf .empty false) true
/-- Leaf 0 is true and leaf 1 is false in base. -/
def conjunction (i j : Fin 2) : Net (Fin 2) 4 :=
  .gate (.gate base j 1 0) i 2 0
def xy := conjunction 0 1
def yx := conjunction 1 0
def onlyY : Net (Fin 2) 3 := .gate base 1 1 0
instance : Fact (Nat.Prime 5) := ⟨by decide⟩
#eval testPair xy yx 0 0 5 1
#eval testPair xy onlyY 0 0 5 1
#eval (blockResult xy onlyY 0 0 5 1).map (fun b => (b 0,b 1))
#eval (solve xy onlyY 0 0).map (fun b => (b 0,b 1))
#eval (solve xy yx 0 0).isNone
end FBDD.Examples
