import FBDD.Output
import FBDD.Selector
namespace FBDD.Output
open Finset
variable {I X F : Type} [Fintype I] [Fintype X] [Field F] [Nonempty X]

def rowHits (M : Matrix I X F) (T : Finset X) :=
  ∀ i, (∀ x ∈ T, M i x = 0) → M i = 0

noncomputable def catalogueSize (M : Matrix I X F) := by
  classical
  exact ((univ : Finset I).image M).card

theorem min_hit (good : Finset X → Prop) (all : good univ) :
    ∃ T : Finset X, T.Nonempty ∧ good T ∧ ∀ U, U.Nonempty → good U → T.card ≤ U.card := by
  classical
  let S := (univ : Finset (Finset X)).filter (fun T => T.Nonempty ∧ good T)
  obtain ⟨T,h,least⟩ := S.exists_min_image Finset.card
    ⟨univ,mem_filter.mpr ⟨mem_univ _,univ_nonempty,all⟩⟩
  exact ⟨T,(mem_filter.mp h).2.1,(mem_filter.mp h).2.2,fun U hu hU =>
    least U (mem_filter.mpr ⟨mem_univ _,hu,hU⟩)⟩

noncomputable def probes (M : Matrix I X F) : Nat := by
  classical
  exact Nat.find (p := fun n => ∃ T : Finset X, T.Nonempty ∧ rowHits M T ∧ T.card = n)
    ⟨_,univ,univ_nonempty,fun i hf => funext (fun x => hf x (mem_univ _)),rfl⟩

theorem cat_opt (M : Matrix I X F) :
    (∃ T : Finset X, T.Nonempty ∧ rowHits M T ∧ T.card = probes M) ∧
    ∀ U : Finset X, U.Nonempty → rowHits M U → probes M ≤ U.card := by
  classical
  unfold probes
  exact ⟨Nat.find_spec (p := fun n => ∃ T : Finset X, T.Nonempty ∧ rowHits M T ∧ T.card = n) _,
    fun U hu hU => Nat.find_min' _ ⟨U,hu,hU,rfl⟩⟩

theorem span_opt (M : Matrix I X F) :
    let W := Submodule.span F (Set.range M.row)
    (∃ T : Finset X, T.Nonempty ∧ detects W T ∧ T.card = max 1 M.rank) ∧
    ∀ U : Finset X, U.Nonempty → detects W U → max 1 M.rank ≤ U.card := by
  classical
  obtain ⟨T,hit,eq,min⟩ := span_matrix M
  refine ⟨?_,fun U hu hU => max_le (card_pos.mpr hu) (eq ▸ min U hU)⟩
  by_cases ht : T.Nonempty
  · exact ⟨T,ht,hit,by rw [← eq,max_eq_right (card_pos.mpr ht)]⟩
  · have et : T = ∅ := not_nonempty_iff_eq_empty.mp ht
    let x : X := Classical.choice inferInstance
    refine ⟨{x},singleton_nonempty x,fun f _ => hit f (by simp [et]),?_⟩
    simp [← eq,et]

structure Table (F : Type) where
  rows : Nat
  cols : Nat
  nonempty : 0 < cols
  matrix : Matrix (Fin rows) (Fin cols) F
  catalogue : Bool

def allowed (B : Table F) (S : Finset (Fin B.cols)) :=
  S.Nonempty ∧ if B.catalogue then rowHits B.matrix S else
    detects (Submodule.span F (Set.range B.matrix.row)) S

noncomputable def localPair (B : Table F) : Nat×Nat := by
  letI : Nonempty (Fin B.cols) := ⟨⟨0,B.nonempty⟩⟩
  exact if B.catalogue then (catalogueSize B.matrix,probes B.matrix) else (0,max 1 B.matrix.rank)

theorem local_pair_exact (B : Table F) :
    (∃ S, allowed B S ∧ S.card = (localPair B).2) ∧
    ∀ S, allowed B S → (localPair B).2 ≤ S.card := by
  letI : Nonempty (Fin B.cols) := ⟨⟨0,B.nonempty⟩⟩
  cases e : B.catalogue
  · obtain ⟨⟨T,nt,ok,eq⟩,lb⟩ := span_opt B.matrix
    simp only [localPair,allowed,e,Bool.false_eq_true,if_false]
    exact ⟨⟨T,⟨nt,ok⟩,eq⟩,fun U h => lb U h.1 h.2⟩
  · obtain ⟨⟨T,nt,ok,eq⟩,lb⟩ := cat_opt B.matrix
    simp only [localPair,allowed,e,if_true]
    exact ⟨⟨T,⟨nt,ok⟩,eq⟩,fun U h => lb U h.1 h.2⟩

inductive Actual (F : Type) [Field F] : List (Table F) → Nat → Nat → Prop where
  | nil : Actual F [] 0 1
  | cons {B : Table F} {bs rc prod} (S : Finset (Fin B.cols)) : allowed B S →
      Actual F bs rc prod → Actual F (B::bs) ((localPair B).1+rc) (S.card*prod)

theorem actual_optimum (bs : List (Table F)) :
    let pairs := bs.map localPair
    Actual F bs (records pairs) (points pairs) ∧ ∀ c p, Actual F bs c p → total pairs ≤ c+p := by
  constructor
  · induction bs with
    | nil => exact .nil
    | cons B bs ih =>
      obtain ⟨S,ok,eq⟩ := (local_pair_exact B).1
      simpa [records,points,eq] using Actual.cons S ok ih
  · intro c p run
    apply (fixed_optimum _).2
    induction run with
    | nil => exact .nil
    | cons S ok run ih => exact .cons le_rfl ((local_pair_exact _).2 S ok) ih

theorem all_plans (plans : List (List (Table F))) (ne : plans ≠ []) :
    ∃ best ∈ plans, Actual F best (records (best.map localPair)) (points (best.map localPair)) ∧
    ∀ bs ∈ plans, ∀ c p, Actual F bs c p → total (best.map localPair) ≤ c+p := by
  classical
  let P := plans.toFinset
  have pos : P.Nonempty := by obtain ⟨b,h⟩ := List.exists_mem_of_ne_nil plans ne; exact ⟨b,List.mem_toFinset.mpr h⟩
  obtain ⟨best,hb,low⟩ := P.exists_min_image (fun bs => total (bs.map localPair)) pos
  exact ⟨best,List.mem_toFinset.mp hb,(actual_optimum best).1,fun bs h c p run =>
    (low _ (List.mem_toFinset.mpr h)).trans ((actual_optimum bs).2 c p run)⟩
end FBDD.Output
