import FBDD.Advice
namespace FBDD
inductive BTree (V : Type) where
  | leaf : Bool → BTree V
  | branch : V → BTree V → BTree V → BTree V

def unroll {V : Type} : {m : Nat} → Net V m → Fin m → BTree V
  | _, .empty => Fin.elim0
  | _, .leaf p b => Fin.cases (.leaf b) (unroll p)
  | _, .gate p i l h => Fin.cases (.branch i (unroll p l) (unroll p h)) (unroll p)

namespace BTree
def value {V} (x : V → Bool) : BTree V → Bool
  | .leaf b => b
  | .branch i l h => if x i then h.value x else l.value x

def depth {V} : BTree V → Nat
  | .leaf _ => 0
  | .branch _ l h => max l.depth h.depth + 1

def visits {V} : BTree V → Nat
  | .leaf _ => 1
  | .branch _ l h => 1 + l.visits + h.visits

theorem visits_le {V} (t : BTree V) : t.visits + 1 ≤ 2^(t.depth+1) := by
  induction t with
  | leaf b => simp [visits,depth]
  | branch i l h il ih =>
    have sl := Nat.pow_le_pow_right (show 0 < 2 by decide) (Nat.succ_le_succ (Nat.le_max_left l.depth h.depth))
    have sh := Nat.pow_le_pow_right (show 0 < 2 by decide) (Nat.succ_le_succ (Nat.le_max_right l.depth h.depth))
    simp only [visits,depth,pow_succ _ (max _ _ + 1)]
    omega

def cells {V} (available : Nat) : BTree V → Nat
  | .leaf _ => 2^available
  | .branch _ l h => l.cells (available-1) + h.cells (available-1)

theorem cells_eq {V} (t : BTree V) (n) (h : t.depth ≤ n) : t.cells n = 2^n := by
  induction t generalizing n with
  | leaf b => rfl
  | branch i l u il iu =>
    cases n with
    | zero => simp [depth] at h
    | succ n =>
      have le : max l.depth u.depth ≤ n := by simpa [depth] using h
      rw [cells, Nat.add_sub_cancel,il n ((Nat.le_max_left ..).trans le),
        iu n ((Nat.le_max_right ..).trans le),pow_succ]
      omega

/-- A leaf has one address, precisely the sequence of Boolean edge choices.
Every complete assignment has exactly one compatible leaf. -/
def trace {V} (x : V → Bool) : BTree V → List Bool × Bool
  | .leaf b => ([],b)
  | .branch i l h =>
    let ans := if x i then h.trace x else l.trace x
    (x i :: ans.1,ans.2)

inductive Compatible {V} (x : V → Bool) : BTree V → List Bool → Bool → Prop where
  | leaf (b) : Compatible x (.leaf b) [] b
  | low {i l h tail b} : x i = false → Compatible x l tail b → Compatible x (.branch i l h) (false::tail) b
  | high {i l h tail b} : x i = true → Compatible x h tail b → Compatible x (.branch i l h) (true::tail) b

theorem trace_compatible {V} (x : V → Bool) (t : BTree V) :
    Compatible x t (t.trace x).1 (t.trace x).2 ∧ (t.trace x).2 = t.value x := by
  induction t with
  | leaf b => exact ⟨.leaf _,rfl⟩
  | branch i l h il ih =>
    cases e : x i
    · simpa [trace,value,e] using And.intro (Compatible.low (h := h) e il.1) il.2
    · simpa [trace,value,e] using And.intro (Compatible.high (l := l) e ih.1) ih.2

theorem trace_unique {V} {x : V → Bool} {t : BTree V} {p b} (ok : Compatible x t p b) :
    t.trace x = (p,b) := by
  induction ok with
  | leaf => rfl
  | low e _ ih => simp [trace,e,ih]
  | high e _ ih => simp [trace,e,ih]
end BTree

theorem unroll_value {V} {m} (p : Net V m) (r : Fin m) (x : V → Bool) :
    (unroll p r).value x = p.boolVal x r := by
  induction p with
  | empty => exact Fin.elim0 r
  | leaf d b ih => exact Fin.cases rfl (fun j => ih j) r
  | gate d i l h ih =>
    refine Fin.cases ?_ (fun j => ih j) r
    cases e : x i <;> simp [unroll,Net.boolVal,BTree.value,e,ih]

theorem unroll_depth {V} [DecidableEq V] {m} (p : Net V m) (fr : p.free) (r : Fin m)
    (S : Finset V) (ok : ∀ v, p.uses v r → v ∈ S) : (unroll p r).depth ≤ S.card := by
  induction p generalizing S with
  | empty => exact Fin.elim0 r
  | leaf d b ih =>
    revert ok; refine Fin.cases (fun _ => Nat.zero_le _) (fun j hj => ih fr j S hj) r
  | gate d i l h ih =>
    revert ok; refine Fin.cases ?_ (fun j hj => ih fr.1 j S hj) r
    intro ok
    have mem := ok i (Or.inl rfl)
    have next (j : _) (reach : ∀ v, d.uses v j → (Net.gate d i l h).uses v 0)
        (no : ¬d.uses i j) : (unroll d j).depth ≤ (S.erase i).card := by
      apply ih fr.1
      intro v hv
      exact Finset.mem_erase.mpr ⟨fun e => no (e ▸ hv), ok v (reach v hv)⟩
    have a := next l (fun _ hv => Or.inr (Or.inl hv)) fr.2.1
    have b := next h (fun _ hv => Or.inr (Or.inr hv)) fr.2.2
    have pos := Finset.card_pos.mpr ⟨i,mem⟩
    rw [Finset.card_erase_of_mem mem] at a b
    change max _ _ + 1 ≤ _
    omega

theorem dense_counts {V} [DecidableEq V] [Fintype V] {m}
    (p : Net V m) (fr : p.free) (r : Fin m) :
    let n := Fintype.card V
    (unroll p r).visits + 1 ≤ 2^(n+1) ∧ (unroll p r).cells n = 2^n := by
  have h := unroll_depth p fr r Finset.univ (fun _ _ => Finset.mem_univ _)
  exact ⟨(BTree.visits_le _).trans (Nat.pow_le_pow_right (by decide) (Nat.succ_le_succ h)),
      BTree.cells_eq _ _ h⟩

/-- Indistinguishability on a deterministic adaptive run: a full-depth parity
tree can independently swap its last gate at each prefix address. -/
def queries {V} (x : V → Bool) : BTree V → List V
  | .leaf _ => []
  | .branch i l h => i :: (if x i then queries x h else queries x l)

theorem agree_on_queries {V} (t : BTree V) (x y : V → Bool)
    (ok : ∀ i ∈ queries x t, x i = y i) : t.value x = t.value y := by
  induction t with
  | leaf b => rfl
  | branch i l h il ih =>
    have eq := ok i (by simp [queries])
    cases e : x i <;> simp [BTree.value,e,← eq] <;>
      first | apply il; intro j hj; exact ok j (by simp [queries,e,hj])
            | apply ih; intro j hj; exact ok j (by simp [queries,e,hj])

def oriented {I} (change : I → Bool) (prefixBit : I → Bool) (prefixId : I) (lastBit : Bool) :=
  (prefixBit prefixId ^^ lastBit) ^^ change prefixId

theorem dense_probes {I} [Fintype I] [DecidableEq I] (parity : I → Bool) (test : BTree I)
    (correct : ∀ change, test.value change = true ↔
       ∀ i b, oriented change parity i b = oriented (fun _ => false) parity i b) :
    Fintype.card I ≤ (queries (fun _ => false) test).length := by
  classical
  let z : I → Bool := fun _ => false
  have hz : test.value z = true := (correct _).mpr (fun _ _ => rfl)
  have full (i : I) : i ∈ queries z test := by
    by_contra miss
    let y := Function.update z i true
    have eq : test.value z = test.value y := agree_on_queries test z y
      (fun j hj => by
        have ne : j ≠ i := by rintro rfl; exact miss hj
        exact (Function.update_of_ne ne true z).symm)
    have both := (correct y).mp (eq ▸ hz) i false
    cases he : parity i <;> simp [oriented,y,z,he] at both
  have h : (queries z test).toFinset = Finset.univ := Finset.eq_univ_of_forall (by simpa using full)
  rw [← Finset.card_univ,← h]
  exact List.toFinset_card_le _
end FBDD
