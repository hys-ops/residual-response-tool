import FBDD.Selector
namespace FBDD.Selector
/-- Finite trace, including prefixes of runs. -/
inductive Path (s : Nat) : Node → List Label → Prop where
  | nil (v) : Path s v []
  | low {v i l h xs} : step s v = .ask i l h → Path s l xs → Path s v (i::xs)
  | high {v i l h xs} : step s v = .ask i l h → Path s h xs → Path s v (i::xs)

theorem path_free {r s v xs} (ok : legal r s v) (run : Path s v xs) :
    xs.Nodup ∧ ∀ i ∈ xs, rank s (owner i) ≤ rank s v := by
  induction run with
  | nil v => simp
  | @low v i l h xs e _ ih =>
    obtain ⟨o,rl,_,ol,_⟩ := edge_certificate ok e
    obtain ⟨nd,bd⟩ := ih ol
    refine ⟨List.nodup_cons.mpr ⟨?_,nd⟩,?_⟩
    · intro hi; have le := bd i hi; rw [←o] at le; omega
    · intro j hj
      rcases List.mem_cons.mp hj with rfl|mem
      · rw [←o]
      · exact (bd _ mem).trans rl.le
  | @high v i l h xs e _ ih =>
    obtain ⟨o,_,rh,_,oh⟩ := edge_certificate ok e
    obtain ⟨nd,bd⟩ := ih oh
    refine ⟨List.nodup_cons.mpr ⟨?_,nd⟩,?_⟩
    · intro hi; have le := bd i hi; rw [←o] at le; omega
    · intro j hj
      rcases List.mem_cons.mp hj with rfl|mem
      · rw [←o]
      · exact (bd _ mem).trans rh.le

theorem root_read_once (r s : Nat) (xs : List Label) (run : Path s (.row r) xs) : xs.Nodup :=
  (path_free (r := r) (show legal r s (.row r) from le_rfl) run).1
end FBDD.Selector
