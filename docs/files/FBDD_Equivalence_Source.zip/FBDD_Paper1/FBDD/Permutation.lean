import FBDD.Budgets
import Mathlib.Data.Fintype.Perm
namespace FBDD.Permutation
abbrev Word (r : Nat) := Fin r → Bool
inductive Node where
  | prefix : List Bool → Node
  | suffix : List Bool → Node
  | reject : Node
  deriving DecidableEq

def valid (r : Nat) : Node → Prop
  | .prefix w | .suffix w => w.length ≤ r
  | .reject => True

def vertices (r : Nat) :=
  [Node.reject] ++ (words [false,true] r).map Node.prefix ++ (words [false,true] r).map Node.suffix

theorem listed {r} (v : Node) : v ∈ vertices r ↔ valid r v := by
  have e (w : List Bool) : w ∈ words [false,true] r ↔ w.length ≤ r := by
    exact ⟨words_size_of_mem,fun h => mem_words _ h (fun b _ => by cases b <;> simp)⟩
  cases v <;> simp [vertices,valid,e]

theorem vertex_count (r : Nat) : (vertices r).length+1 = 4*2^r := by
  have eq (n) : (words [false,true] n).length+1 = 2*2^n := by
    induction n with
    | zero => decide
    | succ n ih => simp [words,pow_succ] at *; omega
  have h := eq r
  simp [vertices]; omega

/-- Epsilon jumps only link the x-selector leaves to shared y-suffix comparators. -/
inductive Move where
  | done : Bool → Move
  | jump : Node → Move
  | test : Nat → Node → Node → Move

def wordOf (r : Nat) (s : List Bool) : Word r := fun i => s[i.val]?.getD false

def step {r} (π : Equiv.Perm (Word r)) : Node → Move
  | .reject => .done false
  | .prefix xs => if xs.length < r then .test xs.length (.prefix (xs++[false])) (.prefix (xs++[true]))
    else .jump (.suffix (List.ofFn (π (wordOf r xs))))
  | .suffix [] => .done true
  | .suffix (b::bs) => .test (2*r-(b::bs).length)
    (if b then .reject else .suffix bs) (if b then .suffix bs else .reject)

def eval {r} (π : Equiv.Perm (Word r)) (x y : Word r) : Node → Bool
  | .reject => false
  | .prefix xs => decide (π (wordOf r (xs ++ (List.ofFn x).drop xs.length)) = y)
  | .suffix ys => decide (ys = (List.ofFn y).drop (r-ys.length))

def assignment {r} (x y : Word r) (i : Nat) : Bool :=
  if h : i < r then x ⟨i,h⟩ else (List.ofFn y)[i-r]?.getD false

theorem drop_split {A} (xs : List A) (i : Nat) (hi : i < xs.length) :
    xs.drop i = xs[i] :: xs.drop (i+1) := by
  induction xs generalizing i with
  | nil => simp at hi
  | cons a xs ih => cases i with
    | zero => rfl
    | succ j => exact ih j (by simpa using hi)

theorem row_ext (r : Nat) (w : Word r) : wordOf r (List.ofFn w) = w := by
  funext i; simp [wordOf,i.isLt]

theorem step_eval {r} (π : Equiv.Perm (Word r)) (x y : Word r) (a : Node) (ok : valid r a) :
    eval π x y a = match step π a with
      | .done b => b
      | .jump v => eval π x y v
      | .test i l h => eval π x y (if assignment x y i then h else l) := by
  cases a with
  | reject => rfl
  | «prefix» xs =>
    by_cases h : xs.length < r
    · have z := drop_split (List.ofFn x) xs.length (by simpa using h)
      simp only [List.getElem_ofFn] at z
      cases bitval : x ⟨xs.length,h⟩ <;>
        simp [step,h,assignment,eval,List.append_assoc,z,bitval] at *
    · have len : xs.length = r := by change xs.length ≤ r at ok; omega
      have drop : (List.ofFn x).drop r = [] := List.drop_eq_nil_of_le (by simp)
      simp [step,h,eval,len,List.ofFn_inj,drop]
  | suffix ys =>
    cases ys with
    | nil => simp [step,eval]
    | cons b bs =>
      change (b::bs).length ≤ r at ok
      let j := r-(b::bs).length
      have h : j < r := by simp [j] at *; omega
      have diff : 2*r-(b::bs).length = r+j := by dsimp [j]; simp only [List.length_cons] at ok ⊢; omega
      have nxt : j+1 = r-bs.length := by dsimp [j]; simp only [List.length_cons] at ok ⊢; omega
      have z := drop_split (List.ofFn y) j (by simpa using h)
      simp only [List.getElem_ofFn] at z
      have get : (List.ofFn y)[j]?.getD false = y ⟨j,h⟩ := by simp [h]
      have sel : assignment x y (r+j) = y ⟨j,h⟩ := by simpa [assignment] using get
      cases e : y ⟨j,h⟩ <;> cases b <;>
        simp only [step,diff,sel,e,Bool.false_eq_true,if_false,if_true,eval] <;>
        change decide (_ = (List.ofFn y).drop j) = _ <;> rw [z,e,nxt] <;> simp [eval]

/-- An increasing level for every query: the two halves use disjoint labels. -/
def level (r : Nat) : Node → Nat
  | .prefix xs => xs.length
  | .suffix ys => 2*r-ys.length
  | .reject => 2*r+1

theorem ordered_edges {r} (π : Equiv.Perm (Word r)) (a : Node) (ok : valid r a) :
    match step π a with
    | .done _ => True
    | .jump d => valid r d ∧ level r a ≤ level r d
    | .test i l h => i = level r a ∧ valid r l ∧ valid r h ∧
      level r a < level r l ∧ level r a < level r h := by
  cases a with
  | reject => trivial
  | «prefix» xs =>
    change xs.length ≤ r at ok
    by_cases g : xs.length < r
    · simp [step,g,valid,level]; omega
    · have e : xs.length = r := by omega
      simp [step,g,valid,level,e]; omega
  | suffix ys => cases ys with
    | nil => trivial
    | cons b bs => cases b <;> simp_all [step,valid,level] <;> omega

theorem root_value {r} (π : Equiv.Perm (Word r)) (x y : Word r) :
    eval π x y (.prefix []) = decide (π x = y) := by simp [eval,row_ext]

theorem distinguish {r} (π σ : Equiv.Perm (Word r)) (h : π ≠ σ) :
    ∃ x y, eval π x y (.prefix []) ≠ eval σ x y (.prefix []) := by
  by_contra! hn
  apply h
  apply Equiv.ext
  intro x
  simpa [root_value] using (hn x (σ x))

theorem signature_bound {F : Type} [Fintype F] {r h} (code : Equiv.Perm (Word r) → Fin h → F)
    (hit : ∀ π σ, (∃ x y, eval π x y (.prefix []) ≠ eval σ x y (.prefix [])) → code π ≠ code σ) :
    Nat.factorial (2^r) ≤ (Fintype.card F)^h := by
  classical
  have hc := Fintype.card_le_of_injective code (fun {π σ} e => by by_contra ne; exact hit π σ (distinguish π σ ne) e)
  simpa [Word,Fintype.card_fun,Fintype.card_perm] using hc

/-- A concrete linear lower bound: if m=2^(r+1), p ≤ (m/2)^8 and r≥1,
a universally separating list has h ≥ m/16. -/
theorem linear_lower {F : Type} [Fintype F] {r h} (hr : 0 < r)
    (pbound : Fintype.card F ≤ (2^r)^8)
    (code : Equiv.Perm (Word (r+1)) → Fin h → F)
    (hit : ∀ π σ, (∃ x y, eval π x y (.prefix []) ≠ eval σ x y (.prefix [])) → code π ≠ code σ) :
    2^r ≤ 8*h := by
  let m := 2^r
  have sig := signature_bound code hit
  rw [pow_succ,show 2^r * 2 = m+m by dsimp [m]; omega] at sig
  have lo : m^m ≤ Nat.factorial (m+m) := by
    have f := Nat.factorial_mul_pow_le_factorial (m := m) (n := m)
    have mpos := Nat.factorial_pos m
    calc
      _ ≤ (m+1)^m := Nat.pow_le_pow_left (by omega) _
      _ ≤ m.factorial*(m+1)^m := by simpa using Nat.mul_le_mul_right ((m+1)^m) mpos
      _ ≤ _ := f
  have ub := Nat.pow_le_pow_left pbound h
  change (Fintype.card F)^h ≤ (m^8)^h at ub
  rw [←pow_mul] at ub
  by_contra! hn
  have mp : 1 < m := Nat.one_lt_pow hr.ne' (by decide)
  exact (not_lt_of_ge ((lo.trans sig).trans ub)) (Nat.pow_lt_pow_right mp hn)

def resolve {r} (π : Equiv.Perm (Word r)) : Node → Node
  | .prefix xs => if xs.length < r then .prefix xs else .suffix (List.ofFn (π (wordOf r xs)))
  | v => v

theorem resolve_value {r} (π : Equiv.Perm (Word r)) (x y : Word r) (a : Node) (ok : valid r a) :
    eval π x y (resolve π a) = eval π x y a := by
  cases a with
  | reject => rfl
  | suffix _ => rfl
  | «prefix» xs =>
    by_cases h : xs.length < r
    · simp [resolve,h]
    · simpa [resolve,step,h] using (step_eval π x y (.prefix xs) ok).symm

theorem resolve_range {r} (π : Equiv.Perm (Word r)) (a : Node) (ok : valid r a) :
    valid r (resolve π a) ∧ level r a ≤ level r (resolve π a) := by
  cases a with
  | reject => exact ⟨ok,le_rfl⟩
  | suffix _ => exact ⟨ok,le_rfl⟩
  | «prefix» xs =>
    by_cases h : xs.length < r
    · simp_all [resolve]
    · simpa [resolve,step,h] using ordered_edges π (.prefix xs) ok

inductive Gate where
  | terminal : Bool → Gate
  | query : Nat → Node → Node → Gate

def direct {r} (π : Equiv.Perm (Word r)) (v : Node) : Gate :=
  match step π (resolve π v) with
  | .done b => .terminal b
  | .test i l h => .query i (resolve π l) (resolve π h)
  | .jump _ => .terminal false

theorem no_jump {r} (π : Equiv.Perm (Word r)) (a d : Node) : step π (resolve π a) ≠ .jump d := by
  cases a with
  | reject => simp [resolve,step]
  | suffix ys => cases ys <;> simp [resolve,step]
  | «prefix» xs =>
    by_cases h : xs.length < r
    · simp [resolve,step,h]
    · simp only [resolve,h,if_false]
      cases List.ofFn (π (wordOf r xs)) <;> simp [step]

theorem direct_correct {r} (π : Equiv.Perm (Word r)) (x y : Word r) (a : Node) (ok : valid r a) :
    eval π x y a = (match direct π a with
    | .terminal b => b
    | .query i l h => eval π x y (if assignment x y i then h else l)) := by
  have z := resolve_range π a ok
  have e := step_eval π x y (resolve π a) z.1
  rw [resolve_value π x y a ok] at e
  have shape := ordered_edges π (resolve π a) z.1
  cases q : step π (resolve π a) with
  | done b => simpa [direct,q] using e
  | jump d => exact (no_jump π a d q).elim
  | test i l h =>
    rw [q] at shape
    cases b : assignment x y i <;> simpa [direct,q,b,resolve_value π x y l shape.2.1,
      resolve_value π x y h shape.2.2.1] using e

theorem direct_ordered {r} (π : Equiv.Perm (Word r)) (a : Node) (ok : valid r a) (i l h)
    (e : direct π a = .query i l h) :
    level r a ≤ i ∧ valid r l ∧ valid r h ∧ i < level r l ∧ i < level r h := by
  have z := resolve_range π a ok
  have sh := ordered_edges π (resolve π a) z.1
  cases q : step π (resolve π a) with
  | done _ => simp [direct,q] at e
  | jump _ => simp [direct,q] at e
  | test j a b =>
    rw [q] at sh; simp [direct,q] at e
    obtain ⟨rfl,rfl,rfl⟩ := e
    obtain ⟨eq,va,vb,la,lb⟩ := sh
    have ra := resolve_range π a va
    have rb := resolve_range π b vb
    exact ⟨eq ▸ z.2,ra.1,rb.1,eq ▸ la.trans_le ra.2,eq ▸ lb.trans_le rb.2⟩
end FBDD.Permutation
