import FBDD.Block
namespace FBDD
/-- Count additions and multiplications in a single affine form. -/
def Form.counted {F} [CommRing F] : {k : Nat} → Form F k → (Fin k → F) → F × Nat
  | 0,a,_ => (a,0)
  | _+1,a,v =>
    let t := Form.counted a.2 (fun j => v j.succ)
    (a.1 * v 0 + t.1, t.2+2)

theorem Form.counted_spec {F} [CommRing F] {k : Nat} (a : Form F k) (v : Fin k → F) :
    Form.counted a v = (Form.ev a v,2*k) := by
  induction k with
  | zero => rfl
  | succ k ih => simp [Form.counted,Form.ev,ih,Nat.mul_add]

def Tri.counted {I F} [CommRing F] (x : I → F) : {k : Nat} → Tri I F k → Vector F k × Nat
  | _, .nil => (#v[],0)
  | _, .step c i a =>
    let (v,n) := c.counted x
    let (z,work) := a.counted (fun j => v[j.rev.val])
    (v.push (x i*z), n+work+1)

theorem Tri.counted_spec {I F} [CommRing F] {k} (t : Tri I F k) (x : I → F) :
    (t.counted x).2 = k^2 ∧ ∀ j : Fin k, (t.counted x).1[j.rev.val] = t.run x j := by
  induction t with
  | nil => exact ⟨rfl,fun j => Fin.elim0 j⟩
  | @step k c i a ih =>
    have eq : (fun j : Fin k => (c.counted x).1[j.rev.val]) = c.run x := funext ih.2
    simp only [Tri.counted,Form.counted_spec,ih.1,eq]
    constructor
    · ring
    · intro j
      refine Fin.cases ?_ (fun u => ?_) j
      · simp only [Fin.rev_zero,Fin.val_last,Vector.getElem_push_eq,Tri.run,Fin.cases_zero]
      · simpa only [Fin.rev_succ,Fin.coe_castSucc,Vector.getElem_push_lt u.rev.isLt,
          Tri.run,Fin.cases_succ] using ih.2 u

def tabRun {I F} [CommRing F] (x : I → F) {k} (t : Tri I F k) : Fin k → F :=
  let v := (t.counted x).1
  fun j => v[j.rev.val]

@[csimp] theorem faster_recurrence : @Tri.run = @tabRun := by
  funext I F inst x k t j
  exact ((Tri.counted_spec t x).2 j).symm

theorem catalogue_entry_cost {I F} [CommRing F] {t} (a : Tri I F t × Form F t) (x : I → F) :
    let (v,n) := a.1.counted x
    let z := a.2.counted (fun j => v[j.rev.val])
    z.1 = a.2.ev (a.1.run x) ∧ n+z.2 = t^2+2*t := by
  have h := Tri.counted_spec a.1 x
  simp only [Form.counted_spec,h.1,funext h.2]
  simp
end FBDD
