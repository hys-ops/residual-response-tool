import FBDD.Greedy
import FBDD.EvalCost
namespace FBDD
open Finset
instance formFintype (F : Type) [Fintype F] : (k : Nat) → Fintype (Form F k)
  | 0 => inferInstanceAs (Fintype F)
  | k+1 => @instFintypeProd F (Form F k) _ (formFintype F k)

theorem form_card (F : Type) [Fintype F] (k : Nat) :
    Fintype.card (Form F k) = (Fintype.card F)^(k+1) := by
  induction k with
  | zero => simp [Form]
  | succ k ih =>
    change Fintype.card (F × Form F k) = _
    rw [Fintype.card_prod,ih,pow_succ _ (k+1),Nat.mul_comm]

def triZero (I F : Type) : Tri I F 0 ≃ Unit where
  toFun _ := ()
  invFun _ := .nil
  left_inv t := by cases t; rfl
  right_inv u := by cases u; rfl

def triStep (I F : Type) (k : Nat) : Tri I F (k+1) ≃ Tri I F k × I × Form F k where
  toFun | .step t i a => (t,i,a)
  invFun q := .step q.1 q.2.1 q.2.2
  left_inv t := by cases t; rfl
  right_inv q := by cases q; rfl

instance triFintype (I F : Type) [Fintype I] [Fintype F] : (k : Nat) → Fintype (Tri I F k)
  | 0 => Fintype.ofEquiv _ (triZero I F).symm
  | k+1 => by
    letI := triFintype I F k
    exact Fintype.ofEquiv _ (triStep I F k).symm

theorem tri_card_bound {I F : Type} [Fintype I] [Fintype F] (hi : Fintype.card I ≤ Fintype.card F)
    (hp : 0 < Fintype.card F) (K t : Nat) (ht : t ≤ K) :
    Fintype.card (Tri I F t) ≤ (Fintype.card F)^(t*(K+2)) := by
  induction t with
  | zero => simp [Fintype.card_congr (triZero I F)]
  | succ t ih =>
    rw [Fintype.card_congr (triStep I F t),Fintype.card_prod,Fintype.card_prod,form_card]
    let p := Fintype.card F
    have a := ih (by omega)
    have b : p^(t+1) ≤ p^(K+1) := Nat.pow_le_pow_right hp (by omega)
    calc
      _ ≤ p^(t*(K+2)) * (p * p^(K+1)) := Nat.mul_le_mul a (Nat.mul_le_mul hi b)
      _ = p^((t+1)*(K+2)) := by rw [Nat.add_mul,one_mul,pow_add p (t*(K+2)) (K+2),pow_succ p (K+1)]; ring

abbrev Description (I F : Type) (t : Nat) := Tri I F t × Form F t

theorem description_card {I F : Type} [Fintype I] [Fintype F] (hi : Fintype.card I ≤ Fintype.card F)
    (hp : 0 < Fintype.card F) {K t : Nat} (ht : t ≤ K) :
    Fintype.card (Description I F t) ≤ (Fintype.card F)^((K+1)*(K+2)) := by
  rw [Fintype.card_prod,form_card]
  calc
    _ ≤ (Fintype.card F)^(t*(K+2)) * (Fintype.card F)^(t+1) :=
      Nat.mul_le_mul_right _ (tri_card_bound hi hp K t ht)
    _ = _ := (pow_add ..).symm
    _ ≤ _ := Nat.pow_le_pow_right hp (by
      rw [Nat.add_mul]; have h := Nat.mul_le_mul_right (K+2) ht; omega)

variable {F : Type} [Field F] [Fintype F] [DecidableEq F]
abbrev Grid (d : Nat) (F : Type) := Fin d → F
/-- Given exhaustive ordered enumerations, both filtering and greedy selection
operate on field values. No identity oracle or zero-polynomial oracle is used. -/
def localList {d t} (rows : Finset (Description (Fin d) F t))
    (grid : List (Grid d F)) (rounds : Nat) : List (Grid d F) :=
  let zeroAt := fun (a : Description (Fin d) F t) (x : Grid d F) =>
    decide (Form.ev a.2 (tabRun x a.1) = 0)
  let live := rows.filter (fun a => grid.any (fun x => !zeroAt a x))
  (greedy zeroAt grid (fun _ => 0) rounds live).1

theorem localList_spec {d t K} (ht : t ≤ K) (hd : d ≤ Fintype.card F)
    (hk : K*K < Fintype.card F) (hp : 1 < Fintype.card F)
    (grid : List (Grid d F)) (all : ∀ x, x ∈ grid)
    (rows : Finset (Description (Fin d) F t)) (complete : ∀ a, a ∈ rows) :
    let T := 2*((K+1)*(K+2))+2
    let H := localList rows grid T
    H.length = T ∧ ∀ a : Description (Fin d) F t, (∃ x, Form.ev a.2 (a.1.run x) ≠ 0) →
      ∃ x ∈ H, Form.ev a.2 (a.1.run x) ≠ 0 := by
  classical
  simp only [localList, ← faster_recurrence]
  let p := Fintype.card F
  let E := (K+1)*(K+2)
  let T := 2*E+2
  let bad := fun (a : Description (Fin d) F t) (x : Grid d F) => decide (Form.ev a.2 (a.1.run x) = 0)
  let U := rows.filter (fun a => grid.any (fun x => !bad a x))
  let G := greedy bad grid (fun _ => 0) T U
  change G.1.length = T ∧ _
  have hs := greedy_spec bad grid (fun _ => 0) T U
  refine ⟨hs.1, ?_⟩
  have hz (a : _) (ha : a ∈ U) :
      p * (univ.filter (fun x => bad a x)).card ≤ K * Fintype.card (Grid d F) := by
    obtain ⟨x,_,hx⟩ := List.any_eq_true.mp (mem_filter.mp ha).2
    have ne : polyOutput a.1 a.2 ≠ 0 := by
      intro he
      have ha' := eval_output a.1 a.2 x
      rw [he,map_zero] at ha'
      simpa [bad, ← ha'] using hx
    have z := zero_count (k := K) (polyOutput a.1 a.2) ne ((output_degree ..).trans ht)
    simpa [bad,eval_output] using z
  have shrink := greedy_shrink bad grid (fun _ => 0) all p K T U hz
  have size : U.card ≤ p^E :=
    (card_le_univ _).trans (description_card (by simpa using hd) (by omega) ht)
  have strict : K^T * U.card < p^T :=
    (Nat.mul_le_mul_left _ size).trans_lt (rounds hk hp)
  have empty : G.2.card = 0 := by
    by_contra hn
    have h1 : p^T ≤ p^T * G.2.card := by
      simpa using Nat.mul_le_mul_left (p^T) (show 1 ≤ G.2.card by omega)
    exact (not_lt_of_ge (h1.trans shrink)) strict
  intro a ha
  obtain ⟨x,hx⟩ := ha
  have hmem : a ∈ U := mem_filter.mpr ⟨complete a, List.any_eq_true.mpr ⟨x,all x, by simpa [bad] using hx⟩⟩
  change ∃ y ∈ G.1, _
  by_contra! h
  have hr : a ∈ G.2 := (hs.2 a).mpr ⟨hmem,fun y hy => by simp [bad,h y hy]⟩
  rw [Finset.card_eq_zero.mp empty] at hr
  simpa using hr

end FBDD
