import FBDD.Run
import FBDD.Exponent
namespace FBDD
variable {V F : Type} [DecidableEq V] [Field F] [Fintype F] [DecidableEq F]

theorem enum_length {m} (d : Net V m) (k) (hk : 0 < k) (ns : List V) (vals : List F) :
    (enumGrid d k ns vals).length =
      2^(heavy d k ns).length * (listBudget (2*k))^(bins d k ns).length := by
  have h := shape_length (2*k) vals ns (heavy d k ns) (encode d (bins d k ns))
  unfold shapeGrid at h
  rw [← bins_flatten d k hk ns,decode_encode] at h
  simpa only [enumGrid,encode,List.length_map] using h

theorem actual_grid_budget {v m} (d : Net (Fin v) m) (k : Nat) (hk : 0 < k)
    (vle : v ≤ m) (nodes : m ≤ k^3) (vals : List F) :
    (enumGrid d k (List.finRange v) vals).length ≤ (listBudget (2*k))^(2*k^2+1) := by
  let ns := List.finRange v
  let H := (heavy d k ns).length
  let B := (bins d k ns).length
  have a := (ordered_packing d k hk ns (by simp [ns]) (List.nodup_finRange v)).1
  simp only [Fintype.card_fin] at a
  change (H+(B-1))*k ≤ m+v at a
  have tot : H+(B-1) ≤ 2*k^2 := by
    apply Nat.le_of_mul_le_mul_left (c := k) _ hk
    nlinarith
  let R := listBudget (2*k)
  have big : 2 ≤ R := by dsimp [R,listBudget]; omega
  rw [enum_length d k hk]
  change 2^H*R^B ≤ R^(2*k^2+1)
  calc
    _ ≤ R^H*R^B := Nat.mul_le_mul_right _ (Nat.pow_le_pow_left big H)
    _ = _ := (pow_add ..).symm
    _ ≤ _ := Nat.pow_le_pow_right (by omega) (by omega)

def estimate (p k : Nat) :=
  p^((2*k+1)*(2*k+2)+2*k)*(listBudget (2*k)+1) + (listBudget (2*k))^(2*k^2+1)

def candidateCount {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) :=
  let k := capacity (m+n)
  let p := primeFor k
  let _ : Fact p.Prime := ⟨(prime_spec _).1⟩
  if 2^v ≤ estimate p k then (allTuples [false,true] v).length
    else (enumGrid (join a b).net k (List.finRange v) (residues p)).length

theorem candidate_min {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (used : v ≤ m+n) (hn : 0 < m+n) :
    let N := m+n
    let k := capacity N
    candidateCount a b ≤ min (2^v) (2^(200*k^2*(Nat.clog 2 (N+2)+1))) := by
  dsimp only
  let k := capacity (m+n)
  let p := primeFor k
  letI : Fact p.Prime := ⟨(prime_spec _).1⟩
  have h := cap_spec (m+n)
  have eb : estimate p k ≤ 2^(200*k^2*(Nat.clog 2 (m+n+2)+1)) := by
    have pr := parameter_budget _ hn
    exact exponent_budget _ _ _ hn h.1 pr.2.1 pr.2.2
  have bg := actual_grid_budget (join a b).net k h.1 used h.2 (residues p)
  have bound : (listBudget (2*k))^(2*k^2+1) ≤ estimate p k := Nat.le_add_left _ _
  unfold candidateCount
  change (if 2^v ≤ estimate p k then _ else _) ≤ _
  split
  · rename_i lo
    simp only [tuples_length,List.length_cons,List.length_nil] 
    exact le_min le_rfl (lo.trans eb)
  · rename_i hi
    exact le_min ((bg.trans bound).trans (not_le.mp hi).le) ((bg.trans bound).trans eb)
end FBDD
