import FBDD.Run
import FBDD.ProbeBound
import FBDD.Common
import FBDD.Permutation
import FBDD.LocalRules
import FBDD.Tradeoff
import FBDD.Faces
namespace FBDD
local instance (k : Nat) : Fact (primeFor k).Prime := ⟨(prime_spec _).1⟩
/-- One statement tying input size, automatically selected parameters, correctness,
the resource estimate used by the dispatcher, and the product enumeration bound.
The resource estimate is an arithmetic expression, not operational bit time. -/
theorem main_checked {v m n} (a : Net (Fin v) m) (b : Net (Fin v) n) (r : Fin m) (s : Fin n)
    (ha : a.free) (hb : b.free) (used : v ≤ m+n) :
    let N := m+n
    let k := capacity N
    let p := primeFor k
    let K := 2*k
    let R := listBudget K
    let E := p^((K+1)*(K+2)+K)*(R+1) + R^(2*k^2+1)
    ResultSpec a b r s (solve a b r s) ∧ k^3 ≤ 8*N ∧
      E ≤ 2^(200*k^2*(Nat.clog 2 (N+2)+1)) ∧
      (autoGrid (F := ZMod p) (join a b).net k).length ≤ R^(2*k^2+1) ∧
      candidateCount a b ≤ min (2^v) (2^(200*k^2*(Nat.clog 2 (N+2)+1))) := by
  dsimp only
  have pos : 0 < m+n := by have h := r.isLt; omega
  have e := cap_spec (m+n)
  have pr := parameter_budget (m+n) pos
  exact ⟨solve_spec a b r s ha hb,root_scale _ _ pos e.1 pr.1,
    exponent_budget _ _ _ pos e.1 pr.2.1 pr.2.2,
    field_point_budget _ _ (by simpa using used) e.2 e.1,candidate_min a b used pos⟩
end FBDD
