import FBDD.Diagram
import Mathlib.Data.Matrix.Rank

namespace FBDD.Output
open Finset
variable {X F : Type} [Fintype X] [Field F]
def detects (W : Submodule F (X → F)) (T : Finset X) :=
  ∀ f : W, (∀ x ∈ T, (f : X → F) x = 0) → f = 0

def projection (W : Submodule F (X → F)) (T : Finset X) : W →ₗ[F] (T → F) where
  toFun f i := f.val i
  map_add' _ _ := rfl
  map_smul' _ _ := rfl

theorem projection_inj {W : Submodule F (X → F)} {T : Finset X} (hit : detects W T) :
    Function.Injective (projection W T) := by
  intro a b eq
  apply sub_eq_zero.mp
  apply hit
  intro i hi
  exact sub_eq_zero.mpr (congrFun eq ⟨i,hi⟩)

theorem span_exact (W : Submodule F (X → F)) :
    ∃ T : Finset X, detects W T ∧ T.card = Module.finrank F W ∧
      ∀ U, detects W U → T.card ≤ U.card := by
  classical
  have all : detects W univ := by
    intro f hf; apply Subtype.ext; funext x; exact hf x (mem_univ x)
  let good := (univ : Finset (Finset X)).filter (detects W)
  obtain ⟨T,hT,least⟩ := good.exists_min_image Finset.card
    ⟨univ,mem_filter.mpr ⟨mem_univ _,all⟩⟩
  have hit := (mem_filter.mp hT).2
  have lb (U) (ok : detects W U) := least U (mem_filter.mpr ⟨mem_univ _,ok⟩)
  have piv (i : T) : ∃ f : W, f.val i ≠ 0 ∧ ∀ j : T, j ≠ i → f.val j = 0 := by
    have hn : ¬detects W (T.erase i.val) := by
      intro he
      exact (Nat.not_le_of_lt (card_erase_lt_of_mem i.property)) (lb _ he)
    unfold detects at hn
    push_neg at hn
    obtain ⟨f,h0,hf⟩ := hn
    refine ⟨f,?_,fun j hj => h0 _ (mem_erase.mpr ⟨fun eq => hj (Subtype.ext eq),j.property⟩)⟩
    intro hi; apply hf; apply hit; intro j hj
    by_cases e : j = i.val
    · simpa [e] using hi
    · exact h0 _ (mem_erase.mpr ⟨e,hj⟩)
  choose f nonzero off using piv
  have sur : Function.Surjective (projection W T) := by
    intro x
    refine ⟨∑ i : T, (x i / (f i).val i) • f i,?_⟩
    rw [map_sum]; funext j
    simp only [Finset.sum_apply,map_smul,Pi.smul_apply,smul_eq_mul]
    rw [Finset.sum_eq_single j]
    · change x j / (f j).val j * (f j).val j = x j
      exact div_mul_cancel₀ _ (nonzero j)
    · intro i _ ne
      change _ * (f i).val j = 0
      rw [off i j (Ne.symm ne),mul_zero]
    · simp
  have eq := (LinearEquiv.ofBijective (projection W T) ⟨projection_inj hit,sur⟩).finrank_eq
  rw [Module.finrank_pi,Fintype.card_coe] at eq
  exact ⟨T,hit,eq.symm,lb⟩

theorem span_matrix {I : Type} [Finite I] (M : Matrix I X F) :
    ∃ T : Finset X, detects (Submodule.span F (Set.range M.row)) T ∧
      T.card = M.rank ∧ ∀ U, detects (Submodule.span F (Set.range M.row)) U → T.card ≤ U.card := by
  rw [Matrix.rank_eq_finrank_span_row]
  exact span_exact _

/-- A list of blocks, with one local rule already chosen per block. first =
catalogue record count (zero for span); second = least allowed nonempty list size. -/
def records (bs : List (Nat×Nat)) := (bs.map Prod.fst).sum
def points (bs : List (Nat×Nat)) := (bs.map Prod.snd).prod
def total (bs : List (Nat×Nat)) := records bs + points bs

inductive Costs : List (Nat×Nat) → Nat → Nat → Prop where
  | nil : Costs [] 0 1
  | cons {c h rc prod extra n tail} : c ≤ extra → h ≤ n → Costs tail rc prod →
    Costs ((c,h)::tail) (extra+rc) (n*prod)

theorem fixed_optimum (bs : List (Nat×Nat)) :
    Costs bs (records bs) (points bs) ∧ ∀ c p, Costs bs c p → total bs ≤ c+p := by
  constructor
  · induction bs with
    | nil => exact .nil
    | cons a bs ih => exact .cons le_rfl le_rfl ih
  · intro c p run
    have bound {bs c p} (run : Costs bs c p) : records bs ≤ c ∧ points bs ≤ p := by
      induction run with
      | nil => exact ⟨le_rfl,le_rfl⟩
      | cons lc lh _ ih => exact ⟨Nat.add_le_add lc ih.1,Nat.mul_le_mul lh ih.2⟩
    exact Nat.add_le_add (bound run).1 (bound run).2

theorem partition_optimum (plans : Finset (List (Nat×Nat))) (h : plans.Nonempty) :
    ∃ best ∈ plans, Costs best (records best) (points best) ∧
      ∀ bs ∈ plans, ∀ c p, Costs bs c p → total best ≤ c+p := by
  obtain ⟨bs,mem,hmin⟩ := plans.exists_min_image total h
  exact ⟨bs,mem,(fixed_optimum bs).1,fun bs' hm c p run => (hmin _ hm).trans ((fixed_optimum bs').2 c p run)⟩
end FBDD.Output
