# FBDD 동치 판정 · 1번 묶음 Lean 검증

Lean 4.19.0 및 mathlib v4.19.0. 두 FBDD의 총 노드 수를 $N$, 사용 변수 이름의 수를 $n$으로 둔다. 판정 정리는 두 DAG를 독립된 입력으로 받는다. 각 경로는 변수를 서로 다른 순서로 읽을 수 있고, 두 입력도 각자 읽기 순서를 정한다. 자유성은 한 질의의 두 자식 아래에서 그 이름이 다시 나타나지 않는다는 조건이다.

## 판정기를 읽는 순서

- `FBDD/Run.lean`의 `solve`는 유한체와 블록 크기를 선택해 불 대입 전수조사 또는 블록 검사를 실행한다. 반환값 `none`은 동치, `some b`는 실제 불 입력 `b`에서 두 루트 값이 다르다는 뜻이다. 정리 `solve_spec`이 두 경우를 모두 증명한다.
- `FBDD/PaperOne.lean`의 `main_checked`는 판정기의 정확성, 정수 세제곱근 매개변수, 비용 추정식, 검사점 개수 상계를 함께 제공한다. 부등식에서 $n\le N$을 가정한다. 변수 수는 총 노드 수와 별도 인자다.
- `FBDD/Universal.lean`은 입력을 보기 전에 검사점을 만드는 별도 함수 `universalGrid`를 제공한다. `universal_correct`는 모든 적격한 입력 쌍에 대한 정확성, `Budgets.lean`의 `universal_size`는 출력 목록 길이의 유한 상계다.
- `FBDD/Examples.lean`은 반대 순서로 읽는 두 AND 회로와 한쪽 질의를 생략한 회로를 실제로 실행한다. 불일치 입력은 `(false, true)`다.

## 원고와 선언의 대응

| 원고의 내용 | 커널이 확인한 선언 | 검증의 단위 |
|---|---|---|
| 고전적 다항식 표현과 Boolean/field 동치 | `Net.val_bit`, `Net.affine`, `delta_affine`, `witness_of_field` | 임의의 경로별 읽기 순서와 두 독립 DAG |
| 바깥 변수를 임의의 체 값으로 고정 | `compile_length`, `compile_correct`, `restriction_as_tri`, `output_degree` | 블록 질의가 정확히 $t$개면 길이 $t$, 차수 최대 $t$ |
| 공통 국소 검사점의 결정론적 생성 | `zero_count`, `greedy_shrink`, `localList_spec`, `common_local` | $K^2<\lvert F\rvert$. 길이 $t\le K$인 모든 점화식에 한 집합을 쓸 수 있다. 길이 상계는 $2(K+1)(K+2)+2$ |
| 두 입력에 대한 자동 판정 및 반례 | `pair_test`, `automatic_equivalence`, `testPair_spec`, `blockResult_spec`, `solve_spec` | 유한체 열거와 검사점을 실제로 생성하는 판정기, 불 대입 복원 |
| 수치 상계 | `packing_budget`, `catalogue_entry_cost`, `local_table_budget`, `field_point_budget`, `parameter_budget`, `exponent_budget`, `actual_grid_budget`, `candidate_min`, `main_checked` | 필드 연산, 목록 길이, 카탈로그 크기와 추정식 단위. 실제 분기에서 생성하는 전역 후보 수도 두 상계의 최솟값을 만족한다. 파싱부터 출력까지의 비트 기계 실행 시간 증명은 남아 있다 |
| 입력 독립 검사점 | `universal_correct`, `universal_size`, `linear_advice` | 앞의 둘은 희소한 배치 기술을 전부 열거하는 구성이다. 세 번째는 더 짧은 $4N+6$개 목록의 존재로, 그 목록의 균일한 빠른 생성은 주장하지 않는다 |
| 선형 조언 하한 | `Permutation.vertex_count`, `direct_correct`, `direct_ordered`, `signature_bound`, `linear_lower` | 공통 순서의 그래프가 서로 다른 순열을 계산하므로, 관측값 목록도 순열마다 달라야 한다는 계수 논증. 아래의 그래프 표현 설명 참조 |
| 국소 목록의 이차 하한 | `Selector.respects_edges`, `data_owners`, `root_read_once`, `represents`, `fixed_graph_lower`, `sharp_graph`, `matrix_exact` | 고정된 유한 DAG 한 개에서 모든 쌍선형식을 실현. $r+s$개 데이터 질의에 검사점이 $rs$개 이상 필요하고 쌍선형 가족에는 기저쌍 $rs$개로 충분 |
| $N=\Theta(2^n)$인 밀집 입력 | `unroll_value`, `dense_counts`, `trace_compatible`, `trace_unique`, `face_size`, `dense_probes` | 펼친 트리 방문 횟수, 말단 면의 크기와 경로 유일성, 마지막 레코드들의 적응적 읽기 하한. 워드 RAM 구현 전체는 미형식화 |
| 고정 블록 출력 최솟값 | `Output.span_matrix`, `cat_opt`, `span_opt`, `local_pair_exact`, `actual_optimum`, `all_plans` | 유한 응답 행렬마다 실제 검사점 집합을 선택하고, 허용한 분할·규칙의 유한 목록 전체에서 최소화한다. 영행렬의 비어 있지 않은 국소 목록 규약 포함 |
| 두 블록 규칙의 로그 인자 하한 | `Marks.mux_u`, `mux_v`, `mux_w`, `miss_all`, `independent_values`, `span_probes`, `Barrier.small_blocks`, `log_factor` | 독립 표시 $t$개의 소거, $2^t$차원 계수공간의 검사점 하한, 작은 블록들의 곱에서 로그 인자를 회복하는 부등식. 큰 그래프족과 모든 분할에 대한 표시 공급은 미형식화 |

## 원고를 읽을 때의 구별

**노드 수와 시간.** 검증된 중간 상계를 $k=\lceil N^{1/3}\rceil$, $K=2k$, $R=2(K+1)(K+2)+2$로 쓰면 입력별 필드 검사점은 $R^{2k^2+1}$개 이하이다. $p\le 8N^2$에서 국소 표 크기와 탐색 크기를 합친 코드의 추정식은 $2^{200k^2(\lceil\log_2(N+2)\rceil+1)}$ 이하이다. 길이 $t$인 점화식을 표에 채울 때 계수 계산 한 번의 덧셈·곱셈 수는 $t^2+2t$이다. 행 필터링·반복 스캔·주소 계산·유한체 산술의 비트 비용, 분기 선택을 하나의 기계 실행과 연결하여 원고의 $\operatorname{poly}(N)\min\{2^n,2^{O(N^{2/3}\log N)}\}$를 결론으로 내는 정리는 아직 없다. `exponent_budget`의 좌변은 실행 시간 측정값이 아니다.

**형식화에서 고른 구현.** 현 원고 §2와 Lean 구현은 모두 위상 순서에 따라 단말에서 루트로 점화식을 컴파일한다. 각 블록 질의마다 수정항을 하나 도입한다. 포장 시 다음 변수를 추가한 뒤 $k$에 도달하면 블록을 닫아 블록당 최대 $2k$를 허용한다. `solve`의 체는 $(2k)^2<p$인 첫 소수를 선택한다. 선형 조언 정리의 큰 체 조건 $N^2<\lvert F\rvert$은 그 정리에 따로 붙는다.

**하한의 그래프 표현.** 판정 입력은 위상적으로 번호를 매긴 `Net`이다. 국소 행렬족과 순열족의 하한은 공유 정점에 이름을 붙이고 다음 간선을 명시하는 유한 DAG로 표현했다. 순열족의 `direct`에는 질의와 단말만 있다. `direct_ordered`가 모든 질의 간선의 순서를, `direct_correct`가 그 의미를 확인한다. 순열족의 $m=2^{r+1}$개 주소에 대해 목록 길이 $h$와 체 크기 $p$는 $m!\le p^h$를 만족한다. $p\le(m/2)^8$이면 $m\le16h$이다. 두 하한 표현을 `Net`으로 직렬화하여 일반 판정기의 인터페이스에 다시 넣는 변환은 포함하지 않았다.

**제한된 모델의 전체 하한.** `Barrier.three_cases`는 큰 span, 큰 catalogue, 작은 블록들의 곱이라는 세 경우 모두에서 로그 인자까지 결론을 낸다. 표시 총량과 각 국소 목록이 내야 할 비용은 명시적 가정이다. 원고에서 바로 앞에 있는, 선형 크기 공유 라우팅을 만드는 superconcentrator의 구성과 크기 보장, 3-정규 이분 확장 그래프에서 모든 허용 분할에 충분한 표시가 남는다는 논증, 이들을 하나의 명시적 입력에 결합하는 단계가 남아 있다. 따라서 이 묶음만으로 두 규칙의 최악 비용이 $2^{\Theta(N^{2/3}\log N)}$이라는 무조건부 정리를 Lean 검증 완료라고 표시할 수 없다. 해당 하한이 다루는 비용은 카탈로그 및 전체 곱 목록의 명시적 출력이다.

## 재현

프로젝트 루트에서 다음을 실행한다.

```sh
lake update
lake exe cache get
lake build
python3 scripts/verify.py
```

마지막 명령은 프로젝트 모듈을 빈 임시 디렉터리에서 다시 컴파일한다. 릴리스와 호환되는 mathlib가 이미 설치되어 있으면 `LEAN_BIN`과 `MATHLIB_LEAN_PATH`를 지정해서 실행할 수도 있다. `verification.txt`에는 실제 클린 빌드 결과, 실행 예제, 주요 정리의 `#print axioms` 결과가 들어 있다.
