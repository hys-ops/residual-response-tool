"""Recompile all project sources into an empty temporary directory and audit declarations."""
from pathlib import Path
import os
import re
import subprocess
import sys
import tempfile

root = Path(__file__).resolve().parents[1]
compiler = os.environ.get("LEAN_BIN", "lean")
env = os.environ.copy()
if "MATHLIB_LEAN_PATH" in env:
    deps = env["MATHLIB_LEAN_PATH"]
else:
    deps = subprocess.check_output(["lake", "env", sys.executable, "-c", "import os; print(os.environ['LEAN_PATH'])"], cwd=root, text=True).strip()
    deps = os.pathsep.join(str((root / s).resolve()) for s in deps.split(os.pathsep) if s)
sources = {"FBDD." + p.stem: p for p in sorted((root / "FBDD").glob("*.lean"))}
sources["FBDD"] = root / "FBDD.lean"
done = set()
with tempfile.TemporaryDirectory() as stage:
    env["LEAN_PATH"] = os.pathsep.join([stage, deps])
    def check(module):
        if module in done:
            return
        src = sources[module]
        data = src.read_text()
        for imported in re.findall(r"^import (FBDD(?:\.[A-Za-z]+)?)\s*$", data, re.M):
            check(imported)
        if re.search(r"\b(?:axiom|sorry|admit|native_decide)\b", data):
            raise RuntimeError("Unfinished or postulated declaration in " + module)
        output = Path(stage) / (module.replace(".", "/") + ".olean")
        output.parent.mkdir(parents=True, exist_ok=True)
        result = subprocess.run([compiler, "-j", "2", "-o", str(output), str(src.relative_to(root))],
            cwd=root, env=env, capture_output=True, text=True)
        print(f"[{len(done)+1}] {module}  exit={result.returncode}", flush=True)
        if result.stdout or result.stderr:
            print(result.stdout + result.stderr, end="", flush=True)
        result.check_returncode()
        if module == "FBDD.Examples":
            expected = ["true", "false", "some (false, true)", "some (false, true)", "true"]
            if result.stdout.strip().splitlines() != expected:
                raise RuntimeError("Unexpected executable smoke-test result")
        if module == "FBDD":
            audits = re.findall(r"depends on axioms: \[(.*?)\]", result.stdout, re.S)
            if len(audits) != data.count("#print axioms "):
                raise RuntimeError("Missing axiom audit")
            for report in audits:
                if set(report.split(", ")) - {"propext", "Classical.choice", "Quot.sound"}:
                    raise RuntimeError("Unexpected axiom: " + report)
        done.add(module)
    for m in sources:
        check(m)
print(f"Clean build passed for {len(done)} modules.")
