"""General exact extractor for binary pointers (bit, target0, target1).
Nodes have fixed ordinary query names. Every filling is promised to be a valid
FBDD. All ordinary names need not use a common reading order. Raw integers 0
and 1 are shared sinks; other integers name ordinary node records.
"""
from flat import FlatDepth
from wiring import parity_chains


class RowSpace:
    def __init__(self, masks):
        self.basis=[]
        self.pivots={}
        for v in masks:
            while v:
                i=v.bit_length()-1
                if i not in self.pivots:
                    self.pivots[i]=(v,len(self.basis))
                    self.basis.append(v)
                    break
                v ^= self.pivots[i][0]

    def coordinates(self, v):
        coef=0
        while v:
            pivot,index=self.pivots[v.bit_length()-1]
            coef ^= 1<<index
            v ^= pivot
        return coef


def extract(rows, roots, k):
    segments=parity_chains(rows,roots)
    covered={u for _,_,_,group in segments for u in group}
    external={u:row for u,row in rows.items() if u not in covered}
    local_bits=sorted({p[0] for _,lo,hi in external.values()
                       for p in (lo,hi) if isinstance(p,tuple)})
    vectors=RowSpace([mask for _,mask,_,_ in segments]+[1<<i for i in local_bits])
    routes={}
    for head,mask,exits,_ in segments:
        for lane,u in enumerate(head):
            routes[u]=vectors.coordinates(mask),lane,exits
    ordinary={v:i for i,v in enumerate(sorted({v for v,a,b in external.values() if a!=b}))}
    controls={i:vectors.coordinates(1<<i) for i in local_bits}
    def evaluate(root, s, x):
        u=root
        while u not in (0,1):
            if u in routes:
                m,lane,exits=routes[u]
                u=exits[lane ^ ((s&m).bit_count()%2)]
            else:
                v,a,b=external[u]
                dest=b if a!=b and ((x>>ordinary[v])&1) else a
                if isinstance(dest,tuple):
                    bit,lo,hi=dest
                    u=hi if (s&controls[bit]).bit_count()%2 else lo
                else:
                    u=dest
        return u
    r=len(vectors.basis)
    g=0
    for s in range(1<<r):
        eq=all(evaluate(roots[0],s,x)==evaluate(roots[1],s,x) for x in range(1<<len(ordinary)))
        g |= int(eq)<<s
    cols=[sum(((mask>>j)&1)<<i for i,mask in enumerate(vectors.basis)) for j in range(k)]
    return r,cols,g


if __name__=="__main__":
    from wiring import make_mux
    rows,roots,k=make_mux(1000)
    r,cols,g=extract(rows,roots,k)
    model=FlatDepth(r,cols)
    d,_=model.strategy(g)
    assert (r,d)==(3,6000)
    print("end-to-end raw extractor: rank",r,"states",len(model.states),"depth",d)
