"""Extract verified two-lane XOR chains from explicit child-pointer descriptors.
Pointers are (setting_index, target_if_0, target_if_1) or a fixed integer.
Each record is (ordinary variable, pointer for x=0, pointer for x=1).
"""
from collections import defaultdict
from random import Random
from flat import FlatDepth


def make_mux(m):
    rows={}
    def node(variable, low, high):
        u=len(rows)+2
        rows[u]=(variable,low,high)
        return u
    xbar=node(0,1,0)
    x=node(0,0,1)
    k=7*m
    types=[v for v in range(1,8) for _ in range(m)]
    stage=0
    def chain(direction, exits):
        nonlocal stage
        pair=exits
        for i in reversed(range(k)):
            if not types[i]&direction:
                continue
            stage+=1
            a,b=pair
            z=(i,a,b)
            o=(i,b,a)
            pair=(node(stage,z,z),node(stage,o,o))
        return pair[0]
    data0=chain(2,(xbar,x))
    data1=chain(4,(xbar,x))
    return rows,(x,chain(1,(data0,data1))),k


def parity_chains(rows,roots):
    by_layer=defaultdict(list)
    feeds=defaultdict(set)
    for u,(v,l,h) in rows.items():
        for d in (l,h):
            for child in (d[1:] if isinstance(d,tuple) else (d,)):
                feeds[child].add(u)
        if l==h and isinstance(l,tuple) and l[1]!=l[2]:
            i,a,b=l
            by_layer[v,i,min(a,b),max(a,b)].append(u)
    lanes={}
    for group in by_layer.values():
        if len(group)!=2: continue
        u,v=sorted(group)
        if rows[u][1][1:] != rows[v][1][1:][::-1]: continue
        lanes[(u,v)]=(rows[u][1][0],rows[u][1][1:])
    after={}
    for g,(_,ends) in lanes.items():
        nxt=tuple(sorted(ends))
        if (nxt in lanes and not set(nxt)&set(roots) and
                all(feeds[v] <= set(g) for v in nxt)):
            after[g]=nxt
    heads=set(lanes)-set(after.values())
    segments=[]
    for head in sorted(heads):
        g=head
        reverse=0
        mask=0
        discarded=set()
        while True:
            i,ends=lanes[g]
            mask^=1<<i
            discarded.update(g)
            if g not in after:
                break
            reverse ^= int(ends != after[g])
            g=after[g]
        segments.append((head,mask,ends[::-1] if reverse else ends,discarded))
    return segments


def run_check(m=1000):
    rows,roots,k=make_mux(m)
    segments=parity_chains(rows,roots)
    covered=set().union(*(s[3] for s in segments))
    assert all(isinstance(l,int) and isinstance(h,int)
               for u,(v,l,h) in rows.items() if u not in covered)
    assert len(segments)==3
    cols=[sum(((mask>>i)&1)<<j for j,(_,mask,_,_) in enumerate(segments)) for i in range(k)]
    routes={}
    for j,(head,_,ends,_) in enumerate(segments):
        for lane,u in enumerate(head):
            routes[u]=(j,lane,ends)
    def result(root,syndrome,x):
        u=root
        while u>=2:
            if u in routes:
                j,lane,exits=routes[u]
                u=exits[lane^((syndrome>>j)&1)]
            else:
                _,l,h=rows[u]
                u=h if x else l
        return u
    def raw(root,z,x):
        u=root
        while u>=2:
            v,l,h=rows[u]
            d=h if (v==0 and x) else l
            u=d[1+((z>>d[0])&1)] if isinstance(d,tuple) else d
        return u
    g=sum(int(all(result(roots[0],s,x)==result(roots[1],s,x) for x in (0,1)))<<s for s in range(8))
    model=FlatDepth(3,cols)
    d,choice=model.strategy(g)
    assert d==6*m
    rng=Random(81439)
    for _ in range(25):
        z=rng.getrandbits(k)
        s=sum(((z&mask).bit_count()%2)<<j for j,(_,mask,_,_) in enumerate(segments))
        assert all(raw(u,z,x)==result(u,s,x) for u in roots for x in (0,1))
        assert model.run(choice,z)[0]==((g>>s)&1)
    print("raw wiring:",len(rows),"nonterminal records;",len(segments),
          "extracted chains;",len(model.states),"affine states;",d,"optimal probes")


if __name__=="__main__":
    run_check()
