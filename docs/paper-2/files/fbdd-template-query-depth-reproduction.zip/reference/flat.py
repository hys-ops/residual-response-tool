"""Exact bit-query depth of g(M theta) for columns in GF(2)^r."""
from collections import Counter
from functools import cache


def span(columns):
    space = {0}
    for v in columns:
        if v not in space:
            space |= {x ^ v for x in space}
    return frozenset(space)


class FlatDepth:
    def __init__(self, r, columns):
        self.r = r
        self.columns = tuple(columns)
        if any(v < 0 or v >= 1 << r for v in self.columns):
            raise ValueError("Column outside the supplied vector space")
        self.weights = Counter(self.columns)
        self.V = span(self.weights)
        self.states = {}
        self.root = self._build(self.V, 0)

    def _build(self, W, shift):
        affine = frozenset(shift ^ w for w in W)
        tag = min(affine)
        key = (W,tag)
        if key in self.states:
            return key
        children = []
        seen = set()
        types = tuple(v for v in self.weights if v in W)
        if len(W) > 1:
            for a in range(1, 1 << self.r):
                H = frozenset(w for w in W if (a & w).bit_count() % 2 == 0)
                if len(H) == len(W) or H in seen:
                    continue
                seen.add(H)
                if span(v for v in types if v in H) != H:
                    continue
                outside = tuple(v for v in types if v not in H)
                cut_cost = sum(self.weights[v] for v in outside)
                first = self._build(H, tag)
                second = self._build(H, tag ^ outside[0])
                children.append((outside,cut_cost,first,second))
        mask = sum(1 << x for x in affine)
        self.states[key] = (mask,children)
        return key

    def strategy(self,g):
        choices = {}
        @cache
        def visit(key):
            mask, transitions = self.states[key]
            hit = mask & g
            if hit == 0 or hit == mask:
                choices[key] = int(hit != 0)
                return 0
            best = None
            for cut, cost, left, right in transitions:
                value = cost + max(visit(left),visit(right))
                if best is None or value < best:
                    best = value
                    choices[key] = (frozenset(cut),left,right)
            assert best is not None
            return best
        return visit(self.root), choices

    def run(self,choices,physical):
        key = self.root
        shift = 0
        probes = 0
        while isinstance(choices[key],tuple):
            cut,left,right = choices[key]
            for i,col in enumerate(self.columns):
                if col in cut:
                    probes += 1
                    if physical >> i & 1:
                        shift ^= col
            H, tag = left
            key = left if (shift ^ tag) in H else right
        return choices[key], probes


def quotient(bits,k):
    """Minimum parity dimension of a complete truth table, via its Walsh support."""
    entries = [1-2*((bits >> x) & 1) for x in range(1 << k)]
    length = 1
    while length < len(entries):
        for i in range(0, len(entries), 2*length):
            for j in range(i, i+length):
                a,b = entries[j],entries[j+length]
                entries[j],entries[j+length] = a+b,a-b
        length *= 2
    rows, covered = [], {0}
    for a,coef in enumerate(entries):
        if coef and a not in covered:
            rows.append(a)
            covered |= {x ^ a for x in covered}
    columns = tuple(sum(((a >> i) & 1) << j for j,a in enumerate(rows)) for i in range(k))
    values={}
    for x in range(1<<k):
        s=sum(((a & x).bit_count()%2) << j for j,a in enumerate(rows))
        bit=(bits>>x)&1
        assert bit==values.setdefault(s,bit)
    return len(rows), columns, sum(b<<s for s,b in values.items())
