from itertools import combinations
from random import Random
from flat import FlatDepth
from check import depth, projections
from extract import extract
from wiring import make_mux


def make_pair(rng,k,n):
    rows={}
    roots=[]
    for _ in range(2):
        pool={0:[0,1]}
        for size in range(1,n+1):
            for group in combinations(range(n),size):
                mask=sum(1<<i for i in group)
                pool[mask]=[]
                for phase in range(2):
                    var=rng.choice(group)
                    legal=[u for subset,nodes in pool.items() if subset&~(mask^(1<<var))==0 for u in nodes]
                    def dest():
                        a,b=rng.choice(legal),rng.choice(legal)
                        return a if rng.randrange(3)==0 else (rng.randrange(k),a,b)
                    u=len(rows)+2
                    rows[u]=(var,dest(),dest())
                    pool[mask].append(u)
        roots.append(rng.choice(pool[(1<<n)-1]))
    return rows,roots


def raw(rows,u,z,x):
    while u>=2:
        v,lo,hi=rows[u]
        a=hi if x>>v&1 else lo
        u=a[1+(z>>a[0]&1)] if isinstance(a,tuple) else a
    return u


def inspect(rows, roots,k,xs):
    r,cols,g=extract(rows,roots,k)
    truth=0
    for z,s in enumerate(projections(cols)):
        eq=all(raw(rows,roots[0],z,x)==raw(rows,roots[1],z,x) for x in xs)
        assert eq==(g>>s&1)
        truth |= eq<<z
    d,_=FlatDepth(r,cols).strategy(g)
    assert d==depth(truth,k)
    return d


if __name__=="__main__":
    rng=Random(424729)
    count=0
    for _ in range(160):
        n=rng.randrange(2,5);k=rng.randrange(1,6)
        rows,roots=make_pair(rng,k,n)
        count+=int(inspect(rows,roots,k,range(1<<n))>0)
    # A physical selector is used both inside parity chains and by an
    # ordinary branching node outside. The direct unit row must be preserved.
    rows,roots,k=make_mux(1)
    new_root=len(rows)+2
    rows[new_root]=(50,(0,roots[0],roots[1]),roots[1])
    inspect(rows,(roots[0],new_root),k,[0,1,1<<50,(1<<50)|1])
    print("160 independent raw pairs:",count,"nonconstant; mixed shared selector OK")
