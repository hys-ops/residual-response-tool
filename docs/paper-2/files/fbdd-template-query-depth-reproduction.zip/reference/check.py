from functools import cache
from itertools import combinations_with_replacement
from random import Random
from flat import FlatDepth, quotient, span


@cache
def split(table,n,i,b):
    result=0
    low_mask=(1<<i)-1
    for x in range(1<<(n-1)):
        orig=(x&low_mask)|((x&~low_mask)<<1)|(b<<i)
        result |= ((table>>orig)&1)<<x
    return result

@cache
def depth(table,n):
    if table in (0,(1<<(1<<n))-1):
        return 0
    return 1+min(max(depth(split(table,n,i,0),n-1),depth(split(table,n,i,1),n-1)) for i in range(n))


def projections(cols):
    xs = [0]
    for v in cols:
        xs += [x ^ v for x in xs]
    return xs


def mask(f,n):
    return sum(int(bool(f(x)))<<x for x in range(1<<n))


def examples():
    fs=[mask(lambda x: (((x>>(1+(x&1)))&1) ^ (x>>3)),4),
        mask(lambda x: ((x&7)!=0) if (x&8) else (x&7)==7,4)]
    pairs=[]
    for f in fs:
        r,cols,g=quotient(f,4)
        d,_=FlatDepth(r,cols).strategy(g)
        pairs.append((r,d))
    assert pairs==[(3,3),(4,4)]
    print("four-bit counterexample (rank, depth):",pairs,flush=True)
    cols=tuple(v for v in range(1,8) for _ in range(1000))
    tab=FlatDepth(3,cols)
    g=mask(lambda x: (x>>(1+(x&1)))&1,3)
    d,choice=tab.strategy(g)
    assert d==6000
    print("7000 physical bits:",len(tab.states),"affine states;",d,"optimal probes",flush=True)


def crosscheck():
    count=0
    for k in range(1,6):
        for cols in combinations_with_replacement(range(1,8),k):
            if len(span(cols))!=8: continue
            p=projections(cols)
            model=FlatDepth(3,cols)
            for f in range(256):
                d,choice=model.strategy(f)
                lifted=sum(((f>>v)&1)<<i for i,v in enumerate(p))
                assert d==depth(lifted,k)
                if f in (0,1,23,150,255):
                    runs=[model.run(choice,z) for z in range(1<<k)]
                    assert all(v==((f>>p[z])&1) for z,(v,l) in enumerate(runs))
                    assert max(l for _,l in runs)==d
                count+=1
    print("all full-rank 3-bit column multisets of size at most 5, x all 256 tables:",count,flush=True)
    rng=Random(529611)
    for j in range(500):
        r=rng.randint(1,4);k=rng.randint(1,8)
        cols=[rng.randrange(1<<r) for _ in range(k)]
        f=rng.getrandbits(1<<r)
        p=projections(cols);bits=sum(((f>>v)&1)<<i for i,v in enumerate(p))
        model=FlatDepth(r,cols)
        d,choices=model.strategy(f)
        assert d==depth(bits,k)
        runs=[model.run(choices,z) for z in range(1<<k)]
        assert max(l for _,l in runs)==d and all(v==((bits>>z)&1) for z,(v,l) in enumerate(runs))
    print("additional random cases including zero columns and deficient ranks: 500",flush=True)


if __name__=="__main__":
    examples()
    crosscheck()
