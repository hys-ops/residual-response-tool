"""Rebuild all project sources, then check the reported dependencies of the main theorems."""
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

project = Path(__file__).resolve().parents[1]
compiler = os.environ.get("LEAN_BIN", "lean")
dependency_paths = os.environ.get("MATHLIB_LEAN_PATH")
if dependency_paths is None:
    dependency_paths = subprocess.check_output(
        ["lake", "env", sys.executable, "-c", "import os; print(os.environ['LEAN_PATH'])"],
        cwd=project, text=True
    ).strip()
    dependency_paths = os.pathsep.join(
        str((project / item).resolve()) for item in dependency_paths.split(os.pathsep)
        if item and (project / item).resolve() != (project / ".lake/build/lib/lean").resolve()
    )
files = list((project / "FBDD").glob("*.lean")) + list((project / "TemplateDepth").glob("*.lean"))
files.append(project / "TemplateDepth.lean")
sources = {".".join(p.relative_to(project).with_suffix("").parts): p for p in files}
allowed = {"propext", "Classical.choice", "Quot.sound"}
checked = set()
print(subprocess.check_output([compiler, "--version"], text=True).strip(), flush=True)
with tempfile.TemporaryDirectory() as stage:
    env = dict(os.environ, LEAN_PATH=os.pathsep.join([stage, dependency_paths]))
    def build(name):
        if name in checked:
            return
        path = sources[name]
        source = path.read_text()
        for dep in re.findall(r"^import ([\w.]+)\s*$", source, re.M):
            if dep in sources:
                build(dep)
        if re.search(r"\b(sorry|admit|axiom|native_decide)\b", source):
            raise RuntimeError(f"Unexpected proof token in {name}")
        output = Path(stage).joinpath(*name.split(".")).with_suffix(".olean")
        output.parent.mkdir(parents=True, exist_ok=True)
        proc = subprocess.run([compiler, "-j", "2", "-o", str(output), str(path.relative_to(project))],
                              cwd=project, env=env, text=True, stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT)
        print(f"{name}  exit={proc.returncode}", flush=True)
        print(proc.stdout, end="", flush=True)
        proc.check_returncode()
        if name == "TemplateDepth":
            audits = dict(re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", proc.stdout))
            for decl in re.findall(r"^#print axioms ([\w.]+)$", source, re.M):
                if decl not in audits or set(audits[decl].split(", ")) - allowed:
                    raise RuntimeError("Axiom check failed for " + decl)
            print(f"Axiom audit passed for {len(audits)} declarations.", flush=True)
        checked.add(name)
    build("TemplateDepth")
    assert checked == set(sources)
print(f"Clean build passed for {len(checked)} modules.", flush=True)
