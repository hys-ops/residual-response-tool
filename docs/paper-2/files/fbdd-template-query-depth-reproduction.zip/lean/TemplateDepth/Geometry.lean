import Mathlib.Algebra.Group.Subgroup.Lattice
import Mathlib.Data.Finset.Card
import Mathlib.Algebra.BigOperators.Group.Finset.Basic
import Mathlib.Data.Nat.Find

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V]

def space (c : I → V) (R : Finset I) : AddSubgroup V :=
  AddSubgroup.closure (c '' (R : Set I))

theorem column_mem (c : I → V) {R : Finset I} {i : I} (hi : i ∈ R) :
    c i ∈ space c R := AddSubgroup.subset_closure ⟨i,hi,rfl⟩

theorem space_mono (c : I → V) {R S : Finset I} (h : R ⊆ S) :
    space c R ≤ space c S := AddSubgroup.closure_mono (Set.image_mono h)

theorem space_le (c : I → V) {R : Finset I} {W : AddSubgroup V}
    (h : ∀ i ∈ R, c i ∈ W) : space c R ≤ W := by
  apply (AddSubgroup.closure_le W).2
  rintro _ ⟨i,hi,rfl⟩
  exact h i hi

def TwoCosets (W H : AddSubgroup V) (v : V) : Prop :=
  ∀ u ∈ W, u ∈ H ∨ ∃ t ∈ H, u = v + t

theorem erase_cosets (two : ∀ x : V, x+x=0) (c : I → V) (R : Finset I) (i : I) :
    TwoCosets (space c R) (space c (R.erase i)) (c i) := by
  intro x hx
  change x ∈ AddSubgroup.closure _ at hx
  induction hx using AddSubgroup.closure_induction with
  | mem x hx =>
    obtain ⟨j,hj,rfl⟩ := hx
    by_cases h : j=i
    · subst j
      exact Or.inr ⟨0,(space c _).zero_mem,(add_zero _).symm⟩
    · exact Or.inl (column_mem _ (Finset.mem_erase.mpr ⟨h,hj⟩))
  | one => exact Or.inl (space c _).zero_mem
  | mul x y _ _ hx hy =>
    rcases hx with hx|⟨a,ha,rfl⟩ <;> rcases hy with hy|⟨b,hb,rfl⟩
    · exact Or.inl ((space c _).add_mem hx hy)
    · exact Or.inr ⟨x+b,(space c _).add_mem hx hb,by ac_rfl⟩
    · exact Or.inr ⟨a+y,(space c _).add_mem ha hy,by ac_rfl⟩
    · left
      rw [show c i+a+(c i+b)=(c i+c i)+(a+b) by ac_rfl,two,zero_add]
      exact (space c _).add_mem ha hb
  | inv x _ hx => rwa [neg_eq_of_add_eq_zero_left (two x)]

theorem space_erase_eq (c : I → V) {R : Finset I} {i : I}
    (h : c i ∈ space c (R.erase i)) : space c (R.erase i) = space c R := by
  apply le_antisymm (space_mono c (Finset.erase_subset _ _)) (space_le c ?_)
  intro j hj
  by_cases heq : j=i
  · simpa [heq] using h
  · exact column_mem _ (Finset.mem_erase.mpr ⟨heq,hj⟩)

def Uniform (g : V → Bool) (W : AddSubgroup V) (z : V) : Prop :=
  ∀ t ∈ W, g (z+t) = g z

theorem uniform_shift {g : V → Bool} {W : AddSubgroup V} {z u : V}
    (h : Uniform g W z) (hu : u ∈ W) : Uniform g W (z+u) := by
  intro t ht
  rw [add_assoc,h _ (W.add_mem hu ht),h _ hu]

end TemplateDepth
