import TemplateDepth.Value
import Mathlib.Data.Finset.Powerset

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V]

/-- Concrete, independent bit-by-bit verifier. Its recursion is on a depth
budget and refers to neither subgroups nor the compressed recurrence. -/
def constantB (c : I → V) (g : V → Bool) (R : Finset I) (z : V) : Bool :=
  decide (∀ a ∈ R.powerset, g (z+∑ j ∈ a, c j) = g z)

def canB (c : I → V) (g : V → Bool) : Nat → Finset I → V → Bool
  | 0,R,z => constantB c g R z
  | d+1,R,z => constantB c g R z ||
      decide (∃ i ∈ R, canB c g d (R.erase i) z = true ∧
        canB c g d (R.erase i) (z+c i) = true)

theorem constantB_spec (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool) (R : Finset I) (z : V) :
    constantB c g R z=true ↔ Uniform g (space c R) z := by
  simp only [constantB,decide_eq_true_eq,Finset.mem_powerset]
  constructor
  · intro h u hu
    obtain ⟨a,ha,rfl⟩ := realized two c R hu
    exact h a ha
  · intro h a ha
    exact h _ (sum_mem c ha)

theorem canB_spec (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool) (R : Finset I) (z : V) (d : Nat) :
    canB c g d R z=true ↔ Probe c g R z d := by
  induction d generalizing R z with
  | zero =>
    rw [canB,constantB_spec two]
    exact ⟨Probe.stop,by intro p; cases p with | stop h => exact h⟩
  | succ d ih =>
    simp only [canB,Bool.or_eq_true,constantB_spec two,decide_eq_true_eq,ih]
    constructor
    · rintro (u|⟨i,hi,a,b⟩)
      · exact .stop u
      · exact .ask hi a b
    · intro p
      cases p with
      | stop u => exact Or.inl u
      | ask hi a b => exact Or.inr ⟨_,hi,a,b⟩

end TemplateDepth
