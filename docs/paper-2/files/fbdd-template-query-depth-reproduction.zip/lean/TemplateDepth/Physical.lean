import TemplateDepth.Geometry

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V]

/-- A physical strategy asks one unread coordinate in each internal node.
The budget is an upper bound on both branch depths. -/
inductive Probe (c : I → V) (g : V → Bool) : Finset I → V → Nat → Prop
  | stop {R z d} : Uniform g (space c R) z → Probe c g R z d
  | ask {R z d i} : i ∈ R → Probe c g (R.erase i) z d →
      Probe c g (R.erase i) (z+c i) d → Probe c g R z (d+1)

variable {c : I → V} {g : V → Bool}

theorem Probe.weaken {R z d} (a : Probe c g R z d) {e} (hle : d ≤ e) :
    Probe c g R z e := by
  induction a generalizing e with
  | stop hu => exact .stop hu
  | ask hi _ _ ih₀ ih₁ =>
    cases e with
    | zero => omega
    | succ e => exact .ask hi (ih₀ (by omega)) (ih₁ (by omega))

theorem Probe.shift (two : ∀ x : V, x+x=0) {R z d} (a : Probe c g R z d)
    {u} (hu : u ∈ space c R) : Probe c g R (z+u) d := by
  induction a generalizing u with
  | stop h => exact .stop (uniform_shift h hu)
  | @ask R z d i hi _ _ ih₀ ih₁ =>
    rcases erase_cosets two c R i u hu with hu|⟨t,ht,rfl⟩
    · exact .ask hi (ih₀ hu) (by simpa [add_right_comm] using ih₁ hu)
    · apply Probe.ask hi
      · simpa only [add_assoc] using ih₁ ht
      · rw [show z+(c i+t)+c i = z+t+(c i+c i) by ac_rfl,two,add_zero]
        exact ih₀ ht

/-- Read every coordinate outside T and continue at the resulting offset. -/
theorem pay_outside {T R : Finset I} {z d} (inc : T ⊆ R)
    (plans : ∀ u ∈ space c R, Probe c g T (z+u) d) :
    Probe c g R z (R.card-T.card+d) := by
  classical
  induction hn : R.card using Nat.strong_induction_on generalizing R z with
  | h n ih =>
    by_cases eq : T=R
    · subst R
      simpa [← hn] using plans 0 (space c T).zero_mem
    · obtain ⟨i,hi,hiT⟩ := (Finset.ssubset_iff_of_subset inc).1
          (Finset.ssubset_iff_subset_ne.2 ⟨inc,eq⟩)
      have inc' : T ⊆ R.erase i := fun j hj =>
        Finset.mem_erase.2 ⟨fun eq => hiT (eq ▸ hj),inc hj⟩
      have down := Finset.card_erase_lt_of_mem hi
      have cr := Finset.card_erase_of_mem hi
      have cT := Finset.card_le_card inc'
      have sub := space_mono c (Finset.erase_subset i R)
      have ci := column_mem c hi
      rw [show n-T.card+d = ((R.erase i).card-T.card+d)+1 by omega]
      apply Probe.ask hi
      · exact ih _ (by omega) inc' (fun u hu => plans u (sub hu)) rfl
      · apply ih _ (by omega) inc' _ rfl
        intro u hu
        rw [add_assoc]
        exact plans _ ((space c R).add_mem ci (sub hu))

theorem all_bits (c : I → V) (g : V → Bool) (R : Finset I) (z : V) :
    Probe c g R z R.card := by
  have emp : space c ∅ ≤ ⊥ := space_le c (by simp)
  have plans : ∀ u ∈ space c R, Probe c g ∅ (z+u) 0 := by
    intro u _
    apply Probe.stop
    intro t ht
    have et : t=0 := emp ht
    simp [et]
  simpa using pay_outside (Finset.empty_subset R) plans

end TemplateDepth
