import TemplateDepth.Templates
import TemplateDepth.FiniteCheck
import Mathlib.Data.ZMod.Basic

set_option linter.unusedSectionVars false

namespace TemplateDepth.Prediction
abbrev S := ZMod 2 × ZMod 2 × ZMod 2
def unit (j : Fin 3) : S :=
  if j=0 then (1,0,0) else if j=1 then (0,1,0) else (0,0,1)
def selector (x : S) : Bool := if x.1=0 then decide (x.2.1=1) else decide (x.2.2=1)
def odd (x : S) : Bool := decide (x.1+x.2.1+x.2.2=1)
def gate (e : Bool) (x : S) : Bool := selector x && (odd x || e)
def bits : Finset (Fin 3) := Finset.univ
theorem binary : ∀ x : S, x+x=0 := by decide

theorem three_bit_depth (e : Bool) : depthValue unit (gate e) bits 0 = if e then 2 else 3 := by
  have bound {g : S → Bool} {d : Nat} (up : canB unit g (d+1) bits 0=true)
      (lo : canB unit g d bits 0=false) : depthValue unit g bits 0 = d+1 := by
    have p := (canB_spec binary unit g bits 0 _).1 up
    obtain ⟨t,hd,h⟩ := (ordinary_iff binary).2 p
    have ub := (depth_min h).trans hd
    obtain ⟨q,hq,qok⟩ := depth_spec unit g bits 0
    by_contra ne
    have qd : q.depth ≤ d := by omega
    have no := (canB_spec binary unit g bits 0 d).2 ((ordinary_iff binary).1 ⟨q,qd,qok⟩)
    rw [lo] at no
    contradiction
  cases e
  · exact bound (d:=2) (by decide) (by decide)
  · exact bound (d:=1) (by decide) (by decide)

/-- The input diagrams may use arbitrary path-dependent orders. The Boolean
semantics of the added input selector determines the encoded equivalence bit. -/
theorem selector_semantics {X : Type} (A B : Diagram X) (x : S) :
    (∀ (s : Bool) (y : X → Bool),
      (if s then A.graph.boolVal y A.root else true) =
      (if s then (if odd x then A.graph.boolVal y A.root else B.graph.boolVal y B.root)
       else selector x)) ↔
      (selector x=true ∧ (odd x=true ∨ ∀ y, A.graph.boolVal y A.root=B.graph.boolVal y B.root)) := by
  constructor
  · intro h
    obtain ⟨q⟩ : Nonempty (X → Bool) := ⟨fun _ => false⟩
    constructor
    · simpa only [Bool.false_eq_true,if_false] using (h false q).symm
    · cases p : odd x with
      | true => exact Or.inl rfl
      | false => exact Or.inr (fun y => by simpa [p] using h true y)
  · rintro ⟨m,p⟩ s y
    cases s with
    | false => simp [m]
    | true =>
      rcases p with p|e
      · simp [p]
      · simp [e y]

end TemplateDepth.Prediction
