import TemplateDepth.Signature

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V]
variable {c : I → V} {g : V → Bool}

/-- Follow zero answers while the space stays unchanged, then retain both
continuations at the first query which decreases the space. -/
theorem first_drop (two : ∀ x : V, x+x=0) {R z d} (a : Probe c g R z d)
    (nc : ¬ Uniform g (space c R) z) :
    ∃ (T : Finset I) (i : I) (e : Nat), T ⊆ R ∧ i ∈ R ∧ c i ∉ space c T ∧
      TwoCosets (space c R) (space c T) (c i) ∧ R.card + e ≤ T.card + d ∧
      Probe c g T z e ∧ Probe c g T (z+c i) e := by
  induction a with
  | stop h => exact (nc h).elim
  | @ask R z d i hi p q ih₀ _ =>
    have sub := Finset.erase_subset i R
    have cr := Finset.card_erase_of_mem hi
    have lt := Finset.card_erase_lt_of_mem hi
    by_cases hv : c i ∈ space c (R.erase i)
    · have eq := space_erase_eq c hv
      obtain ⟨T,j,e,ht,hj,hout,cover,fee,a,b⟩ := ih₀ (by rwa [eq])
      exact ⟨T,j,e,Finset.Subset.trans ht sub,sub hj,hout,eq ▸ cover,by omega,a,b⟩
    · exact ⟨R.erase i,i,d,sub,hi,hv,erase_cosets two c R i,by omega,p,q⟩

variable [Fintype V]

theorem physical_to_phases (two : ∀ x : V, x+x=0) (U : Finset I) {W z d}
    (full : space c (active c U W)=W) (p : Probe c g (active c U W) z d) :
    Phases g (histogram c U) W z d := by
  classical
  induction d using Nat.strong_induction_on generalizing W z with
  | h d ih =>
    by_cases unif : Uniform g W z
    · exact .stop unif
    let R := active c U W
    obtain ⟨T,i,e,hT,hi,hout,cover,budget,a,b⟩ :=
      first_drop two p (by rwa [full])
    let H := space c T
    let K := active c U H
    have Hsub : H ≤ W := full ▸ space_mono c hT
    have TK : T ⊆ K := fun j hj =>
      mem_active.2 ⟨(mem_active.1 (hT hj)).1,column_mem c hj⟩
    have KR : K ⊆ R := fun j hj =>
      mem_active.2 ⟨(mem_active.1 hj).1,Hsub (mem_active.1 hj).2⟩
    have Kgen : space c K = H := le_antisymm
      (space_le c (fun _ hj => (mem_active.1 hj).2)) (space_mono c TK)
    have half : Cut (histogram c U) W H (c i) := {
      sub := Hsub, inW := (mem_active.1 hi).2, outside := hout,
      positive := histogram_pos.2 ⟨i,(mem_active.1 hi).1,rfl⟩,
      generated := (space_active c U H).symm.trans Kgen, cover := full ▸ cover }
    have ksmall : K.card < R.card := Finset.card_lt_card
      ((Finset.ssubset_iff_of_subset KR).2 ⟨i,hi,fun h => hout (mem_active.1 h).2⟩)
    have ts := Finset.card_le_card TK
    change R.card+e ≤ T.card+d at budget
    let next := K.card-T.card+e
    have dec : next < d := by dsimp [next]; omega
    have extend {y} (a : Probe c g T y e) : Probe c g K y next := by
      apply pay_outside TK
      intro u hu
      apply a.shift two
      change u ∈ H
      rwa [← Kgen]
    apply Phases.cut half (e:=next)
    · rw [mass_histogram,mass_histogram]
      change R.card-K.card+next ≤ d
      dsimp [next]; omega
    · exact ih next dec Kgen (extend a)
    · exact ih next dec Kgen (extend b)

theorem phases_to_physical (two : ∀ x : V, x+x=0) (U : Finset I) {W z d}
    (p : Phases g (histogram c U) W z d) (full : space c (active c U W)=W) :
    Probe c g (active c U W) z d := by
  classical
  induction p with
  | stop h => exact .stop (full.symm ▸ h)
  | @cut W z d H v e cut budget _ _ ih₀ ih₁ =>
    let R := active c U W
    let K := active c U H
    have gen : space c K=H := (space_active c U H).trans cut.generated
    have KR : K ⊆ R := fun j hj =>
      mem_active.2 ⟨(mem_active.1 hj).1,cut.sub (mem_active.1 hj).2⟩
    rw [mass_histogram,mass_histogram] at budget
    apply Probe.weaken _ budget
    apply pay_outside KR
    intro u hu
    rcases cut.cover u (full ▸ hu) with h|⟨t,ht,rfl⟩
    · exact (ih₀ gen).shift two (gen.symm ▸ h)
    · rw [← add_assoc]
      exact (ih₁ gen).shift two (gen.symm ▸ ht)

end TemplateDepth
