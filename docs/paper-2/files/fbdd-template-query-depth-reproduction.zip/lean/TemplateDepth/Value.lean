import TemplateDepth.Trees

noncomputable section
set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V] [Fintype V]

def signalSpace (μ : V → Nat) : AddSubgroup V :=
  AddSubgroup.closure {v | 0 < μ v}

theorem signalSpace_histogram (c : I → V) (U : Finset I) :
    signalSpace (histogram c U) = space c U := by
  unfold signalSpace space
  congr 1
  ext v
  exact histogram_pos

theorem active_full (c : I → V) (U : Finset I) : active c U (space c U) = U := by
  ext i
  simpa only [mem_active,and_iff_left_iff_imp] using (@column_mem I V _ _ c U i)

def depthValue (c : I → V) (g : V → Bool) (U : Finset I) (z : V) : Nat := by
  classical
  exact Nat.find (show ∃ d, ∃ t : Tree I, t.depth ≤ d ∧ Correct c g U z t from
    ⟨U.card,by
      obtain ⟨t,_,hd,ok⟩ := tree_of_probe (all_bits c g U z)
      exact ⟨t,hd,ok⟩⟩)

theorem depth_spec (c : I → V) (g : V → Bool) (U : Finset I) (z : V) :
    ∃ t : Tree I, t.depth ≤ depthValue c g U z ∧ Correct c g U z t := by
  classical
  unfold depthValue
  exact Nat.find_spec (p:=fun d => ∃ t : Tree I, t.depth ≤ d ∧ Correct c g U z t) _

theorem depth_min {c : I → V} {g : V → Bool} {U z} {t : Tree I}
    (h : Correct c g U z t) : depthValue c g U z ≤ t.depth := by
  classical exact Nat.find_min' _ ⟨t,le_rfl,h⟩

/-- Value of the signal-only recurrence. The fallback concerns unsupported states
only; every state used in the Bellman theorem has a certificate. -/
def Phi (g : V → Bool) (μ : V → Nat) (W : AddSubgroup V) (z : V) : Nat := by
  classical exact if h : ∃ d, Phases g μ W z d then Nat.find h else 0

theorem phi_spec {g : V → Bool} {μ W z} (ex : ∃ d, Phases g μ W z d) :
    Phases g μ W z (Phi g μ W z) := by
  classical simpa only [Phi,dif_pos ex] using Nat.find_spec ex

theorem phi_min {g : V → Bool} {μ W z d} (h : Phases g μ W z d) :
    Phi g μ W z ≤ d := by
  classical
  have ex : ∃ n, Phases g μ W z n := ⟨d,h⟩
  simpa only [Phi,dif_pos ex] using Nat.find_min' ex h

theorem Phases.weaken {g : V → Bool} {μ W z d} (p : Phases g μ W z d)
    {e} (hle : d ≤ e) : Phases g μ W z e := by
  cases p with
  | stop h => exact .stop h
  | cut hc budget a b => exact .cut hc (le_trans budget hle) a b

theorem phase_exists (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool) (U : Finset I)
    {W} (full : space c (active c U W)=W) (z : V) :
    ∃ d, Phases g (histogram c U) W z d :=
  ⟨_,physical_to_phases two U full (all_bits c g _ _)⟩

/-- The exact minimum over unrestricted ordinary physical-bit decision trees. -/
theorem optimal_depth_eq_phi (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool)
    (U : Finset I) (z : V) :
    depthValue c g U z = Phi g (histogram c U) (signalSpace (histogram c U)) z := by
  rw [signalSpace_histogram]
  have full : space c (active c U (space c U)) = space c U := by rw [active_full]
  have ex := phase_exists two c g U full z
  apply le_antisymm
  · have p := phases_to_physical two U (phi_spec ex) full
    rw [active_full] at p
    obtain ⟨t,hd,ok⟩ := (ordinary_iff two).2 p
    exact le_trans (depth_min ok) hd
  · have p := (ordinary_iff two).1 (depth_spec c g U z)
    exact phi_min (physical_to_phases two U full (by rwa [active_full]))

theorem phi_constant {g : V → Bool} {μ W z} (h : Uniform g W z) : Phi g μ W z = 0 :=
  Nat.eq_zero_of_le_zero (phi_min (Phases.stop (d:=0) h))

def options (g : V → Bool) (μ : V → Nat) (W : AddSubgroup V) (z : V) : Set Nat :=
  {d | ∃ H v, Cut μ W H v ∧ d = mass μ W - mass μ H +
        max (Phi g μ H z) (Phi g μ H (z+v))}

/-- The nonconstant clause of the min--max recurrence. IsLeast includes
attainment: a minimizing hyperplane and its two continuations exist. -/
theorem phi_bellman (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool) (U : Finset I)
    {W z} (full : space c (active c U W)=W) (nc : ¬ Uniform g W z) :
    IsLeast (options g (histogram c U) W z) (Phi g (histogram c U) W z) := by
  let μ := histogram c U
  have best {H v} (cut : Cut μ W H v) :
      Phi g μ W z ≤ mass μ W-mass μ H + max (Phi g μ H z) (Phi g μ H (z+v)) := by
    have child := (space_active c U H).trans cut.generated
    have a := phi_spec (phase_exists two c g U child z)
    have b := phi_spec (phase_exists two c g U child (z+v))
    exact phi_min (.cut cut le_rfl (a.weaken (le_max_left _ _)) (b.weaken (le_max_right _ _)))
  constructor
  · have p := phi_spec (phase_exists two c g U full z)
    generalize eq : Phi g (histogram c U) W z = n at p
    cases p with
    | stop h => exact (nc h).elim
    | @cut _ _ _ H v e cut fee a b =>
      refine ⟨H,v,cut,le_antisymm (eq ▸ best cut) ?_⟩
      exact le_trans (Nat.add_le_add_left (max_le (phi_min a) (phi_min b)) _) fee
  · rintro _ ⟨H,v,cut,rfl⟩
    exact best cut

end TemplateDepth
