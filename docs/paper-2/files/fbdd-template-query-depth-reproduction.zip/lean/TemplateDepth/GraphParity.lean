import TemplateDepth.Trace
import TemplateDepth.Templates
import Mathlib.Algebra.BigOperators.Ring.Finset
set_option linter.unusedSectionVars false

namespace TemplateDepth.Graph
abbrev Bit := ZMod 2

variable {Y E : Type} [Fintype Y] [Fintype E] [DecidableEq Y] [DecidableEq E]

def delta : Option Y → Y → Bit
  | none => 0
  | some i => unitColumn i

structure RootedGraph (Y E : Type) where
  src : E → Option Y
  dst : E → Option Y

def edge (G : RootedGraph Y E) (e : E) : Y → Bit := delta (G.src e) + delta (G.dst e)

inductive Walk (G : RootedGraph Y E) : Option Y → Prop
  | root : Walk G none
  | forward (e : E) : Walk G (G.src e) → Walk G (G.dst e)
  | backward (e : E) : Walk G (G.dst e) → Walk G (G.src e)

def Connected (G : RootedGraph Y E) := ∀ v : Y, Walk G (some v)

theorem bit_two (u : Bit) : u+u=0 := by
  have h : ∀ x : Bit, x+x=0 := by decide
  exact h u

theorem vec_two (v : Y → Bit) : v+v=0 := funext (fun j => bit_two (v j))

theorem reachable_delta {G : RootedGraph Y E} {v : Option Y} (reach : Walk G v) :
    delta v ∈ space (edge G) Finset.univ := by
  induction reach with
  | root => exact (space _ _).zero_mem
  | forward e _ ih =>
    have sum := (space (edge G) Finset.univ).add_mem ih (column_mem (edge G) (Finset.mem_univ e))
    simpa only [edge,← add_assoc,vec_two,zero_add] using sum
  | backward e _ ih =>
    have sum := (space (edge G) Finset.univ).add_mem (column_mem (edge G) (Finset.mem_univ e)) ih
    simpa only [edge,add_assoc,vec_two,add_zero] using sum

theorem odd_edges (G : RootedGraph Y E) (conn : Connected G) :
    ∃ a : Finset E, ∀ v, (∑ e ∈ a, edge G e) v = 1 := by
  classical
  have sum : (∑ v : Y, unitColumn v) ∈ space (edge G) Finset.univ := by
    exact AddSubgroup.sum_mem _ (fun v _ => reachable_delta (conn v))
  obtain ⟨a,_,eq⟩ := realized vec_two (edge G) _ sum
  exact ⟨a,fun v => by rw [eq,sum_unit]; simp⟩

def coeff (G : RootedGraph Y E) (y : Finset Y) (e : E) : Bit := ∑ v ∈ y, edge G e v
def cutSet (G : RootedGraph Y E) (y : Finset Y) : Finset E :=
  Finset.univ.filter (fun e => coeff G y e=1)
def score (G : RootedGraph Y E) (y : Finset Y) (a : Finset E) : Bit := ∑ e ∈ a, coeff G y e

theorem score_transpose (G : RootedGraph Y E) (y : Finset Y) (a : Finset E) :
    score G y a = ∑ v ∈ y, (∑ e ∈ a, edge G e) v := by
  simp only [score,coeff,Finset.sum_apply]
  rw [Finset.sum_comm]

def flip (i : Y) (a : Finset Y) := if i ∈ a then a.erase i else insert i a

theorem flip_other {j i : Y} (a : Finset Y) (ne : j≠i) :
    j ∈ flip i a ↔ j ∈ a := by unfold flip; split <;> simp [ne]

theorem flip_sum {T : Type} [DecidableEq T] (a : Finset T) (i : T) (f : T → Bit)
    (one : f i=1) : (∑ j ∈ flip i a, f j) ≠ ∑ j ∈ a, f j := by
  unfold flip
  split
  next hi =>
    have eq := Finset.add_sum_erase a f hi
    rw [one] at eq
    intro h
    rw [← h] at eq
    have h0 : (1:Bit)=0 := add_right_cancel (eq.trans (zero_add _).symm)
    exact one_ne_zero h0
  next hi =>
    rw [Finset.sum_insert hi,one]
    intro h
    exact one_ne_zero (add_right_cancel (h.trans (zero_add _).symm))

theorem edge_flip {G : RootedGraph Y E} {y : Finset Y} {a : Finset E} {e}
    (he : e ∈ cutSet G y) : score G y (flip e a) ≠ score G y a :=
  flip_sum a e _ (Finset.mem_filter.1 he).2

theorem color_flip {G : RootedGraph Y E} {a : Finset E}
    (odd : ∀ v, (∑ e ∈ a, edge G e) v=1) (y : Finset Y) (v : Y) :
    score G (flip v y) a ≠ score G y a := by
  rw [score_transpose,score_transpose]
  exact flip_sum _ _ _ (odd v)

def packed (y : Finset Y) (a : Finset E) : Finset (Y ⊕ E) := y.disjSum a
def colors (p : Finset (Y ⊕ E)) := p.toLeft
def data (p : Finset (Y ⊕ E)) := p.toRight
def answer (G : RootedGraph Y E) (p : Finset (Y ⊕ E)) : Bool :=
  decide (score G (colors p) (data p) = 1)

end TemplateDepth.Graph
