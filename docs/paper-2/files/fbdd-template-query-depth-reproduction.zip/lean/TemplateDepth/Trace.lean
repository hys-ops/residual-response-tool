import TemplateDepth.Trees

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I : Type*} [DecidableEq I]

def Tree.trace (a : Finset I) : Tree I → Finset I
  | .leaf _ => ∅
  | .query i l h => insert i (if i ∈ a then h.trace a else l.trace a)

theorem trace_size (t : Tree I) (a : Finset I) : (t.trace a).card ≤ t.depth := by
  induction t with
  | leaf => simp [Tree.trace,Tree.depth]
  | query i l h lo hi =>
    rw [Tree.trace,Tree.depth]
    split <;> apply le_trans (Finset.card_insert_le _ _) <;> omega

theorem trace_forces (t : Tree I) (a b : Finset I)
    (same : ∀ i ∈ t.trace a, i ∈ a ↔ i ∈ b) : t.run a=t.run b := by
  induction t with
  | leaf => rfl
  | query i l h lo hi =>
    have first := same i (Finset.mem_insert_self _ _)
    by_cases yes : i ∈ a
    · have next : ∀ j ∈ h.trace a, j ∈ a ↔ j ∈ b := fun j hj => same j (by
        simp only [Tree.trace,if_pos yes]; exact Finset.mem_insert_of_mem hj)
      simpa [Tree.run,yes,first.1 yes] using hi next
    · have nb : i ∉ b := fun q => yes (first.2 q)
      have next : ∀ j ∈ l.trace a, j ∈ a ↔ j ∈ b := fun j hj => same j (by
        simp only [Tree.trace,if_neg yes]; exact Finset.mem_insert_of_mem hj)
      simpa [Tree.run,yes,nb] using lo next

/-- Read the listed coordinates and pass their true subset to a continuation. -/
def gather : List I → Finset I → (Finset I → Tree I) → Tree I
  | [],s,k => k s
  | i::is,s,k => .query i (gather is s k) (gather is (insert i s) k)

theorem gather_run (L : List I) (s a : Finset I) (k : Finset I → Tree I) :
    (gather L s k).run a = (k (s ∪ (L.toFinset ∩ a))).run a := by
  induction L generalizing s with
  | nil => simp [gather]
  | cons i L ih =>
    by_cases h : i ∈ a
    · simp only [gather,Tree.run,if_pos h,ih,List.toFinset_cons]
      congr 2; ext j; by_cases eq : j=i <;> simp_all
    · simp only [gather,Tree.run,if_neg h,ih,List.toFinset_cons]
      congr 2; ext j; by_cases eq : j=i <;> simp_all

theorem gather_depth (L : List I) (s : Finset I) (k : Finset I → Tree I) {d : Nat}
    (bound : ∀ a, (k a).depth ≤ d) : (gather L s k).depth ≤ L.length+d := by
  induction L generalizing s with
  | nil => simpa [gather] using bound s
  | cons i L ih =>
    have a := ih s; have b := ih (insert i s)
    simp only [gather,Tree.depth,List.length_cons]
    omega

end TemplateDepth
