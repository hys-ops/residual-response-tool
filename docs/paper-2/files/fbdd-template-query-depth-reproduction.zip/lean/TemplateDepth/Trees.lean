import TemplateDepth.Normalize
set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V]

inductive Tree (I : Type*)
  | leaf (answer : Bool)
  | query (i : I) (low high : Tree I)

def Tree.depth : Tree I → Nat
  | .leaf _ => 0
  | .query _ l h => max l.depth h.depth + 1

def Tree.run (a : Finset I) : Tree I → Bool
  | .leaf b => b
  | .query i l h => if i ∈ a then h.run a else l.run a

def Tree.Fresh : Tree I → Finset I → Prop
  | .leaf _,_ => True
  | .query i l h,R => i ∈ R ∧ l.Fresh (R.erase i) ∧ h.Fresh (R.erase i)

theorem run_agree {t : Tree I} {R a b : Finset I} (fresh : t.Fresh R)
    (agree : ∀ j ∈ R, j ∈ a ↔ j ∈ b) : t.run a = t.run b := by
  induction t generalizing R with
  | leaf => rfl
  | query i l h ih₀ ih₁ =>
    obtain ⟨hi,fl,fh⟩ := fresh
    have rest := fun j (hj : j ∈ R.erase i) => agree j (Finset.mem_erase.1 hj).2
    unfold Tree.run
    by_cases val : i ∈ a
    · simpa [val,(agree i hi).1 val] using ih₁ fh rest
    · have valb : i ∉ b := fun hb => val ((agree i hi).2 hb)
      simpa [val,valb] using ih₀ fl rest

/-- Any binary decision tree can be specialized to its unread coordinates,
including trees which repeat queries or ask known coordinates. -/
theorem prune (t : Tree I) (R B : Finset I) :
    ∃ q : Tree I, q.Fresh R ∧ q.depth ≤ t.depth ∧
      ∀ a ⊆ R, q.run a = t.run (B ∪ a) := by
  classical
  induction t generalizing R B with
  | leaf b => exact ⟨.leaf b,trivial,le_rfl,fun _ _ => rfl⟩
  | query i l h ih₀ ih₁ =>
    by_cases fixed : i ∈ B
    · obtain ⟨q,f,d,eq⟩ := ih₁ R B
      refine ⟨q,f,by simp only [Tree.depth]; omega,?_⟩
      intro a ha
      simpa [Tree.run,fixed] using eq a ha
    by_cases live : i ∈ R
    · obtain ⟨p,fp,dp,ep⟩ := ih₀ (R.erase i) B
      obtain ⟨q,fq,dq,eq⟩ := ih₁ (R.erase i) (insert i B)
      refine ⟨.query i p q,⟨live,fp,fq⟩,by simp only [Tree.depth]; omega,?_⟩
      intro a ha
      by_cases v : i ∈ a
      · have sub : a.erase i ⊆ R.erase i := Finset.erase_subset_erase i ha
        have same : q.run a = q.run (a.erase i) := run_agree fq (by
          intro j hj; simp [(Finset.mem_erase.1 hj).1])
        have union : insert i B ∪ a.erase i = B ∪ a := by
          ext j; by_cases e : j=i <;> simp_all
        simpa [Tree.run,v,fixed,union] using same.trans (eq _ sub)
      · have sub : a ⊆ R.erase i := fun j hj =>
          Finset.mem_erase.2 ⟨fun e => v (e ▸ hj),ha hj⟩
        simpa [Tree.run,v,fixed] using ep a sub
    · obtain ⟨p,f,d,eq⟩ := ih₀ R B
      refine ⟨p,f,by simp only [Tree.depth]; omega,?_⟩
      intro a ha
      have v : i ∉ a := fun h => live (ha h)
      simpa [Tree.run,v,fixed] using eq a ha

theorem sum_mem (c : I → V) {a R : Finset I} (sub : a ⊆ R) :
    ∑ j ∈ a, c j ∈ space c R := by
  classical
  induction a using Finset.induction_on with
  | empty => simpa using (space c R).zero_mem
  | @insert i a hi ih =>
    rw [Finset.sum_insert hi]
    exact (space c R).add_mem (column_mem c (sub (Finset.mem_insert_self _ _)))
      (ih (Finset.Subset.trans (Finset.subset_insert _ _) sub))

theorem realized (two : ∀ x : V, x+x=0) (c : I → V) (R : Finset I)
    {u} (hu : u ∈ space c R) : ∃ a ⊆ R, ∑ j ∈ a, c j = u := by
  classical
  induction R using Finset.induction_on generalizing u with
  | empty =>
    have sub : space c ∅ ≤ ⊥ := space_le c (by simp)
    have eq : u=0 := sub hu
    exact ⟨∅,by simp,by simp [eq]⟩
  | @insert i R hi ih =>
    have cover := erase_cosets two c (insert i R) i u hu
    rw [Finset.erase_insert hi] at cover
    rcases cover with h|⟨t,ht,rfl⟩
    · obtain ⟨a,ha,ea⟩ := ih h
      exact ⟨a,Finset.Subset.trans ha (Finset.subset_insert _ _),ea⟩
    · obtain ⟨a,ha,ea⟩ := ih ht
      exact ⟨insert i a,Finset.insert_subset_insert i ha,by
        rw [Finset.sum_insert (fun h => hi (ha h)),ea]⟩

def Correct (c : I → V) (g : V → Bool) (R : Finset I) (z : V) (t : Tree I) : Prop :=
  ∀ a ⊆ R, t.run a = g (z + ∑ j ∈ a, c j)

theorem tree_of_probe {c : I → V} {g : V → Bool} {R z d}
    (p : Probe c g R z d) : ∃ t : Tree I, t.Fresh R ∧ t.depth ≤ d ∧ Correct c g R z t := by
  classical
  induction p with
  | @stop R z d h =>
    exact ⟨.leaf (g z),trivial,Nat.zero_le _,fun _ ha => (h _ (sum_mem c ha)).symm⟩
  | @ask R z d i hi _ _ ih₀ ih₁ =>
    obtain ⟨l,fl,dl,el⟩ := ih₀
    obtain ⟨h,fh,dh,eh⟩ := ih₁
    refine ⟨.query i l h,⟨hi,fl,fh⟩,by simp only [Tree.depth]; omega,?_⟩
    intro a ha
    by_cases v : i ∈ a
    · have same : h.run a = h.run (a.erase i) := run_agree fh (by
        intro j hj; simp [(Finset.mem_erase.1 hj).1])
      rw [Tree.run,if_pos v,same,eh _ (Finset.erase_subset_erase i ha),add_assoc,
        Finset.add_sum_erase _ _ v]
    · rw [Tree.run,if_neg v]
      exact el _ (fun j hj => Finset.mem_erase.2 ⟨fun eq => v (eq ▸ hj),ha hj⟩)

theorem probe_of_fresh (two : ∀ x : V, x+x=0) {c : I → V} {g : V → Bool}
    {t : Tree I} {R z} (fr : t.Fresh R) (h : Correct c g R z t) :
    Probe c g R z t.depth := by
  classical
  induction t generalizing R z with
  | leaf b =>
    apply Probe.stop
    intro u hu
    obtain ⟨a,ha,rfl⟩ := realized two c R hu
    have first := h a ha
    have second := h ∅ (Finset.empty_subset _)
    simpa [Tree.run] using first.symm.trans second
  | query i l t ih₀ ih₁ =>
    obtain ⟨hi,fl,ft⟩ := fr
    apply Probe.ask hi
    · apply Probe.weaken _ (Nat.le_max_left _ _)
      apply ih₀ fl
      intro a ha
      have hni : i ∉ a := fun h => (Finset.mem_erase.1 (ha h)).1 rfl
      simpa [Tree.run,hni] using h a (Finset.Subset.trans ha (Finset.erase_subset _ _))
    · apply Probe.weaken _ (Nat.le_max_right _ _)
      apply ih₁ ft
      intro a ha
      have hni : i ∉ a := fun h => (Finset.mem_erase.1 (ha h)).1 rfl
      have same : t.run a = t.run (insert i a) := run_agree ft (by
        intro j hj; simp [(Finset.mem_erase.1 hj).1])
      rw [same,add_assoc,← Finset.sum_insert hni]
      simpa [Tree.run] using h (insert i a)
        (Finset.insert_subset hi (Finset.Subset.trans ha (Finset.erase_subset _ _)))

theorem ordinary_iff (two : ∀ x : V, x+x=0) {c : I → V} {g : V → Bool} {R z d} :
    (∃ t : Tree I, t.depth ≤ d ∧ Correct c g R z t) ↔ Probe c g R z d := by
  constructor
  · rintro ⟨t,ht,h⟩
    obtain ⟨q,fr,small,same⟩ := prune t R ∅
    have cert : Correct c g R z q := by
      intro a ha; simpa using (same a ha).trans (by simpa using h a ha)
    exact (probe_of_fresh two fr cert).weaken (le_trans small ht)
  · intro h
    obtain ⟨t,_,ht,ok⟩ := tree_of_probe h
    exact ⟨t,ht,ok⟩

end TemplateDepth
