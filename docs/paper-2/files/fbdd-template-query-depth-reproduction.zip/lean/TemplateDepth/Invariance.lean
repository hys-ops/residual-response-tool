import TemplateDepth.Value
set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I J V : Type*} [DecidableEq I] [DecidableEq J] [AddCommGroup V] [Fintype V]

theorem same_histogram_same_depth (two : ∀ x : V, x+x=0) (g : V → Bool) (z : V)
    (a : I → V) (b : J → V) (U : Finset I) (T : Finset J)
    (same : histogram a U=histogram b T) : depthValue a g U z=depthValue b g T z := by
  rw [optimal_depth_eq_phi two,optimal_depth_eq_phi two,same]

theorem phi_coset (two : ∀ x : V, x+x=0) (c : I → V) (g : V → Bool) (U : Finset I)
    {W} (full : space c (active c U W)=W) (z u : V) (hu : u ∈ W) :
    Phi g (histogram c U) W (z+u) = Phi g (histogram c U) W z := by
  have step (y : V) : Phi g (histogram c U) W (y+u) ≤ Phi g (histogram c U) W y := by
    have proof := phi_spec (phase_exists two c g U full y)
    have phys := phases_to_physical two U proof full
    exact phi_min (physical_to_phases two U full (phys.shift two (full.symm ▸ hu)))
  exact le_antisymm (step z) (by simpa [add_assoc,two] using step (z+u))

end TemplateDepth
