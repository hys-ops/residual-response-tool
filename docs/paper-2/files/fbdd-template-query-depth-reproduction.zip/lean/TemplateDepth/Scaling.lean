import TemplateDepth.Value
import Mathlib.Algebra.BigOperators.Ring.Finset
set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {V : Type*} [AddCommGroup V] [Fintype V]

def scale (k : Nat) (μ : V → Nat) (v : V) := k * μ v

theorem mass_scale (μ : V → Nat) (W : AddSubgroup V) (k : Nat) :
    mass (scale k μ) W = k * mass μ W := by
  classical unfold mass scale
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro v _
  split <;> simp

theorem scale_cut {μ : V → Nat} {k W H v} (pos : 0<k) :
    Cut (scale k μ) W H v ↔ Cut μ W H v := by
  have eq : supportedSpan (scale k μ) H = supportedSpan μ H := by
    unfold supportedSpan; congr 1; ext v; simp [scale,pos]
  constructor <;> intro c
  · exact ⟨c.sub,c.inW,c.outside,by simpa [scale,pos] using c.positive,eq ▸ c.generated,c.cover⟩
  · exact ⟨c.sub,c.inW,c.outside,by simpa [scale,pos] using c.positive,eq.symm ▸ c.generated,c.cover⟩

theorem phases_scale {μ : V → Nat} {g W z d k} (pos : 0<k)
    (a : Phases g μ W z d) : Phases g (scale k μ) W z (k*d) := by
  induction a with
  | stop h => exact .stop h
  | cut cut fee _ _ x y =>
    apply Phases.cut ((scale_cut pos).2 cut) _ x y
    simpa only [mass_scale,← Nat.mul_sub,← Nat.mul_add] using Nat.mul_le_mul_left k fee

theorem phases_unscale {μ : V → Nat} {g W z d k} (pos : 0<k)
    (a : Phases g (scale k μ) W z d) : ∃ e, k*e ≤ d ∧ Phases g μ W z e := by
  induction a with
  | stop h => exact ⟨0,by simp,.stop h⟩
  | @cut W z d H v e cut fee _ _ x y =>
    obtain ⟨a,ha,pa⟩ := x
    obtain ⟨b,hb,pb⟩ := y
    have mx : k*max a b ≤ e := by
      rcases le_total a b with h|h
      · simpa [max_eq_right h] using hb
      · simpa [max_eq_left h] using ha
    rw [mass_scale,mass_scale,← Nat.mul_sub] at fee
    refine ⟨_,?_,Phases.cut ((scale_cut pos).1 cut) le_rfl (pa.weaken (le_max_left a b))
      (pb.weaken (le_max_right a b))⟩
    rw [Nat.mul_add]
    exact le_trans (Nat.add_le_add_left mx _) fee

theorem phi_scale {μ : V → Nat} {g W z k} (pos : 0<k) (ex : ∃ d, Phases g μ W z d) :
    Phi g (scale k μ) W z = k*Phi g μ W z := by
  have upper := phases_scale pos (phi_spec ex)
  apply le_antisymm (phi_min upper)
  obtain ⟨e,fee,cert⟩ := phases_unscale pos (phi_spec ⟨_,upper⟩)
  exact le_trans (Nat.mul_le_mul_left _ (phi_min cert)) fee

end TemplateDepth
