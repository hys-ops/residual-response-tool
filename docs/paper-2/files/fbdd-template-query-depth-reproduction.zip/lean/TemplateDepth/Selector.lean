import TemplateDepth.Scaling
import TemplateDepth.FiniteCheck
import Mathlib.Data.ZMod.Basic

set_option linter.unusedSectionVars false

namespace TemplateDepth.Selector
abbrev Signal := ZMod 2 × ZMod 2 × ZMod 2

def col (i : Fin 7) : Signal :=
  (if (i.val+1).testBit 0 then 1 else 0,
   if (i.val+1).testBit 1 then 1 else 0,
   if (i.val+1).testBit 2 then 1 else 0)

def mux (x : Signal) : Bool := if x.1 = 0 then decide (x.2.1=1) else decide (x.2.2=1)
def names : Finset (Fin 7) := Finset.univ

theorem binary : ∀ x : Signal, x+x=0 := by decide
set_option maxRecDepth 200000 in
set_option maxHeartbeats 25000000 in
theorem base_upper : canB col mux 6 names 0 = true := by decide
set_option maxRecDepth 200000 in
set_option maxHeartbeats 25000000 in
theorem base_lower : canB col mux 5 names 0 = false := by decide

theorem base_depth : depthValue col mux names 0 = 6 := by
  have yes := (canB_spec binary col mux names 0 6).1 base_upper
  have no : ¬ Probe col mux names 0 5 := by
    intro p
    have h := (canB_spec binary col mux names 0 5).2 p
    rw [base_lower] at h
    contradiction
  obtain ⟨t,hd,ok⟩ := (ordinary_iff binary).2 yes
  have ub := le_trans (depth_min ok) hd
  have p := (ordinary_iff binary).1 (depth_spec col mux names 0)
  by_contra h
  exact no (p.weaken (by omega))

theorem repeated_depth (m : Nat) (hm : 0<m) :
    Phi mux (scale m (histogram col names)) (space col names) 0 = 6*m := by
  have full : space col (active col names (space col names)) = space col names := by rw [active_full]
  rw [phi_scale hm (phase_exists binary col mux names full 0)]
  have base := optimal_depth_eq_phi binary col mux names 0
  rw [signalSpace_histogram,base_depth] at base
  rw [← base,Nat.mul_comm]

theorem seven_thousand : Phi mux (scale 1000 (histogram col names)) (space col names) 0 = 6000 :=
  repeated_depth 1000 (by decide)

end TemplateDepth.Selector
