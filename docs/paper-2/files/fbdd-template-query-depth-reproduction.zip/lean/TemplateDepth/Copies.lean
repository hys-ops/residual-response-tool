import TemplateDepth.Selector

set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V] [Fintype V]

theorem histogram_copies (c : I → V) (U : Finset I) (m : Nat) :
    histogram (fun x : I × Fin m => c x.1) (U ×ˢ Finset.univ) = scale m (histogram c U) := by
  classical
  funext v
  have fibers : (U ×ˢ (Finset.univ : Finset (Fin m))).filter (fun x => c x.1=v) =
      (U.filter (fun i => c i=v)) ×ˢ Finset.univ := by
    ext x; simp [and_assoc]
  simp only [histogram,scale,fibers,Finset.card_product,Finset.card_univ,Fintype.card_fin]
  exact Nat.mul_comm _ _

theorem signalSpace_scale (μ : V → Nat) {m : Nat} (pos : 0<m) :
    signalSpace (scale m μ) = signalSpace μ := by
  unfold signalSpace
  congr 1
  ext v
  simp [scale,pos]

namespace Selector
theorem distinct_types : Function.Injective col := by decide
theorem nonzero_types : ∀ i, col i ≠ 0 := by decide

theorem physical_selector_depth (m : Nat) (pos : 0<m) :
    depthValue (fun x : Fin 7 × Fin m => col x.1) mux (names ×ˢ Finset.univ) 0 = 6*m := by
  rw [optimal_depth_eq_phi binary,histogram_copies,signalSpace_scale _ pos,signalSpace_histogram]
  exact repeated_depth m pos

theorem physical_7000 :
    (names ×ˢ (Finset.univ : Finset (Fin 1000))).card = 7000 ∧
    depthValue (fun x : Fin 7 × Fin 1000 => col x.1) mux (names ×ˢ Finset.univ) 0 = 6000 := by
  exact ⟨by simp [names],physical_selector_depth 1000 (by decide)⟩
end Selector
end TemplateDepth
