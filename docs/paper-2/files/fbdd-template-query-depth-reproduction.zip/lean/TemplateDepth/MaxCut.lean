import TemplateDepth.GraphParity
import Mathlib.Data.Finset.Max
set_option linter.unusedSectionVars false

namespace TemplateDepth.Graph
variable {Y E : Type} [Fintype Y] [Fintype E] [DecidableEq Y] [DecidableEq E]

def color (y : Finset Y) : Option Y → Bit
  | none => 0
  | some i => if i ∈ y then 1 else 0

theorem sum_delta (y : Finset Y) (v : Option Y) : ∑ j ∈ y, delta v j = color y v := by
  cases v with
  | none => simp [delta,color]
  | some i => simp [delta,unitColumn,color,eq_comm]

theorem edge_crosses (G : RootedGraph Y E) (y : Finset Y) (e : E) :
    e ∈ cutSet G y ↔ color y (G.src e) ≠ color y (G.dst e) := by
  have addOne : ∀ a b : Bit, a+b=1 ↔ a≠b := by decide
  simp [cutSet,coeff,edge,Finset.sum_add_distrib,sum_delta,addOne]

theorem score_restrict (G : RootedGraph Y E) (y : Finset Y) (a : Finset E) :
    score G y (cutSet G y ∩ a) = score G y a := by
  apply Finset.sum_subset (Finset.inter_subset_right)
  intro e he hn
  have n : coeff G y e ≠ 1 := fun h => hn (Finset.mem_inter.mpr
    ⟨Finset.mem_filter.mpr ⟨Finset.mem_univ _,h⟩,he⟩)
  have both : ∀ x : Bit, x ≠ 1 → x=0 := by decide
  exact both _ n

noncomputable def graphTree (G : RootedGraph Y E) : Tree (Y ⊕ E) := by
  classical
  let ys := packed (Finset.univ : Finset Y) (∅ : Finset E)
  exact gather ys.toList ∅ (fun p =>
    let es := packed (∅ : Finset Y) (cutSet G (colors p))
    gather es.toList ∅ (fun q => .leaf (decide (score G (colors p) (data q)=1))))

theorem graphTree_correct (G : RootedGraph Y E) (p : Finset (Y ⊕ E)) :
    (graphTree G).run p = answer G p := by
  classical
  unfold graphTree
  simp only [gather_run,Finset.toList_toFinset,Finset.empty_union,Tree.run]
  simp only [colors,data,packed,Finset.toLeft_inter,Finset.toRight_inter,Finset.toLeft_disjSum,
    Finset.toRight_disjSum,Finset.univ_inter,score_restrict,answer]

theorem graphTree_depth (G : RootedGraph Y E) {b : Nat} (maxBound : ∀ y, (cutSet G y).card ≤ b) :
    (graphTree G).depth ≤ Fintype.card Y + b := by
  classical
  unfold graphTree
  have leftCount : (packed (Finset.univ : Finset Y) (∅ : Finset E)).toList.length=Fintype.card Y := by
    simp [packed]
  rw [← leftCount]
  apply gather_depth
  intro p
  have lim := @gather_depth (Y ⊕ E) _ (packed (∅ : Finset Y) (cutSet G (colors p))).toList
    ∅ (fun q => .leaf (decide (score G (colors p) (data q)=1))) 0 (fun _ => le_rfl)
  simpa [packed] using lim.trans (by simpa [packed] using maxBound (colors p))

theorem graph_lower (G : RootedGraph Y E) (conn : Connected G) (t : Tree (Y ⊕ E))
    (ok : ∀ p, t.run p=answer G p) (y : Finset Y) :
    Fintype.card Y+(cutSet G y).card ≤ t.depth := by
  classical
  obtain ⟨a,odd⟩ := odd_edges G conn
  let p := packed y a
  have inj : ∀ a b : Bit, decide (a=1)=decide (b=1) → a=b := by decide
  have necessary : packed (Finset.univ : Finset Y) (cutSet G y) ⊆ t.trace p := by
    intro i hi
    by_contra miss
    cases i with
    | inl v =>
      let q : Finset (Y ⊕ E) := packed (flip v y) a
      have same : t.run p=t.run q := by
        apply trace_forces
        intro j hj
        cases j with
        | inl u =>
          have ne : u≠v := fun e => miss (e ▸ hj)
          simpa [p,q,packed] using (flip_other y ne).symm
        | inr e => simp [p,q,packed]
      rw [ok,ok] at same
      apply color_flip odd y v
      apply inj
      simpa [answer,p,q,packed,colors,data] using same.symm
    | inr e =>
      have he : e ∈ cutSet G y := by simpa [packed] using hi
      let q : Finset (Y ⊕ E) := packed y (flip e a)
      have same : t.run p=t.run q := by
        apply trace_forces
        intro j hj
        cases j with
        | inl u => simp [p,q,packed]
        | inr f =>
          have ne : f≠e := fun eq => miss (eq ▸ hj)
          simpa [p,q,packed] using (flip_other a ne).symm
      rw [ok,ok] at same
      apply edge_flip he (a:=a)
      apply inj
      simpa [answer,p,q,packed,colors,data] using same.symm
  simpa [packed] using (Finset.card_le_card necessary).trans (trace_size t p)

/-- The graph-directed strategy is optimal and its own worst depth equals the
rooted vertex count plus the maximum cut. The maximizing coloring is attained. -/
theorem graph_optimal (G : RootedGraph Y E) (conn : Connected G) :
    ∃ y : Finset Y, (∀ s, (cutSet G s).card ≤ (cutSet G y).card) ∧
      (graphTree G).depth = Fintype.card Y + (cutSet G y).card ∧
      ∀ t : Tree (Y ⊕ E), (∀ p, t.run p=answer G p) → (graphTree G).depth ≤ t.depth := by
  classical
  obtain ⟨y,_,hm⟩ := Finset.exists_max_image (Finset.univ : Finset (Finset Y))
    (fun s => (cutSet G s).card) Finset.univ_nonempty
  have maxBound := fun s => hm s (Finset.mem_univ _)
  have eq := le_antisymm (graphTree_depth G maxBound) (graph_lower G conn _ (graphTree_correct G) y)
  exact ⟨y,maxBound,eq,fun t h => eq ▸ graph_lower G conn t h y⟩

end TemplateDepth.Graph
