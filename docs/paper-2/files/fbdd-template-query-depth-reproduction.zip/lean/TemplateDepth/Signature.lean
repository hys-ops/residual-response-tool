import TemplateDepth.Physical

noncomputable section
open scoped BigOperators
set_option linter.unusedSectionVars false

namespace TemplateDepth
variable {I V : Type*} [DecidableEq I] [AddCommGroup V] [Fintype V]

def histogram (c : I → V) (U : Finset I) (v : V) : Nat := by
  classical
  exact (U.filter (fun i => c i=v)).card

def active (c : I → V) (U : Finset I) (W : AddSubgroup V) : Finset I := by
  classical
  exact U.filter (fun i => c i ∈ W)

theorem mem_active {c : I → V} {U : Finset I} {W : AddSubgroup V} {i} :
    i ∈ active c U W ↔ i ∈ U ∧ c i ∈ W := by classical simp [active]

theorem histogram_pos {c : I → V} {U : Finset I} {v} :
    0 < histogram c U v ↔ ∃ i ∈ U, c i=v := by
  classical simp [histogram,Finset.card_pos,Finset.Nonempty]

def mass (μ : V → Nat) (W : AddSubgroup V) : Nat := by
  classical exact ∑ v : V, if v ∈ W then μ v else 0

theorem mass_histogram (c : I → V) (U : Finset I) (W : AddSubgroup V) :
    mass (histogram c U) W = (active c U W).card := by
  classical
  have count := Finset.sum_fiberwise_of_maps_to (s:=active c U W)
    (t:=Finset.univ) (g:=c) (fun _ _ => Finset.mem_univ _) (fun _ => (1:Nat))
  simp only [Finset.sum_const, Nat.nsmul_eq_mul, mul_one] at count
  rw [← count]
  unfold mass
  apply Finset.sum_congr rfl
  intro v _
  by_cases hv : v ∈ W
  · rw [if_pos hv]
    unfold histogram
    congr 1
    ext i
    simp only [Finset.mem_filter,mem_active]
    constructor
    · rintro ⟨hi,he⟩
      exact ⟨⟨hi,he ▸ hv⟩,he⟩
    · exact fun h => ⟨h.1.1,h.2⟩
  · rw [if_neg hv]
    symm
    apply Finset.card_eq_zero.mpr
    apply Finset.eq_empty_of_forall_not_mem
    intro i h
    obtain ⟨hi,he⟩ := Finset.mem_filter.1 h
    exact hv (he ▸ (mem_active.1 hi).2)

def supportedSpan (μ : V → Nat) (H : AddSubgroup V) : AddSubgroup V :=
  AddSubgroup.closure {v | 0 < μ v ∧ v ∈ H}

theorem space_active (c : I → V) (U : Finset I) (H : AddSubgroup V) :
    space c (active c U H) = supportedSpan (histogram c U) H := by
  unfold space supportedSpan
  congr 1
  ext v
  constructor
  · rintro ⟨i,hi,rfl⟩
    obtain ⟨hiU,hiH⟩ := mem_active.1 hi
    exact ⟨histogram_pos.2 ⟨i,hiU,rfl⟩,hiH⟩
  · rintro ⟨h,hv⟩
    obtain ⟨i,hi,rfl⟩ := histogram_pos.1 h
    exact ⟨i,mem_active.2 ⟨hi,hv⟩,rfl⟩

/-- A supported hyperplane and a representative of the second coset. -/
structure Cut (μ : V → Nat) (W H : AddSubgroup V) (v : V) : Prop where
  sub : H ≤ W
  inW : v ∈ W
  outside : v ∉ H
  positive : 0 < μ v
  generated : supportedSpan μ H = H
  cover : TwoCosets W H v

/-- A certificate for the two-branch recurrence, using signal data only. -/
inductive Phases (g : V → Bool) (μ : V → Nat) : AddSubgroup V → V → Nat → Prop
  | stop {W z d} : Uniform g W z → Phases g μ W z d
  | cut {W z d H v e} : Cut μ W H v → mass μ W - mass μ H + e ≤ d →
      Phases g μ H z e → Phases g μ H (z+v) e → Phases g μ W z d

end TemplateDepth
