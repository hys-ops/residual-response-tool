import TemplateDepth.Value
import FBDD.Diagram

noncomputable section
set_option linter.unusedSectionVars false

namespace TemplateDepth
/-- Reuse the first paper's topologically indexed sharing semantics. -/
structure Diagram (X : Type) where
  nodes : Nat
  graph : FBDD.Net X nodes
  root : Fin nodes
  free : graph.free

structure Template (I X : Type) where
  left : Finset I → Diagram X
  right : Finset I → Diagram X

variable {I X V : Type} [DecidableEq I] [AddCommGroup V] [Fintype V]

def Agrees (s : Template I X) (a : Finset I) : Prop :=
  ∀ x : X → Bool, (s.left a).graph.boolVal x (s.left a).root =
    (s.right a).graph.boolVal x (s.right a).root

def Represents (s : Template I X) (U : Finset I) (c : I → V) (g : V → Bool) : Prop :=
  ∀ a ⊆ U, Agrees s a ↔ g (∑ j ∈ a, c j)=true

def Solves (s : Template I X) (U : Finset I) (t : Tree I) : Prop :=
  ∀ a ⊆ U, t.run a = true ↔ Agrees s a

/-- A cost j suffices on the actual template iff the signal-only optimum is ≤ j. -/
theorem template_exact (two : ∀ x : V, x+x=0) {s : Template I X} {U : Finset I}
    {c : I → V} {g : V → Bool} (rep : Represents s U c g) (j : Nat) :
    (∃ t : Tree I, t.depth ≤ j ∧ Solves s U t) ↔
      Phi g (histogram c U) (signalSpace (histogram c U)) 0 ≤ j := by
  rw [← optimal_depth_eq_phi two c g U 0]
  have eq (t : Tree I) : Solves s U t ↔ Correct c g U 0 t := by
    constructor
    · intro h a ha
      have iff := (h a ha).trans (rep a ha)
      simpa only [zero_add] using (Bool.eq_iff_iff.mpr iff)
    · intro h a ha
      rw [h a ha,zero_add]
      exact (rep a ha).symm
  constructor
  · rintro ⟨t,hd,ok⟩
    exact (depth_min ((eq t).1 ok)).trans hd
  · intro ub
    obtain ⟨t,hd,ok⟩ := depth_spec c g U 0
    exact ⟨t,hd.trans ub,(eq t).2 ok⟩

def unitColumn (i j : I) : ZMod 2 := if i=j then 1 else 0

theorem sum_unit (a : Finset I) (j : I) :
    (∑ i ∈ a, unitColumn i) j = if j ∈ a then 1 else 0 := by
  classical
  rw [Finset.sum_apply]
  simp [unitColumn]

/-- Every template admits a representation, regardless of its wiring, by
keeping the original setting bits as signals. -/
theorem identity_rep (s : Template I X) (U : Finset I) :
    ∃ g : (I → ZMod 2) → Bool, Represents s U unitColumn g := by
  classical
  refine ⟨fun x => decide (Agrees s (U.filter (fun i => x i=1))),?_⟩
  intro a ha
  simp only [decide_eq_true_eq]
  have eq : U.filter (fun i => (∑ j ∈ a, unitColumn j) i=1) = a := by
    ext i
    rw [Finset.mem_filter,sum_unit]
    by_cases h : i ∈ a
    · simp [h,ha h]
    · simp [h]
  rw [eq]

end TemplateDepth
