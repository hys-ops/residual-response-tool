import Mathlib.Algebra.MvPolynomial.SchwartzZippel
import Mathlib.Tactic.Ring
import Mathlib.Tactic.Linarith
import Mathlib.Data.ZMod.Basic

namespace FBDD
/-- A topologically indexed DAG. Index zero is the newest gate. Both outgoing
pointers address earlier gates; any number of later gates can share a child. -/
inductive Net (V : Type) : Nat → Type where
  | empty : Net V 0
  | leaf : Net V m → Bool → Net V (m+1)
  | gate : Net V m → V → Fin m → Fin m → Net V (m+1)

def Net.val {V F : Type} [CommRing F] (x : V → F) :
    {m : Nat} → Net V m → Fin m → F
  | _, .empty => Fin.elim0
  | _, .leaf d b => Fin.cases (if b then 1 else 0) (d.val x)
  | _, .gate d i l h =>
    let v := d.val x
    Fin.cases (v l + x i * (v h - v l)) v

def Net.boolVal {V : Type} (x : V → Bool) : {m : Nat} → Net V m → Fin m → Bool
  | _, .empty => Fin.elim0
  | _, .leaf d b => Fin.cases b (d.boolVal x)
  | _, .gate d i l h =>
    let v := d.boolVal x
    Fin.cases (if x i then v h else v l) v

def bit {F : Type} [Zero F] [One F] (b : Bool) : F := if b then 1 else 0

theorem Net.val_bit {V F : Type} [CommRing F] {m} (d : Net V m) (x : V → Bool)
    (r : Fin m) : d.val (fun i => bit (F := F) (x i)) r = bit (d.boolVal x r) := by
  induction d with
  | empty => exact Fin.elim0 r
  | leaf d b ih => refine Fin.cases ?_ (fun j => ih j) r; rfl
  | gate d i l h ih =>
    refine Fin.cases ?_ (fun j => ih j) r
    cases e : x i <;> simp [Net.val, Net.boolVal, bit, e] <;> first | exact ih l | exact ih h

def Net.uses {V : Type} (i : V) : {m : Nat} → Net V m → Fin m → Prop
  | _, .empty => Fin.elim0
  | _, .leaf d _ => Fin.cases False (d.uses i)
  | _, .gate d j l h => Fin.cases (j = i ∨ d.uses i l ∨ d.uses i h) (d.uses i)

/-- The queried name can never occur again below that gate, on either edge. -/
def Net.free {V : Type} : {m : Nat} → Net V m → Prop
  | _, .empty => True
  | _, .leaf d _ => d.free
  | _, .gate d i l h => d.free ∧ ¬d.uses i l ∧ ¬d.uses i h

theorem Net.val_congr {V F : Type} [CommRing F] {m} (d : Net V m) (r : Fin m)
    (x y : V → F) (h : ∀ i, d.uses i r → x i = y i) : d.val x r = d.val y r := by
  induction d with
  | empty => exact Fin.elim0 r
  | leaf d b ih =>
    revert h
    refine Fin.cases ?_ (fun j hj => ih j hj) r
    intro; rfl
  | gate d i l u ih =>
    revert h
    refine Fin.cases ?_ (fun j hj => ih j hj) r
    intro hj
    change d.val x l + x i * (d.val x u - d.val x l) = _
    rw [ih l (fun v hv => hj v (Or.inr (Or.inl hv))),
        ih u (fun v hv => hj v (Or.inr (Or.inr hv))), hj i (Or.inl rfl)]
    rfl

def AffineAt {V F : Type} [DecidableEq V] [CommRing F] (f : (V → F) → F) (i : V) :=
  ∀ x, f x = (1-x i)*f (Function.update x i 0) + x i*f (Function.update x i 1)

theorem Net.affine {V F : Type} [DecidableEq V] [CommRing F] {m} (d : Net V m)
    (hf : d.free) (r : Fin m) (i : V) : AffineAt (F := F) (fun x => d.val x r) i := by
  induction d with
  | empty => exact Fin.elim0 r
  | leaf d b ih =>
    refine Fin.cases ?_ (fun j => ih hf j) r
    intro x
    simp only [Net.val, Fin.cases_zero]
    ring
  | gate d j l u ih =>
    refine Fin.cases ?_ (fun q => ih hf.1 q) r
    intro x
    simp only [Net.val, Fin.cases_zero]
    by_cases e : j = i
    · subst j
      have fixChild (q : _) (hq : ¬d.uses i q) (a : F) :
          d.val (Function.update x i a) q = d.val x q := by
        apply d.val_congr
        intro v hv
        apply Function.update_of_ne
        rintro rfl; exact hq hv
      simp [Function.update_self, fixChild l hf.2.1, fixChild u hf.2.2]
      ring
    · have hl := ih hf.1 l x
      have hu := ih hf.1 u x
      simp only [Function.update_of_ne e]
      change d.val x l = _ at hl
      change d.val x u = _ at hu
      rw [hl, hu]
      ring
end FBDD
