import TemplateDepth.Invariance
import TemplateDepth.Templates
import TemplateDepth.Copies
import TemplateDepth.MaxCut
import TemplateDepth.Prediction

#print axioms TemplateDepth.optimal_depth_eq_phi
#print axioms TemplateDepth.template_exact
#print axioms TemplateDepth.identity_rep
#print axioms TemplateDepth.phi_bellman
#print axioms TemplateDepth.phi_constant
#print axioms TemplateDepth.same_histogram_same_depth
#print axioms TemplateDepth.phi_coset
#print axioms TemplateDepth.first_drop
#print axioms TemplateDepth.physical_to_phases
#print axioms TemplateDepth.phases_to_physical
#print axioms TemplateDepth.ordinary_iff
#print axioms TemplateDepth.phi_scale
#print axioms TemplateDepth.Selector.physical_selector_depth
#print axioms TemplateDepth.Selector.physical_7000
#print axioms TemplateDepth.Graph.edge_crosses
#print axioms TemplateDepth.Graph.graph_optimal
#print axioms TemplateDepth.Prediction.three_bit_depth
#print axioms TemplateDepth.Prediction.selector_semantics
