# An exact recurrence for the optimal query depth of FBDD templates

Working manuscript, 24 November 2026. The editable paper is in paper/. The Lean project is in lean/. The Python implementations and their original Korean README are in reference/.

## Typeset the paper

In paper/ run the following with a standard TeX Live installation.

    pdflatex -halt-on-error FBDD_Template_Query_Depth.tex
    pdflatex -halt-on-error FBDD_Template_Query_Depth.tex

## Reproduce the Lean verification

Use Lean 4.19.0, mathlib v4.19.0, and Python 3. From lean/ run

    lake update
    lake exe cache get
    python3 scripts/verify.py

The verifier rebuilds all local sources in an empty temporary directory. The top-level module audits 18 named declarations. verification.txt is the actual clean-run transcript. If the tagged mathlib is already compiled, MATHLIB_LEAN_PATH may instead be a path list of its compiled library and all compiled dependencies, and LEAN_BIN may be the absolute path of the matching Lean executable. Both procedures rebuild every included project module. The exact seven-bit calculation is kernel-checked and can be the slowest step.

## Find a result

| Question | File in lean/TemplateDepth/ | Declaration |
| --- | --- | --- |
| What is an ordinary tree and how are repeated queries handled? | Trees.lean | ordinary_iff, prune |
| Why may one postpone partially read bits? | Normalize.lean | first_drop, physical_to_phases, phases_to_physical |
| Does the table give the exact minimum among all physical trees? | Value.lean | optimal_depth_eq_phi, phi_bellman |
| May distributions of identical columns replace physical labels? | Invariance.lean | same_histogram_same_depth, phi_coset |
| How does the statement specialize to filled free DAGs? | Templates.lean | template_exact, identity_rep |
| Why is the 7,000-bit selector optimal at 6,000? | Selector.lean, Copies.lean | base_depth, physical_selector_depth, physical_7000 |
| Is the graph strategy always optimal? | GraphParity.lean, MaxCut.lean | odd_edges, edge_crosses, graph_optimal |
| What do the three setting bits certify? | Prediction.lean | three_bit_depth, selector_semantics |

Declarations start in namespace TemplateDepth. The selector, graph, and prediction declarations also use the Selector, Graph, and Prediction namespaces respectively. A correct tree's depth counts individual setting queries. Subgroup membership and the minimum in Phi are classical mathematical definitions. The equality of that minimum with the affine Bellman equation and with unrestricted physical-tree optimal depth is kernel-verified.

## Prior code and scope

One of the eighteen modules, FBDD/Diagram.lean, is byte-identical to the first paper's module (SHA-256 51a80035e8d46f6f67ad3e3f2fb4df9023c0cffb7b7c39c0ef2339a3e94b8202). The other seventeen include the new proof sources and the aggregate module with the axiom audit. The earlier Python programs are provided unchanged.

The predicate interpretation of individual templates is part of template_exact through an explicit Represents hypothesis. identity_rep proves that a unit-column representation always exists. Specific raw wiring extraction, its time bound, the bit-time cost of the affine-state enumeration, and the explicit sizes of the reductions are written arguments. The formal graph theorem establishes the strategy and depth for the graph predicate itself. Section 6 of the paper specifies the boundaries.

## Reproduce the independent computations

Use Python 3 in reference/. These scripts require only the standard library.

    python3 check.py
    python3 extract.py
    python3 check_raw.py
    python3 wiring.py

Expected results include 121,856 exhaustive comparisons with physical-bit decision-tree search, 500 random comparisons, the exact value 6,000 for the 7,000-bit selector, and 160 raw FBDD pairs checked. The raw selector extractor visits 51 affine states.
